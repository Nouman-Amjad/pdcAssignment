/*
        Your Name: Muhammad Moiz Ansari
        Your Section: BS(CS)-F
        Your Roll#: 23i-0523
        Instructor: Ms. Marium Hida
        TA Name: Ariyaan
        Assignment # 3
*/

#pragma once
#include <iostream>
#include <string>
using namespace std;



///////////////////////////
//                       //
//          ALU          //
//                       //
///////////////////////////

class ALU
{
private:
    int NoOfAdders;
    int NoOfSubtractor;
    int NoOfRegisters;
    int sizeOfRegisters;

public:
    //Constructors:
    ALU();
    ALU(int regsize, string archtype);

    //Setters:
    void setAdders(int add);
    void setSubtractor(int sub);
    void setRegisters(int reg);
    void setSizeofRegisters(int size);

    //Getters:
    int getAdders();
    int getSubtractor();
    int getRegisters();
    int getSizeofRegisters();
};

////////////////////////////////////
//                                //
//          Control Unit          //
//                                //
////////////////////////////////////

class ControlUnit
{
private:
    float clock;

public:
    //Constructors:
    ControlUnit();
    ControlUnit(int regsize);

    //Setters:
    void setClock(float c);

    //Getters:
    float getClock();
};

////////////////////////////////////
//                                //
//          Graphic Card          //
//                                //
////////////////////////////////////

class GraphicCard
{
protected:
    string brand;
    int memorySize;
    double price;

public:
    //Constructors:
    GraphicCard();
    GraphicCard(string b, int ms, double p);

    //Setters:
    void setBrand(string b);
    void setMemorySize(int ms);
    void setPrice(double p);

    //Getters:
    string getBrand();
    int getMemorySize();
    double getPrice();
};

class GC_MAC : public GraphicCard
{
private:
    string type = "Apple GPU";

public:
    GC_MAC();
};

class GC_Windows : public GraphicCard
{
private:
    string type,
        * types = new string[2]{ "Nvidia","AMD" };

public:
    GC_Windows();
};

////////////////////////////////////
//                                //
//          Network Card          //
//                                //
////////////////////////////////////

class NetworkCard
{
private:
    string type, * nctypes = NULL;
    int speed;
    double price;

public:
    // Constructors
    NetworkCard();
    NetworkCard(string t, int s, double p);

    // Setters
    void setType(string t);
    void setSpeed(int s);
    void setPrice(double p);

    // Getters
    string getType();
    int getSpeed();
    double getPrice();
    string getNcType(int ind);

    // Destructor
    ~NetworkCard();
};

//////////////////////////////////////
//                                  //
//          Storage Device          //
//                                  //
//////////////////////////////////////

class StorageDevice
{
private:
    string type,
        * sdtypes = NULL;
    int capacity;   //Unit: Gb
    double price;

    int num_of_sd;

public:
    // Constructors
    StorageDevice();
    StorageDevice(string t, int cap, double p, int nos);

    // Setters
    void setType(string t);
    void setCapacity(int cap);
    void setPrice(double p);
    void setNumOfSD(int nos);

    // Getters
    string getType();
    int getCapacity();
    double getPrice();
    int getNumOfSD();

    // Destructor
    ~StorageDevice();
};

///////////////////////////////
//                           //
//            CPU            //
//                           //
///////////////////////////////

//CPU
class CPU
{
protected:
    ALU alu;
    ControlUnit cu;

    string ArchType;
    string ArchSize;
    double price;
    string ProcessorType="";
    string AS1 = "32-bit";
    string AS2 = "64-bit";

public:
    //Constructors:
    CPU();
    CPU(int regsize, double p);

    //Setters:
    void setRegisters(int reg);
    void setSizeofRegisters(int size);
    void setClock(float c);
    void setCPU(string str);
    void setArchSize(string str);
    void setPrice(double p);

    //Getters:
    int getAdders();
    int getSubtractor();
    int getRegisters();
    int getSizeofRegisters();
    float getClock();
    CPU getCPU();
    string getArchType();
    string getArchSize();
    double getPrice();
};

////////// Intel/AMD //////////
class Intel_AMD_CPU : public CPU
{
protected:
    bool selected;
    string* processortypes;

public:
    Intel_AMD_CPU();
    
    void setSelected(bool b);
    void setProcessorType(int index);

    bool getSelected();
    string getProcessorTypes(int index);
    string getProcessorType();
};

//////////// Apple ////////////
class Apple_CPU : public CPU
{
protected:
    bool selected;
    string* processortypes;

public:
    Apple_CPU();

    void setSelected(bool b);
    void setProcessorType(int index);
    
    bool getSelected();
    string getProcessorTypes(int index);
    string getProcessorType();
};

///////////////////////////////////
//                               //
//          Main Memory          //
//                               //
///////////////////////////////////

class MainMemory
{
private:
    int capacity;
    string technologyType,
        * techtype = new string[2]{ "Semiconductor" ,"Silicon" },
        PhyMemType,
        * pm_types = new string[2]{ "DDR4/5", "LPDDR4/5" };
    double price;

public:
    //Constructors:
    MainMemory();
    MainMemory(int cap, string tech, double p);

    //Setters:
    void setCapacity(int cap);
    void setTechnologyType(string tech);
    void setTechnologyType(int index);
    void setPhyMemType(string tech);
    void setPhyMemType(int index);
    void setPrice(double p);

    //Getters:
    int getCapacity();
    string getTechnologyType();
    string getPhyMemType();
    double getPrice();
};

////////////////////////////
//                        //
//          Port          //
//                        //
////////////////////////////

class Port
{
private:
    string type,    //                1              2              3           4             5             6            7
        * p_type = new string[7]{ "VGI Port", "Charging Port", "USB Port", "HDMI Port", "USB-C Port", "AUDIO Port", "LAN Port" };
    int baud_rate,
        * p_baudrate = new int[7] {0, 0, 5, 18, 5, 0, 3};   //Unit: Gbps

public:
    //Constructors:
    Port();
    Port(string t, int rate);

    //Setters:
    void setType(string t);
    void setType(int index);
    void setBaudRate(int rate);


    //Getters:
    string getType();
    string getP_Type(int ind);
    int getBaudRate();
    int getP_BaudRate(int index);
};

///////////////////////////////////
//                               //
//         Mother Board          //
//                               //
///////////////////////////////////

class MotherBoard
{
private:
    MainMemory* mm;
    int num_of_ports;
    double price;
    Port* ports;
    //                                   1              2              3           4             5             6            7
    string* p_type = new string[7]{ "VGI Port", "Charging Port", "USB Port", "HDMI Port", "USB-C Port", "AUDIO Port", "LAN Port" };
    int* p_baudrate = new int[7] {0, 0, 5, 18, 5, 0, 3};   //Unit: Gbps

public:
    //Constructors:
    MotherBoard();
    MotherBoard(MainMemory M, int p_n);

    //Setters:
    void setMotherBoard(MainMemory M, int p_n);
    void setMainMemory(MainMemory M);
    void setNumOfPorts(int n);
    void setPorts(int ind, int br, int type);
    void setPorts(int ind, int br, string str);
    void setPrice(double p);

    //Getters:
    MainMemory getMainMemory();
    int getMainMemoryCapacity();
    string getMainMemoryType();
    string getMainMemoryPhyType();
    int getNumOfPorts();
    string getPortType(int ind);
    int getPortBaudRate(int ind);
    double getPrice();
    string getP_Types(int ind);
    int getP_BaudRates(int ind);
};

///////////////////////////////////////
//                                   //
//          Physical Memory          //
//                                   //
///////////////////////////////////////

class PhysicalMemory
{
private:
    int capacity;

public:
    //Constructors:
    PhysicalMemory();
    PhysicalMemory(int cap);

    //Setters:
    void setCapacity(int cap);

    //Getters:
    int getCapacity();
};

////////////////////////////////////
//                                //
//          Power Supply          //
//                                //
////////////////////////////////////

class PowerSupply
{
private:
    int wattage;
    string efficiencyRating,
        * effrating = new string[3]{ "80 Plus Bronze", "80 Plus Gold", "80 Plus Platinum" };
    double price;

public:
    //Constructors:
    PowerSupply();
    PowerSupply(int watt, int effrat, double price);

    //Setters:
    void setWattage(int watt);
    void setEfficiencyRating(int effrat);
    void setPrice(double p);

    //Getters:
    int getWattage();
    string getEfficiencyRating();
    string getEfficiencyRating(int index);
    double getPrice();
};

///////////////////////////////
//                           //
//          Battery          //
//                           //
///////////////////////////////

class Battery
{
private:
    int Capacity;
    double price;

public:
    //Constructors:
    Battery();
    Battery(int cap, double p);

    //Setters:
    void setCapacity(int cap);
    void setPrice(double p);

    //Getters:
    int getCapacity();
    double getPrice();
};

///////////////////////////
//                       //
//         Case          //
//                       //
///////////////////////////

class Case
{
private:
    string formFactor, color,
        * case_ffac = new string[3 + 3]{
                                        "ATX", "Micro ATX", "Mini ITX",  //For PC
                                        "Traditional Laptop", "Gaming Laptop", "Ultrabook" //For Laptop
    },
        * colors = new string[5]{ "Black", "Grey", "White", "Silver", "Gold" };
    double price;

public:
    //Constructors:
    Case();
    Case(int ffac, int col);

    //Setters:
    void setFormFactor(int ffac);
    void setColor(int col);
    void setPrice(float p);

    //Getters:
    string getFormFactor();
    string getFormFactor(int ind);
    string getColor();
    string getColor(int ind);
    double getPrice();
};

///////////////////////////////////
//                               //
//          Outer Parts          //
//                               //
///////////////////////////////////

class OuterParts
{
private:
    PowerSupply* ptrpowersupply;
    Battery* bat;
    Case* c;

public:
    // Constructors
    OuterParts();
    OuterParts(PowerSupply& ps, Battery& b, Case& ca);

    // Setters
    void setPowerSupply(PowerSupply& ps);
    void setBattery(Battery& b);
    void setCase(Case& ca);

    // Getters
    PowerSupply* getPowerSupply();
    Battery* getBattery();
    Case* getCase();

    // Destructor
    ~OuterParts();
};

////////////////////////////////
//                            //
//          Computer          //
//                            //
////////////////////////////////

class Computer
{
private:
    PhysicalMemory* pm;
    MotherBoard* mb;
    CPU* cpu;


public:
    // Constructors
    Computer();
    Computer(PhysicalMemory PM, MotherBoard MB, CPU CPU);

    // Setters
    void setComputer(PhysicalMemory PM, MotherBoard MB, CPU CPU);

    // Getters
    PhysicalMemory* getPhysicalMemory();
    MotherBoard* getMotherBoard();
    CPU* getCPU();
};




////////////////////////////////////////
//                                    //
//          Computer Assembly         //
//                                    //
////////////////////////////////////////

class ComputerAssembly
{
protected:
    string DeviceType;
    double price;

    PowerSupply powersupply;
    Battery battery;
    Case dev_case;
    NetworkCard networkcard;
    GraphicCard graphiccard;
    MainMemory mainmemory;
    StorageDevice storagedevice;
    PhysicalMemory physicalmemory;
    MotherBoard motherboard;
    OuterParts outerparts;
    Intel_AMD_CPU IAcpu;
    Apple_CPU Acpu;
    Computer computer;

public:
    const string* const devicetype = new string[4]{ "Laptop","PC","MAC_PC", "MAC_Laptop" };
    const string laptop = "Laptop", pc = "PC", maclaptop = "MAC_Laptop", macpc = "MAC_PC";
    //Constructor
    ComputerAssembly();
    ComputerAssembly(string devtype, double p);

    //Setter
    void setDeviceType(int compt);
    void setDeviceType(string str);
    void setPrice(int p);

    //Getter
    string getDeviceType();
    double getCompAssPrice();

    double getPowerSupplyPrice();
    double getBatteryPrice();
    double getCasePrice();
    double getNetworkCardPrice();
    double getGraphicCardPrice();
    double getMainMemoryPrice();
    double getStorageDevicePrice();
    double getMotherBoardPrice();
    double getIntel_AMDCPUPrice();
    double getApple_CPUPrice();


    //Functions
    void Display();
    
    //Addition:
    void addPowerSupply();
    void addBattery();
    void addCase();
    void addNetworkCard();
    void addGraphicCard();
    void addStorageDevice();
    void addMainMemory();
    void createPhysicalMemory();
    void createComputer(int);
    void createOuterParts();
    void createCPU(int);
    void createMotherBoard();

};



//////////////////////////////
//                          //
//          Device          //
//                          //
//////////////////////////////

class Device
{
protected:
    int CompType;
    ComputerAssembly* computerassptr;

public:
    Device();

    int getCompType();
    ComputerAssembly& getComputerAssembly();

    int selectcomp();
};

//////////////////////////////
//                          //
//          Laptop          //
//                          //
//////////////////////////////

class Laptop : public Device
{
private:
    ComputerAssembly computerassembly;

public:
    Laptop();
};

//////////////////////////
//                      //
//          PC          //
//                      //
//////////////////////////

class PC : public Device
{
private:
    ComputerAssembly computerassembly;

public:
    PC();
};

//////////////////////////////
//                          //
//          MAC_PC          //
//                          //
//////////////////////////////

class MAC_PC : public Device
{
private:
    ComputerAssembly computerassembly;

public:
    MAC_PC();
};

//////////////////////////////////
//                              //
//          MAC_Laptop          //
//                              //
//////////////////////////////////

class MAC_Laptop : public Device
{
private:
    ComputerAssembly computerassembly;

public:
    MAC_Laptop();
};
