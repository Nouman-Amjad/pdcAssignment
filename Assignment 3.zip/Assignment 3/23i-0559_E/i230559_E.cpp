/*
	Name: Ruhab Ahmad
	Roll Number: 23I-0559
	Section: E
	Instructor Name: Marium Hida
	Teacher Assistant: Muhammad Ali Naveed
*/

#include <iostream>
#include <string>
#include "D:\FAST\Semester 2\OOP\Assignments\Assignment 3\i230559_E.h"
using namespace std;

int main()
{
	int choice = 0;
	cout << "Welcome to Computer Assembly program!" << endl;
	cout << "What type of Computer do you want to build? (Choose 1,2 or 3)" << endl;
	cout << "1. Macbook (Mac), 2. Personal Computer (PC) or 3. Laptop" << endl;
	cin >> choice;

	while (choice != 1 && choice != 2 && choice != 3)
	{
		cout << "Invalid entry, enter again!" << endl;
		cin >> choice;
	}

	ComputerAssembly assembly;

    int cpuBrand, cpuModel, adders, subtractors, registers, sizeOfRegisters;
    float clock;

    string caseFormFactor, caseColor;
    double casePrice = 0.0;

    int psuWattage = 0;
    string psuEfficiencyRating;
    float batteryCapacity = 0.0;

    int networkCardType, networkCardSpeed;

    int gpuBrand, gpuModel, gpuMemory;

    int ramCapacity;
    string storageType;
    int storageCapacity;

	// PC or Laptop
	if (choice == 2 || choice == 3)
	{
        cout << "CPU brand options: 1. Intel, 2. AMD. Enter 1 or 2!" << endl;
        cin >> cpuBrand;

        while (cpuBrand != 1 && cpuBrand != 2)
        {
            cout << "Invalid entry, enter again!" << endl;
            cin >> cpuBrand;
        }

        if (cpuBrand == 1)
        {
            cout << "CPU model options: 1. i3, 2. i5, 3. i7, 4. i9. Enter 1-4!";
            cin >> cpuModel;

            while (cpuModel != 1 && cpuModel != 2 && cpuModel != 3 && cpuModel != 4)
            {
                cout << "Invalid entry, enter again!" << endl;
                cin >> cpuModel;
            }
        }

        else if (cpuBrand == 2)
        {
            cout << "CPU model options: 1. Ryzen 3, 2. Ryzen 5, 3. Ryzen 7, 4. Ryzen 9. Enter 1-4!";
            cin >> cpuModel;

            while (cpuModel != 1 && cpuModel != 2 && cpuModel != 3 && cpuModel != 4)
            {
                cout << "Invalid entry, enter again!" << endl;
                cin >> cpuModel;
            }
        }

        cout << "CPU's number of adders: ";
        cin >> adders;
        cout << "CPU's number of subtractors: ";
        cin >> subtractors;
        cout << "CPU's number of registers: ";
        cin >> registers;
        cout << "CPU's size of registers: ";
        cin >> sizeOfRegisters;
        cout << "CU's Clock speed: ";
        cin >> clock;
        cout << endl;

        if (cpuBrand == 1) // Intel
        {
            if (cpuModel == 1) // i3
            {
                Intel intel("i3", adders, subtractors, registers, sizeOfRegisters, clock);
                MotherBoard mb(&intel);
                assembly.setMotherBoard(&mb);
            }

            if (cpuModel == 2) // i5
            {
                Intel intel("i5", adders, subtractors, registers, sizeOfRegisters, clock);
                MotherBoard mb(&intel);
                assembly.setMotherBoard(&mb);
            }

            if (cpuModel == 3) //i7
            {
                Intel intel("i7", adders, subtractors, registers, sizeOfRegisters, clock);
                MotherBoard mb(&intel);
                assembly.setMotherBoard(&mb);
            }

            if (cpuModel == 4) //i9
            {
                Intel intel("i9", adders, subtractors, registers, sizeOfRegisters, clock);
                MotherBoard mb(&intel);
                assembly.setMotherBoard(&mb);
            }
        }

        else if (cpuBrand == 2) // AMD
        {
            if (cpuModel == 1) // Ryzen 3
            {
                AMDCPU amd("Ryzen 3", adders, subtractors, registers, sizeOfRegisters, clock);
                MotherBoard mb(&amd);
                assembly.setMotherBoard(&mb);
            }

            if (cpuModel == 2) // Ryzen 5
            {
                AMDCPU amd("Ryzen 5", adders, subtractors, registers, sizeOfRegisters, clock);
                MotherBoard mb(&amd);
                assembly.setMotherBoard(&mb);
            }

            if (cpuModel == 3) // Ryzen 7
            {
                AMDCPU amd("Ryzen 7", adders, subtractors, registers, sizeOfRegisters, clock);
                MotherBoard mb(&amd);
                assembly.setMotherBoard(&mb);
            }

            if (cpuModel == 4) // Ryzen 9
            {
                AMDCPU amd("Ryzen 9", adders, subtractors, registers, sizeOfRegisters, clock);
                MotherBoard mb(&amd);
                assembly.setMotherBoard(&mb);
            }
        }

        // GPU SPECS
        cout << "GPU brand options: 1. Nvidia, 2. AMD. Enter 1 or 2!";
        cin >> gpuBrand;

        while (gpuBrand != 1 && gpuBrand != 2)
        {
            cout << "Invalid entry, enter again!" << endl;
            cin >> gpuBrand;
        }

        if (gpuBrand == 1) 
        {
            cout << "GPU model options: 1. RTX, 2. GTX. Enter 1 or 2!";
            cin >> gpuModel;

            while (gpuModel != 1 && gpuModel != 2)
            {
                cout << "Invalid entry, enter again!" << endl;
                cin >> gpuModel;
            }

            cout << "Enter GPU memory capacity (in gb): ";
            cin >> gpuMemory;

            if (gpuModel == 1)
            {
                Nvidia nvidia("RTX", gpuMemory, gpuMemory * 30);
                MotherBoard* mb = assembly.getMotherBoard();
                mb->nvidia = &nvidia;
            }

            else if (gpuModel == 2)
            {
                Nvidia nvidia("GTX", gpuMemory, gpuMemory * 30);
                MotherBoard* mb = assembly.getMotherBoard();
                mb->nvidia = &nvidia;
            }
        }

        else if (gpuBrand == 2)
        {
            cout << "GPU model options: 1. Radeon, 2. Radeon RX. Enter 1 or 2!";
            cin >> gpuModel;

            while (gpuModel != 1 && gpuModel != 2)
            {
                cout << "Invalid entry, enter again!" << endl;
                cin >> gpuModel;
            }

            cout << "Enter GPU memory capacity (in gb): ";
            cin >> gpuMemory;
            cout << endl;

            if (gpuModel == 1)
            {
                AMDGPU amdgpu("Radeon", gpuMemory, gpuMemory * 28);
                MotherBoard* mb = assembly.getMotherBoard();
                mb->amdgpu = &amdgpu;
            }

            else if (gpuModel == 2)
            {
                AMDGPU amdgpu("Radeon RX", gpuMemory, gpuMemory * 28);
                MotherBoard* mb = assembly.getMotherBoard();
                mb->amdgpu = &amdgpu;
            }
        }

        // MEMORY.
        cout << "Enter RAM capacity (in gb): ";
        cin >> ramCapacity;

        while (ramCapacity % 4 != 0 || ramCapacity < 4)
        {
            cout << "Invalid RAM, Enter again!";
            cin >> ramCapacity;
        }

        cout << "Enter storage type (HDD or SSD): ";
        cin >> storageType;

        cout << "Enter storage capacity (in GB): ";
        cin >> storageCapacity;

        while (storageCapacity % 128 != 0 && storageCapacity < 128)
        {
            cout << "Invalid capacity, Enter again!";
            cin >> storageCapacity;
        }

        cout << endl;

        PhysicalMemory ram(ramCapacity);
        MotherBoard* mb = assembly.getMotherBoard();
        mb->pm = &ram;

        StorageDevice storage(storageType, storageCapacity, storageCapacity * 0.2);
        mb->storage = &storage;

        // NETWORK CARD.
        cout << "Enter the network card type (1. Wifi or 2. ethernet): ";
        cin >> networkCardType;

        while (networkCardType != 1 && networkCardType != 2)
        {
            cout << "Invalid entry, Enter again!";
            cin >> networkCardType;
        }

        cout << "Enter network card speed: ";
        cin >> networkCardSpeed;
        cout << endl;

        if (networkCardType == 1)
        {
            NetworkCard nc("Wi-fi", networkCardSpeed, networkCardSpeed * 0.05);
            mb->nc = &nc;
        }

        else if (networkCardType == 2)
        {
            NetworkCard nc("Ethernet", networkCardSpeed, networkCardSpeed * 0.1);
            mb->nc = &nc;
        }

        if (choice == 3) // Laptop
        {
            cout << "Enter the battery capacity in mAh: ";
            cin >> batteryCapacity;
            cout << endl;

            Battery battery(batteryCapacity, batteryCapacity * 0.005);
            mb->battery = &battery;
        }

        //Battery
        else if (choice == 2) //PC
        {
            cout << "Enter the power supply wattage: ";
            cin >> psuWattage;
            cin.ignore();

            cout << "Enter the power supply efficiency rating: ";
            getline(cin, psuEfficiencyRating);
            cout << endl;

            PowerSupply psu(psuWattage, psuEfficiencyRating, psuWattage * 0.2);
            mb->psu = &psu;
        }

        if (choice == 2) 
        {
            // PORTS
            const int numOfPorts = 4;
            Port ports[numOfPorts];
            string type;
            int baudRate;
            for (int i = 0; i < numOfPorts; i++) 
            {
                cout << "Enter type of port " << i + 1 << ": ";
                cin >> type;
                cout << "Enter baud rate of port " << i + 1 << ": ";
                cin >> baudRate;

                ports[i].setType(type);
                ports[i].setBaudRate(baudRate);
            }

            cout << endl;

            for (int i = 0; i < numOfPorts; i++) 
            {
                mb->ports[i] = ports[i];
            }
        }

        // CASE SPECS.
        if (choice == 2) // PC
        { 
            cout << "Case Form factor: ";
            cin >> caseFormFactor;
            cout << "Case Color: ";
            cin >> caseColor;
            cout << "Case Price: ";
            cin >> casePrice;
            cout << endl;

            Case pcCase(caseFormFactor, caseColor, casePrice);
            assembly.setCase(&pcCase);
            assembly.addCasePrice(true);
        }
	}

	// MAC
    else if (choice == 1)
    {
        // Input for Mac specs
        cout << "Number of adders: ";
        cin >> adders;
        cout << "Number of subtractors: ";
        cin >> subtractors;
        cout << "Number of registers: ";
        cin >> registers;
        cout << "Size of registers: ";
        cin >> sizeOfRegisters;

        cout << "Clock speed: ";
        cin >> clock;
        cout << endl;

        // Create Mac components
        AppleSilicon appleSilicon("Apple Silicon", adders, subtractors, registers, sizeOfRegisters, clock); // Set default model
        MotherBoard mb(&appleSilicon);
        assembly.setMotherBoard(&mb);

        MotherBoard* mbPtr = assembly.getMotherBoard();

        // GPU SPECS
        string gpuModel;
        cout << "Enter GPU model: ";
        cin >> gpuModel;
        cout << endl;

        cout << "Enter GPU memory capacity (in gb): ";
        cin >> gpuMemory;
        cout << endl;

        AppleGPU applegpu(gpuModel, gpuMemory);
        (*mbPtr).applegpu = &applegpu;

        // MEMORY
        cout << "Enter RAM capacity (in gb): ";
        cin >> ramCapacity;
        cout << "Enter storage device type (HDD or SSD): ";
        cin >> storageType;
        cout << "Enter storage device capacity (in gb): ";
        cin >> storageCapacity;
        cout << endl;

        PhysicalMemory ram(ramCapacity);
        (*mbPtr).pm = &ram;

        StorageDevice storage(storageType, storageCapacity, storageCapacity * 0.1);
        (*mbPtr).storage = &storage;

        // NETWORK CARD.
        cout << "Enter network card type (1. Wifi, 2. Ethernet): ";
        cin >> networkCardType;
        cout << "Enter network card speed: ";
        cin >> networkCardSpeed;
        cout << endl;

        if (networkCardType == 1)
        {
            NetworkCard nc("Wifi", networkCardSpeed, networkCardSpeed * 0.1);
            (*mbPtr).nc = &nc;
        }
        
        else if (networkCardType == 2)
        {
            NetworkCard nc("Ethernet", networkCardSpeed, networkCardSpeed * 0.1);
            (*mbPtr).nc = &nc;
        }

        cout << "Enter battery capacity (mAh): ";
        cin >> batteryCapacity;
        cout << endl;

        Battery battery(batteryCapacity, batteryCapacity * 0.005);
        (*mbPtr).battery = &battery;
    }

    // calculate and display total price.
    double totalPrice = 0;

    totalPrice = totalPrice + (networkCardSpeed * 0.1); // assuming network card price is $0.1 per Mbps.
    totalPrice = totalPrice + (ramCapacity * 5); // assuming RAM price is $5 per GB.
    totalPrice = totalPrice + (clock * 30) + (registers * 10);
    totalPrice = totalPrice + gpuMemory * 30;
    totalPrice = totalPrice + (storageCapacity * 0.1); // assuming storage price is $0.1 per GB.
   
    if (choice == 2) //PC
    {
        totalPrice = totalPrice + casePrice;
        totalPrice = totalPrice + (psuWattage * 0.2); // assuming PSU price is $0.2
    }

    if (choice == 1 || choice == 3) //Laptop/Mac
    {
        totalPrice = totalPrice + (batteryCapacity * 0.1); // assuming battery price is $0.1 per mAh.
    }

    cout << "Total price of computer: $" << totalPrice << endl;
    cout << endl;

    cout << "Network card price: $" << (networkCardSpeed * 0.1) << endl;
    cout << "CPU price: $" << (clock * 20) + (registers * 5) << endl;
    cout << "GPU price: $" << gpuMemory * 30 << endl;
    cout << "RAM price: $" << (ramCapacity * 10) << endl;
    cout << "Storage price: $" << (storageCapacity * 0.1) << endl;
    cout << "Case price: $" << (choice == 2 ? casePrice : 0) << endl;
    cout << "Power supply price: $" << (psuWattage * 0.2) << endl;
    cout << "Battery price: $" << (batteryCapacity * 0.1) << endl;
    
    return 0;
}