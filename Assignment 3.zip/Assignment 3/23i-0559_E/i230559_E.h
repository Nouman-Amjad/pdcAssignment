/*
	Name: Ruhab Ahmad
	Roll Number: 23I-0559
	Section: E
	Instructor Name: Marium Hida
	Teacher Assistant: Muhammad Ali Naveed
*/
#pragma once

#include <iostream>
using namespace std;

class ALU
{
private:
	int NoOfAdders;
	int NoOfSubtractor;
	int NoOfRegisters;
	int sizeOfRegisters;

public:
	ALU()
	{
		NoOfAdders = 0;
		NoOfSubtractor = 0;
		NoOfRegisters = 0;
		sizeOfRegisters = 0;
	}

	ALU(int a, int s, int r, int size)
	{
		NoOfAdders = a;
		NoOfSubtractor = s;
		NoOfRegisters = r;
		sizeOfRegisters = size;
	}

	void setNoOfAdders(int a)
	{
		NoOfAdders = a;
	}

	int getNoOfAdders()
	{
		return NoOfAdders;
	}

	void setNoOfSubtractor(int a)
	{
		NoOfSubtractor = a;
	}

	int getNoOfSubtractor()
	{
		return NoOfSubtractor;
	}

	void setNoOfRegisters(int a)
	{
		NoOfRegisters = a;
	}

	int getNoOfRegisters()
	{
		return NoOfRegisters;
	}

	void setsizeOfRegisters(int a)
	{
		sizeOfRegisters = a;
	}

	int getsizeOfRegisters()
	{
		return sizeOfRegisters;
	}
};

class ControlUnit
{
private:
	float clock;
public:
	ControlUnit()
	{
		clock = 0.0;
	}

	ControlUnit(float c)
	{
		clock = c;
	}

	void setClock(float a)
	{
		clock = a;
	}

	float getClock()
	{
		return clock;
	}
};

// CPU is composed of ALU and CU
class CPU
{
private:
	ALU alu;
	ControlUnit cu;

public:
	CPU()
	{
		alu.setNoOfAdders(0);
		alu.setNoOfRegisters(0);
		alu.setNoOfSubtractor(0);
		alu.setsizeOfRegisters(0);

		cu.setClock(0);
	}

	CPU(int a, int r, int s, int size, float c)
	{
		alu.setNoOfAdders(a);
		alu.setNoOfRegisters(r);
		alu.setNoOfSubtractor(s);
		alu.setsizeOfRegisters(size);

		cu.setClock(c);
	}

	void setALU(ALU inALU) 
	{
		alu = inALU;
	}

	ALU getALU() 
	{
		return alu;
	}

	void setCU(ControlUnit inCU) 
	{
		cu = inCU;
	}

	ControlUnit getCU() 
	{
		return cu;
	}

	double getPriceOfCPU()
	{
		double price = 0.0;
		double priceOfSimpleCPU = 10.0;
		double priceOfOneRegister = 10.0;
		double priceOfClockPerGHz = 10.0;

		price = priceOfSimpleCPU + (priceOfOneRegister * alu.getNoOfRegisters()) + (priceOfClockPerGHz * cu.getClock());
		return price;
	}
};

class Intel : public CPU 
{
private:
	string model;
	string architecture;

public:
	Intel()
	{
		model = "Core i3";
		architecture = "x86";

		CPU();
	}

	Intel(string str1, int a, int s, int r, int size, float c)
	{
		model = str1;
		CPU(a, s, r, size, c);
	}

	void setModel(string str) 
	{
		model = str;
	}

	string getModel()
	{
		return model;
	}

	void setArchitecture(string str)
	{
		architecture = str;
	}

	string getArchitecture() 
	{
		return architecture;
	}
};

class AMDCPU : public CPU 
{
private:
	string model;
	string architecture;

public:
	AMDCPU()
	{
		model = "Ryzen 3";
		architecture = "x86";

		CPU();
	}

	AMDCPU(string str1, int a, int s, int r, int size, float c)
	{
		model = str1;
		CPU(a, s, r, size, c);
	}

	void setModel(string str) 
	{
		model = str;
	}

	string getModel() 
	{
		return model;
	}

	void setArchitecture(string str)
	{
		model = str;
	}
	
	string getArchitecture() 
	{
		return architecture;
	}
};

class AppleSilicon : public CPU 
{
private:
	string model;
	string architecture;

public:
	AppleSilicon()
	{
		model = "M1";
		architecture = "ARM64";

		CPU();
	}

	AppleSilicon(string str1, int a, int s, int r, int size, float c)
	{
		model = str1;
		CPU(a, s, r, size, c);
	}

	void setModel(string str) 
	{
		model = str;
	}

	string getModel() 
	{
		return model;
	}

	void setArchitecture(string str)
	{
		architecture = str;
	}

	string getArchitecture() 
	{
		return architecture;
	}
};

class MainMemory
{
private:
	int capacity;
	string technologyType;

public:
	MainMemory()
	{
		capacity = 0;
		technologyType = "";
	}

	MainMemory(int c, string str)
	{
		capacity = c;
		technologyType = str;
	}

	void setCapacity(int a)
	{
		capacity = a;
	}

	int getCapacity()
	{
		return capacity;
	}

	void setTechnologyType(string str)
	{
		technologyType = str;
	}

	string getTechnologyType()
	{
		return technologyType;
	}
};

class Port
{
private:
	string type;
	int baud_rate;

public:
	Port()
	{
		baud_rate = 0;
		type = "";
	}

	Port(int r, string str)
	{
		baud_rate = r;
		type = str;
	}

	void setType(string str)
	{
		type = str;
	}

	string getType()
	{
		return type;
	}

	void setBaudRate(int a)
	{
		baud_rate = a;
	}

	int getBaudRate()
	{
		return baud_rate;
	}
};

class PhysicalMemory
{
private:
	int capacity;

public:
	PhysicalMemory()
	{
		capacity = 0;
	}

	PhysicalMemory(int c)
	{
		capacity = c;
	}

	void setCapacity(int c)
	{
		capacity = c;
	}

	int getCapacity()
	{
		return capacity;
	}
};

class DDR4 : public PhysicalMemory 
{
private:
	string type;

public:
	DDR4()
	{
		type = "DDR";
		PhysicalMemory();
	}
	
	DDR4(int c) : type("DDR"), PhysicalMemory(c) {}

	string getType() 
	{
		return type;
	}
};

class LPDDR4 : public PhysicalMemory 
{
private:
	string type;

public:
	LPDDR4()
	{
		type = "LDDR";
		PhysicalMemory();
	}
	LPDDR4(int c) : type("LDDR"), PhysicalMemory(c) {}

	string getType() 
	{
		return type;
	}
};

// Computer is aggregated with PhysicalMemory, CPU and MotherBoard
//class Computer
//{
//private:
//	PhysicalMemory* pm;
//	CPU* cpu;
//	MotherBoard* mb;
//
//public:
//	Computer(PhysicalMemory* p, CPU* c, MotherBoard* m)
//	{
//		pm = p;
//		cpu = c;
//		mb = m;
//	}
//
//	void setPhysicalMemory(PhysicalMemory* p)
//	{
//		pm = p;
//	}
//
//	PhysicalMemory* getPhysicalMemory()
//	{
//		return pm;
//	}
//
//	void setCPU(CPU* c)
//	{
//		cpu = c;
//	}
//
//	CPU* getCPU()
//	{
//		return cpu;
//	}
//
//	void setMotherBoard(MotherBoard* m)
//	{
//		mb = m;
//	}
//
//	MotherBoard* getMotherBoard()
//	{
//		return mb;
//	}
//
//	// Destructor to release dynamically allocated memory
//	~Computer()
//	{
//		delete pm;
//		delete cpu;
//		delete mb;
//	}
//};


class GraphicsCard
{
private:
	string brand;
	int memorySize;
	double price;

public:
	GraphicsCard()
	{
		brand = "Nvidia";
		memorySize = 4;
		price = 100.0;
	}

	GraphicsCard(string str, int s, double p)
	{
		brand = str;
		memorySize = s;
		price = p;
	}

	void setBrand(string str)
	{
		brand = str;
	}

	string getBrand()
	{
		return brand;
	}

	void setMemorySize(int s)
	{
		memorySize = s;
	}

	double getMemorySize()
	{
		return memorySize;
	}

	void setPrice(int p)
	{
		price = p;
	}

	double getPrice()
	{
		return price;
	}
};

class Nvidia : public GraphicsCard
{
private:
	string model;
	string type;

public:
	Nvidia()
	{
		model = "GTX 1050";
		type = "Discrete";

		GraphicsCard();
	}
	Nvidia(string str, int memory, double price)
	{
		model = str;
		GraphicsCard("Nvidia", memory, price);
	}

	void setModel(string str)
	{
		model = str;
	}

	string getModel() 
	{
		return model;
	}

	string getType()
	{
		return type;
	}
};

class AMDGPU : public GraphicsCard 
{
private:
	string model;
	string type;

public:
	AMDGPU()
	{
		model = "RX 570";
		type = "Discrete";

		GraphicsCard("AMD", 4, 200.0);
	}

	AMDGPU(string str, int memory, double price)
	{
		model = str;
		GraphicsCard("AMD", memory, price);
	}

	string getModel() 
	{
		return model;
	}

	void setModel(string str)
	{
		model = str;
	}

	string getType() 
	{
		return type;
	}
};

class AppleGPU : public GraphicsCard 
{
private:
	string model;
	string type;

public:
	AppleGPU()
	{
		model = "M1";
		type = "Integrated";
		GraphicsCard();
	}
	
	AppleGPU(string str, int memory)
	{
		model = str;
		type = "Integrated";
		GraphicsCard("Apple", memory, memory * 30);
	}

	void setModel(string str)
	{
		model = str;
	}

	string getModel() 
	{
		return model;
	}

	string getType() 
	{
		return type;
	}
};

class StorageDevice
{
private:
	string type;
	int capacity;
	double price;

public:
	StorageDevice()
	{
		type = "HDD";
		capacity = 256;
		price = 50.0;
	}

	StorageDevice(string str, int c, double p)
	{
		type = str;
		capacity = c;
		price = p;
	}

	void setType(string str)
	{
		type = str;
	}

	string getType()
	{
		return type;
	}

	void setCapacity(int c)
	{
		capacity = c;
	}

	int getCapacity()
	{
		return capacity;
	}

	void setPrice(int p)
	{
		price = p;
	}

	double getPrice()
	{
		return price;
	}
};

class NetworkCard
{
private:
	string type;
	int speed;
	double price;
public:
	NetworkCard()
	{
		type = "Ethernet";
		speed = 1000;
		price = 20.0;
	}

	NetworkCard(string str, int s, double p)
	{
		type = str;
		speed = s;
		price = p;
	}

	void setType(string str)
	{
		type = str;
	}

	string getType()
	{
		return type;
	}

	void setSpeed(int s)
	{
		speed = s;
	}

	int getSpeed()
	{
		return speed;
	}

	void setPrice(int p)
	{
		price = p;
	}

	double getPrice()
	{
		return price;
	}
};

class PowerSupply
{
private:
	int wattage;
	string efficiencyRating;
	double price;

public:
	PowerSupply()
	{
		wattage = 500;
		efficiencyRating = "80 plus bronze";
		price = 50.0;
	}

	PowerSupply(int w, string str, double p)
	{
		wattage = w;
		efficiencyRating = str;
		price = p;
	}

	void setWattage(int w)
	{
		wattage = w;
	}

	int getWattage()
	{
		return wattage;
	}

	void setEfficiencyRating(string str)
	{
		efficiencyRating = str;
	}

	string getEfficiencyRating()
	{
		return efficiencyRating;
	}

	void setPrice(int p)
	{
		price = p;
	}

	double getPrice()
	{
		return price;
	}
};

class Battery
{
private:
	int capacity;
	double price;
public:
	Battery()
	{
		capacity = 10000;
		price = 30.0;
	}

	Battery(int c, double p)
	{
		capacity = c;
		price = p;
	}

	void setCapacity(int c)
	{
		capacity = c;
	}

	int getCapacity()
	{
		return capacity;
	}

	void setPrice(double p)
	{
		price = p;
	}

	double getPrice()
	{
		return price;
	}
};

// Motherboard is composed of Ports
// Motherboard is aggregated with MainMemory
class MotherBoard
{
public:
	Intel* intelcpu;
	AMDCPU* amdcpu;
	AppleSilicon* applecpu;
	DDR4* ddr4;
	LPDDR4* lpddr4;
	Port ports[4];
	Nvidia* nvidia;
	AMDGPU* amdgpu;
	AppleGPU* applegpu;
	NetworkCard* nc;
	PowerSupply* psu;
	Battery* battery;
	PhysicalMemory* pm;
	StorageDevice* storage;

public:
	MotherBoard(Intel* _intel, Nvidia* _nvidia, PhysicalMemory* _pm, StorageDevice* _storage, Port _ports[], NetworkCard* _nc, PowerSupply* _psu, Battery* _battery)
		: intelcpu(_intel), nvidia(_nvidia), pm(_pm), storage(_storage), nc(_nc), psu(_psu), battery(_battery)
	{
		for (int i = 0; i < 4; ++i)
		{
			ports[i] = _ports[i];
		}
	}
	MotherBoard(Intel* _intel, AMDGPU* _amdgpu, PhysicalMemory* _pm, StorageDevice* _storage, Port _ports[], NetworkCard* _nc, PowerSupply* _psu, Battery* _battery)
		: intelcpu(_intel), amdgpu(_amdgpu), pm(_pm), storage(_storage), nc(_nc), psu(_psu), battery(_battery)
	{
		for (int i = 0; i < 4; ++i)
		{
			ports[i] = _ports[i];
		}
	}
	MotherBoard(AMDCPU* _amdcpu, Nvidia* _nvidia, PhysicalMemory* _pm, StorageDevice* _storage, Port _ports[], NetworkCard* _nc, PowerSupply* _psu, Battery* _battery)
		: amdcpu(_amdcpu), nvidia(_nvidia), pm(_pm), storage(_storage), nc(_nc), psu(_psu), battery(_battery)
	{
		for (int i = 0; i < 4; ++i)
		{
			ports[i] = _ports[i];
		}
	}
	MotherBoard(AMDCPU* _amdcpu, AMDGPU* _amdgpu, PhysicalMemory* _pm, StorageDevice* _storage, Port _ports[], NetworkCard* _nc, PowerSupply* _psu, Battery* _battery)
		: amdcpu(_amdcpu), amdgpu(_amdgpu), pm(_pm), storage(_storage), nc(_nc), psu(_psu), battery(_battery)
	{
		for (int i = 0; i < 4; ++i)
		{
			ports[i] = _ports[i];
		}
	}
	MotherBoard(AppleSilicon* _applecpu, AppleGPU* _applegpu, PhysicalMemory* _pm, StorageDevice* _storage, Port _ports[], NetworkCard* _nc, PowerSupply* _psu, Battery* _battery)
		: applecpu(_applecpu), applegpu(_applegpu), pm(_pm), storage(_storage), nc(_nc), psu(_psu), battery(_battery)
	{
		for (int i = 0; i < 4; ++i)
		{
			ports[i] = _ports[i];
		}
	}
	// Constructor for Intel CPU only
	MotherBoard(Intel* _intel)
		: intelcpu(_intel), nvidia(nullptr), amdcpu(nullptr), amdgpu(nullptr), applecpu(nullptr), applegpu(nullptr), pm(nullptr), storage(nullptr), nc(nullptr), psu(nullptr), battery(nullptr)
	{
		for (int i = 0; i < 4; ++i)
		{
			ports[i] = Port();
		}
	}

	// Constructor for AMD CPU only
	MotherBoard(AMDCPU* _amdcpu)
		: intelcpu(nullptr), nvidia(nullptr), amdcpu(_amdcpu), amdgpu(nullptr), applecpu(nullptr), applegpu(nullptr), pm(nullptr), storage(nullptr), nc(nullptr), psu(nullptr), battery(nullptr)
	{
		for (int i = 0; i < 4; ++i)
		{
			ports[i] = Port();
		}
	}

	// Constructor for AppleSilicon CPU only
	MotherBoard(AppleSilicon* _applecpu)
		: intelcpu(nullptr), nvidia(nullptr), amdcpu(nullptr), amdgpu(nullptr), applecpu(_applecpu), applegpu(nullptr), pm(nullptr), storage(nullptr), nc(nullptr), psu(nullptr), battery(nullptr)
	{
		for (int i = 0; i < 4; ++i)
		{
			ports[i] = Port();
		}
	}
};

class Case
{
private:
	string formFactor;
	string color;
	double price;

public:
	Case()
	{
		formFactor = "ATX";
		color = "Black";
		price = 30.0;
	}

	Case(string ff, string c, double p)
	{
		formFactor = ff;
		color = c;
		price = p;
	}

	void setformFactor(string str)
	{
		formFactor = str;
	}

	string getformFactor()
	{
		return formFactor;
	}

	void setColor(string str)
	{
		color = str;
	}

	string getColor()
	{
		return color;
	}

	void setPrice(double p)
	{
		price = p;
	}

	double getPrice()
	{
		return price;
	}
};

class ComputerAssembly
{
private:
	Case* computerCase;
	MotherBoard* motherBoard;
	double totalPrice;

public:
	ComputerAssembly()
	{
		totalPrice = 0;
	}

	ComputerAssembly(Case* _case, MotherBoard* _mb, double p)
	{
		computerCase = _case;
		motherBoard = _mb;
		totalPrice = p;
	}
	
	Case* getCase() 
	{ 
		return computerCase; 
	}

	void setCase(Case* Case) 
	{ 
		computerCase = Case; 
	}

	MotherBoard* getMotherBoard() 
	{ 
		return motherBoard; 
	}

	void setMotherBoard(MotherBoard* MB) 
	{ 
		motherBoard = MB; 
	}

	double getTotalPrice() 
	{ 
		return totalPrice; 
	}

	void setTotalPrice(double p)
	{
		totalPrice = p;

	}

	void addCasePrice(bool isPC)
	{
		if (isPC && computerCase != nullptr)
		{
			totalPrice += computerCase->getPrice();
		}
	}
};

