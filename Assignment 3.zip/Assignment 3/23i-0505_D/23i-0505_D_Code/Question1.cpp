#include <iostream>
#include "class_ALU.h"
#include "Inherited.h"
#include"abcd.h"
using namespace std;

/////////---------------------------------------------------------------------------------------------------------------///////////////

//Name: Abdullah Durrani
//Section : Cs - D
//Roll number : 23i - 0505
//Instructor : Sir Sheryar Rashid
//TA assignment : Rafay
//TA section: Zain

/////////---------------------------------------------------------------------------------------------------------------///////////////
// Function to gather input for CPU components

int main() {
    cout << "Enter what you want to make:" << endl;
    cout << "1. Press 1 for MAC" << endl;
    cout << "2. Press 2 for PC" << endl;

    int choice;
    cin >> choice;

    // Validate user input for computer type
    choice = validateComputerType(choice);

    // Create objects based on user's choice
    if (choice == 1) {
        // Create a MAC
        MAC mac;

        // Gather input for CPU components
        ALU aALU;
        ControlUnit aControlUnit;
        inputCPUComponents(aALU, aControlUnit);

        // Set CPU components for MAC
        mac.setALU(aALU);
        mac.setControlUnit(aControlUnit);

        // Additional steps for MAC setup if needed
    }
    else if (choice == 2) {
        // Create a PC
        PC pc;

        // Gather input for CPU components
        ALU aALU;
        ControlUnit aControlUnit;
        inputCPUComponents(aALU, aControlUnit);

        // Set CPU components for PC
        pc.setALU(aALU);
        pc.setControlUnit(aControlUnit);



        cout << "Enter the capacity of the main memory for your PC: ";
        int capacity;
        cin >> capacity;

        // Additional input validation if needed

        // Set the capacity of the main memory for the PC
        pc.setMainMemory(capacity);




        cout << "Enter the type of physical memory and  capacity of the physical memory for your PC: ";
        string type;

        cin >>type>> capacity;

        // Additional input validation if needed

        // Set the capacity of the main memory for the PC
        pc.setMainMemory(capacity);


        
      

        cout << "--------------This Model Comes with 7 ports design type of ports and specify baud rate " << endl;

        Port* port[7];
        for (int i = 0; i < 7; ++i)
        {
            string type;
            int baudRate;
            cout << "Enter port type and baud rate for port "<<i+1 << endl;
            cin >> type >> baudRate;
            port[i] = new Port(type, baudRate);

        }

     

            // Additional steps for PC setup if needed
    }




    

    return 0;
}
