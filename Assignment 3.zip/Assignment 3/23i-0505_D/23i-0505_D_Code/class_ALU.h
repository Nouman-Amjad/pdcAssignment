#pragma once
#include<cstring>
#include<string.h>
#include<string>
#include<iostream>
using namespace std;

void validation(string techonolgyType)
{

    //Checking input validation for techonolgyType except semiconductor and silicon 
    //Assign the values if values are found 
    if (techonolgyType == "Semiconductor" || techonolgyType == "semiconductor" || techonolgyType == "Silicon" || techonolgyType == "silicon")
        techonolgyType = techonolgyType;



    // Ask the user to re enter the assigned values 
    else
    {
        do {
            cout << "Enter your techonolgy type again the possible values only are silicon and semiconductors " << endl;

            cin >> techonolgyType;
            techonolgyType = techonolgyType;

        } while (techonolgyType != "Semiconductor" && techonolgyType != "semiconductor" && techonolgyType != "Silicon" && techonolgyType != "silicon");
    }

}


// Function to validate user input for computer type
int validateComputerType(int choice) {
    while (choice != 1 && choice != 2) {
        cout << "Invalid input. Please enter 1 for MAC or 2 for PC: ";
        cin >> choice;
    }
    return choice;
}

class ALU {

private:


    int numOfAdders, numOfSubtractors, numOfRegisters, sizeOfRegisters;

public:
    ALU()
    {
        numOfAdders = 0;
        numOfSubtractors = 0;
        numOfRegisters = 0;
        sizeOfRegisters = 0;
    }

    ALU(int numOfAdders, int numOfSubtractors, int numOfRegisters, int sizeOfRegisters)
    {
        this->numOfAdders = numOfAdders;
        this->numOfSubtractors = numOfSubtractors;
        this->numOfRegisters = numOfRegisters;
        this->sizeOfRegisters = sizeOfRegisters;
    }

    void setNumOfAdders(int numOfAdders)
    {
        this->numOfAdders = numOfAdders;
    }

    void setNumOfSubtractors(int numOfSubtractors)
    {
        this->numOfSubtractors = numOfSubtractors;
    }

    void setNumOfRegisters(int numOfRegisters)
    {
        this->numOfRegisters = numOfRegisters;
    }

    void setSizeOfRegisters(int sizeOfRegisters)
    {
        this->sizeOfRegisters = sizeOfRegisters;
    }


    int getNumOfAdders() const
    {
        return this->numOfAdders;
    }

    int getNumOfSubtractors() const
    {
        return this->numOfSubtractors;
    }

    int getNumOfRegisters() const
    {
        return this->numOfRegisters;
    }

    int getSizeOfRegisters() const
    {
        return  this->sizeOfRegisters;
    }


};

class ControlUnit {

private:
    float clock;
public:
    ControlUnit()
    {
        clock = 0;
    }
    ControlUnit(float clock)
    {
        this->clock = clock;
    }

    void setClock(int clock)
    {
        this->clock = clock;
    }

    float getClock() const
    {
        return this->clock;
    }
};

class CPU {
protected:
    ALU aALU;
    ControlUnit aControlUnit;


public:

    CPU() : aALU(), aControlUnit() {}

    CPU(ALU& aALU, ControlUnit& aControlUnit) : aALU(aALU), aControlUnit(aControlUnit) {}


    void setALU(const ALU& aALU)
    {
        //This  intializes the object ALU with the paramter object 
        this->aALU.setNumOfAdders(aALU.getNumOfAdders());
        this->aALU.setNumOfSubtractors(aALU.getNumOfSubtractors());
        this->aALU.setNumOfRegisters(aALU.getNumOfRegisters());
        this->aALU.setSizeOfRegisters(aALU.getSizeOfRegisters());
    }


    void setControlUnit(const ControlUnit& aControlUnit)
    {
        //This intiliazes the object controlunit with the parameter object

        this->aControlUnit.setClock(aControlUnit.getClock());
    }

    ALU getALU()
    {
        return this->aALU;
    }

    ControlUnit getControlUnit()
    {
        return this->aControlUnit;
    }
};



class MainMemory {
protected:
    int capacity;
    // string techonolgyType;

public:
    MainMemory() : capacity(0) {}

    MainMemory(const MainMemory& aMainMemory) : capacity(aMainMemory.capacity) {}

    MainMemory(int capacity) : capacity(capacity) {

    }
    void setCapacity(int capacity) { this->capacity = capacity; }

    void setTechonolgyType(string techonolgyType) {



    }

    int getCapacity() const { return this->capacity; }


};

class Port {
private:
    string type;
    int baudRate;

public:
    Port() : type(""), baudRate(0) {}

    Port(string type, int baudRate) : type(type), baudRate(baudRate) {}

    void setType(string type) { this->type = type; }

    void setBaudRate(int baudRate) { this->baudRate = baudRate; }

    int getBaudRate() const { return this->baudRate; }

    string getType() const { return this->type; }
};

class MotherBoard {
private:
    MainMemory aMainMemory;
    Port* ports[7]; // Assuming there are 7 ports
    static int index;

public:


    void setMainMemory(MainMemory& abc)
    {
        aMainMemory = abc;
    }
    MotherBoard() : aMainMemory(0) {}

    MotherBoard(MainMemory bMainMemory = 0, Port* port = nullptr) : aMainMemory(aMainMemory) {
        for (int i = 0; i < 7; i++) {
            ports[i] = port;
        }
        ports[index++] = port;
        aMainMemory = bMainMemory;
    }





}; int MotherBoard::index = 0;


//Upon asking i will change this 
class PhysicalMemory {

private:
    int capacity;
public:
    PhysicalMemory()
    {
        capacity = 0;
    }
    PhysicalMemory(int capcity)
    {
        this->capacity = capcity;
    }


    void setCapacity(int capacity)
    {
        this->capacity = capacity;
    }

    int getCapacity() const
    {
        return this->capacity;
    }

};

class Computer {

private:

    PhysicalMemory* aPhysicalMemory;

    MotherBoard* aMotherBoard;

    CPU* aCPU;

public:

    Computer() : aPhysicalMemory(NULL), aMotherBoard(NULL), aCPU(NULL)
    {

    }


    Computer(PhysicalMemory* aPhysicalMemory, MotherBoard* aMotherBoard, CPU* aCPU) : aPhysicalMemory(aPhysicalMemory), aMotherBoard(aMotherBoard), aCPU(aCPU) {}



};


class GraphicsCard {
private:
    std::string brand;
    int memorySize;
    double price;

public:
    // Default constructor
    GraphicsCard() : brand(""), memorySize(0), price(0.0) {}

    // Overloaded constructor
    GraphicsCard(string b, int m, double p) : brand(b), memorySize(m), price(p) {}

    // Getters
    std::string getBrand() const { return brand; }
    int getMemorySize() const { return memorySize; }
    double getPrice() const { return price; }

    // Setters
    void setBrand(const string& b) { brand = b; }
    void setMemorySize(int m) { memorySize = m; }
    void setPrice(double p) { price = p; }
};



class StorageDevice {
private:
    string type;
    int capacity;
    double price;

public:
    // Default constructor
    StorageDevice() : type(""), capacity(0), price(0.0) {}

    // Overloaded constructor
    StorageDevice(string t, int c, double p) : capacity(c), price(p)
    {

        if (t == "SSD" || t == "HDD") {
            type = t;
        }
        else {


            while (t != "SSD" && t != "HDD")
            {
                cout << "Invalid type. Please enter either 'SSD' or 'HDD'.\n";

                cin >> t;

            }
        }
    }

    // Getters
    string getType() const { return type; }
    int getCapacity() const { return capacity; }
    double getPrice() const { return price; }

    // Setters
    void setType(string t) {
        if (t == "SSD" || t == "HDD") {
            type = t;
        }
        else {


            while (t != "SSD" && t != "HDD")
            {
                cout << "Invalid type. Please enter either 'SSD' or 'HDD'.\n";

                cin >> t;

            }
        }
    }
    void setCapacity(int c) { capacity = c; }
    void setPrice(double p) { price = p; }
};

class NetworkCard {
private:
    string type;
    int speed;
    double price;

public:
    // Default constructor
    NetworkCard() : type(""), speed(0), price(0.0) {}

    // Overloaded constructor
    NetworkCard(string t, int s, double p) : speed(s), price(p) {
        if (t == "Ethernet" || t == "Wifi") {
            type = t;
        }
        else {
            while (t != "Ethernet" && t != "Wifi") {
                cout << "Invalid type. Please enter either 'Ethernet' or 'Wifi'.\n";
                cin >> t;
            }
            type = t;
        }
    }

    // Getters
    string getType() const { return type; }
    int getSpeed() const { return speed; }
    double getPrice() const { return price; }

    // Setters
    void setType(string t) {
        if (t == "Ethernet" || t == "Wifi") {
            type = t;
        }
        else {
            while (t != "Ethernet" && t != "Wifi") {
                cout << "Invalid type. Please enter either 'Ethernet' or 'Wifi'.\n";
                cin >> t;
            }
            type = t;
        }
    }
    void setSpeed(int s) { speed = s; }
    void setPrice(double p) { price = p; }
};


class PowerSupply {
private:
    int wattage;
    string efficiencyRating;
    double price;

public:
    PowerSupply(int watt = 0, string rating = "80 Plus Bronze", double pr = 0.0) : wattage(watt), efficiencyRating(rating), price(pr) {}

    int getWattage() const { return wattage; }
    void setWattage(int watt) { wattage = watt; }

    string getEfficiencyRating() const { return efficiencyRating; }
    void setEfficiencyRating(const string& rating) { efficiencyRating = rating; }

    double getPrice() const { return price; }
    void setPrice(double pr) { price = pr; }
};

class Battery {
private:
    int capacity;

public:
    Battery(int cap = 0) : capacity(cap) {}

    int getCapacity() const { return capacity; }
    void setCapacity(int cap) { capacity = cap; }
};

class Case {
private:
    string formFactor;
    string color;
    double price;

public:
    Case(string form = "ATX", string col = "black", double pr = 0.0) : formFactor(form), color(col), price(pr) {}

    string getFormFactor() const { return formFactor; }
    void setFormFactor(const string& form) { formFactor = form; }

    string getColor() const { return color; }
    void setColor(const string& col) { color = col; }

    double getPrice() const { return price; }
    void setPrice(double pr) { price = pr; }
};



class ComputerAssembly {

protected:
    PowerSupply* powerSupply;
    Case* computerCase;

    NetworkCard* networkCard;


public:
    ComputerAssembly(PowerSupply* ps = nullptr, Case* cc = nullptr)
        : powerSupply(ps), computerCase(cc) {}

    ~ComputerAssembly() {
        delete powerSupply;


    }

    PowerSupply* getPowerSupply() const { return powerSupply; }
    void setPowerSupply(PowerSupply* ps) { powerSupply = ps; }


    Case* getCase() const { return computerCase; }
    void setCase(Case* cc) { computerCase = cc; }



};