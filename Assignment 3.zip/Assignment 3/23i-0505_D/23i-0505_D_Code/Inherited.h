#pragma once

#include"class_ALU.h"

#include<iostream>
using namespace std;





// Child class for DDR4/5 memory
class DDRMemory : public PhysicalMemory {

    string techonolgyType;
public:
    DDRMemory(int cap = 0) : PhysicalMemory(cap) {}


};

// Child class for LPDDR4/5 memory
class LPDDRMemory : public PhysicalMemory {

    string techonolgyType;
    
public:
    LPDDRMemory(int cap = 0) : PhysicalMemory(cap) {}


};



class AppleSilicon : public CPU {

private:

    GraphicsCard gpu;

public:

    AppleSilicon() :CPU() {

    }
};


class IntelCPU : public CPU {

private:
public:
    IntelCPU() :CPU() {

    }

};



// Specific MainMemory classes
class SemiconductorMemory : public MainMemory {
private:
    string techonolgyType;
public:
    SemiconductorMemory(string technology = "Semiconductor", int capcity = 0) :MainMemory(capacity), techonolgyType(technology)
    {

    }


    void setCapacity(int capacity)
    {
        this->capacity = capacity;
    }

    int getCapacity() const
    {

        return capacity;
    }

    void setTechonolgyType(string techonolgyType) {

        this->techonolgyType = techonolgyType;
    }

    string getTechonolgyType() const {

        return  this->techonolgyType;
    }
};

class SiliconMemory : public MainMemory {
  private:
    string techonolgyType;
public:
    SiliconMemory(string technology = "silicon", int capcity = 0) :MainMemory(capacity), techonolgyType(technology)
    {

    }


    void setCapacity(int capacity)
    {
        this->capacity = capacity;
    }

    int getCapacity() const
    {

        return capacity;
    }

    void setTechonolgyType(string techonolgyType) {

        this->techonolgyType = techonolgyType;
    }

    string getTechonolgyType() const {

        return  this->techonolgyType;
    }

};

// Define similar classes for other components like StorageDevice, NetworkCard, etc.


class PC : public ComputerAssembly
{
private:
    IntelCPU intelCPU;

    SemiconductorMemory mainMemory;
    DDRMemory physicalMemory;
    double priceTag;

public:
    PC() : ComputerAssembly() {}

    void setALU(const ALU& aALU)
    {
        // Set ALU for PC
        intelCPU.setALU(aALU);
    }

    void setControlUnit(const ControlUnit& aControlUnit)
    {
        // Set ControlUnit for PC
        intelCPU.setControlUnit(aControlUnit);
    }

    void setMainMemory(int capacity)
    {
        mainMemory.setCapacity(capacity);
    }

    SemiconductorMemory getMainMemory() const
    {
        return mainMemory;
    }


};

class MAC : public ComputerAssembly
{
private:
    AppleSilicon CPU;
    SiliconMemory mainMemory;
    Battery battery;
    LPDDRMemory physicalMemory;

public:
    MAC() : ComputerAssembly() {}

    void setALU(const ALU& aALU)
    {
        // Set ALU for MAC
        CPU.setALU(aALU);
    }

    void setControlUnit(const ControlUnit& aControlUnit)
    {
        // Set ControlUnit for MAC
        CPU.setControlUnit(aControlUnit);
    }


};
