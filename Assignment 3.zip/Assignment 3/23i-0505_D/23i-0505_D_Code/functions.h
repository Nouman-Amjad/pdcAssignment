#pragma once
#include<iostream>
#include "class_ALU.h"
#include "Inherited.h"

using namespace std;


void inputCPUComponents(ALU& aALU, ControlUnit& aControlUnit) {
    // Gather input for ALU
    int numOfAdders, numOfSubtractors, numOfRegisters, sizeOfRegisters;
    cout << "Enter number of adders in your ALU Of CPU: ";
    cin >> numOfAdders;
    cout << "Enter number of subtractors in your ALU Of CPU: ";
    cin >> numOfSubtractors;
    cout << "Enter number of registers in your ALU Of CPU: ";
    cin >> numOfRegisters;
    cout << "Enter size of registers in your ALU Of CPU: ";
    cin >> sizeOfRegisters;

    aALU = ALU(numOfAdders, numOfSubtractors, numOfRegisters, sizeOfRegisters);

    // Gather input for Control Unit
    float clock;
    cout << "Enter clock speed: ";
    cin >> clock;
    aControlUnit = ControlUnit(clock);
}
