/*
		AKIF JAWAD
		CS - 2B
		23i-0583
		Sir Ali Zeeshan
		T.A Muhammad Mohsin Ramzan
									*/

#include <iostream>
using namespace std;
#include"computerAssembly.h"

int main() {
	computerAssembly myPC;
	myPC.display();
}