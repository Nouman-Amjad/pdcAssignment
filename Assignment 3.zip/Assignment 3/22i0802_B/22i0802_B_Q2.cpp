#include "pch.h"
#include "22i0802_B_Q2.h"
#include <iostream>
using namespace std;

// Custom string length function
size_t myStrlen(const char* str) {
    const char* s;
    for (s = str; *s; ++s);
    return s - str;
}

// Custom string copy function
void myStrcpy(char* dest, const char* src) {
    while ((*dest++ = *src++));
}

// Custom string concatenate function
char* myStrcat(char* destination, const char* source) {
    char* ptr = destination + myStrlen(destination);

    while (*source != '\0') {
        *ptr++ = *source++;
    }
    *ptr = '\0';

    return destination;
}

// Custom string comparison function
int myStrcmp(const char* s1, const char* s2) {
    while (*s1 && (*s1 == *s2)) {
        ++s1;
        ++s2;
    }
    return *(const unsigned char*)s1 - *(const unsigned char*)s2;
}

// Custom function to find substring
char* myStrstr(const char* haystack, const char* needle) {
    if (!*needle) return (char*)haystack;
    char* p1 = (char*)haystack;
    while (*p1) {
        char* p1Begin = p1, * p2 = (char*)needle;
        while (*p1 && *p2 && *p1 == *p2) {
            p1++;
            p2++;
        }
        if (!*p2) return p1Begin;
        p1 = p1Begin + 1;
    }
    return nullptr;
}

// Default constructor
String::String() : name(new char[1]) {
    name[0] = '\0';
}

// Constructor with c-string
String::String(const char* str) {
    name = new char[myStrlen(str) + 1];
    myStrcpy(name, str);
}

// Copy constructor
String::String(const String& other) {
    name = new char[myStrlen(other.name) + 1];
    myStrcpy(name, other.name);
}

// Constructor with size
String::String(int x) {
    name = new char[1];
    name[0] = '\0';
}

// Destructor
String::~String() {
    delete[] name;
}

// Get data
char* String::getdata() const {
    return name;
}

// Subscript operator
const char String::operator[](int i) const {
    int len = myStrlen(name);
    if (i < 0) i += len;
    return (i >= 0 && i < len) ? name[i] : '\0';
}

// Adds a String to the end of the current String
String& String::operator+=(const String& str) {
    size_t newLength = myStrlen(this->name) + myStrlen(str.name) + 1;  // +1 for the null-terminator
    char* newStr = new char[newLength];

    myStrcpy(newStr, this->name);  // Copy the original string
    myStrcat(newStr, str.name);  // Concatenate the new string

    delete[] this->name;  // Deallocate the old string
    this->name = newStr;  // Point to the new string

    return *this;  // Return the current object by reference
}

// Concatenation operators
// Appends a String at the end of the current String and returns it
String String::operator+(const String& str) {
    return String(*this) += str;
}

// Appends a char at the end of the current String and returns it
String String::operator+(const char& ch) {
    char str[] = { ch, '\0' };
    return String(*this) += String(str);
}

// Appends a C-string at the end of the current String and returns it
String String::operator+(const char* str) {
    return String(*this) += String(str);
}

// Remove first occurrence of `substr` from the `String`
String String::operator-(const String& substr) {
    char* position = myStrstr(this->name, substr.name);
    if (!position) return *this; // Substring not found, return unchanged string

    size_t newLength = myStrlen(this->name) - myStrlen(substr.name);
    char* newStr = new char[newLength + 1];
    char* current = newStr;

    for (char* it = this->name; it != position; ++it, ++current) {
        *current = *it;
    }

    for (char* it = position + myStrlen(substr.name); *it; ++it, ++current) {
        *current = *it;
    }

    *current = '\0';

    String result(newStr);
    delete[] newStr;
    return result;
}

// Remove all occurrences of `ch` from the `String`
String String::operator-(const char& ch) {
    size_t length = myStrlen(this->name);
    char* newStr = new char[length + 1]; // Allocating max possible size needed
    char* current = newStr;

    for (size_t i = 0; i < length; ++i) {
        if (this->name[i] != ch) {
            *current = this->name[i];
            ++current;
        }
    }

    *current = '\0'; // Null-terminate the new string

    String result(newStr);
    delete[] newStr;
    return result;
}

// Remove first occurrence of `str` from the `String`
String String::operator-(const char* str) {
    char* position = myStrstr(this->name, str);
    if (!position) return *this; // Substring not found, return unchanged string

    size_t newLength = myStrlen(this->name) - myStrlen(str);
    char* newStr = new char[newLength + 1];
    char* current = newStr;

    for (char* it = this->name; it != position; ++it, ++current) {
        *current = *it;
    }

    for (char* it = position + myStrlen(str); *it; ++it, ++current) {
        *current = *it;
    }

    *current = '\0';

    String result(newStr);
    delete[] newStr;
    return result;
}

// Overloads the assignment operator to copy from another String
String& String::operator=(const String& other) {
    if (this != &other) {  // Protect against invalid self-assignment
        delete[] this->name;  // Deallocate the old string
        this->name = new char[myStrlen(other.name) + 1];  // +1 for the null-terminator
        myStrcpy(this->name, other.name);  // Copy the string
    }
    return *this;  // Return the current object by reference
}

// Overloads the assignment operator to copy from a C-string
String& String::operator=(const char* str) {
    delete[] this->name;  // Deallocate the old string
    this->name = new char[myStrlen(str) + 1];  // +1 for the null-terminator
    myStrcpy(this->name, str);  // Copy the string

    return *this;  // Return the current object by reference
}


// Equality operators
bool String::operator==(const String& str) const {
    return myStrcmp(name, str.name) == 0;
}

bool String::operator==(const char* str) const {
    return myStrcmp(name, str) == 0;
}

// Boolean not operator
bool String::operator!() {
    return name[0] == '\0';
}

// Function-call operators
int String::operator()(char ch) const {
    for (size_t i = 0; name[i] != '\0'; ++i) {
        if (name[i] == ch) return i;
    }
    return -1;
}

int String::operator()(const String& str) const {
    char* substr = myStrstr(name, str.name);
    return substr ? substr - name : -1;
}

int String::operator()(const char* str) const {
    char* substr = myStrstr(name, str);
    return substr ? substr - name : -1;
}

// Conversion operator to int
String::operator int() const {
    return myStrlen(name);
}

// Output stream operator
ostream& operator<<(ostream& output, const String& str) {
    output << str.getdata();
    return output;
}

// Input stream operator
istream& operator>>(istream& input, String& str) {
    char buffer[1024]; // Simple buffer, might need adjustments for larger input
    input >> buffer;
    str = buffer;
    return input;
}