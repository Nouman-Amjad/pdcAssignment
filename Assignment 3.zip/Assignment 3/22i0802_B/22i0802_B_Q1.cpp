#include "pch.h"
#include "22i0802_B_Q1.h"
#include <iostream>

using namespace std;

// Helper function to duplicate strings without <cstring>
char* duplicateString(const char* source) {
    int length = 0;
    while (source[length] != '\0') ++length; // Calculate length

    char* dest = new char[length + 1]; // Allocate memory
    for (int i = 0; i <= length; ++i) {
        dest[i] = source[i];
    }
    return dest;
}

// Copy Constructor
Shop::Shop(const Shop& other) : start(nullptr) {
    if (!other.start) return;

    Container* tempOther = other.start;
    Container** tempThis = &start;

    while (tempOther) {
        *tempThis = new Container();
        (*tempThis)->name = duplicateString(tempOther->name);
        (*tempThis)->containerno = tempOther->containerno;
        tempThis = &((*tempThis)->link);
        tempOther = tempOther->link;
    }
}

// Destructor
Shop::~Shop() {
    while (start) {
        Container* temp = start;
        start = start->link;
        delete[] temp->name;
        delete temp;
    }
}

// Add Container
void Shop::add_Container(char* name, int containerindex) {
    Container* newContainer = new Container();
    newContainer->name = duplicateString(name);
    newContainer->containerno = containerindex;
    newContainer->link = nullptr;

    Container** ptr = &start;
    while (*ptr) {
        ptr = &((*ptr)->link);
    }
    *ptr = newContainer;
}

// Print Shop
void Shop::print_Shop() {
    Container* current = start;
    while (current) {
        cout << current->name << "-" << current->containerno << "\n";
        current = current->link;
    }
}

// Delete Chain
void Shop::delete_Chain(int containerindex) {
    Container** curr = &start;
    while (*curr) {
        if ((*curr)->containerno == containerindex) {
            Container* temp = *curr;
            *curr = (*curr)->link;
            delete[] temp->name;
            delete temp;
            return;
        }
        curr = &((*curr)->link);
    }
}

// Update Name at Container Number
void Shop::update_name_at_containerNumber(int containerindex, char* name) {
    for (Container* curr = start; curr != nullptr; curr = curr->link) {
        if (curr->containerno == containerindex) {
            delete[] curr->name;
            curr->name = duplicateString(name);
            return;
        }
    }
}

// Sort Chain
void Shop::Sort_Chain() {
    if (!start || !start->link) return;

    bool swapped;
    do {
        swapped = false;
        Container** curr = &start;
        while ((*curr)->link) {
            Container* a = *curr;
            Container* b = (*curr)->link;
            if (a->containerno > b->containerno) {
                a->link = b->link;
                b->link = a;
                *curr = b;
                swapped = true;
            }
            curr = &((*curr)->link);
        }
    } while (swapped);
}

// Remove Duplicate
void Shop::remove_Duplicate() {
    Container* current = start, * prev = nullptr, * temp;
    while (current && current->link) {
        prev = current;
        temp = current->link;
        while (temp) {
            if (temp->containerno == current->containerno) {
                prev->link = temp->link;
                delete[] temp->name;
                delete temp;
                temp = prev->link;
            }
            else {
                prev = temp;
                temp = temp->link;
            }
        }
        current = current->link;
    }
}

// Find Container
void Shop::findContainer(int containerindex) {
    for (Container* curr = start; curr != nullptr; curr = curr->link) {
        if (curr->containerno == containerindex) {
            cout << curr->name << "\n";
            return;
        }
    }
}

// Find Container in Range
void Shop::findContainer(int containerindex1, int containerindex2) {
    for (Container* curr = start; curr != nullptr; curr = curr->link) {
        if (curr->containerno >= containerindex1 && curr->containerno <= containerindex2) {
            cout << curr->name << "\n";
        }
    }
}