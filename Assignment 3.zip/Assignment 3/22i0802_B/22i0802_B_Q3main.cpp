#include "22i0802_B_Q3.h"

int main() {
    CAList tt, tt2, tt3, tt4;
    tt.addEntry("OOP", "Dr.Ali");
    tt.addEntry("OOP", "Mr.Shehryar");
    tt.addEntry("OOP", "Ms.Hida");
    tt.addEntry("OOP", "Mr.Shams");
    tt.addEntry("DLD", "Mr.Amir");
    tt.addEntry("DLD", "Mr.Shams");
    tt.addEntry("DLD", "Dr.Mehwish");

    cout << "CAList tt:\n" << tt << endl;

    tt2.addEntry("Algo", "Mr.Owais");
    tt2.addEntry("Pak Stds", "Mr.Ajmal");
    tt2.addEntry("Pak Stds", "Ms.Gul");
    tt2.addEntry("Pak Stds", "Ms.Memoona");
    tt2.addEntry("Islamiat", "Dr.Tayab");
    tt2.addEntry("Islamiat", "Ms.Sobia");
    tt2.addEntry("Islamiat", "Mr.Usman");
    tt2.addEntry("Islamiat", "Ms.Gul");
    tt2.addEntry("Islamiat", "Mr.Anas");

    cout << "CAList tt2:\n" << tt2 << endl;

    tt3 = tt + tt2;
    cout << "CAList tt3 (tt + tt2):\n" << tt3 << endl;

    tt4 = tt3 - tt2;
    cout << "CAList tt4 (tt3 - tt2):\n" << tt4 << endl;

    return 0;
}