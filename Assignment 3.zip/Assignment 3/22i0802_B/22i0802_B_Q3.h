#pragma once
#ifndef Q3_H
#define Q3_H

#include <iostream>
#include <string>
using namespace std;

const int MAX_NAMES = 6; // Maximum names per specialty
const int MAX_SPECIALTIES = 7; // Maximum different specialties

class Entry {
public:
    string names[MAX_NAMES];
    int nameCount;
    string specialty;
    Entry();
    void addName(const string& name);
    void removeName(const string& name);
    Entry& operator=(const string& name);
    friend ostream& operator<<(ostream& os, const Entry& entry);
};

class CAList {
    int entryCount;

public:
    Entry entries[MAX_SPECIALTIES];

    CAList();
    void addEntry(const string& specialty, const string& name);
    CAList operator+(const CAList& other) const;
    CAList operator-(const CAList& other) const;
    Entry& operator[](const string& specialty);
    CAList& operator+=(const Entry& entry);
    CAList& operator-=(const Entry& entry);
    friend ostream& operator<<(ostream& os, const CAList& list);
};

#endif // Q3_H