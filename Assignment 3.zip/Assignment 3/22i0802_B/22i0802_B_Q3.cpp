#include "22i0802_B_Q3.h"

Entry::Entry() : nameCount(0), specialty("") {}

void Entry::addName(const string& name) {
    if (nameCount < MAX_NAMES) {
        names[nameCount++] = name;
    }
}

void Entry::removeName(const string& name) {
    for (int i = 0; i < nameCount; ++i) {
        if (names[i] == name) {
            for (int j = i; j < nameCount - 1; ++j) {
                names[j] = names[j + 1];
            }
            --nameCount;
            break;
        }
    }
}

Entry& Entry::operator=(const string& name) {
    addName(name);
    return *this;
}

ostream& operator<<(ostream& os, const Entry& entry) {
    os << entry.specialty << " : { ";
    for (int i = 0; i < entry.nameCount; ++i) {
        os << entry.names[i];
        if (i < entry.nameCount - 1) os << ", ";
    }
    os << " }";
    return os;
}

CAList::CAList() : entryCount(0) {}

void CAList::addEntry(const string& specialty, const string& name) {
    for (int i = 0; i < entryCount; ++i) {
        if (entries[i].specialty == specialty) {
            entries[i].addName(name);
            return;
        }
    }
    if (entryCount < MAX_SPECIALTIES) {
        entries[entryCount].specialty = specialty;
        entries[entryCount].addName(name);
        ++entryCount;
    }
}

CAList CAList::operator+(const CAList& other) const {
    CAList result = *this;
    for (int i = 0; i < other.entryCount; ++i) {
        result += other.entries[i];
    }
    return result;
}

CAList CAList::operator-(const CAList& other) const {
    CAList result = *this;
    for (int i = 0; i < other.entryCount; ++i) {
        result -= other.entries[i];
    }
    return result;
}

Entry& CAList::operator[](const string& specialty) {
    for (int i = 0; i < entryCount; ++i) {
        if (entries[i].specialty == specialty) {
            return entries[i];
        }
    }
    if (entryCount < MAX_SPECIALTIES) {
        entries[entryCount++].specialty = specialty;
    }
    return entries[entryCount - 1];
}

CAList& CAList::operator+=(const Entry& entry) {
    for (int i = 0; i < entryCount; ++i) {
        if (entries[i].specialty == entry.specialty) {
            for (int j = 0; j < entry.nameCount; ++j) {
                entries[i].addName(entry.names[j]);
            }
            return *this;
        }
    }
    if (entryCount < MAX_SPECIALTIES) {
        entries[entryCount++] = entry;
    }
    return *this;
}

CAList& CAList::operator-=(const Entry& entry) {
    for (int i = 0; i < entryCount; ++i) {
        if (entries[i].specialty == entry.specialty) {
            for (int j = 0; j < entry.nameCount; ++j) {
                entries[i].removeName(entry.names[j]);
            }
            return *this;
        }
    }
    return *this;
}

ostream& operator<<(ostream& os, const CAList& list) {
    for (int i = 0; i < list.entryCount; ++i) {
        os << list.entries[i] << endl;
    }
    return os;
}