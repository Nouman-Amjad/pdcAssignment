//Fatima Binte Shakir
//23I-0503
//E
//Ma'am Marium Hida
//Muhammad Ali Naveed
#pragma on
#include<iostream>

using namespace std;

class ALU
{
private:
	int NoOfAdders;
	int NoOfSubtractors;
	int NoOfRegistors;
	int sizeOfRegistors;
public:
	ALU();
};
/// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
class ControlUnit
{
private:
	float clock;
public:
	ControlUnit();
};
/// ///////////////////////////////////////////////////////////////////////////////////////////////////////////////
class CPU
{
private:
	ALU alu;
	ControlUnit cu;
	double price;
public:
	CPU();
	double getprice()const;
};
/// /////////////////////////////////////////////////////////////////////////////////////////////////////////////
class GraphicCard
{
private:
	string brand;
	int memorysize;
	double price;
public:
	GraphicCard();
	string getbrand()const;
	int getmemsize()const;
	double getprice()const;
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
class appleCPU : public CPU
{
	double price;
public:
	appleCPU();
	double getprice();
};
/// ///////////////////////////////////////////////////////////////////////////////////////////////////////////
class Networkcard
{
private:
	string type;
	int speed;
	double price;
public:
	Networkcard();
	Networkcard(string s);
	double getprice()const;
	string gettype()const;
};
/// ////////////////////////////////////////////////////////////////////////////////////////////////////////
class PhysicalMemory
{
	int capacity;
	double price;
public:
	PhysicalMemory();
	PhysicalMemory(string s1, string s2);
	double getprice()const;
	int getcapacity()const;
};
/// //////////////////////////////////////////////////////////////////////////////////////////////////////////////
class MainMemory
{
	int capacity;
	string technologytype;
	double price;
public:
	MainMemory();
	MainMemory(string s1, string s2);
	int getcapacity()const;
	double getprice()const;
	string get_t_type()const;
};
/// //////////////////////////////////////////////////////////////////////////////////////////////////////////////
class Ports
{
	int baudrate;
	string type;
	int priceport;
public:
	Ports();
	void setport(int a);
	void display();
};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
class MotherBoard
{
private:
	Ports port;
	MainMemory* mm;
	PhysicalMemory* pm;
	CPU* cpu;
	GraphicCard* gpu;
	Networkcard* nc;
	appleCPU* applecpu;
	double price;
public:
	MotherBoard();
	MotherBoard(MainMemory* m, PhysicalMemory* p, CPU* c, GraphicCard* g, Networkcard* network);
	MotherBoard(MainMemory* m, PhysicalMemory* p, appleCPU* apple, Networkcard* network);
	double getprice()const;
	void display();
};
/// //////////////////////////////////////////////////////////////////////////////////////////////////////////////
class storagedevice
{
private:
	string type;
	int capacity;
	double price;

public:
	storagedevice();
	void settype(string& s);
	string gettype()const;
	void setcapacity(int c);
	int getcapacity()const;
	void setprice(double p);
	double getprice()const;
	friend istream& operator>>(istream& input, storagedevice& sd);
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
class powersupply
{
private:
	int wattage;
	string rating;
	double price;
public:
	powersupply();
	void setwattage(int w);
	void setprice(double p);
	void setrating(string& s);
	int getwattage()const;
	double getprice()const;
	string getrating()const;
	friend istream& operator>>(istream& input, powersupply& ps);
};
///////////////////////////////////////////////////////////////////////////////////////////////////////////
class battery
{
private:
	int capacity;
	double price;
public:
	battery();
	void setcapacity(int c);
	void setprice(double p);
	int getcapacity()const;
	double getprice()const;
};
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
class Computerassembly
{
	MotherBoard* mb;
	storagedevice sd;
	powersupply ps;
	battery b;
	double totalprice;
public:
	Computerassembly();
	Computerassembly(MotherBoard* m,storagedevice& s,powersupply& p,battery& bt);
	void settotalprice(double p);
	double gettotalprice()const;
};
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
class Case
{
private:
	string color;
	string formfactor;
	double price;
	Computerassembly* a;
public:
	Case();
	Case(string ff, string c, double p);
	void setformfactor(const string& ff);
	void setcolor(const string& c);
	void setprice(double price);
	string getformfactor() const;
	string getcolor() const;
	void seta(Computerassembly* assembly);
	double getprice() const;
	double totalprice(Computerassembly* c)const;
	void display();
};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
class Computer
{
	Case* c;
	double totalprice;
public:
	Computer();
	void setcomputer(Case& cases);
};