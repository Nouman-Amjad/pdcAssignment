//Fatima Binte Shakir
//23I-0503
//E
//Ma'am Marium Hida
//Muhammad Ali Naveed
#include<iostream>
#include"Header.h"

using namespace std;

int main()
{
	string name;
	cout << "Enter the choice you want (APPLE OR OTHER) Other means every pc or laptop except for an apple" << endl;
	cin >> name;
	string name2, name3;
	if (name == "apple")
	{
		cout << "You are going to get a MAC" << endl;
		name2 = "MAC";
	}
	while (name != "other" && name!="apple")
	{
		cout << "incorrect name. write other in lower case.Enter again" << endl;
		cin >> name;
	}
	if (name == "other")
	{
		cout << "Enter second choice: (PC or LAPTOP)" << endl;
		cin >> name3;
	}
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////
	CPU* cpu = nullptr;
	GraphicCard* gpu = nullptr;
	appleCPU* macCPU = nullptr;
	Networkcard* nc = nullptr;
	PhysicalMemory* pm = nullptr;
	MainMemory* mm = nullptr;
	nc = new Networkcard(name2 == "MAC" ? name2 : name3);
	pm = new PhysicalMemory(name2, name3);
	mm = new MainMemory(name2, name3);
	if (name2 == "MAC")
	{
		macCPU = new appleCPU;
	}
	else
	{
		cpu = new CPU;          
		gpu = new GraphicCard;
	}
	MotherBoard* appleMotherBoard = nullptr;
	MotherBoard* pcMotherBoard = nullptr;
	if (name2 == "MAC")
	{
	   appleMotherBoard= new MotherBoard(mm, pm, macCPU, nc);
	}
	else
	{
		pcMotherBoard= new MotherBoard(mm, pm, cpu, gpu, nc);
	}
	////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//cout << "Total price of PC Motherboard: " << pcMotherBoard->getprice() << endl;
	storagedevice sd;
	cin >> sd;
	double price = 1000;
	if (name2 == "MAC" && sd.gettype() == "SDD")
	{
		price = price * 2.5;//SSD are more costly
	}
	else if (name2 == "MAC" && sd.gettype() == "HDD")
	{
		price = price * 1.5;//HDD are cheaper
	}
	else if (name3 == "PC" && sd.gettype() == "SSD")
	{
		price = price + 300;
	}
	else if (name3 == "PC" && sd.gettype() == "HDD")
	{
		price = price + 200;
	}
	else if (name3 == "laptop" && sd.gettype() == "SSD")
	{
		price = price + 600;
	}
	else if (name3 == "laptop" && sd.gettype() == "HDD")
	{
		price = price + 500;
	}
	sd.setprice(price);
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////
	powersupply ps;
	cin >> ps;
	double p = 10000; //default price
	if ((name2 == "MAC" && ps.getrating() == "bronze") ? p = p * 3.5 : p = p * 4.5)
	{}
	else if ((name3 == "pc" || name3 == "PC" || name3 == "Pc" && ps.getrating() == "bronze") ? p = p * 1.5 : p = p * 2.5)
	{}
	else if ((name3 == "laptop" && ps.getrating() == "bronze") ? p = p * 1.25 : p = p * 2.25)
	{ }
	ps.setprice(p);
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	battery b;
	int c;
	double pb = 20000;
	cout << "Enter capacity of battery" << endl;
	cin >> c;
	while (c <= 0)
	{
		cout << "Invalid capacity. It should be greater than 0. Enter again" << endl;
		cin >> c;
	}
	if (name2 == "MAC")
	{
		pb = pb * 3.5;
	}
	else if (name3 == "laptop" ? pb = pb + 1000 : pb = pb + 900)
	{}
	b.setcapacity(c);
	b.setprice(pb);
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	Computerassembly* assemblepc=nullptr;
	Computerassembly* assemblemac=nullptr;
	double total;
	if (name2 == "MAC")
	{
		assemblemac = new Computerassembly(appleMotherBoard, sd, ps, b);
		total = appleMotherBoard->getprice() + sd.getprice() + ps.getprice() + b.getprice();
	}
	else
	{
		assemblepc = new Computerassembly(pcMotherBoard, sd, ps, b);
		total = pcMotherBoard->getprice() + sd.getprice() + ps.getprice() + b.getprice();
	}
	if (name2 == "MAC")
	{
		assemblemac->settotalprice(total);
	}
	else
	{
		assemblepc->settotalprice(total);
	}
	//cout << "PRICE FOR MAC IS: " << assemblemac->gettotalprice() << endl;
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	Case* cases = nullptr;
	string formfactor,color;
	double pcase = 6000;
	double totalprice = 0;
	cout << "Enter form factor(ATX or microATX)" << endl;
	cin >> formfactor;
	while(formfactor!="atx" && formfactor!="microatx")
	{
		cout << "Invalid input. Enter again" << endl;
		cin >> formfactor;
	}
	cout << "Enter colour of case" << endl;
	cin >> color;
	if (name2 == "MAC" && formfactor == "atx")
	{
		pcase = pcase * 2;
		cases = new Case(formfactor, color, pcase);
		totalprice = cases->totalprice(assemblemac);
	}
	if (name2 == "MAC" && formfactor == "microatx")
	{
		pcase = pcase * 1.5;
		cases = new Case(formfactor, color, pcase);
		totalprice = cases->totalprice(assemblemac);
	}
	else if (name3 == "PC" || name3 == "pc" || name3 == "Pc" && formfactor == "atx")
	{
		pcase = pcase * 1.25;
		cases = new Case(formfactor, color, pcase);
		totalprice = cases->totalprice(assemblepc);
	}
	else if (name3 == "PC" || name3 == "pc" || name3 == "Pc" && formfactor == "microatx")
	{
		pcase = pcase * 0.75;
		cases = new Case(formfactor, color, pcase);
		totalprice = cases->totalprice(assemblepc);
	}
	else if (name3 == "laptop")
	{
		cases = new Case(formfactor, color, pcase);
		totalprice = total;
	}
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	Computer comp;
	cout << "\nSPECIFICATIONS OF YOUR COMPUTER ARE: " << endl;
	cout << "Network Card with " << nc->gettype() << " type." << endl;
	cout << "Physical Memory with " << pm->getcapacity() << "GB capacity." << endl;
	cout << "Main Memory with " << mm->getcapacity() << "GB capacity." << endl;
	cout << "Main memory with " << mm->get_t_type() << " technology type. " << endl;
	if (name3 == "PC" || name3 == "pc" || name3 == "Pc" || name3 == "laptop")
	{
		cout << "Graphic card with " << gpu->getmemsize() << " memory size. " << endl;
		cout << "Graphic card with " << gpu->getbrand() << " brand." << endl;
		pcMotherBoard->display();
	}
	if (name2 == "MAC")
	{
		cout << "An appleGPU integrated with GPU" << endl;
		appleMotherBoard->display();
	}
	cout << "Storage Device with " << sd.getcapacity() << " capacity." << endl;
	cout << "Storage Device with " << sd.gettype() << " type." << endl;
	cout << "Powersupply with " << ps.getrating() << " rating" << endl;
	cout << "Powersupply with " << ps.getwattage() << " wattage" << endl;
	cout << "Battery with " << b.getcapacity() << " capacity" << endl;
	cout << "Case with " << cases->getformfactor() << " form factor" << endl;
	cout << "Case with " << cases->getcolor() << " color" << endl;
	cout << "Price of your computer is: $" << totalprice << endl;
	
}