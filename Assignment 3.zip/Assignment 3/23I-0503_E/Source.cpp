//Fatima Binte Shakir
//23I-0503
//E
//Ma'am Marium Hida
//Muhammad Ali Naveed
#include"Header.h"
#include<iostream>
using namespace std;

//NETWORK CARD CLASS
Networkcard::Networkcard()
{
	type = "";
	speed = 0;
	price = 0.0;
}

Networkcard::Networkcard(string s)
{
	price = 4000.0;
	cout << "Enter type you want (either ethernet or wifi) : " << endl;
	cin >> type;
	while (type != "ethernet" && type != "wifi")
	{
		cout << "Incorrect type entered. Enter again." << endl;
		cin >> type; 
	}
	cout << "Enter speed you want: " << endl;
	cin >> speed;
	if (s == "MAC")
	{
		price = price * 1.2;
	}
	else if (s == "PC" || s == "pc" || s == "Pc")
	{
		price = price;
	}
	else if (s == "laptop")
	{
		price = price + 200;;
	}
}

double Networkcard::getprice()const
{
	return price;
}

string Networkcard::gettype()const
{
	return type;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//PHYSICAL MEMORY CLASS
PhysicalMemory::PhysicalMemory()
{
	capacity = 0;
	price = 0.0;
}

PhysicalMemory::PhysicalMemory(string s1, string s2)
{
	cout << "Enter Capacity of physical memory (in GB)" << endl;
	cin >> capacity;
	while (capacity <= 0 || capacity > 128)
	{
		cout << "Invalid capacity. Enter again." << endl;
		cin >> capacity;
	}
	price = 3000; //default price;
	if (s1 == "MAC")
	{
		price = price * 1.5; //price will be higher for mac
	}
	else if (s2 == "PC" || s2 == "pc" || s2 == "Pc")
	{
		price = price;
	}
	else if (s2 == "laptop")
	{
		price = price * 1.2;
	}
}

double PhysicalMemory::getprice()const
{
	return price;
}

int  PhysicalMemory::getcapacity()const
{
	return capacity;
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//MAIN MEMORY CALSS
MainMemory::MainMemory()
{
	price = 0.0;
	capacity = 0;
	technologytype = "";
}

MainMemory::MainMemory(string s1, string s2)
{
	cout << "Enter capacity of main memory(in GB)" << endl;
	cin >> capacity;
	while (capacity <= 0 || capacity > 512)
	{
		cout << "Invalid capacity. Enter again." << endl;
		cin >> capacity;
	}
	cout << "Enter technology type (silicon or semiconductor)" << endl;
	cin >> technologytype;
	while (technologytype != "semiconductor" && technologytype != "silicon")
	{
		cout << "Invalid input. Input again" << endl;
		cin >> technologytype;
	}
	price = 6000; //default price
	if (s1 == "MAC")
	{
		price = price * 1.5; //price will be higher for mac
	}
	else if (s2 == "PC" || s2 == "pc" || s2 == "Pc")
	{
		price = price;
	}
	else if (s2 == "laptop")
	{
		price = price * 1.2;
	}
}

double MainMemory::getprice()const
{
	return price;
}

int  MainMemory::getcapacity()const
{
	return capacity;
}

string MainMemory::get_t_type()const
{
	return technologytype;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//ALU CLASS
ALU::ALU()
{
	NoOfAdders = 1;
	NoOfSubtractors = 1;
	NoOfRegistors = 8;
	sizeOfRegistors = 32;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////
//CU CLASS
ControlUnit::ControlUnit()
{
	clock = 12.5;
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//CPU CLASS
CPU::CPU()
{
	alu = ALU();
	cu = ControlUnit();
	price = 9000.0;
}

double CPU::getprice()const 
{
	return price;
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//GRAPHIC CARD CLASS
GraphicCard::GraphicCard()
{
	cout << "Enter Name of brand (NVIDIA or AMD)" << endl;
	cin >> brand;
	while (brand!="nvidia"&& brand!="NVIDIA"&& brand!="AMD"&&brand!="amd")
	{
		cout << "You have entered invalid brand. Enter again" << endl;
		cin >> brand;
	}
	cout << "Enter memory size (in gb) " << endl;
	cin >> memorysize;
	price = 8500.0;
}

string GraphicCard::getbrand()const
{
	return brand;
}

int GraphicCard::getmemsize()const
{
	return memorysize;
}

double GraphicCard::getprice()const
{
	return price;
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//APPLE CPU CLASS
appleCPU::appleCPU() 
{
	price = 8500.0; 
	CPU();
}

double appleCPU::getprice()
{
	return price;
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
Ports::Ports() 
{
	priceport = 0;
	type = "";
	baudrate = 0;
}
void Ports::setport(int a) 
{
	switch (a) {
	case 1:type = "HDMI port";
		priceport = 5000;
		baudrate = 100;
		break;
	case 2:type = "VGI port";
		priceport = 3000;
		baudrate = 80;
		break;
	case 3:type = "USB port";
		priceport = 2500;
		baudrate = 60;
		break;
	case 4:type = "I/O port";
		priceport = 2000;
		baudrate = 50;
		break;

	}
}

void Ports::display() 
{

	cout << "   Type of port : "<< type << endl;
	cout << "   Baud_rate : "<< baudrate << endl;
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//MOTHER BOARD CLASS
MotherBoard::MotherBoard() 
{
	mm = nullptr;
	pm = nullptr;
	cpu = nullptr;
	gpu = nullptr;
	nc = nullptr;
	applecpu = nullptr;
}

MotherBoard::MotherBoard(MainMemory* m, PhysicalMemory* p, CPU* c, GraphicCard* g, Networkcard* network)
{
	mm = m;
	pm = p;
	cpu = c;
	gpu = g;
	nc = network;
	price = mm->getprice() + pm->getprice() + cpu->getprice() + gpu->getprice() + nc->getprice();
}

MotherBoard::MotherBoard(MainMemory* m, PhysicalMemory* p, appleCPU* apple, Networkcard* network)
{
	mm = m;
	pm = p;
	applecpu = apple;
	nc = network;
	price = mm->getprice() + pm->getprice() + applecpu->getprice() + nc->getprice();
}

double MotherBoard::getprice()const
{
	return price;
}

void MotherBoard::display()
{
	port.display();
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//STORAGE DEVICE CLASS
storagedevice::storagedevice()
{
	type = "";
	capacity = 0;
	price = 0;
}

void storagedevice::setcapacity(int c)
{
	capacity = c;
}

void storagedevice::settype(string& s)
{
	type = s;
}

void storagedevice::setprice(double p)
{
	price = p;
}

double storagedevice::getprice()const
{
	return price;
}

string storagedevice::gettype()const
{
	return type;
}

int storagedevice::getcapacity()const
{
	return capacity;
}

istream& operator>>(istream& input, storagedevice& sd)
{
	cout << "Enter capacity of storage device: " << endl;
	input >> sd.capacity;
	while (sd.capacity <= 0)
	{
		cout << "Invalid capacity. Enter again" << endl;
		cin >> sd.capacity;
	}
	cout << "Enter type of storage device (HDD or SSD)" << endl;
	input >> sd.type;
	while (sd.type != "HDD" && sd.type != "SSD")
	{
		cout << "Either you are entering wrong input or HDD and SSD are not capital. Enter again" << endl;
		input >> sd.type;
	}
	sd.setcapacity(sd.capacity);
	sd.settype(sd.type);
	return input;
}
////////////////////S/////////////////////////////////////////////////////////////////////////////////////////////
//CLASS POWERSUPPLY
powersupply::powersupply()
{
	wattage = 0;
	rating = "";
	price = 0;
}

void powersupply::setwattage(int w)
{
	wattage = w;
}

void powersupply::setrating(string& s)
{
	rating = s;
}

void powersupply::setprice(double p)
{
	price = p;
}

double powersupply::getprice()const
{
	return price;
}

string powersupply::getrating()const
{
	return rating;
}

int powersupply::getwattage()const
{
	return wattage;
}

istream& operator>>(istream& input, powersupply& ps)
{
	cout << "Enter wattage of power supply:" << endl;
	input >> ps.wattage;
	cout << "Enter efficiency rating(bronze or gold): " << endl;
	input >> ps.rating;
	while (ps.rating != "bronze" && ps.rating != "gold")
	{
		cout << "You have entered invalid rating. Enter again" << endl;
		input >> ps.rating;
	}
	ps.setrating(ps.rating);
	ps.setwattage(ps.wattage);
	return input;
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//BATTERY CLASS
battery::battery()
{
	capacity = 0;
	price = 0.0;
}

void battery::setcapacity(int s)
{
	capacity = s;
}

void battery::setprice(double p)
{
	price = p;
}

int battery::getcapacity()const
{
	return capacity;
}

double battery::getprice()const
{
	return price;
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
Computerassembly::Computerassembly()
{
	totalprice = 0.0;
	mb = nullptr;
}
Computerassembly::Computerassembly(MotherBoard* m,storagedevice& s, powersupply& p,battery& bt)
{
	mb = m;
	sd = s;
	ps = p;
	b = bt;
}
void Computerassembly::settotalprice(double p)
{
	totalprice = p;
}
double Computerassembly::gettotalprice()const
{
	return totalprice;
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
Case::Case()
{
	formfactor = "";
	color = "";
	price = 0.0;
}

Case::Case(string ff, string c, double p)
{
	formfactor = ff;
	color = c;
	price = p;
}

void Case::setcolor(const string& c)
{
	color = c;
}

void Case::setprice(double p)
{
	price = p;
}

void Case::setformfactor(const string& ff)
{
	formfactor = ff;
}

string Case::getformfactor() const 
{
	return formfactor;
}

string Case::getcolor() const 
{
	return color;
}

void Case::seta(Computerassembly* assembly)
{
	a = assembly;
}

double Case::getprice() const 
{
	return price;
}

double Case::totalprice(Computerassembly* assembly)const
{
	return price + assembly->gettotalprice();
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
Computer::Computer()
{
	c = nullptr;
}

void Computer::setcomputer(Case& cases)
{
	c = &cases;
}
