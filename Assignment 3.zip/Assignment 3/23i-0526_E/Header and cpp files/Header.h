#pragma once
#include <iostream>
using namespace std;

void Cascading(string& a);