#pragma once

#include <string>

class PowerSupply {
private:
    int wattage;
    std::string efficiencyRating;
    double price;

public:
    // Default Constructor
    PowerSupply();

    // Parameterized Constructor
    PowerSupply(int w, const std::string& e, double p);

    // Getters
    int getWattage() const;
    std::string getEfficiencyRating() const;
    double getPrice() const;

    // Setters
    void setWattage(int w);
    void setEfficiencyRating(const std::string& e);
    void setPrice(double p);
};
