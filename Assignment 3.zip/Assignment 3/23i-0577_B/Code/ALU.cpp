#include "ALU.h"
    // Default Constructor using initializer list
    ALU::ALU() : NoOfAdders(0), NoOfSubtractor(0), NoOfRegisters(0), sizeOfRegisters(0) {}

    // Parameterized Constructor using initializer list
    ALU::ALU(int add, int sub, int reg, int sizereg)
        : NoOfAdders(add), NoOfSubtractor(sub), NoOfRegisters(reg), sizeOfRegisters(sizereg) {}

    // Getters
    int ALU::getNoOfAdders() const {
        return NoOfAdders;
    }   
    int ALU::getNoOfSubtractors() const {
        return NoOfSubtractor;
    }
    int ALU::getNoOfRegisters() const {
        return NoOfRegisters;
    }
    int ALU::getSizeOfRegisters() const {
        return sizeOfRegisters;
    }

    // Setters
    void ALU::setNoOfAdders(int adders) {
        NoOfAdders = adders;
    }
    void ALU::setNoOfSubtractors(int subtract) {
        NoOfSubtractor = subtract;
    }
    void ALU::setNoOfRegisters(int registers) {
        NoOfRegisters = registers;
    }
    void ALU::setSizeOfRegisters(int regSize) {
        sizeOfRegisters = regSize;
    }