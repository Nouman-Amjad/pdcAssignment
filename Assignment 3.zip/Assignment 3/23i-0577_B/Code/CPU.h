#pragma once

#include "ALU.h"
#include "ControlUnit.h"
#include"../A3/GraphicsCard.h"
#include <string>

class CPU {
private:
    ALU* alu;
    ControlUnit* cu;
    std::string type;
    bool hasIntegratedGPU;
    double Price;
public:
    // Constructors
    CPU();
    CPU(ALU* a, ControlUnit* b);

    // Destructor to manage composed objects
    //~CPU();

    // Getters
    ALU* get_ALU() const;
    ControlUnit* get_cu() const;
    std::string getType() const;
    bool getHasIntegratedGPU() const;

    // Setters
    void set_ALU(ALU* a);
    void set_cu(ControlUnit* b);
    void setCPUType(const std::string& type);
    void set_Price(double a);
    double get_Price();
    void setSystemType(const std::string& systemType);
    // Choose CPU type based on system type
    void configureALU(int adders, int subtractors, int registers, int size);
    void configureCU(float clockSpeed);
    void displayALUDetails() const;
    void displayCUDetails() const;
};
