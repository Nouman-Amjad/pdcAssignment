#include "MainMemory.h"

// Default Constructor
MainMemory::MainMemory()
    : capacity(1), technologyType("") {}

// Parameterized Constructor
MainMemory::MainMemory(int cap, const std::string& tech)
    : capacity(cap), technologyType(tech) {}

// Setters
void MainMemory::setCapacity(int cap) {
    capacity = cap;
}

void MainMemory::setTechnologyType(const std::string& tech) {
    technologyType = tech;
}

// Getters
int MainMemory::getCapacity() const {
    return capacity;
}

std::string MainMemory::getTechnologyType() const {
    return technologyType;
}
