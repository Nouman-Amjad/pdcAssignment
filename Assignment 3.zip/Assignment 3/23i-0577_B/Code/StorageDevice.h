#pragma once

#include <string>

class StorageDevice {
private:
    std::string type;
    int capacity;
    double price;

public:
    // Default Constructor
    StorageDevice();

    // Parameterized Constructor
    StorageDevice(const std::string& type, int capacity, double price);

    // Getters
    std::string getType() const;
    int getCapacity() const;
    double getPrice() const;

    // Setters
    void setType(const std::string& type);
    void setCapacity(int capacity);
    void setPrice(double price);
};


