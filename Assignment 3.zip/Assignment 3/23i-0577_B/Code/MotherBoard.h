#pragma once

#include "../A3/MainMemory.h"
#include "../A3/Port.h"

class MotherBoard {
private:
    MainMemory* mm;
    Port* ports;

public:
    // Default Constructor
    MotherBoard();

    // Parameterized Constructor
    MotherBoard(MainMemory* m, Port* p);
};
