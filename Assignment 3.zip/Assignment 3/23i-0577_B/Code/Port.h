#pragma once

#include <string>

class Port {
private:
    std::string type;
    int baud_rate;

public:
    // Default Constructor
    Port();

    // Parameterized Constructor
    Port(const std::string& type, int baud);

    // Getter for type
    std::string getType() const;

    // Setter for type
    void setType(const std::string& t);

    // Getter for baud rate
    int getBaudRate() const;

    // Setter for baud rate
    void setBaudRate(int baud);
};
