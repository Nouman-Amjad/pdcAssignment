#include "Case.h"

// Default Constructor using initializer list
Case::Case() : formFactor(""), color("") {}

// Parameterized Constructor using initializer list
Case::Case(const std::string& a, const std::string& b)
    : formFactor(a), color(b) {}

// Getters
std::string Case::get_formFactor() const {
    return formFactor;
}

std::string Case::get_color() const {
    return color;
}

// Setters
void Case::set_formFactor(const std::string& a) {
    formFactor = a;
}

void Case::set_color(const std::string& b) {
    color = b;
}

void Case::set_Price(double a)
{
    price = a;
}

double Case::get_Price()
{
    return price;
}
