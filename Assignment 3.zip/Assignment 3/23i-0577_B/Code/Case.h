#pragma once
#include <string>

class Case {
private:
    std::string formFactor;
    std::string color;
    double price;
public:
    // Default Constructor
    Case();

    // Parameterized Constructor
    Case(const std::string& a, const std::string& b);

    // Getters
    std::string get_formFactor() const;
    std::string get_color() const;

    // Setters
    void set_formFactor(const std::string& a);
    void set_color(const std::string& b);
    void set_Price(double a);
    double get_Price();
};
