#pragma once

#include <string>
#include "../A3/CPU.h"
#include "../A3/MotherBoard.h"
#include "../A3/PhysicalMemory.h"

class Computer {
private:
    PhysicalMemory* pm;
    MotherBoard* mb;
    CPU* cpu;

public:
    // Default Constructor
    Computer();

    // Parameterized Constructor
    Computer(PhysicalMemory* a, MotherBoard* b, CPU* c);

    // Getters and Setters
    PhysicalMemory* get_PhysicalMemory() const;
    void set_PhysicalMemory(PhysicalMemory* a);
    // Getters and Setters
    MotherBoard* get_MotherBoard() const;
    void set_MotherBoard(MotherBoard* b);

    CPU* get_CPU() const;
    void set_CPU(CPU* c);
};
