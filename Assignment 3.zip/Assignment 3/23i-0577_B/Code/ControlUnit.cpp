#include "ControlUnit.h"

// Constructor with default parameter
ControlUnit::ControlUnit(float clk) : clock(clk) {}

// Getter for clock
float ControlUnit::getClock() const {
    return clock;
}

// Setter for clock
void ControlUnit::setClock(float clk) {
    clock = clk;
}
