#include "NetworkCard.h"

// Default Constructor
NetworkCard::NetworkCard() : type(""), speed(0), price(0.0) {}

// Parameterized Constructor
NetworkCard::NetworkCard(const std::string& t, int s, double p)
    : type(t), speed(s), price(p) {}

// Getters
std::string NetworkCard::getType() const {
    return type;
}

int NetworkCard::getSpeed() const {
    return speed;
}

double NetworkCard::getPrice() const {
    return price;
}

// Setters
void NetworkCard::setType(const std::string& t) {
    type = t;
}

void NetworkCard::setSpeed(int s) {
    speed = s;
}

void NetworkCard::setPrice(double p) {
    price = p;
}
