#pragma once

class ALU {
private:
    int NoOfAdders;
    int NoOfSubtractor;
    int NoOfRegisters;
    int sizeOfRegisters;

public:
    // Constructors
    ALU();
    ALU(int add, int sub, int reg, int sizereg);

    // Getters
    int getNoOfAdders() const;
    int getNoOfSubtractors() const;
    int getNoOfRegisters() const;
    int getSizeOfRegisters() const;

    // Setters
    void setNoOfAdders(int adders);
    void setNoOfSubtractors(int subtract);
    void setNoOfRegisters(int registers);
    void setSizeOfRegisters(int regSize);

};
