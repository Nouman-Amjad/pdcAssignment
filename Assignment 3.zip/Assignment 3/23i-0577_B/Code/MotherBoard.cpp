#include "MotherBoard.h"

// Default Constructor
MotherBoard::MotherBoard() : mm(nullptr), ports(nullptr) {}

// Parameterized Constructor
MotherBoard::MotherBoard(MainMemory* m, Port* p) : mm(m), ports(p) {}
