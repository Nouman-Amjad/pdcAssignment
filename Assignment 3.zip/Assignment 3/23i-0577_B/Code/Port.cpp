#include "Port.h"

// Default Constructor
Port::Port() : type(""), baud_rate(1) {}

// Parameterized Constructor
Port::Port(const std::string& type, int baud)
    : type(type), baud_rate(baud) {}

// Getter for type
std::string Port::getType() const {
    return type;
}

// Setter for type
void Port::setType(const std::string& t) {
    type = t;
}

// Getter for baud rate
int Port::getBaudRate() const {
    return baud_rate;
}

// Setter for baud rate
void Port::setBaudRate(int baud) {
    baud_rate = baud;
}
