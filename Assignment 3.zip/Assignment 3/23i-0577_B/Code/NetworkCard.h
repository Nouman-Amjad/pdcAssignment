#pragma once

#include <string>

class NetworkCard {
private:
    std::string type;
    int speed;
    double price;

public:
    // Default Constructor
    NetworkCard();

    // Parameterized Constructor
    NetworkCard(const std::string& t, int s, double p);

    // Getters
    std::string getType() const;
    int getSpeed() const;
    double getPrice() const;

    // Setters
    void setType(const std::string& t);
    void setSpeed(int s);
    void setPrice(double p);
};
