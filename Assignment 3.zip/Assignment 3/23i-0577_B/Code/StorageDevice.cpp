#include "StorageDevice.h"

// Default Constructor
StorageDevice::StorageDevice()
    : type(""), capacity(0), price(0.0) {}

// Parameterized Constructor
StorageDevice::StorageDevice(const std::string& type, int capacity, double price)
    : type(type), capacity(capacity), price(price) {}

// Getters
std::string StorageDevice::getType() const {
    return type;
}

int StorageDevice::getCapacity() const {
    return capacity;
}

double StorageDevice::getPrice() const {
    return price;
}

// Setters
void StorageDevice::setType(const std::string& type) {
    this->type = type;
}

void StorageDevice::setCapacity(int capacity) {
    this->capacity = capacity;
}

void StorageDevice::setPrice(double price) {
    this->price = price;
}
