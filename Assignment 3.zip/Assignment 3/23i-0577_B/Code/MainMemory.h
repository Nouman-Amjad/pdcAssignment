#pragma once

#include <string>

class MainMemory {
private:
    int capacity;
    std::string technologyType;

public:
    // Default Constructor
    MainMemory();

    // Parameterized Constructor
    MainMemory(int cap, const std::string& tech);

    // Setters
    void setCapacity(int cap);
    void setTechnologyType(const std::string& tech);

    // Getters
    int getCapacity() const;
    std::string getTechnologyType() const;
};
