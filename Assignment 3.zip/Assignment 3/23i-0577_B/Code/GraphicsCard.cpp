#include "GraphicsCard.h"

GraphicsCard::GraphicsCard() : brand("Unknown"), memorySize(0), price(0.0), isDiscrete(true) {}
//setters
void GraphicsCard::setBrand(const std::string& brand) {
    this->brand = brand;
}

void GraphicsCard::setMemorySize(int memorySize) {
    this->memorySize = memorySize;
}

void GraphicsCard::setPrice(double price) {
    this->price = price;
}

void GraphicsCard::setIsDiscrete(bool isDiscrete) {
    this->isDiscrete = isDiscrete;
}
//getters
std::string GraphicsCard::getBrand() const {
    return brand;
}

int GraphicsCard::getMemorySize() const {
    return memorySize;
}

double GraphicsCard::getPrice() const {
    return price;
}

bool GraphicsCard::getIsDiscrete() const {
    return isDiscrete;
}
//setter
void GraphicsCard::setGPUByCPU(const std::string& cpuType) {
    if (cpuType == "AppleSilicon") {
        setBrand("AppleGPU");
        setMemorySize(8);  
        setPrice(0);       
        setIsDiscrete(false);
    }
    else {
        setBrand("Nvidia");  
        setMemorySize(6);   
        setPrice(300);     
        setIsDiscrete(true);
    }
}
