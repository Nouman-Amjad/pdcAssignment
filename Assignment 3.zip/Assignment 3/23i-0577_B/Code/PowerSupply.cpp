#include "PowerSupply.h"

// Default Constructor
PowerSupply::PowerSupply() : wattage(0), efficiencyRating(""), price(0.0) {}

// Parameterized Constructor
PowerSupply::PowerSupply(int w, const std::string& e, double p)
    : wattage(w), efficiencyRating(e), price(p) {}

// Getters
int PowerSupply::getWattage() const {
    return wattage;
}

std::string PowerSupply::getEfficiencyRating() const {
    return efficiencyRating;
}

double PowerSupply::getPrice() const {
    return price;
}

// Setters
void PowerSupply::setWattage(int w) {
    wattage = w;
}

void PowerSupply::setEfficiencyRating(const std::string& e) {
    efficiencyRating = e;
}

void PowerSupply::setPrice(double p) {
    price = p;
}
