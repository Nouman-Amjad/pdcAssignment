#pragma once

class Battery {
private:
    int capacity; // Capacity of the battery
    double price;
public:
    // Constructors
    Battery();
    Battery(int bat);

    // Getter
    int get_battery() const;

    // Setter
    void set_battery(int a);
    void set_Price(double a);
    double get_Price();
};
