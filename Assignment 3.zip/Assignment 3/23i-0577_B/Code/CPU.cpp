#include "CPU.h"
#include <iostream>
using namespace std;
// default constructors
CPU::CPU() : alu(nullptr), cu(nullptr), type("Unknown"), hasIntegratedGPU(false) {}
// Parameterized Constructor
CPU::CPU(ALU* a, ControlUnit* b) : alu(a), cu(b), type("Unknown"), hasIntegratedGPU(false) {}


//getters
ALU* CPU::get_ALU() const {
    return alu;
}

ControlUnit* CPU::get_cu() const {
    return cu;
}

std::string CPU::getType() const {
    return type;
}

bool CPU::getHasIntegratedGPU() const {
    return hasIntegratedGPU;
}
//settter
void CPU::set_ALU(ALU* a) {
    delete alu;  
    alu = a;
}

void CPU::set_cu(ControlUnit* b) {
    delete cu; 
    cu = b;
}

void CPU::setCPUType(const std::string& type) {
    this->type = type;
    if (type == "AppleSilicon") {
        hasIntegratedGPU = true;
    }
    else {
        hasIntegratedGPU = false;
    }
    std::cout << "CPU type set to " << type << (hasIntegratedGPU ? " with integrated GPU." : ".") << std::endl;
}
//getters
void CPU::set_Price(double a)
{
    Price = a;
}

double CPU::get_Price()
{
    return Price;
}

void CPU::setSystemType(const std::string& systemType) {
    if (systemType == "PC") {
        setCPUType("Intel/AMD"); // Default to Intel/AMD for PC and offer choice for Custom
    }
    else if (systemType == "Mac") {
        setCPUType("AppleSilicon");
    }
    else if (systemType == "Custom") {
        while (true) {
            std::cout << "\nEnter your choice\n1: Intel/AMD\n2: AppleSilicon\n" << std::endl;
            int get;
            cin >> get;
            if (get == 1) {
                while (true) {
                    int set;
                    cout << "\n1: Intel\n2: AMD\n";
                    cin >> set;
                    if (set == 1) {
                        setCPUType("Intel"); break;
                    }
                    else if (set == 2) {
                        setCPUType("AMD"); break;
                    }
                    cout << "Enter again\n";

                }
            }
            else if (get == 2) {
                setCPUType("AppleSilicon"); break;
            }
            cout << "Invalid Input! Enter Again\n";
        }
    }
    
    // sssume prices are predefined differently for each type
    set_Price(systemType == "Mac" ? 300 : 200);
}
//configure
void CPU::configureALU(int adders, int subtractors, int registers, int size) {
    alu->setNoOfAdders(adders);
    alu->setNoOfSubtractors(subtractors);
    alu->setNoOfRegisters(registers);
    alu->setSizeOfRegisters(size);
}

void CPU::configureCU(float clockSpeed) {
    cu->setClock(clockSpeed);
}
//display
void CPU::displayALUDetails() const {
    if (alu) {
        std::cout << "\tALU:\n";
        std::cout << "\t\tAdders: " << alu->getNoOfAdders() << "\n";
        std::cout << "\t\tSubtractors: " << alu->getNoOfSubtractors() << "\n";
        std::cout << "\t\tRegisters: " << alu->getNoOfRegisters() << "\n";
        std::cout << "\t\tRegister Size: " << alu->getSizeOfRegisters() << " bits\n";
    }
    else {
        std::cout << "\tALU is not configured.\n";
    }
}

void CPU::displayCUDetails() const {
    if (cu) {
        std::cout << "\tControl Unit:\n";
        std::cout << "\t\tClock Speed: " << cu->getClock() << " GHz\n";
    }
    else {
        std::cout << "\tControl Unit is not configured.\n";
    }
}


