#pragma once

class ControlUnit {
private:
    float clock;

public:
    // Constructor with default parameter
    ControlUnit(float clk = 1.0f);

    // Getter for clock
    float getClock() const;

    // Setter for clock
    void setClock(float clk);
};
