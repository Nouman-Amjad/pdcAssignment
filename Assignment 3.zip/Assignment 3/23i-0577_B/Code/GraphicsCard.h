#pragma once

#include <string>

class GraphicsCard {
private:
    std::string brand;
    int memorySize; 
    double price;    
    bool isDiscrete; 

public:
    GraphicsCard();

    // Setters
    void setBrand(const std::string& brand);
    void setMemorySize(int memorySize);
    void setPrice(double price);
    void setIsDiscrete(bool isDiscrete);

    // Getters
    std::string getBrand() const;
    int getMemorySize() const;
    double getPrice() const;
    bool getIsDiscrete() const;

    // Method to automatically set GPU attributes based on CPU type
    void setGPUByCPU(const std::string& cpuType);
};
