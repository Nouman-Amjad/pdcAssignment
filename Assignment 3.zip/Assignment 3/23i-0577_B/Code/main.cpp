//Name: Shahzad Ahmad
//Roll-No: 23i-0577
//Section: CS(B)
//Subject: oop A3
//Instructor: Zeehshan Ali
// TA: Muhammad Mohsin ramzan
#include <iostream>
#include <string>
#include <cmath>
#include <limits>
#include "ComputerAssembly.h"
#include <iomanip>
#include"../A3/Computer.h"
#include"../A3/MotherBoard.h"
#include"../A3/Computer.h"
using namespace std;
//validations for the input integers, strings and capacity
void clearInput() {
    cin.clear();
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
}

int getValidatedInteger(const string& prompt) {
    int value;
    cout << prompt;
    while (!(cin >> value) || value <= 0) {
        cout << "Invalid input, please enter a valid positive integer.\n";
        clearInput();
        cout << prompt;
    }
    clearInput();
    return value;
}

bool isPowerOfTwo(int x) {
    return x > 0 && (x & (x - 1)) == 0;
}

std::string getValidatedString(const std::string& prompt) {
    std::string input;
    std::cout << prompt;
    getline(std::cin, input);
    while (input.empty()) {
        std::cout << "Invalid input, please enter a non-empty string.\n";
        std::cout << prompt;
        getline(std::cin, input);
    }
    return input;
}
//Physical Memory configurations
bool configurePhysicalMemory(PhysicalMemory& pm) {
    cout << "Configure Physical Memory:\n";
    int capacity = getValidatedInteger("Enter capacity of Physical Memory in GB (power of 2): ");
    if (!isPowerOfTwo(capacity)) {
        cout << "Error: Capacity must be a power of 2.\n";
        return false;
    }
    // settin the capacity in the class
    pm.setCapacity(capacity);
    cout << endl;
    return true;
}

// Graphics Card
bool configureGraphicsCard(GraphicsCard& gpu) {
    cout << endl;
    return true;
}
// CPU
bool configureCPU(CPU& cpu) {
    // taking inpputs to built cpu
    int adders = getValidatedInteger("Enter number of adders: ");
    int subtractors = getValidatedInteger("Enter number of subtractors: ");
    int registers = getValidatedInteger("Enter number of registers: ");
    int size = getValidatedInteger("Enter size of registers (in bits): ");
    cout << "Enter clock speed (in GHz): ";
    float clockSpeed;
    cin >> clockSpeed;
    clearInput();
    cout << endl;
    return true;
}
// Storage  configuration
bool configureStorageDevice(StorageDevice& storage) {
    cout << "Configure Storage Device:\n";
    string type;
    while (true) {
        // asking type of device
        cout << "Enter Storage Device type\n1: HDD\n2: SSD\n";
        int get;
        cin >> get;
        if (get == 1) {
            type = "HDD"; 
            break;
        }
        else if(get == 2) {
            type = "SSD";
            break;
        }
        cout << "Invalid Input! Enter again" << endl;
    }
    // If HDD is chosen

    if (type == "HDD") {
        while (true) {
            cout << "type of HDD?\n1: Consumer HDD\n2: NAS HDD\n";
            int get;
            cin >> get;
            if (get == 1) {
                type = "Consumer HDD"; break;
            }
            else if(get==2 ){
                type = "NAS SSD"; break;
            }
            cout << "\nInvalid Input! Enter again" << endl;
        }
    }
    // validating
    int capacity = getValidatedInteger("Storage Device capacity in GB: ");

    double price = 0;
    if (type == "SSD") {
        price = 12;
    }
    else if (type == "Consumer HDD") {
        price = 5;
    }
    else if (type == "NAS HDD") {
        price = 7; 
    }
// setters
    storage.setType(type);
    storage.setCapacity(capacity);
    storage.setPrice(price*capacity);
    cout << endl;
    return true; 
}
//Main memory
MainMemory* configureMainMemory() {
    string technology;
    int choice;
    int capacity = getValidatedInteger("Main Memory in GB (power of 2): ");
    while (true) {
        cout << "technology type:\n1: Semiconductor\n2:Silicon\n" << endl;
        cin >> choice;
        if (choice == 1) {
            technology = "Semiconductor"; break;
        }
        else if(choice == 2){
            technology = "Silicon"; break;
        }
        cout << "\nInvalid Input! Enter again" << endl;
    }
  // returning a object
    return new MainMemory(capacity, technology);
}

// Port
bool configurePort() {
    std::string type;
    while (true) {
        std::cout << "Enter port type \n1: VGI\n2: I/O\n3: USB\n4: HDMI\n";
        int get;
        cin >> get;
        // asking type of port user wants
        if (get == 1) {
            type = "VGI"; break;
        }
        else if (get == 2) {
            type = "I/O"; break;
        }
        else if (get == 3) {
            type = "USB"; break;
        }
        else if (get == 4){
            type = "HDMI"; break;
    }
        cout << "\nInvalid Input! Enter again" << endl;
    }// then settig the bandwidht
    if (type == "USB" || type == "HDMI" || type == "I/O" || type == "VGI") {
        cout << "Enter port bandwidth (Mbps): ";
        int bandwidth;
        cin >> bandwidth;
        clearInput();
        Port p(type, bandwidth); 
        return true;
    }
    else {
        return false;
    }
}
// Network Card
bool configureNetworkCard(NetworkCard& networkCard) {
    cout << "Configure Network Card:\n";
    string type;
    while (true) {
        int select;
        cout << "Enter Network Card type\n1: Ethernet\n2: Wi-Fi\n";
        cin >> select;
        if (select == 1) {
            type = "Ethernet"; break;
        }
        else if (select == 2) {
            type = "Wi-Fi"; break;
        }
        cout << "\nInvalid Input! Enter again" << endl;
    }
    int speed = getValidatedInteger("Enter Network Card speed in Mbps: ");
    //setters calling
    networkCard.setType(type);
    networkCard.setSpeed(speed);
    networkCard.setPrice(25);
    return true;
}
// Power Supply
bool configurePowerSupply(PowerSupply& power) {
    cout << "Power Supply:\n";
    int wattage = getValidatedInteger("Power Supply wattage in watts: ");
    string efficiencyRating;
    int get;
        cout << "\nPower Supply efficiency rating:\n1: 80 Plus Bronze\n2: 80 Plus Gold\n" << endl;
        cin >> get;
        if (get %2 ==  0) {
            efficiencyRating = "80 Plus Bronze";
        }
        else if (get%2 == 1) {
            efficiencyRating = "80 Plus Gold";
        }
        // setters calling
    power.setWattage(wattage);
    power.setEfficiencyRating(efficiencyRating);
    power.setPrice(40);
    return true;
}
// Battery
bool configureBattery(Battery& battery) {
    cout << "Configure Battery:\n";
    int capacity = getValidatedInteger("Battery capacity in mAh: ");
    cout << endl;
    // setters calling
    battery.set_battery(capacity);
    battery.set_Price(5*capacity); 
    return true;
}
// Case
bool configureCase(Case& casee) {
    cout << "Configure Case:\n";
    string formFactor;
    cout << "Enter Case form factor\n1: ATX\n2: Micro ATX\n";
    int get;
    cin >> get;
    // asking user a type
    if(get%2==0)
        formFactor = "ATX";
    else
        formFactor = "Micro ATX";
    string color;
    cout << "Enter Case color: ";
    getline(cin, color);
    // setters calling
    casee.set_formFactor(formFactor);
    casee.set_color(color);
    casee.set_Price(70);
    cout << endl;
    return true;
}
// Total Price
double calculateTotalPrice(const ComputerAssembly& assembly) {
    return assembly.getPhysicalMemory().get_Price() +
        assembly.getCPU().get_Price() +
        assembly.getGraphicsCard().getPrice() +
        assembly.getStorageDevice().getPrice() +
        assembly.getNetworkCard().getPrice() +
        assembly.getPowerSupply().getPrice() +
        assembly.getBattery().get_Price() +
        assembly.getCase().get_Price();
}
// Display
void displayConfiguration(const ComputerAssembly& assembly) {
    cout << "Configuration Summary:\n"; 
    cout << endl;
    cout << "Physical Memory: " << assembly.getPhysicalMemory().get_Capacity() << " GB\n";
    cout << endl;
    cout << "CPU: " << assembly.getCPU().getType() << "\n";
    cout << endl;
    cout << "Graphics Card: " << assembly.getGraphicsCard().getBrand() << " " << assembly.getGraphicsCard().getMemorySize() << " GB\n";
    cout << endl;
    cout << "Storage Device: " << assembly.getStorageDevice().getType() << " " << assembly.getStorageDevice().getCapacity() << " GB\n";
    cout << endl;
    cout << "Network Card: " << assembly.getNetworkCard().getType() << " " << assembly.getNetworkCard().getSpeed() << " Mbps\n";
    cout << endl;
    cout << "Power Supply: " << assembly.getPowerSupply().getEfficiencyRating() << " " << assembly.getPowerSupply().getWattage() << " Watts\n";
    cout << endl;
    cout << "Battery: " << assembly.getBattery().get_battery() << " mAh\n";
    cout << endl;
    cout << "Case: " << assembly.getCase().get_formFactor() << " " << assembly.getCase().get_color() << "\n";
    cout << endl;
    cout << "Total Price: $" << calculateTotalPrice(assembly) << endl;
}

int main() {
    // asking user type
    int systemChoice;
    do {
        cout << "Select the type of computer to configure:\n";
        cout << "1. PC\n";
        cout << "2. Mac\n";
        cout << "3. Custom\n";
        cin >> systemChoice;
        
    } while (systemChoice != 1 && systemChoice != 2 && systemChoice != 3);
    string systemType = (systemChoice == 1) ? "PC" : (systemChoice == 2) ? "Mac" : "Custom";
// objects
    ComputerAssembly computerAssembly;
    PhysicalMemory pm;
    ALU alu;
    ControlUnit cu;
    CPU cpu;
    GraphicsCard gpu;
    StorageDevice storage;
    NetworkCard networkCard;
    PowerSupply powerSupply;
    Battery battery;
    Case casee;
    Computer computer;
    Port ports;
    MainMemory mainMemory;
    MotherBoard mb;

    // setters
    pm.setSystemType(systemType);
    cpu.setSystemType(systemType);
    gpu.setGPUByCPU(cpu.getType()); 
    cout << "\nPlease configure your computer assembly.\n";
    configureMainMemory();
   
    while (true) {
        
        if (configurePort() &&
            configurePhysicalMemory(pm) &&
            configureCPU(cpu)&&
            configureGraphicsCard(gpu) &&
            configureStorageDevice(storage) &&
            configureNetworkCard(networkCard) &&
            configurePowerSupply(powerSupply) &&
            configureBattery(battery) &&
            configureCase(casee)) {
            break;            
        }
        else {
            cout << "Incorrect input detected\n";
            clearInput();

        }
    }
    // Setters
    computerAssembly.setPhysicalMemory(pm);
    computerAssembly.setCPU(cpu);
    computerAssembly.setGraphicsCard(gpu);
    computerAssembly.setStorageDevice(storage);
    computerAssembly.setNetworkCard(networkCard);
    computerAssembly.setPowerSupply(powerSupply);
    computerAssembly.setBattery(battery);
    computerAssembly.setCase(casee);
    cout << endl << endl << endl;
    // Display function
    displayConfiguration(computerAssembly);

    return 0;
}