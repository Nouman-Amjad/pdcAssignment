#include "Computer.h"

// Default Constructor using initializer list
Computer::Computer() : pm(nullptr), mb(nullptr), cpu(nullptr) {}

// Parameterized Constructor using initializer list
Computer::Computer(PhysicalMemory* a, MotherBoard* b, CPU* c)
    : pm(a), mb(b), cpu(c) {}

// Getters
PhysicalMemory* Computer::get_PhysicalMemory() const {
    return pm;
}

MotherBoard* Computer::get_MotherBoard() const {
    return mb;
}


CPU* Computer::get_CPU() const {
    return cpu;
}

// Setters
void Computer::set_PhysicalMemory(PhysicalMemory* a) {
    pm = a;
}

void Computer::set_MotherBoard(MotherBoard* b) {
    mb = b;
}

void Computer::set_CPU(CPU* c) {
    cpu = c;
}
