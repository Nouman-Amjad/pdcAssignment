#pragma once
#include<string>
using namespace std;
class PhysicalMemory {
private:
    int capacity;
    double Price;
    string type;
public:
    // Default Constructor
    PhysicalMemory();

    // Parameterized Constructor
    PhysicalMemory(int a);

    // Getters
    int get_Capacity();
    double get_Price() const;

    // Setters
    void setCapacity(int a);
    void set_Price(double a);

    string getType();
    void setType(string a);
    void setSystemType(const std::string& systemType);

};
