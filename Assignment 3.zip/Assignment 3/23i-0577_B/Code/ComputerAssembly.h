#pragma once

#include "PhysicalMemory.h"
#include "MotherBoard.h"
#include "CPU.h"
#include "GraphicsCard.h"
#include "StorageDevice.h"
#include "NetworkCard.h"
#include "PowerSupply.h"
#include "Battery.h"
#include "Case.h"
#include"../A3/MotherBoard.h"
#include"../A3/Port.h"

class ComputerAssembly {
private:
    double totalPrice;
    PhysicalMemory pm;
    MotherBoard mb;
    CPU cpu;
    GraphicsCard gpu;
    StorageDevice storage;
    NetworkCard networkCard;
    PowerSupply power;
    Battery battery;
    Case casee;

public:
    // Default Constructor
    ComputerAssembly();

    // Parameterized Constructor
    ComputerAssembly(double price, const PhysicalMemory& pm, const MotherBoard& mb, const CPU& cpu,
        const GraphicsCard& gpu, const StorageDevice& storage, const NetworkCard& nc,
        const PowerSupply& power, const Battery& battery, const Case& casee);

    // Getters
    double getTotalPrice() const;
    PhysicalMemory getPhysicalMemory() const;
    MotherBoard getMotherBoard() const;
    CPU getCPU() const;
    GraphicsCard getGraphicsCard() const;
    StorageDevice getStorageDevice() const;
    NetworkCard getNetworkCard() const;
    PowerSupply getPowerSupply() const;
    Battery getBattery() const;
    Case getCase() const;

    // Setters
    void setTotalPrice(double price);
    void setPhysicalMemory(const PhysicalMemory& pm);
    void setMotherBoard(const MotherBoard& mb);
    void setCPU(const CPU& cpu);
    void setGraphicsCard(const GraphicsCard& gpu);
    void setStorageDevice(const StorageDevice& storage);
    void setNetworkCard(const NetworkCard& nc);
    void setPowerSupply(const PowerSupply& power);
    void setBattery(const Battery& battery);
    void setCase(const Case& casee);
};
