#include "ComputerAssembly.h"

// Default Constructor
ComputerAssembly::ComputerAssembly()
    : totalPrice(0), pm(), mb(), cpu(), gpu(), storage(), networkCard(), power(), battery(), casee() {}

// Parameterized Constructor
ComputerAssembly::ComputerAssembly(double price, const PhysicalMemory& pm, const MotherBoard& mb, const CPU& cpu,
    const GraphicsCard& gpu, const StorageDevice& storage, const NetworkCard& nc,
    const PowerSupply& power, const Battery& battery, const Case& casee)
    : totalPrice(price), pm(pm), mb(mb), cpu(cpu), gpu(gpu), storage(storage),
    networkCard(nc), power(power), battery(battery), casee(casee) {}

// Getters
double ComputerAssembly::getTotalPrice() const { 
    return totalPrice;
}
PhysicalMemory ComputerAssembly::getPhysicalMemory() const { 
    return pm; }
MotherBoard ComputerAssembly::getMotherBoard() const { return mb; 
}
CPU ComputerAssembly::getCPU() const { 
    return cpu;
}
GraphicsCard ComputerAssembly::getGraphicsCard() const { 
    return gpu;
}
StorageDevice ComputerAssembly::getStorageDevice() const { 
    return storage; 
}
NetworkCard ComputerAssembly::getNetworkCard() const { 
    return networkCard; 
}
PowerSupply ComputerAssembly::getPowerSupply() const { 
    return power; 
}
Battery ComputerAssembly::getBattery() const { 
    return battery;
}
Case ComputerAssembly::getCase() const { 
    return casee; 
}

// Setters
void ComputerAssembly::setTotalPrice(double price) { 
    totalPrice = price;
}
void ComputerAssembly::setPhysicalMemory(const PhysicalMemory& pm) { 
    this->pm = pm;
}
void ComputerAssembly::setMotherBoard(const MotherBoard& mb) { 
    this->mb = mb; 
}
void ComputerAssembly::setCPU(const CPU& cpu) { 
    this->cpu = cpu; 
}
void ComputerAssembly::setGraphicsCard(const GraphicsCard& gpu) { 
    this->gpu = gpu; 
}
void ComputerAssembly::setStorageDevice(const StorageDevice& storage) { 
    this->storage = storage;
}
void ComputerAssembly::setNetworkCard(const NetworkCard& nc) { 
    this->networkCard = nc; 
}
void ComputerAssembly::setPowerSupply(const PowerSupply& power) { 
    this->power = power; 
}
void ComputerAssembly::setBattery(const Battery& battery) {
    this->battery = battery; 
}

void ComputerAssembly::setCase(const Case& casee) { 
    this->casee = casee; 
}
