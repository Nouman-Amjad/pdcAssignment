#include "Battery.h"

// Default constructor with initializer list
Battery::Battery() : capacity(0) {}

// Parameterized constructor with initializer list
Battery::Battery(int bat) : capacity(bat) {}

// Getter for battery capacity
int Battery::get_battery() const {
    return capacity;
}

// Setter for battery capacity
void Battery::set_battery(int a) {
    capacity = a;
}

void Battery::set_Price(double a)
{
    price = a;
}

double Battery::get_Price()
{
    return price;
}
