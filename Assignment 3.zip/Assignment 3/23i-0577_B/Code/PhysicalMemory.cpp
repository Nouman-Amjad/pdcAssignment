#include "PhysicalMemory.h"
#include <string>
#include<iostream>
using namespace std;

// Default Constructor
PhysicalMemory::PhysicalMemory() : capacity(0), Price(0) {}

// Parameterized Constructor
PhysicalMemory::PhysicalMemory(int a) : capacity(a) {}

// Getter for capacity
int PhysicalMemory::get_Capacity() {
    return capacity;
}

// Getter for price
double PhysicalMemory::get_Price() const {
    return Price;
}

// Setter for capacity
void PhysicalMemory::setCapacity(int a) {
    capacity = a;
}

// Setter for price
void PhysicalMemory::set_Price(double a) {
    Price = a;
}

string PhysicalMemory::getType()
{
    return type;
}

void PhysicalMemory::setType(string a)
{
    type = a;
}


void PhysicalMemory::setSystemType(const std::string& systemType) {
    if (systemType == "PC") {
        setType("DDR4/5"); // Default to DDR4/5 for PC and offer choice for Custom
    }
    else if (systemType == "Mac") {
        setType("LPDDR4/5");
    }
    else if (systemType == "Custom") {
        while (true) {
            std::cout << "\nEnter your choice\n1: DDR4/5\n2: LPDDR4/5\n" << std::endl;
            int get;
            cin >> get;
            if (get == 1) {
                setType("DDR4/5"); break;
            }
            else if (get == 2) {
                setType("LPDDR4/5"); break;
            }
            cout << "Invalid Input! Enter Again\n";
        }
    }
    // Set prices accordingly
    set_Price(systemType == "Mac" ? 10*capacity : 15*capacity);
}
