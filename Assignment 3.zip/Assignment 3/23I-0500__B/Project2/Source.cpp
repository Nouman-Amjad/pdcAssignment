#include <iostream>
#include <string>
#include "../Project2/Header.h"
using namespace std;

/*
Name: Rehan Akram
Section: CS-B
Roll No.: 23I-0500
Instructor: Sir Ali Raza
TA: Mohsin Raza
*/
ALU::ALU() {
	noOfAdders = 3; noOfSubtractors = 3; noOfRegisters = 3; registerSize = 32;

}

ALU::ALU(int a, int b, int c, int d) {
	noOfAdders = a; noOfSubtractors = b; noOfRegisters = c; registerSize = d;

}

int ALU::getnoOfAdders()
{
	return noOfAdders;
}

int ALU::getnoOfSubtractors()
{
	return noOfSubtractors;
}

int ALU::getnoOfRegisters()
{
	return noOfRegisters;
}

int ALU::getregisterSize()
{
	return registerSize;
}

void ALU::setnoOfAdders(int x)
{
	noOfAdders = x;
}

void ALU::setnoOfSubtractors(int x)
{
	noOfSubtractors = x;
}

void ALU::setnoOfRegisters(int x)
{
	noOfRegisters = x;
}

void ALU::setregisterSize(int x)
{
	registerSize = x;
}

CU::CU()
{
	clock = 0;
}

CU::CU(float x)
{
	clock = x;
}

float CU::getClock()
{
	return clock;
}

void CU::setClock(float x)
{
	clock = x;
}

Port::Port()
{
	type = ""; baud_rate = 0;
}

Port::Port(string x, int y)
{
	type = x; baud_rate = y;
}

string Port::getype()
{
	return type;
}

int Port::getbaud_rate()
{
	return baud_rate;
}

void Port::settype(string x)
{
	type = x;
}

void Port::setbaud_rate(int x)
{
	baud_rate = x;
}

CPU::CPU()
{
	price = 0;
	architecture = ' ';
}

CPU::CPU(ALU x, CU y, double z, string s)
{
	alu = x;
	cu = y;
	price = z;
	architecture = s;
}

ALU CPU::getALU()
{
	return alu;
}

CU CPU::getCU()
{
	return cu;
}

double CPU::getprice()
{
	return price;
}

string CPU::getarchitecture()
{
	return architecture;
}

void CPU::setALU(ALU x)
{
	alu = x;
}

void CPU::setCU(CU x)
{
	cu = x;
}

void CPU::setprice()
{
	if (architecture == "AMD Ryzen 9 7950X")
		price = 540.99;
	if (architecture == "Intel Core I9-13900")
		price = 569.97;
	if (architecture == "AMD Ryzen 9 5950X")
		price = 441.71;
	if (architecture == "Intel Core I7-13700")
		price = 407.99;
	if (architecture == "Apple M2")
		price = 789.00;
}

void CPU::setarchitecture(string x)
{
	architecture = x;
}

MainMemory::MainMemory()
{
	capacity = 0;
	techType = "";
	price = 0;
}

MainMemory::MainMemory(int x, string y, double z)
{
	capacity = x;
	techType = y;
	price = z;
}

int MainMemory::getcapacity()
{
	return capacity;
}

string MainMemory::gettechType()
{
	return techType;
}

double MainMemory::getprice()
{
	return price;
}

void MainMemory::setcapacity(int x)
{
	capacity = x;
}

void MainMemory::gettechType(string x)
{
	techType = x;
}

void MainMemory::setprice()
{
	price = 49.99;
}

Motherboard::Motherboard()
{
	mm = nullptr;
	price = 0.0;
}

Motherboard::Motherboard(MainMemory* x, Port& y, double z)
{
	mm = x;
	ports = y;
	price = z;
}

Motherboard::~Motherboard() {
	delete mm;
}

MainMemory* Motherboard::getMainMemory()
{
	return mm;
}

Port& Motherboard::getPorts()
{
	return ports;
}

double Motherboard::getPrice()
{
	return price;
}

void Motherboard::setMainMemory(MainMemory* x) {
	delete mm;
	mm = x;
}

void Motherboard::setPorts(Port& x)
{
	ports = x;
}

void Motherboard::setPrice()
{
	price = mm->getprice() + 50;
}

PhysicalMemory::PhysicalMemory()
{
	capacity = 0;
	price = 0.0;
	type = "";
}

PhysicalMemory::PhysicalMemory(int x, double y, string z)
{
	capacity = x;
	price = y;
	type = z;
}

int PhysicalMemory::getcapacity()
{
	return capacity;
}

double PhysicalMemory::getprice()
{
	return price;
}

string PhysicalMemory::gettype()
{
	return type;
}

void PhysicalMemory::setcapacity(int x)
{
	capacity = x;
}

void PhysicalMemory::setprice()
{
	if (type == "DDR4")
	{
		if (capacity == 8)
			price = 19.99;
		else if (capacity == 16)
			price = 39.99;
	}
	else if (type == "DDR5")
	{
		if (capacity == 8)
			price = 25.99;
		else if (capacity == 16)
		{
			price = 69.99;
		}
	}
}

void PhysicalMemory::settype(string x)
{
	type = x;
}

GraphicsCard::GraphicsCard()
{
	brand = "";
	price = 0;
	memorySize = 0;
}

GraphicsCard::GraphicsCard(string x, int z, double y)
{
	brand = x;
	memorySize = z;
	price = y;
}

string GraphicsCard::getbrand()
{
	return brand;
}

double GraphicsCard::getprice()
{
	return price;
}

int GraphicsCard::getmemorySize()
{
	return memorySize;
}

void GraphicsCard::setbrand(string x)
{
	brand = x;
}

void GraphicsCard::setprice()
{
	if (brand == "NVIDIA" && memorySize == 24)
		price = 1999.99;
	if (brand == "NVIDIA" && memorySize == 16)
		price = 1149.99;
	if (brand == "NVIDIA" && memorySize == 8)
		price = 599.99;
	if (brand == "AMD" && memorySize == 24)
		price = 2199.99;
	if (brand == "AMD" && memorySize == 16)
		price = 999.99;
	if (brand == "AMD" && memorySize == 8)
		price = 350.99;
	if (brand == "Apple GPU")
		price = 999.99;
}

void GraphicsCard::setmemorySize(int x)
{
	memorySize = x;
}

StorageDevice::StorageDevice()
{
	type = "";
	capacity = 0;
	price = 0;
}

StorageDevice::StorageDevice(string x, int y, double z)
{
	type = x;
	capacity = y;
	price = z;
}

string StorageDevice::gettype()
{
	return type;
}

int StorageDevice::getcapacity()
{
	return capacity;
}

double StorageDevice::getprice()
{
	return price;
}

void StorageDevice::settype(string x)
{
	type = x;
}

void StorageDevice::setcapacity(int x)
{
	capacity = x;
}

void StorageDevice::setprice()
{
	if (type == "HDD")
	{
		if (capacity == 512)
			price = 79.99;
		else if (capacity == 1024)
			price = 129.99;
	}
	else if (type == "SDD")
	{
		if (capacity == 512)
			price = 109.99;
		else if (capacity == 1024)
			price = 159.99;
	}
}

NetworkCard::NetworkCard()
{
	type = "";
	speed = 0;
	price = 0;
}

NetworkCard::NetworkCard(string x, int y, double z)
{
	type = x;
	speed = y;
	price = z;
}

string NetworkCard::gettype()
{
	return type;
}

int NetworkCard::getspeed()
{
	return speed;
}

double NetworkCard::getprice()
{
	return price;
}

void NetworkCard::settype(string x)
{
	type = x;
}

void NetworkCard::setspeed(int x)
{
	speed = x;
}

void NetworkCard::setprice()
{
	if (type == "Ethernet")
	{
		if (speed == 2.5)
			price = 24.99;
		else if (speed == 10)
			price = 94.99;
		else if (speed == 1)
			price = 9.99;
	}
	else if (type == "Wi-Fi")
	{
		if (speed == 6)
			price = 44.99;
		else if (speed == 10)
			price = 119.99;
		else if (speed == 5)
			price = 39.99;
		else if (speed == 2)
			price = 19.99;
		else if (speed == 25)
			price = 199.99;
		else if (speed == 15)
			price = 129.99;
	}
}

PowerSupply::PowerSupply()
{
	efficiencyRating = "";
	wattage = 0;
	price = 0;
}

PowerSupply::PowerSupply(string x, int y, double z)
{
	efficiencyRating = x;
	wattage = y;
	price = z;
}

string PowerSupply::getefficiencyRating()
{
	return efficiencyRating;
}

int PowerSupply::getwattage()
{
	return wattage;
}

double PowerSupply::getprice()
{
	return price;
}

void PowerSupply::setefficiencyRating(string x)
{
	efficiencyRating = x;
}

void PowerSupply::setwattage(int x)
{
	wattage = x;
}

void PowerSupply::setprice()
{
	if (efficiencyRating == "80 Plus Bronze") {
		if (wattage == 600)
			price = 54.99;
		else if (wattage == 450)
			price = 39.99;
		else if (wattage == 500)
			price = 44.99;
	}
	if (efficiencyRating == "80 Plus Gold") {
		if (wattage == 600)
			price = 94.99;
		else if (wattage == 450)
			price = 59.99;
		else if (wattage == 500)
			price = 74.99;
	}
}

Battery::Battery()
{
	capacity = 0;
	price = 0;
}

Battery::Battery(int y, double z)
{
	capacity = y;
	price = z;
}

int Battery::getcapacity()
{
	return capacity;
}

double Battery::getprice()
{
	return price;
}

void Battery::setcapacity(int x)
{
	capacity = x;
}

void Battery::setprice()
{
	if (capacity == 52000)
		price = 99.99;
	else if (capacity == 49900)
		price = 89.99;
	else if (capacity == 72900)
		price = 129.99;
	else if (capacity == 60000)
		price = 109.99;
}

Case::Case()
{
	formFactor = "";
	colour = "";
	price = 0;
}

Case::Case(string x, string y, double z)
{
	formFactor = x;
	colour = y;
	price = z;
}

string Case::getformFactor()
{
	return formFactor;
}

string Case::getcolour()
{
	return colour;
}

double Case::getprice()
{
	return price;
}

void Case::setformFactor(string x)
{
	formFactor = x;
}

void Case::setcolour(string x)
{
	colour = x;
}

void Case::setprice()
{
	if (formFactor == "ATX")
		price = 199.99;
	else if (formFactor == "mATX")
		price = 89.99;
	else if (formFactor == "ITX")
		price = 129.99;
	else if (formFactor == "E-ATX")
		price = 309.99;
}

ComputerAssembly::ComputerAssembly() : pm(), mm(), cpu(), sd(), ps(), c(), b(), nc(), gc() {
	TotalPrice = 0;
}

ComputerAssembly::ComputerAssembly(PhysicalMemory& PM, Motherboard& MM, CPU& Cpu, StorageDevice& SD,
	PowerSupply& PS, Case& C, Battery& B, NetworkCard& NC, GraphicsCard& GC)
{
	pm = PM;
	mm = MM;
	cpu = Cpu;
	sd = SD;
	ps = PS;
	c = C;
	b = B;
	nc = NC;
	gc = GC;
	TotalPrice = 0;
}

GraphicsCard& ComputerAssembly::getGraphicsCard()
{
	return gc;
}

PhysicalMemory& ComputerAssembly::getPhysicalMemory()
{
	return pm;
}

Motherboard& ComputerAssembly::getMotherboard()
{
	return mm;
}

CPU& ComputerAssembly::getCPU()
{
	return cpu;
}

StorageDevice& ComputerAssembly::getStorageDevice()
{
	return sd;
}

PowerSupply& ComputerAssembly::getPowerSupply()
{
	return ps;
}

Case& ComputerAssembly::getCase() {
	return c;
}

Battery& ComputerAssembly::getBattery()
{
	return b;
}

NetworkCard& ComputerAssembly::getNetworkCard()
{
	return nc;
}

double ComputerAssembly::getTotalPrice()
{
	return TotalPrice;
}

void ComputerAssembly::setGraphicsCard(GraphicsCard& GC)
{
	gc = GC;
}

void ComputerAssembly::setPhysicalMemory(PhysicalMemory& PM)
{
	pm = PM;
}

void ComputerAssembly::setMotherboard(Motherboard& MM)
{
	mm = MM;
}

void ComputerAssembly::setCPU(CPU& Cpu)
{
	cpu = Cpu;
}

void ComputerAssembly::setStorageDevice(StorageDevice& SD)
{
	sd = SD;
}

void ComputerAssembly::setPowerSupply(PowerSupply& PS)
{
	ps = PS;
}

void ComputerAssembly::setCase(Case& C)
{
	c = C;
}

void ComputerAssembly::setBattery(Battery& B)
{
	b = B;
}

void ComputerAssembly::setNetworkCard(NetworkCard& NC)
{
	nc = NC;
}

void ComputerAssembly::setTotalPrice()
{
	TotalPrice = mm.getPrice() + nc.getprice() + b.getprice() + c.getprice() + ps.getprice() + sd.getprice() + cpu.getprice()
		+ pm.getprice() + gc.getprice();
}

int main() {
	CPU cpu1; PhysicalMemory pm; GraphicsCard gc; StorageDevice sd; NetworkCard nc; PowerSupply ps; Battery b; Case c; Motherboard mm;
	int x; string y;
	cout << "Press 1 if you want to build a PC or 2 if you want to build a Mac.\n";
	cin >> x;
	while (x != 1 && x != 2) {
		cout << "\nPlease enter the correct input.\n";
		cin >> x;
	}
	if (x == 1)
	{
		cout << "Choose the products to build your PC. Let's begin with your CPU. Please choose from option 1 to 4.\n1. AMD Ryzen 9 7950X\n2. Intel Core I9-13900\n3.";
		cout << "AMD Ryzen 9 5950X\n4. Intel Core I7-13700\n";
		cin >> x;
		while (x != 1 && x != 2 && x != 3 && x != 4) {
			cout << "\nPlease enter the correct input.\n";
			cin >> x;
		}
		if (x == 1)
			cpu1.setarchitecture("AMD Ryzen 9 7950X");
		if (x == 2)
			cpu1.setarchitecture("Intel Core I9-13900");
		if (x == 3)
			cpu1.setarchitecture("AMD Ryzen 9 5950X");
		if (x == 4)
			cpu1.setarchitecture("Intel Core I7-13700");
		cout << "\nNow let's choose your preferred GPU.We will start off with the brand. Press 1 if you want the processor of NVIDIA or 2 if you prefer AMD\n";
		cin >> x;
		while (x != 1 && x != 2) {
			cout << "\nPlease enter the correct input.\n";
			cin >> x;
		}
		if (x == 1)
			gc.setbrand("NVIDIA");
		if (x == 2)
			gc.setbrand("AMD");
		cout << "\nNow let's choose your preferred Memory size. Press 1 to pick 24, 2 to pick 16, 3 to pick 8\n";
		cin >> x;
		while (x != 1 && x != 2 && x != 3) {
			cout << "\nplease enter the correct input.\n";
			cin >> x;
		}
		if (x == 1)
			gc.setmemorySize(24);
		if (x == 2)
			gc.setmemorySize(16);
		if (x == 3)
			gc.setmemorySize(8);
	}
	else {
		cpu1.setarchitecture("Apple M2");
		gc.setbrand("Apple");
	}
	cout << "\nNow let's choose which RAM you prefer.\n Press 1 if you want a DDR4 or 2 if you want a DDR5.\n";
	cin >> x;
	while (x != 1 && x != 2) {
		cout << "\nplease enter the correct input.\n";
		cin >> x;
	}
	if (x == 1)
		pm.settype("DDR4");
	if (x == 2)
		pm.settype("DDR5");
	cout << "\nNow let's choose the capacity.\n Press 1 if you want an 8GB or 2 if you want a 16GB.\n";
	cin >> x;
	while (x != 1 && x != 2) {
		cout << "\nplease enter the correct input.\n";
		cin >> x;
	}
	if (x == 1)
		pm.setcapacity(8);
	if (x == 2)
		pm.setcapacity(16);
	cout << "\nNow choose the storage that suits you. Press 1 if you want the SSD or 2 if you prefer HDD\n";
	cin >> x;
	while (x != 1 && x != 2) {
		cout << "\nplease enter the correct input.\n";
		cin >> x;
	}
	if (x == 1)
		sd.settype("SSD");
	if (x == 2)
		sd.settype("HDD");
	cout << "\nPress 1 if you want 512 GB or 2 if you prefer 1 TB\n";
	cin >> x;
	while (x != 1 && x != 2) {
		cout << "\nplease enter the correct input.\n";
		cin >> x;
	}
	if (x == 1)
		sd.setcapacity(512);
	if (x == 2)
		sd.setcapacity(1024);
	cout << "\nNow Press 1 if you want Wi-Fi for your network card or 2 if you want ethernet.\n";
	cin >> x;
	while (x != 1 && x != 2) {
		cout << "\nplease enter the correct input.\n";
		cin >> x;
	}
	if (x == 1)
	{
		nc.settype("Wi-Fi");
		cout << "Now type the speed you want. You can have choose from 2 Mbps, 5 Mbps, 6 Mbps, 10 Mbps, 15 Mbps, 25 Mbps.\n";
		cin >> x;
		while (x != 2 && x != 5 && x != 6 && x != 10 && x != 15 && x != 25) {
			cout << "\nPlease enter the correct input.\n";
			cin >> x;
		}
		nc.setspeed(x);
	}
	else
	{
		nc.settype("Ethernet");
		cout << "Now type the speed you want. You can have choose from 1 Mbps, 2.5 Mbps, 10 Mbps.\n";
		cin >> x;
		while (x != 1 && x != 2.5 && x != 10) {
			cout << "\nPlease enter the correct input.\n";
			cin >> x;
		}
		nc.setspeed(x);
	}
	cout << "\nNow choose your power supply. Press 1 for 80 Plus Bronze options and 2 for 80 Plus Gold options.\n";
	cin >> x;
	while (x != 1 && x != 2) {
		cout << "\nplease enter the correct input.\n";
		cin >> x;
	}
	if (x == 1)
	{
		ps.setefficiencyRating("80 Plus Bronze");
		cout << "Now type the wattage you want. You can have choose from 450, 500 or 600\n";
		cin >> x;
		while (x != 450 && x != 500 && x != 600) {
			cout << "\nPlease enter the correct input.\n";
			cin >> x;
		}
		ps.setwattage(x);
	}
	if (x == 2)
	{
		ps.setefficiencyRating("80 Plus Gold");
		cout << "Now type the wattage you want. You can have choose from 450, 500 or 600\n";
		cin >> x;
		while (x != 450 && x != 500 && x != 600) {
			cout << "\nPlease enter the correct input.\n";
			cin >> x;
		}
		ps.setwattage(x);
	}
	cout << "Now type the capacity of the battery you want. You can have choose from 49000 mah, 52000 mah, 60000 mah, 72900 mah.\n";
	cin >> x;
	while (x != 49000 && x != 52000 && x != 60000 && x != 72900) {
		cout << "\nPlease enter the correct input.\n";
		cin >> x;
	}
	b.setcapacity(x);
	cout << "Lastly choose your case.\n1. ATX\n2. mATX\n3. ITX\n4. E-ATX\n";
	cin >> x;
	while (x != 1 && x != 2 && x != 3 && x != 4) {
		cout << "\nPlease enter the correct input.\n";
		cin >> x;
	}
	switch (x)
	{
	case 1:
		c.setformFactor("ATX");
		break;
	case 2:
		c.setformFactor("mATX");
		break;
	case 3:
		c.setformFactor("ITX");
		break;
	case 4:
		c.setformFactor("E-ATX");
		break;
	}
	cout << "Type the colour of your case.\n";
	cin >> y;
	c.setcolour(y);
	c.setprice(); pm.setprice(); cpu1.setprice(); sd.setprice(); ps.setprice(); b.setprice(); nc.setprice(); gc.setprice();
	ComputerAssembly C(pm, mm, cpu1, sd, ps, c, b, nc, gc);
	C.setTotalPrice();
	cout << "Total price: " << C.getTotalPrice();
	cout << "\nYour device has the following specifications:\n1. CPU: " << cpu1.getarchitecture() << "\n2. GPU: " << gc.getbrand() << "  " << gc.getmemorySize() << "\n3. ";
	cout << pm.getcapacity() << " GB RAM\n4. Storage: " << sd.gettype() << "  " << sd.getcapacity() << " GB\n5. Network card: " << nc.gettype() << "  " << nc.getspeed() << "\n6. Power Supply: ";
	cout << ps.getwattage() << "watts with " << ps.getefficiencyRating() << "\n7. Battery: " << b.getcapacity() << "mah\n8. Case:" << c.getformFactor() << " in " << c.getcolour();

	return 0;
}