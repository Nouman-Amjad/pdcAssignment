#pragma once
#include <iostream>
#include <string>
using namespace std;

class ALU {
private:
	int noOfAdders;	int noOfSubtractors; int noOfRegisters; int registerSize;
public:
	ALU();
	ALU(int, int, int, int);
	int getnoOfAdders();
	int getnoOfSubtractors();
	int getnoOfRegisters();
	int getregisterSize();
	void setnoOfAdders(int);
	void setnoOfSubtractors(int);
	void setnoOfRegisters(int);
	void setregisterSize(int);
};

class CU {
private:
	float clock;
public:
	CU();
	CU(float);
	float getClock();
	void setClock(float);
};

class CPU {
private:
	ALU alu;
	CU cu;
	double price;
	string architecture;
public:
	CPU();
	CPU(ALU, CU, double, string);
	ALU getALU();
	CU getCU();
	double getprice();
	string getarchitecture();
	void setALU(ALU);
	void setCU(CU);
	void setprice();
	void setarchitecture(string);
};

class MainMemory {
private:
	int capacity; string techType; double price;
public:
	MainMemory();
	MainMemory(int, string, double);
	int getcapacity();
	string gettechType();
	double getprice();
	void setcapacity(int);
	void gettechType(string);
	void setprice();
};

class Port {
private:
	string type; int baud_rate;
public:
	Port();
	Port(string, int);
	string getype();
	int getbaud_rate();
	void settype(string);
	void setbaud_rate(int);
};

class Motherboard {
private:
	MainMemory* mm;
	Port ports;
	double price;
public:
	Motherboard();
	Motherboard(MainMemory*, Port&, double);
	~Motherboard();
	MainMemory* getMainMemory();
	Port& getPorts();
	double getPrice();
	void setMainMemory(MainMemory*);
	void setPorts(Port&);
	void setPrice();
};

class PhysicalMemory {
private:
	int capacity;
	double price;
	string type;
public:
	PhysicalMemory();
	PhysicalMemory(int, double, string);
	int getcapacity();
	double getprice();
	string gettype();
	void setcapacity(int);
	void setprice();
	void settype(string);
};

class GraphicsCard {
private:
	string brand;
	double price;
	int memorySize;
public:
	GraphicsCard();
	GraphicsCard(string, int, double);
	string getbrand();
	double getprice();
	int getmemorySize();
	void setbrand(string);
	void setprice();
	void setmemorySize(int);
};

class StorageDevice {
private:
	string type;
	int capacity;
	double price;
public:
	StorageDevice();
	StorageDevice(string, int, double);
	string gettype();
	int getcapacity();
	double getprice();
	void settype(string);
	void setcapacity(int);
	void setprice();
};

class NetworkCard {
private:
	string type;
	int speed;
	double price;
public:
	NetworkCard();
	NetworkCard(string, int, double);
	string gettype();
	int getspeed();
	double getprice();
	void settype(string);
	void setspeed(int);
	void setprice();
};

class PowerSupply {
private:
	string efficiencyRating;
	int wattage;
	double price;
public:
	PowerSupply();
	PowerSupply(string, int, double);
	string getefficiencyRating();
	int getwattage();
	double getprice();
	void setefficiencyRating(string);
	void setwattage(int);
	void setprice();
};

class Battery {
private:
	int capacity;
	double price;
public:
	Battery();
	Battery(int, double);
	int getcapacity();
	double getprice();
	void setcapacity(int);
	void setprice();
};

class Case {
private:
	string formFactor;
	string colour;
	double price;
public:
	Case();
	Case(string, string, double);
	string getformFactor();
	string getcolour();
	double getprice();
	void setformFactor(string);
	void setcolour(string);
	void setprice();
};

class ComputerAssembly {
private:
	GraphicsCard gc;
	PhysicalMemory pm;
	Motherboard mm;
	CPU cpu;
	StorageDevice sd;
	PowerSupply ps;
	Case c;
	Battery b;
	NetworkCard nc;
	double TotalPrice;
public:
	ComputerAssembly();
	ComputerAssembly(PhysicalMemory&, Motherboard&, CPU&, StorageDevice&, PowerSupply&, Case&, Battery&, NetworkCard&, GraphicsCard&);
	GraphicsCard& getGraphicsCard();
	PhysicalMemory& getPhysicalMemory();
	Motherboard& getMotherboard();
	CPU& getCPU();
	StorageDevice& getStorageDevice();
	PowerSupply& getPowerSupply();
	Case& getCase();
	Battery& getBattery();
	NetworkCard& getNetworkCard();
	double getTotalPrice();
	void setGraphicsCard(GraphicsCard&);
	void setPhysicalMemory(PhysicalMemory&);
	void setMotherboard(Motherboard&);
	void setCPU(CPU&);
	void setStorageDevice(StorageDevice&);
	void setPowerSupply(PowerSupply&);
	void setCase(Case&);
	void setBattery(Battery&);
	void setNetworkCard(NetworkCard&);
	void setTotalPrice();
};
