#include <iostream>
#include <string>
using namespace std;

//Hassan Abid 23i0064 CS-F
//Ariyan Chaudhary :)

class ALU {
private:
    int noOfAdders;
    int noOfSubtractors;
    int noOfRegisters;
    int sizeOfRegisters;

public:
    ALU() : noOfAdders(2), noOfSubtractors(1), noOfRegisters(4), sizeOfRegisters(64) {}
    ALU(int add, int sub, int reg, int size) : noOfAdders(add), noOfSubtractors(sub), noOfRegisters(reg), sizeOfRegisters(size) {}
    ALU(const ALU& a) : noOfAdders(a.noOfAdders), noOfSubtractors(a.noOfSubtractors), noOfRegisters(a.noOfRegisters), sizeOfRegisters(a.sizeOfRegisters) {}

    int getNoOfAdders() const { return noOfAdders; }
    void setNoOfAdders(int value) { noOfAdders = value; }
    int getNoOfSubtractors() const { return noOfSubtractors; }
    void setNoOfSubtractors(int value) { noOfSubtractors = value; }
    int getNoOfRegisters() const { return noOfRegisters; }
    void setNoOfRegisters(int value) { noOfRegisters = value; }
    int getSizeOfRegisters() const { return sizeOfRegisters; }
    void setSizeOfRegisters(int value) { sizeOfRegisters = value; }

    void display() const {
        cout << "ALU: " << noOfAdders << " adders, " << noOfSubtractors << " subtractors, "
            << noOfRegisters << " registers, " << sizeOfRegisters << " bits each." << endl;
    }
};

class ControlUnit {
private:
    float clock;

public:
    ControlUnit() : clock(3.0) {}
    ControlUnit(float clk) : clock(clk) {}

    float getClock() const { return clock; }
    void setClock(float value) { clock = value; }

    void display() const {
        cout << "Control Unit: Clock speed is " << clock << " GHz." << endl;
    }
};

class CPU {
private:
    ALU alu;
    ControlUnit cu;

public:
    CPU() : alu(), cu() {}
    CPU(const ALU& a, const ControlUnit& c) : alu(a), cu(c) {}

    void setALU(const ALU& a) { alu = a; }
    void setControlUnit(const ControlUnit& c) { cu = c; }

    ALU getALU() const { return alu; }
    ControlUnit getControlUnit() const { return cu; }

    void display() const {
        alu.display();
        cu.display();
    }
};

class AppleCPU : public CPU {
private:
    string gpu;

public:
    AppleCPU(const string& gpuType = "Apple M1 GPU") : CPU(), gpu(gpuType) {}

    string getGpu() const { return gpu; }
    void setGpu(const string& value) { gpu = value; }

    void display() const {
        CPU::display();
        cout << "Integrated GPU: " << gpu << "." << endl;
    }
};

class MainMemory {
private:
    int capacity;
    string technologyType;

public:
    MainMemory(int cap = 16, string tt = "Semiconductor") : capacity(cap), technologyType(tt) {}

    int getCapacity() const { return capacity; }
    void setCapacity(int value) { capacity = value; }
    string getTechnologyType() const { return technologyType; }
    void setTechnologyType(const string& value) { technologyType = value; }

    void display() const {
        cout << "Main Memory: Capacity = " << capacity << " GB, Technology Type = " << technologyType << "." << endl;
    }
};

class Ports {
private:
    string type;
    int baudRate;

public:
    Ports(string t = "USB", int baud = 5000) : type(t), baudRate(baud) {}

    string getType() const { return type; }
    void setType(const string& value) { type = value; }
    int getBaudRate() const { return baudRate; }
    void setBaudRate(int value) { baudRate = value; }

    void display() const {
        cout << "Ports: Type = " << type << ", Baud Rate = " << baudRate << " Mbps." << endl;
    }
};

class MotherBoard {
private:
    MainMemory* memory;
    Ports* ports;
    int numPorts;

public:
    MotherBoard(MainMemory* mem, Ports* ps, int num) : memory(mem), ports(new Ports[num]), numPorts(num) {
        for (int i = 0; i < num; i++) {
            ports[i] = ps[i];
        }
    }
    ~MotherBoard() {
        delete memory;
        delete[] ports;
    }

    MainMemory* getMemory() const { return memory; }
    void setMemory(MainMemory* mem) { memory = mem; }
    Ports* getPorts() const { return ports; }
    void setPorts(Ports* ps, int num) {
        delete[] ports;
        ports = new Ports[num];
        numPorts = num;
        for (int i = 0; i < num; i++) {
            ports[i] = ps[i];
        }
    }

    void display() const {
        cout << "Motherboard Specifications:" << endl;
        memory->display();
        for (int i = 0; i < numPorts; i++) {
            ports[i].display();
        }
    }
};

class PhysicalMemory {
private:
    int capacity;

public:
    PhysicalMemory(int cap = 16) : capacity(cap) {}

    int getCapacity() const { return capacity; }
    void setCapacity(int value) { capacity = value; }

    void display() const {
        cout << "Physical Memory: Capacity = " << capacity << " GB." << endl;
    }
};

class Computer {
private:
    string systemType; // "PC" or "Mac"
    CPU* cpu;
    MotherBoard* mb;
    PhysicalMemory* pm;

public:
    Computer(string type, CPU* c, MotherBoard* m, PhysicalMemory* p) : systemType(type), cpu(c), mb(m), pm(p) {}
    ~Computer() {
        delete cpu;
        delete mb;
        delete pm;
    }

    string getSystemType() const { return systemType; }
    void setSystemType(const string& type) { systemType = type; }
    CPU* getCPU() const { return cpu; }
    void setCPU(CPU* c) { cpu = c; }
    MotherBoard* getMotherBoard() const { return mb; }
    void setMotherBoard(MotherBoard* m) { mb = m; }
    PhysicalMemory* getPhysicalMemory() const { return pm; }
    void setPhysicalMemory(PhysicalMemory* p) { pm = p; }

    void display() const {
        cout << systemType << " Computer Specifications:" << endl;
        cpu->display();
        mb->display();
        pm->display();
    }
};

class GraphicsCard {
private:
    string brand;
    int memorySize;
    double price;

public:
    GraphicsCard(string b = "Nvidia", int mSize = 8, double p = 500) : brand(b), memorySize(mSize), price(p) {}

    string getBrand() const { return brand; }
    void setBrand(const string& value) { brand = value; }
    int getMemorySize() const { return memorySize; }
    void setMemorySize(int value) { memorySize = value; }
    double getPrice() const { return price; }
    void setPrice(double value) { price = value; }

    void display() const {
        cout << "Graphics Card: Brand = " << brand << ", Memory Size = " << memorySize << " GB, Price = $" << price << "." << endl;
    }
};

class StorageDevice {
private:
    string type; // HDD or SSD
    int capacity;
    double price;

public:
    StorageDevice(string t = "SSD", int cap = 256, double p = 150) : type(t), capacity(cap), price(p) {}

    string getType() const { return type; }
    void setType(const string& value) { type = value; }
    int getCapacity() const { return capacity; }
    void setCapacity(int value) { capacity = value; }
    double getPrice() const { return price; }
    void setPrice(double value) { price = value; }

    void display() const {
        cout << "Storage Device: Type = " << type << ", Capacity = " << capacity << " GB, Price = $" << price << "." << endl;
    }
};

class NetworkCard {
private:
    string type;
    int speed;
    double price;

public:
    NetworkCard(string t = "Ethernet", int s = 1000, double p = 150) : type(t), speed(s), price(p) {}

    string getType() const { return type; }
    void setType(const string& value) { type = value; }
    int getSpeed() const { return speed; }
    void setSpeed(int value) { speed = value; }
    double getPrice() const { return price; }
    void setPrice(double value) { price = value; }

    void display() const {
        cout << "Network Card: Type = " << type << ", Speed = " << speed << " Mbps, Price = $" << price << "." << endl;
    }
};

class PowerSupply {
private:
    int wattage;
    string efficiencyRating;
    double price;

public:
    PowerSupply(int w = 650, string rating = "80 Plus Gold", double p = 120) : wattage(w), efficiencyRating(rating), price(p) {}

    int getWattage() const { return wattage; }
    void setWattage(int value) { wattage = value; }
    string getEfficiencyRating() const { return efficiencyRating; }
    void setEfficiencyRating(const string& value) { efficiencyRating = value; }
    double getPrice() const { return price; }
    void setPrice(double value) { price = value; }

    void display() const {
        cout << "Power Supply: Wattage = " << wattage << "W, Efficiency Rating = " << efficiencyRating << ", Price = $" << price << "." << endl;
    }
};

class Battery {
private:
    int capacity;

public:
    Battery(int cap = 5000) : capacity(cap) {}

    int getCapacity() const { return capacity; }
    void setCapacity(int value) { capacity = value; }

    void display() const {
        cout << "Battery: Capacity = " << capacity << " mAh." << endl;
    }
};

class Case {
private:
    string formFactor;
    string color;

public:
    Case(string form = "ATX", string col = "Black") : formFactor(form), color(col) {}

    string getFormFactor() const { return formFactor; }
    void setFormFactor(const string& value) { formFactor = value; }
    string getColor() const { return color; }
    void setColor(const string& value) { color = value; }

    void display() const {
        cout << "Case: Form Factor = " << formFactor << ", Color = " << color << "." << endl;
    }
};

class ComputerAssembly {
private:
    Computer* computer;
    GraphicsCard* graphicsCard;
    StorageDevice* storageDevice;
    NetworkCard* networkCard;
    PowerSupply* powerSupply;
    Battery* battery;
    Case* caseUnit;
    double totalPrice;

public:
    ComputerAssembly() : computer(nullptr), graphicsCard(nullptr), storageDevice(nullptr),
        networkCard(nullptr), powerSupply(nullptr), battery(nullptr), caseUnit(nullptr), totalPrice(0.0) {}

    ~ComputerAssembly() {
        delete computer;
        delete graphicsCard;
        delete storageDevice;
        delete networkCard;
        delete powerSupply;
        delete battery;
        delete caseUnit;
    }

    Computer* getComputer() const { return computer; }
    void setComputer(Computer* c) { computer = c; }
    GraphicsCard* getGraphicsCard() const { return graphicsCard; }
    void setGraphicsCard(GraphicsCard* gc) { graphicsCard = gc; }
    StorageDevice* getStorageDevice() const { return storageDevice; }
    void setStorageDevice(StorageDevice* sd) { storageDevice = sd; }
    NetworkCard* getNetworkCard() const { return networkCard; }
    void setNetworkCard(NetworkCard* nc) { networkCard = nc; }
    PowerSupply* getPowerSupply() const { return powerSupply; }
    void setPowerSupply(PowerSupply* ps) { powerSupply = ps; }
    Battery* getBattery() const { return battery; }
    void setBattery(Battery* b) { battery = b; }
    Case* getCaseUnit() const { return caseUnit; }
    void setCaseUnit(Case* c) { caseUnit = c; }
    double getTotalPrice() const { return totalPrice; }
    void setTotalPrice(double price) { totalPrice = price; }

    void display() const {
        if (computer) computer->display();
        if (graphicsCard) graphicsCard->display();
        if (storageDevice) storageDevice->display();
        if (networkCard) networkCard->display();
        if (powerSupply) powerSupply->display();
        if (battery) battery->display();
        if (caseUnit) caseUnit->display();
        cout << "Total Price of Computer Assembly: $" << totalPrice << endl;
    }

    friend istream& operator>>(istream& in, ComputerAssembly& ca);
};

// Valid input functions
int validint(const string& prompt, int min, int max) {
    int value;
    while (true) {
        cout << prompt;
        cin >> value;
        if (cin.fail() || value < min || value > max) {
            cin.clear(); // Clear error flag
            cin.ignore(1000, '\n');
            cout << "Invalid input. Please enter a number between " << min << " and " << max << ".\n";
        }
        else {
            break;
        }
    }
    return value;
}

double validdouble(const string& prompt, double min, double max) {
    double value;
    while (true) {
        cout << prompt;
        cin >> value;
        if (cin.fail() || value < min || value > max) {
            cin.clear();
            cin.ignore(1000, '\n');
            cout << "Invalid input. Please enter a value between " << min << " and " << max << ".\n";
        }
        else {
            break;
        }
    }
    return value;
}

string validstring(const string& prompt) {
    string value;
    cout << prompt;
    cin >> value;
    return value;
}

istream& operator>>(istream& in, ComputerAssembly& ca) {
    int adders = validint("Enter the number of adders in ALU: ", 1, 10);
    int subtractors = validint("Enter the number of subtractors in ALU: ", 1, 10);
    int registers = validint("Enter the number of registers in ALU: ", 1, 32);
    int size = validint("Enter the size of registers in ALU (bits): ", 32, 128);
    ALU alu(adders, subtractors, registers, size);

    float clockSpeed = validdouble("Enter the clock speed of the Control Unit (GHz): ", 0.5, 5.0);
    ControlUnit cu(clockSpeed);

    CPU* cpu = new CPU(alu, cu);

    int memCapacity = validint("Enter main memory capacity (GB): ", 4, 512);
    string techType = validstring("Enter technology type of main memory (e.g., 'DDR4'): ");
    MainMemory* mainMemory = new MainMemory(memCapacity, techType);

    Ports ports[3];
    for (int i = 0; i < 3; i++) {
        string portType = validstring("Enter port type (e.g., 'USB', 'Ethernet'): ");
        int baudRate = validint("Enter baud rate for port (Mbps): ", 10, 10000);
        ports[i] = Ports(portType, baudRate);
    }
    MotherBoard* motherboard = new MotherBoard(mainMemory, ports, 3);

    string systemType = validstring("Enter system type ('PC' or 'Mac'): ");
    PhysicalMemory* pm = new PhysicalMemory(memCapacity);

    ca.setComputer(new Computer(systemType, cpu, motherboard, pm));

    string brand = validstring("Enter brand of Graphics Card (e.g., 'NVIDIA', 'AMD'): ");
    int memorySize = validint("Enter memory size of Graphics Card (GB): ", 1, 32);
    double price = validdouble("Enter price of Graphics Card ($): ", 50, 2000);
    ca.setGraphicsCard(new GraphicsCard(brand, memorySize, price));

    string storageType = validstring("Enter type of Storage Device (e.g., 'HDD', 'SSD'): ");
    int storageCapacity = validint("Enter capacity of Storage Device (GB): ", 128, 4096);
    double storagePrice = validdouble("Enter price of Storage Device ($): ", 50, 1000);
    ca.setStorageDevice(new StorageDevice(storageType, storageCapacity, storagePrice));

    string networkType = validstring("Enter type of Network Card (e.g., 'Ethernet', 'WiFi'): ");
    int networkSpeed = validint("Enter speed of Network Card (Mbps): ", 10, 10000);
    double networkPrice = validdouble("Enter price of Network Card ($): ", 20, 500);
    ca.setNetworkCard(new NetworkCard(networkType, networkSpeed, networkPrice));

    int wattage = validint("Enter power wattage of Power Supply (W): ", 200, 1500);
    string efficiencyRating = validstring("Enter efficiency rating of Power Supply (e.g., '80 Plus Bronze', '80 Plus Gold'): ");
    double powerSupplyPrice = validdouble("Enter price of Power Supply ($): ", 50, 500);
    ca.setPowerSupply(new PowerSupply(wattage, efficiencyRating, powerSupplyPrice));

    int batteryCapacity = validint("Enter battery capacity (mAh): ", 1000, 10000);
    ca.setBattery(new Battery(batteryCapacity));

    string formFactor = validstring("Enter form factor of Case (e.g., 'ATX', 'Mini-ATX'): ");
    string color = validstring("Enter color of Case: ");
    ca.setCaseUnit(new Case(formFactor, color));

    ca.setTotalPrice(validdouble("Enter total price for the computer assembly ($): ", 500, 10000));

    return in;
}

int main() {
    ComputerAssembly ca;
    cin >> ca;

    cout << "\n\n***************************************\n";
    ca.display();
    return 0;
}
