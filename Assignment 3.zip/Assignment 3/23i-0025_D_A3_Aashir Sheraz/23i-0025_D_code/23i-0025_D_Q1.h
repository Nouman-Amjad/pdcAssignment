#pragma once
#include <iostream>
#include <string>
using namespace std;
// ALU class
class ALU {
private:
    int NoOfAdders;
    int NoOfSubtractors;
    int NoOfRegisters;
    int sizeOfRegisters;
public:
    // Default constructor
    ALU() : NoOfAdders(0), NoOfSubtractors(0), NoOfRegisters(0), sizeOfRegisters(0) {}
    // Overloaded constructor
    ALU(int adders, int subtractors, int registers, int size) : NoOfAdders(adders), NoOfSubtractors(subtractors),
        NoOfRegisters(registers), sizeOfRegisters(size) {}
    // Getters
    int getNoOfAdders() const { return NoOfAdders; }
    int getNoOfSubtractors() const { return NoOfSubtractors; }
    int getNoOfRegisters() const { return NoOfRegisters; }
    int getSizeOfRegisters() const { return sizeOfRegisters; }
    // Setters
    void setNoOfAdders(int adders) { NoOfAdders = adders; }
    void setNoOfSubtractors(int subtractors) { NoOfSubtractors = subtractors; }
    void setNoOfRegisters(int registers) { NoOfRegisters = registers; }
    void setSizeOfRegisters(int size) { sizeOfRegisters = size; }
    // Destructor
    ~ALU() {}
};

// ControlUnit class
class ControlUnit {
private:
    float clock;
public:
    // Default constructor
    ControlUnit() : clock(0.0) {}
    // Overloaded constructor
    ControlUnit(float clk) : clock(clk) {}
    // Getters
    float getClock() const { return clock; }
    // Setters
    void setClock(float clk) { clock = clk; }
    // Destructor
    ~ControlUnit() {}
};

// CPU class
class CPU {
private:
    ALU* alu;
    ControlUnit* cu;
public:
    // Default constructor
    CPU() : alu(nullptr), cu(nullptr) {}
    // Overloaded constructor
    CPU(int adders, int subtractors, int registers, int size, float clk) : alu(new ALU(adders, subtractors, registers, size)), cu(new ControlUnit(clk)) {}
    // Getters
    ALU* getALU() const { return alu; }
    ControlUnit* getCU() const { return cu; }
    // Setters
    void setALU(ALU* a) { alu = a; }
    void setCU(ControlUnit* c) { cu = c; }
    // Destructor
    ~CPU() { delete alu; delete cu; }
};
// MainMemory class
class MainMemory {
private:
    int capacity;
    string technologyType;
public:
    // Default constructor
    MainMemory() : capacity(0), technologyType("") {}
    // Overloaded constructor
    MainMemory(int cap, string tech) : capacity(cap), technologyType(tech) {}
    // Getters
    int getCapacity() const { return capacity; }
    string getTechnologyType() const { return technologyType; }
    // Setters
    void setCapacity(int cap) { capacity = cap; }
    void setTechnologyType(string tech) { technologyType = tech; }
    // Destructor
    ~MainMemory() {}
};
// Port class
class Port {
private:
    string type;
    int baud_rate;
public:
    // Default constructor
    Port() : type(""), baud_rate(0) {}
    // Overloaded constructor
    Port(string t, int br) : type(t), baud_rate(br) {}
    // Getters
    string getType() const { return type; }
    int getBaudRate() const { return baud_rate; }
    // Setters
    void setType(string t) { type = t; }
    void setBaudRate(int br) { baud_rate = br; }
    // Destructor
    ~Port() {}
};
// MotherBoard class
class MotherBoard {
private:
    MainMemory* mm;
    Port* ports[4]; // Assuming 4 ports
public:
    // Default constructor
    MotherBoard() : mm(nullptr) {
        for (int i = 0; i < 4; ++i) {
            ports[i] = nullptr;
        }
    }
    // Overloaded constructor
    MotherBoard(int cap, string tech) : mm(new MainMemory(cap, tech)) {
        for (int i = 0; i < 4; ++i) {
            ports[i] = new Port();
        }
    }
    // Getters
    MainMemory* getMainMemory() const { return mm; }
    Port** getPorts() { return ports; }
    // Setters
    void setMainMemory(MainMemory* m) { mm = m; }
    void setPorts(Port** p) {
        for (int i = 0; i < 4; ++i) {
            ports[i] = p[i];
        }
    }
    // Destructor
    ~MotherBoard() {
        delete mm;
        for (int i = 0; i < 4; ++i) {
            delete ports[i];
        }
    }
};
// PhysicalMemory class
class PhysicalMemory {
protected:
    int capacity;
public:
    // Default constructor
    PhysicalMemory() : capacity(0) {}
    // Overloaded constructor
    PhysicalMemory(int cap) : capacity(cap) {}
    // Getters
    int getCapacity() const { return capacity; }
    // Setters
    void setCapacity(int cap) { capacity = cap; }
    // Destructor
    ~PhysicalMemory() {}
};
// DDR4_5 class (inherits from PhysicalMemory)
class DDR4_5 : public PhysicalMemory {
public:
    // Overloaded constructor
    DDR4_5(int cap) : PhysicalMemory(cap) {}
};
// LPDDR4_5 class (inherits from PhysicalMemory)
class LPDDR4_5 : public PhysicalMemory {
public:
    // Overloaded constructor
    LPDDR4_5(int cap) : PhysicalMemory(cap) {}
};
// Computer class
class Computer {
private:
    PhysicalMemory* pm;
    CPU* cpu;
    MotherBoard* mb;
public:
    // Default constructor
    Computer() : pm(nullptr), cpu(nullptr), mb(nullptr) {}
    // Overloaded constructor
    Computer(int pmCap, int cap, string tech, int adders, int subtractors, int registers, int size, float clk)
        : pm(new PhysicalMemory(pmCap)), cpu(new CPU(adders, subtractors, registers, size, clk)),
        mb(new MotherBoard(cap, tech)) {}
    // Calculate total price
    double calculateTotalPrice(double gpuPrice, double networkPrice) const {
        return gpuPrice + networkPrice;
    }
    // Getters
    PhysicalMemory* getPhysicalMemory() const { return pm; }
    CPU* getCPU() const { return cpu; }
    MotherBoard* getMotherBoard() const { return mb; }
    // Setters
    void setPhysicalMemory(PhysicalMemory* p) { pm = p; }
    void setCPU(CPU* c) { cpu = c; }
    void setMotherBoard(MotherBoard* m) { mb = m; }
    // Destructor
    ~Computer() {
        delete pm;
        delete cpu;
        delete mb;
    }
};

// GraphicsCard class
class GraphicsCard {
private:
    string brand;
    int memorySize;
    double price;
public:
    // Default constructor
    GraphicsCard() : brand(""), memorySize(0), price(100.0) {}
    // Overloaded constructor
    GraphicsCard(string b, int size, double p) : brand(b), memorySize(size), price(p) {}
    // Getters
    string getBrand() const { return brand; }
    int getMemorySize() const { return memorySize; }
    double getPrice() const { return price; }
    // Setters
    void setBrand(string b) { brand = b; }
    void setMemorySize(int size) { memorySize = size; }
    void setPrice(double p) { price = p; }
    // Destructor
    ~GraphicsCard() {}
};

// StorageDevice class
class StorageDevice {
private:
    string type;
    int capacity;
    double price;
public:
    // Default constructor
    StorageDevice() : type(""), capacity(0), price(50.0) {}
    // Overloaded constructor
    StorageDevice(string t, int cap, double p) : type(t), capacity(cap), price(p) {}
    // Getters
    string getType() const { return type; }
    int getCapacity() const { return capacity; }
    double getPrice() const { return price; }
    // Setters
    void setType(string t) { type = t; }
    void setCapacity(int cap) { capacity = cap; }
    void setPrice(double p) { price = p; }
    // Destructor
    ~StorageDevice() {}
};

// NetworkCard class
class NetworkCard {
private:
    string type;
    int speed;
    double price;
public:
    // Default constructor
    NetworkCard() : type(""), speed(0), price(20.0) {}
    // Overloaded constructor
    NetworkCard(string t, int s, double p) : type(t), speed(s), price(p) {}
    // Getters
    string getType() const { return type; }
    int getSpeed() const { return speed; }
    double getPrice() const { return price; }
    // Setters
    void setType(string t) { type = t; }
    void setSpeed(int s) { speed = s; }
    void setPrice(double p) { price = p; }
    // Destructor
    ~NetworkCard() {}
};

// PowerSupply class
class PowerSupply {
private:
    int wattage;
    double efficiencyRating;
    double price;
public:
    // Default constructor
    PowerSupply() : wattage(0), efficiencyRating(0.0), price(30.0) {}
    // Overloaded constructor
    PowerSupply(int w, double er, double p) : wattage(w), efficiencyRating(er), price(p) {}
    // Getters
    int getWattage() const { return wattage; }
    double getEfficiencyRating() const { return efficiencyRating; }
    double getPrice() const { return price; }
    // Setters
    void setWattage(int w) { wattage = w; }
    void setEfficiencyRating(double er) { efficiencyRating = er; }
    void setPrice(double p) { price = p; }
    // Destructor
    ~PowerSupply() {}
};

// Battery class
class Battery {
private:
    int capacity;
public:
    // Default constructor
    Battery() : capacity(0) {}
    // Overloaded constructor
    Battery(int cap) : capacity(cap) {}
    // Getters
    int getCapacity() const { return capacity; }
    // Setters
    void setCapacity(int cap) { capacity = cap; }
    // Destructor
    ~Battery() {}
};

// Case class
class Case {
private:
    string formFactor;
    string color;
public:
    // Default constructor
    Case() : formFactor(""), color("") {}
    // Overloaded constructor
    Case(string ff, string c) : formFactor(ff), color(c) {}
    // Getters
    string getFormFactor() const { return formFactor; }
    string getColor() const { return color; }
    // Setters
    void setFormFactor(string ff) { formFactor = ff; }
    void setColor(string c) { color = c; }
    // Destructor
    ~Case() {}
};

// ComputerAssembly class
class ComputerAssembly {
private:
    Computer* computer;
    GraphicsCard* gpu;
    StorageDevice* storage;
    NetworkCard* network;
    PowerSupply* psu;
    Battery* battery;
    Case* case_;
    double totalPrice;
public:
    // Default constructor
    ComputerAssembly() : computer(nullptr), gpu(nullptr), storage(nullptr), network(nullptr), psu(nullptr), battery(nullptr), case_(nullptr), totalPrice(0.0) {}
    // Overloaded constructor
    ComputerAssembly(int pmCap, int cap, string tech, int adders, int subtractors, int registers, int size, float clk, string gpuBrand, int gpuSize, double gpuPrice,
        string storageType, int storageCap, double storagePrice, string networkType, int networkSpeed, double networkPrice, int psuWattage, double psuEfficiency,
        double psuPrice, int batteryCap, string caseFormFactor, string caseColor) :\ computer(new Computer(pmCap, cap, tech, adders, subtractors, registers, size, clk)),
        gpu(new GraphicsCard(gpuBrand, gpuSize, gpuPrice)), storage(new StorageDevice(storageType, storageCap, storagePrice)), network(new NetworkCard(networkType, networkSpeed,
            networkPrice)), psu(new PowerSupply(psuWattage, psuEfficiency, psuPrice)), battery(new Battery(batteryCap)), case_(new Case(caseFormFactor, caseColor)),
        totalPrice(computer->calculateTotalPrice(gpuPrice, networkPrice) + storagePrice + psuPrice + batteryCap * 0.1 + (caseColor == "black" ? 5.0 : 10.0)) {}
    // Getters
    Computer* getComputer() const { return computer; }
    GraphicsCard* getGPU() const { return gpu; }
    StorageDevice* getStorage() const { return storage; }
    NetworkCard* getNetwork() const { return network; }
    PowerSupply* getPSU() const { return psu; }
    Battery* getBattery() const { return battery; }
    Case* getCase() const { return case_; }
    double getTotalPrice() const { return totalPrice; }
    // Setters
    void setComputer(Computer* c) { computer = c; }
    void setGPU(GraphicsCard* g) { gpu = g; }
    void setStorage(StorageDevice* s) { storage = s; }
    void setNetwork(NetworkCard* n) { network = n; }
    void setPSU(PowerSupply* p) { psu = p; }
    void setBattery(Battery* b) { battery = b; }
    void setCase(Case* c) { case_ = c; }
    void setTotalPrice(double price) { totalPrice = price; }
    // Destructor
    ~ComputerAssembly() {
        delete computer;
        delete gpu;
        delete storage;
        delete network;
        delete psu;
        delete battery;
        delete case_;
    }
};
