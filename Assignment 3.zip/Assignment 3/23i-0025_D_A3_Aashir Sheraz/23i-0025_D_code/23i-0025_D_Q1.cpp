#include <iostream>
#include <string>
#include "23i-0025_D_Q1.h"
using namespace std;
//-------------------------Functions for Input Validation--------------------------
int validateInputInt(const string& prompt) {
    int num;
    while (true) {
        cout << prompt;
        if (cin >> num) {
            return num;
        }
        cout << "Invalid input. Please enter a valid integer: ";
        cin.clear();
        cin.ignore(1000, '\n');
    }
}
float validateInputFloat(const string& prompt) {
    float num;
    while (true) {
        cout << prompt;
        if (cin >> num) {
            return num;
        }
        cout << "Invalid input. Please enter a valid float: ";
        cin.clear();
        cin.ignore(1000, '\n');
    }
}
string validateInputString(const string& prompt) {
    string str;
    while (true) {
        cout << prompt;
        getline(cin, str);
        if (str.empty()) {
            cout << "Invalid Input! Enter a valid input: \n";
        }
        else {
            return str;
        }
    }
}


//-------------------------Main starts here---------------------------
int main() {
    // Get user input for computer assembly components
    int pmCap, cap, adders, subtractors, registers, size;
    float clk;
    string tech, gpuBrand, storageType, networkType, caseFormFactor, caseColor;

    cout << "Enter physical memory capacity (GB): ";
    cin >> pmCap;
    while (pmCap <= 0) {
        cout << "Invalid input. Please enter a positive value: ";
        cin >> pmCap;
    }

    cout << "Enter main memory capacity (GB): ";
    cin >> cap;
    while (cap <= 0) {
        cout << "Invalid input. Please enter a positive value: ";
        cin >> cap;
    }

    cout << "Enter technology type (e.g. DDR4): ";
    cin >> tech;
    while (tech.empty()) {
        cout << "Invalid input. Please enter a valid technology type: ";
        cin >> tech;
    }

    cout << "Enter number of ALU adders: ";
    cin >> adders;
    while (adders <= 0) {
        cout << "Invalid input. Please enter a positive value: ";
        cin >> adders;
    }

    cout << "Enter number of ALU subtractors: ";
    cin >> subtractors;
    while (subtractors <= 0) {
        cout << "Invalid input. Please enter a positive value: ";
        cin >> subtractors;
    }

    cout << "Enter number of ALU registers: ";
    cin >> registers;
    while (registers <= 0) {
        cout << "Invalid input. Please enter a positive value: ";
        cin >> registers;
    }

    cout << "Enter ALU register size (bits): ";
    cin >> size;
    while (size <= 0) {
        cout << "Invalid input. Please enter a positive value: ";
        cin >> size;
    }

    cout << "Enter control unit clock speed (GHz): ";
    cin >> clk;
    while (clk <= 0) {
        cout << "Invalid input. Please enter a positive value: ";
        cin >> clk;
    }

    cout << "Enter GPU brand: ";
    cin >> gpuBrand;
    while (gpuBrand.empty()) {
        cout << "Invalid input. Please enter a valid brand: ";
        cin >> gpuBrand;
    }

    cout << "Enter storage type (e.g. SSD): ";
    cin >> storageType;
    while (storageType.empty()) {
        cout << "Invalid input. Please enter a valid storage type: ";
        cin >> storageType;
    }

    cout << "Enter network type (e.g. Ethernet): ";
    cin >> networkType;
    while (networkType.empty()) {
        cout << "Invalid input. Please enter a valid network type: ";
        cin >> networkType;
    }

    cout << "Enter case form factor (e.g. ATX): ";
    cin >> caseFormFactor;
    while (caseFormFactor.empty()) {
        cout << "Invalid input. Please enter a valid form factor: ";
        cin >> caseFormFactor;
    }

    cout << "Enter case color (e.g. black or white): ";
    cin >> caseColor;
    while (caseColor.empty()) {
        cout << "Invalid input. Please enter a valid color: ";
        cin >> caseColor;
    }

    // Create computer assembly object with user input
    ComputerAssembly assembly(pmCap, cap, tech, adders, subtractors, registers, size, clk, gpuBrand, 8, 100.0, storageType,
        1024, 50.0, networkType, 1000, 20.0, 650, 0.8, 30.0, 500, caseFormFactor, caseColor);

    // Display output
    cout << "Final specifications for the computer assembly:" << endl;
    cout << "--------------------------------------------------------" << endl;
    cout << "Physical Memory Capacity: " << assembly.getComputer()->getPhysicalMemory()->getCapacity() << " GB" << endl;
    cout << "Main Memory Capacity: " << assembly.getComputer()->getMotherBoard()->getMainMemory()->getCapacity() << " GB" << endl;
    cout << "Main Memory Technology Type: " << assembly.getComputer()->getMotherBoard()->getMainMemory()->getTechnologyType() << endl;
    cout << "ALU Adders: " << assembly.getComputer()->getCPU()->getALU()->getNoOfAdders() << endl;
    cout << "ALU Subtractors: " << assembly.getComputer()->getCPU()->getALU()->getNoOfSubtractors() << endl;
    cout << "ALU Registers: " << assembly.getComputer()->getCPU()->getALU()->getNoOfRegisters() << endl;
    cout << "ALU Register Size: " << assembly.getComputer()->getCPU()->getALU()->getSizeOfRegisters() << " bits" << endl;
    cout << "Control Unit Clock: " << assembly.getComputer()->getCPU()->getCU()->getClock() << " GHz" << endl;
    cout << "GPU Brand: " << assembly.getGPU()->getBrand() << endl;
    cout << "Storage Type: " << assembly.getStorage()->getType() << endl;
    cout << "Storage Capacity: " << assembly.getStorage()->getCapacity() << " GB" << endl;
    cout << "Network Type: " << assembly.getNetwork()->getType() << endl;
    cout << "Network Speed: " << assembly.getNetwork()->getSpeed() << " Mbps" << endl;
    cout << "Power Supply Wattage: " << assembly.getPSU()->getWattage() << " W" << endl;
    cout << "Power Supply Efficiency Rating: " << assembly.getPSU()->getEfficiencyRating() << endl;
    cout << "Battery Capacity: " << assembly.getBattery()->getCapacity() << " Wh" << endl;
    cout << "Case Form Factor: " << assembly.getCase()->getFormFactor() << endl;
    cout << "Case Color: " << assembly.getCase()->getColor() << endl;
    cout << "Total Price: $" << assembly.getTotalPrice() << endl;

    return 0;
}
