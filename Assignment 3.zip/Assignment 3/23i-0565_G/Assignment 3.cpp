#include<iostream>
#include<string>
using namespace std;

class ALU {
	int NoOfAdders;
	int NoOfSubstracters;
	int NoOfRegisters;
	int SizeOfRegisters;
public:
	ALU(int NoOfAdders = 0, int NoOfSubstractors = 0, int NoOfRegisters = 0, int SizeOfRegisters = 0)
	{
		setAdders(NoOfAdders);
		setSubstracters(NoOfSubstractors);
		setRegisters(NoOfRegisters);
		setRegSize(SizeOfRegisters);
	}
	void setAdders(int NoOfAdders) {
		this->NoOfAdders = NoOfAdders;
	}
	void setSubstracters(int NoOfSubstracters) {
		this->NoOfSubstracters = NoOfSubstracters;
	}
	void setRegisters(int NoOfRegisters) {
		this->NoOfRegisters= NoOfRegisters;
	}
	void setRegSize(int SizeOfRegisters) {
		this->SizeOfRegisters = SizeOfRegisters;
	}
	int getAdders() {
		return this->NoOfAdders;
	}
	int getSubstractors() {
		return this->NoOfSubstracters;
	}
	int getRegisters() {
		return this->NoOfRegisters;
	}
	int getRegSize() {
		return this->SizeOfRegisters;
	}
};
class ControlUnit {
	float clock;
public:
	//ControlUnit() {
	//	clock = 0;
	//}
	ControlUnit(float clock = 0) {
		setClock(clock);
	}
	void setClock(float clock) {
		this->clock = clock;
	}
	float getClock() {
		return this->clock;
	}
};
class CPU {
	ALU alu;
	ControlUnit cu;
public:
	CPU() {

	}
	CPU(int NoOfAdders, int NoOfSubstractors, int NoOfRegisters, int SizeOfRegisters, float clock) :alu(NoOfAdders, NoOfSubstractors, NoOfRegisters, SizeOfRegisters), cu(clock) {
		setAlu(alu);
		setCu(cu);
	}
	CPU(int NoOfAdders, int NoOfSubstractors, int NoOfRegisters, int SizeOfRegisters, float clock) :alu(NoOfAdders, NoOfSubstractors, NoOfRegisters, SizeOfRegisters), cu(clock) {
		this->alu.setSubstracters(0);
		this->alu.setAdders(0);
		this->alu.setRegisters(0);
		this->alu.setRegSize(0);
		this->cu.setClock(0);
	}
	
	
	void setAlu(ALU alu) {
		this->alu = alu;
	}
	void setCu(ControlUnit cu) {
		this->cu = cu;
	}
	ALU getAlu() {
		return this->alu;
	}
	ControlUnit getCu() {
		return this->cu;
	}
};
class MainMemory {
	int capacity;
	string technologyType;
public:
	MainMemory() {
		this->capacity = 0;
		this->technologyType="";
	}
	MainMemory(int capacity = 0, string technologyType = ""){
		setCapacity(capacity);
		setTechnologyType(technologyType);
	}
	void setCapacity(int capacity) {
		this->capacity = capacity;
	}
	void setTechnologyType(string technologyType) {
		this->technologyType = technologyType;
	}
	int getCapacity() {
		return this->capacity;
	}
	string getTechnologyType() {
		return this->technologyType;
	}
};
class Port {
	string type;
	int baudRate;
public:
	
	Port(string type = "", int baudRate = 0) {
		setType(type);
		setBaudRate(baudRate);
	}
	void setType(string type) {
		this->type = type;
	}
	void setBaudRate(int baudRate) {
		this->baudRate = baudRate;
	}
	int getBaudRate() {
		return this->baudRate;
	}
	string getType() {
		return this->type;
	}
};
class MotherBoard {
	Port portsArray;
	MainMemory* mm;
public:
	MotherBoard() {

	}
	MotherBoard(string type,int baudRate, int capacity ,string technologyType):portsArray(type,baudRate),mm(new MainMemory(capacity,technologyType))
	{
		this->portsArray.setType("");
		this->portsArray.setBaudRate(0);
		this->mm->setCapacity(0);
		this->mm->setTechnologyType("");

	}
	MotherBoard(string type, int baudRate, int capacity, string technologyType) :portsArray(type, baudRate), mm(new MainMemory(capacity, technologyType))
	{
		setPortsArray(portsArray);
		setMM(mm);
	}
	void setPortsArray(Port portsArray) {
		this->portsArray = portsArray;
	}
	void setMM(MainMemory* mm) {
		this->mm = mm;
	}
	Port getPortsArray() {
		return this->portsArray;
	}
	MainMemory* getMM() {
		return this->mm;
	}
};
class PhysicalMemory {
	int capacity;
public:
	PhysicalMemory(int capacity = 0) {
		setCapacity(capacity);
	}
	void setCapacity(int capacity) {
		this->capacity = capacity;
	}
	int getCapacity() {
		return this->capacity;
	}
};
class Computer {
	PhysicalMemory *pm;
	CPU *cpu;
	MotherBoard* mb;
public:
	Computer(int capacity, ALU alu, ControlUnit cu, Port portsArray, MainMemory* mm) :pm(new PhysicalMemory(capacity)), cpu(new CPU), mb(new MotherBoard) {
		setPm(pm);
		setCpu(cpu);
		setMb(mb);
	}
	void setCpu(CPU* cpu) {
		this->cpu = cpu;
	}
	void setPm(PhysicalMemory* pm) {
		this->pm = pm;
	}
	void setMb(MotherBoard* mb) {
		this->mb = mb;
	}
	PhysicalMemory* getPm() {
		return this->pm;
	}
	CPU* getCpu() {
		return this->cpu;
	}
	MotherBoard* getMb() {
		return this->mb;
	}
};
class GraphicsCard {
	string brand;
	int memorySize;
	double price;
public:
	GraphicsCard(string brand = "", int memorySize = 0, double price = 0) {
		setBrand(brand);
		setMemorySize(memorySize);
		setPrice(price);
	}
	void setBrand(string brand) {
		this->brand = brand;
	}
	void setMemorySize(int memorySize) {
		this->memorySize = memorySize;
	}
	void setPrice(double price) {
		this->price = price;
	}
	string getBrand() {
		return this->brand;
	}
	int getMemorySize() {
		return this->memorySize;
	}
	double getPrice() {
		return this->price;
	}
};
class StorageDevice {
	string type;
	int capacity;
	double price;
public:
	StorageDevice(string type = "", int capacity = 0, double price = 0) {
		setType(type);
		setCapacity(capacity);
		setPrice(price);
	}
	void setType(string type) {
		this->type = type;
	}
	void setCapacity(int capacity) {
		this->capacity = capacity;
	}
	void setPrice(double price) {
		this->price = price;
	}
	string getType() {
		return this->type;
	}
	int getCapacity() {
		return this->capacity;
	}
	double getPrice() {
		return this->price;
	}
};
class NetworkCard {
	string type;
	int speed;
	double price;
public:
	NetworkCard(string type = "", int speed = 0, double price = 0) {
		setType(type);
		setSpeed(speed);
		setPrice(price);
	}
	void setType(string type) {
		this->type = type;
	}
	void setSpeed(int capacity) {
		this->speed = speed;
	}
	void setPrice(double price) {
		this->price = price;
	}
	string getType() {
		return this->type;
	}
	int getSpeed() {
		return this->speed;
	}
	double getPrice() {
		return this->price;
	}
};
class PowerSupply{
	int wattage;
	string efficiencyRating;
	double price;
public:
	PowerSupply(int wattage = 0, string efficiencyRating = "", double price = 0) {
		setWattage(wattage);
		setEfficiencyRating(efficiencyRating);
		setPrice(price);
	}
	void setWattage(int wattage) {
		this->wattage = wattage;
	}
	void setEfficiencyRating(string efficiencyRating) {
		this->efficiencyRating = efficiencyRating;
	}
	void setPrice(double price){
		this->price = price;
	}
	int getWattage() {
		return this->wattage;
	}
	string getEfficiencyRating() {
		return this->efficiencyRating;
	}
	double getPrice() {
		return this->price;
	}
};
class Battery {
	int capacity;
public:
	Battery(int capacity) {
		setCapacity(capacity);
	}
	void setCapacity(int capacity) {
		this->capacity =capacity;
	}
	int getCapacity() {
		return this->capacity;
	}
};
class Case {
	string formFactor;
	string color;
public:
	Case(string formFactor = "", string color = "") {
		setFormFactor(formFactor);
		setColor(color);
	}
	void setFormFactor(string formFactor) {
		this->formFactor = formFactor;
	}
	void setColor(string color) {
		this->color = color;
	}
	string getFormFactor() {
		return this->formFactor;
	}
	string getColor() {
		return this->color;
	}
};
class ComputerAssembly {
	double price;
public:
	ComputerAssembly() {

	}
};