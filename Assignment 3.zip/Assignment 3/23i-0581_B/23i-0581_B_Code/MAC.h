#pragma once
#include "Computer.h"
#include "AppleSiliconMB.h"
#include "PhysicalMemory.h"
#include "AppleSiliconCPU.h"
#include "GraphicsCard.h"

class MAC : public Computer {
private:
    AppleSiliconMB motherBoard;
    PhysicalMemory mem;
    AppleSiliconCPU cpu;
    GraphicsCard gpu;

public:
    // Constructors
    MAC();
    MAC(const AppleSiliconMB& motherBoard, const PhysicalMemory& mem, const AppleSiliconCPU& cpu, const GraphicsCard& gpu);

    // Getters and Setters
    AppleSiliconMB getMotherBoard() const;
    void setMotherBoard(const AppleSiliconMB& motherBoard);
    PhysicalMemory getMemory() const;
    void setMemory(const PhysicalMemory& mem);
    AppleSiliconCPU getCPU() const;
    void setCPU(const AppleSiliconCPU& cpu);
    GraphicsCard getGPU() const;
    void setGPU(const GraphicsCard& gpu);
};
