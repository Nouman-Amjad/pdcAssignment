#pragma once

#include "MotherBoard.h"
#include "AppleSiliconCPU.h"

class AppleSiliconMB : public MotherBoard {
private:
    AppleSiliconCPU cpu;

public:

    // Constructors
    AppleSiliconMB();
    AppleSiliconMB(const MainMemory& mm, int numPorts, const NetworkCard& nic, const AppleSiliconCPU& cpu);

    // Getters
    AppleSiliconCPU getCPU() const;

    // Setters
    void setCPU(const AppleSiliconCPU& cpu);
};

