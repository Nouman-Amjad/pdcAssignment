#pragma once
#include "PhysicalMemory.h"
#include "PowerSupply.h"
#include "Case.h"
#include "Computer.h"

class ComputerAssembly {
private:
    double totalPrice;
    PhysicalMemory* physicalMem;
    PowerSupply* power;
    Case* c_case;
    Computer* Comp;

public:
    // Constructors
    ComputerAssembly();
    ComputerAssembly(double totalPrice, PhysicalMemory* physicalMem, PowerSupply* power, Case* c_case, Computer* comp);

    // Getters
    Computer* getComputer() const;
    double getTotalPrice() const;
    PhysicalMemory* getPhysicalMemory() const;
    PowerSupply* getPowerSupply() const;
    Case* getCase() const;

    // Setters
    void setComputer(Computer* comp);
    void setTotalPrice(double price);
    void setPhysicalMemory(PhysicalMemory* memory);
    void setPowerSupply(PowerSupply* powerSupply);
    void setCase(Case* c);
};
