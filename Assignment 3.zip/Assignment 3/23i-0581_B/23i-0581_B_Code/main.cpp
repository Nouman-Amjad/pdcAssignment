// Muneeba Zaheer
// BSCS-2B
// 23i-0581
// Dr. Ali Zeeshan
// Muhammad Mohsin Ramzan

#include <iostream>
#include <string>
#include "ComputerAssembly.h"
#include "AppleSiliconMB.h"
#include "PhysicalMemory.h"
#include "AppleSiliconCPU.h"
#include "GraphicsCard.h"
#include "IntelMB.h"
#include "IntellCPU.h"
#include "NetworkCard.h"
#include "PowerSupply.h"
#include "Case.h"
#include "MAC.h"
#include "PC.h"
#include "Laptop.h"
#include "Battery.h"
#include "StorageDevice.h"
using namespace std;

int main() {
    cout << "<----------------------Computer Shop-------------------------------->" << endl;
    string computerType;
    cout << "Enter the type of computer you want to build (MAC, PC, or Laptop): ";
    cin >> computerType;

    if (computerType == "MAC") {
        cout << "----------------Enter details for MAC:--------------------------" << endl;

        // ALU details:
        cout << "Enter the details for ALU (adders(1-4), subtractors(1-4), registers(32/64), size of registers(8/16/32/64)): ";
        int a, b, c, d;
        cin >> a >> b >> c >> d;
        ALU cpuALU(a, b, c, d);

        // CU details:
        cout << "Enter the clockspeed of CU (2.4/3.5/4.0): ";
        float clk;
        cin >> clk;
        ControlUnit cpuControlUnit;
        cpuControlUnit.setclock(clk);

        // CPU details:
        CPU Applecpu(cpuALU, cpuControlUnit);

        // GPU details:
        GraphicsCard cpuGPU;
        cout << "Enter the brand of GPU (AppleSilicon): ";
        string cpub;
        cin >> cpub;
        cpuGPU.setBrand(cpub);
        cout << "Enter the memory size of GPU (4/6): ";
        int s;
        cin >> s;
        cpuGPU.setMemorySize(s);
        cpuGPU.setPrice(12000);


        // Main Memory Details
        MainMemory macMainMemory;
        cout << "Enter capacity of Main Memory (4/8/16/32/64): ";
        int capacity;
        cin >> capacity;
        cout << "Enter technology type of Main Memory: (Semiconductor/Silicon): ";
        string technologyType;
        cin >> technologyType;
        macMainMemory.setCapacity(capacity);
        macMainMemory.setTechnologyType(technologyType);

        // Network Card Details:
        string nicType;
        int nicSpeed;
        NetworkCard macNIC;

        cout << "Enter type of Network Card (Ethernet/WiFi): ";
        cin >> nicType;
        macNIC.setType(nicType);
        cout << "Enter speed of Network Card (10-100): ";
        cin >> nicSpeed;
        macNIC.setSpeed(nicSpeed);
        macNIC.setPrice(10000);

        // Motherboard details
        int numPorts;
        cout << "Enter number of ports: ";
        cin >> numPorts;
        MotherBoard macMotherBoard(macMainMemory, numPorts, macNIC);

        // Port details
        cout << "Enter details for each port:" << endl;
        for (int i = 0; i < numPorts; ++i) {
            cout << "Details for Port " << i + 1 << ":" << endl;
            string type;
            int baudRate;
            cout << "Enter type of port: ";
            cin >> type;
            cout << "Enter baud rate of port: ";
            cin >> baudRate;
            macMotherBoard.setPort(i, Port(type, baudRate));
        }

        //Physical Memory Details
        int cap;
        string typ;
        StorageDevice storageDevice;

        cout << "Enter the capacity of the storage device (128/256/512/1024): ";
        cin >> cap;
        storageDevice.setCapacity(cap);
        cout << "Enter the type of the storage device (HDD/SSD): ";
        cin >> typ;
        storageDevice.setType(typ);
        storageDevice.setPrice(15000);


        //Battery Details:
        int wattage;
        string efficiencyRating;
        int capac;
        Battery battery;

        cout << "Enter the wattage of the battery (100-1800): ";
        cin >> wattage;
        battery.setWattage(wattage);
        cout << "Enter the efficiency rating of the battery (Bronze/Gold/Silver): ";
        cin >> efficiencyRating;
        battery.setEfficiencyRating(efficiencyRating);
        cout << "Enter the capacity of the battery(2000/4000/6000): ";
        cin >> capac;
        battery.setCapacity(capac);
        battery.setPrice(10000);

        //Case Details:
        string formFactor, color;
        cout << "Enter the form factor of the case (ATX/Micro ATX): ";
        cin >> formFactor;
        cout << "Enter the color of the case: ";
        cin >> color;

        Case computerCase(formFactor, color);

        // Display MAC details
        cout << "\nMAC Details:" << endl;
        cout << "--------------------------" << endl;
        // Display CPU details
        cout << "----------------CPU Details:" << endl;
        cout << "----------------ALU Details: " << endl;
        cout << "Adders: " << cpuALU.getNoOfAdders() << endl;
        cout << "Subtracors: " << cpuALU.getNoOfSubtractor() << endl;
        cout << "Registeres: " << cpuALU.getNoOfRegisters() << endl;
        cout << "Size of Registers: " << cpuALU.getsizeOfRegisters() << endl << endl;

        cout << "----------------CU Details: " << endl;
        cout << "Clockspeed of CU: " << cpuControlUnit.getclock() << endl << endl;

        cout << "----------------GPU Details:" << endl;
        cout << "Brand of GPU: " << cpuGPU.getBrand() << endl;
        cout << "Memory size of GPU: " << cpuGPU.getMemorySize() << endl;
        cout << "Price: " << cpuGPU.getPrice() << endl << endl;
        // Display Main Memory details
        cout << "----------------Main Memory Details:" << endl;
        cout << "Capacity of Main Memory: " << macMainMemory.getCapacity() << endl;
        cout << "Technology type of Main Memory: " << macMainMemory.getTechnologyType() << endl << endl;

        // Display Network Card details
        cout << "----------------Network Card Details:" << endl;
        cout << "Type of Network Card: " << macNIC.getType() << endl;
        cout << "Speed of Network Card: " << macNIC.getSpeed() << endl;
        cout << "Price of Network Card:" << macNIC.getPrice() << endl << endl;

        // Display Motherboard details
        cout << "----------------Motherboard Details:" << endl;
        cout << "Number of ports: " << numPorts << endl << endl;
        // Display details of each port
        cout << "----------------Details of Ports:" << endl;
        for (int i = 0; i < numPorts; ++i)
        {
            Port port = macMotherBoard.getPort(i);
            cout << "Port " << i + 1 << ": Type - " << port.getType() << ", Baud Rate - " << port.getBaudRate() << endl;
        }
        cout << endl;
        // Display Physical Memory details
        cout << "----------------Physical Memory Details:" << endl;
        cout << "Capacity of Storage Device: " << storageDevice.getCapacity() << endl;
        cout << "Type of Storage Device: " << storageDevice.getType() << endl << endl;

        // Display Battery details
        cout << "----------------Battery Details:" << endl;
        cout << "Wattage of the battery: " << battery.getWattage() << endl;
        cout << "Efficiency rating of the battery: " << battery.getEfficiencyRating() << endl;
        cout << "Price of the battery: " << battery.getPrice() << endl;
        cout << "Capacity of the battery: " << battery.getCapacity() << endl << endl;

        // Display Case details
        cout << "----------------Case Details:" << endl;
        cout << "Form factor of the case: " << computerCase.getFormFactor() << endl;
        cout << "Color of the case: " << computerCase.getColor() << endl << endl;
    }
    else if (computerType == "PC") {
        cout << "----------------Enter details for PC:--------------------------" << endl;
        // ALU details:
        cout << "Enter the details for ALU (adders(1-4), subtractors(1-4), registers(32/64), size of registers(8/16/32/64)): ";
        int a, b, c, d;
        cin >> a >> b >> c >> d;
        ALU cpuALU(a, b, c, d);

        // CU details:
        cout << "Enter the clockspeed of CU (2.4/3.5/4.0): ";
        float clk;
        cin >> clk;
        ControlUnit cpuControlUnit(clk);

        // CPU details:
        CPU Intellcpu(cpuALU, cpuControlUnit);
        IntellCPU cpu(cpuALU, cpuControlUnit);

        // GPU details:
        GraphicsCard cpuGPU;
        cout << "Enter the brand of GPU (Nvidia/AMD): ";
        string brand;
        cin >> brand;
        cpuGPU.setBrand(brand);
        cout << "Enter the memory size of GPU (4/6): ";
        int memorySize;
        cin >> memorySize;
        cpuGPU.setMemorySize(memorySize);
        cpuGPU.setPrice(12000);

        // Main Memory Details
        MainMemory mainMemory;
        cout << "Enter capacity of Main Memory (4/8/16/32/64): ";
        int capacity;
        cin >> capacity;
        mainMemory.setCapacity(capacity);
        cout << "Enter technology type of Main Memory (Semiconductor/Silicon): ";
        string technologyType;
        cin >> technologyType;
        mainMemory.setTechnologyType(technologyType);

        //NetworkCard details
        string nicType;
        int nicSpeed;
        NetworkCard networkCard;

        cout << "Enter type of Network Card (Ethernet/WiFi): ";
        cin >> nicType;
        networkCard.setType(nicType);
        cout << "Enter speed of Network Card (10-100): ";
        cin >> nicSpeed;
        networkCard.setSpeed(nicSpeed);
        networkCard.setPrice(10000);

        // Motherboard details
        int numPorts;
        cout << "Enter number of ports: ";
        cin >> numPorts;
        IntelMB intelMotherBoard(mainMemory, numPorts, networkCard, cpu, cpuGPU);

        // Port details
        cout << "Enter details for each port:" << endl;
        for (int i = 0; i < numPorts; ++i) {
            cout << "Details for Port " << i + 1 << ":" << endl;
            string type;
            int baudRate;
            cout << "Enter type of port: ";
            cin >> type;
            cout << "Enter baud rate of port: ";
            cin >> baudRate;
            intelMotherBoard.setPort(i, Port(type, baudRate));
        }

        // Physical Memory Details
        StorageDevice storageDevice;
        cout << "Enter the capacity of the storage device (128/256/512/1024): ";
        int storageCapacity;
        cin >> storageCapacity;
        storageDevice.setCapacity(storageCapacity);
        cout << "Enter the type of the storage device (HDD/SSD): ";
        string storageType;
        cin >> storageType;
        storageDevice.setType(storageType);
        storageDevice.setPrice(15000);

        // Power Supply Details
        PowerSupply powerSupply;
        int wattage;
        string efficiencyRating;
        cout << "Enter the wattage of the power supply (100--1800): ";
        cin >> wattage;
        powerSupply.setWattage(wattage);
        cout << "Enter the efficiency rating of the power supply (Bronze/Silver/Gold): ";
        cin >> efficiencyRating;
        powerSupply.setEfficiencyRating(efficiencyRating);
        powerSupply.setPrice(1000);

        // Case Details
        string formFactor, caseColor;
        cout << "Enter the form factor of the case (ATX/Micro ATX): ";
        cin >> formFactor;
        cout << "Enter the color of the case: ";
        cin >> caseColor;
        Case pcCase(formFactor, caseColor);

        // Display PC details
        cout << "\nPC Details:" << endl;
        cout << "--------------------------" << endl;
        // Display CPU details
        cout << "----------------CPU Details:" << endl;
        cout << "----------------ALU Details: " << endl;
        cout << "Adders: " << cpuALU.getNoOfAdders() << endl;
        cout << "Subtractors: " << cpuALU.getNoOfSubtractor() << endl;
        cout << "Registers: " << cpuALU.getNoOfRegisters() << endl;
        cout << "Size of Registers: " << cpuALU.getsizeOfRegisters() << endl << endl;

        cout << "----------------CU Details: " << endl;
        cout << "Clockspeed of CU: " << cpuControlUnit.getclock() << endl << endl;

        // Display GPU details
        cout << "----------------GPU Details:" << endl;
        cout << "Brand of GPU: " << cpuGPU.getBrand() << endl;
        cout << "Memory size of GPU: " << cpuGPU.getMemorySize() << endl;
        cout << "Price of GPU: " << cpuGPU.getPrice() << endl << endl;

        // Display Main Memory details
        cout << "----------------Main Memory Details:" << endl;
        cout << "Capacity of Main Memory: " << mainMemory.getCapacity() << endl;
        cout << "Technology type of Main Memory: " << mainMemory.getTechnologyType() << endl << endl;

        // Display Network Card details
        cout << "----------------Network Card Details:" << endl;
        cout << "Type of Network Card: " << networkCard.getType() << endl;
        cout << "Speed of Network Card: " << networkCard.getSpeed() << endl << endl;
        cout << "Price of Network Card:" << networkCard.getPrice() << endl << endl;

        // Display Motherboard details
        cout << "----------------Motherboard Details:" << endl;
        cout << "Number of ports: " << numPorts << endl << endl;
        // Display details of each port
        cout << "----------------Details of Ports:" << endl;
        for (int i = 0; i < numPorts; ++i) {
            Port port = intelMotherBoard.getPort(i);
            cout << "Port " << i + 1 << ": Type - " << port.getType() << ", Baud Rate - " << port.getBaudRate() << endl;
        }
        cout << endl;

        // Display Physical Memory details
        cout << "----------------Physical Memory Details:" << endl;
        cout << "Capacity of Storage Device: " << storageDevice.getCapacity() << endl;
        cout << "Type of Storage Device: " << storageDevice.getType() << endl << endl;

        // Display Power Supply details
        cout << "----------------Power Supply Details:" << endl;
        cout << "Wattage of the power supply: " << powerSupply.getWattage() << endl;
        cout << "Efficiency rating of the power supply: " << powerSupply.getEfficiencyRating() << endl;
        cout << "Price of the power supply: " << powerSupply.getPrice() << endl << endl;

        // Display Case details
        cout << "----------------Case Details:" << endl;
        cout << "Form factor of the case: " << pcCase.getFormFactor() << endl;
        cout << "Color of the case: " << pcCase.getColor() << endl << endl;
        }
    else if (computerType == "Laptop") {
            cout << "----------------Enter details for Laptop:--------------------------" << endl;

            // ALU details:
            cout << "Enter the details for ALU (adders(1-4), subtractors(1-4), registers(32/64), size of registers(8/16/32/64)): ";
            int a, b, c, d;
            cin >> a >> b >> c >> d;
            ALU cpuALU(a, b, c, d);

            // CU details:
            cout << "Enter the clockspeed of CU (2.4/3.5/4.0): ";
            float clk;
            cin >> clk;
            ControlUnit cpuControlUnit(clk);

            // CPU details:
            IntellCPU cpu(cpuALU, cpuControlUnit);

            // GPU details:
            GraphicsCard cpuGPU;
            cout << "Enter the brand of GPU (Nvidia/AMD): ";
            string brand;
            cin >> brand;
            cpuGPU.setBrand(brand);
            cout << "Enter the memory size of GPU (4/6): ";
            int memorySize;
            cin >> memorySize;
            cpuGPU.setMemorySize(memorySize);
            cpuGPU.setPrice(12000);

            // Main Memory Details
            MainMemory mainMemory;
            cout << "Enter capacity of Main Memory (4/8/16/32/64): ";
            int capacity;
            cin >> capacity;
            mainMemory.setCapacity(capacity);
            cout << "Enter technology type of Main Memory (Semiconductor/Silicon): ";
            string technologyType;
            cin >> technologyType;
            mainMemory.setTechnologyType(technologyType);

            //NetworkCard Details
            string nicType;
            int nicSpeed;
            NetworkCard networkCard;

            cout << "Enter type of Network Card (Ethernet/WiFi): ";
            cin >> nicType;
            networkCard.setType(nicType);
            cout << "Enter speed of Network Card (10-100): ";
            cin >> nicSpeed;
            networkCard.setSpeed(nicSpeed);
            networkCard.setPrice(10000);

            // Motherboard details
            int numPorts;
            cout << "Enter number of ports: ";
            cin >> numPorts;
            IntelMB intelMotherBoard(mainMemory, numPorts, networkCard, cpu, cpuGPU);

            // Port details
            cout << "Enter details for each port:" << endl;
            for (int i = 0; i < numPorts; ++i) {
                cout << "Details for Port " << i + 1 << ":" << endl;
                string type;
                int baudRate;
                cout << "Enter type of port: ";
                cin >> type;
                cout << "Enter baud rate of port: ";
                cin >> baudRate;
                intelMotherBoard.setPort(i, Port(type, baudRate));
            }

            // Battery Details
            string efficiencyR;
            int batteryCapacity;
            Battery battery;
            cout << "Enter the efficiency rating of the battery (Bronze/Silver/Gold): ";
            cin >> efficiencyR;
            battery.setEfficiencyRating(efficiencyR);
            cout << "Enter the capacity of the battery: ";
            cin >> batteryCapacity;
            battery.setCapacity(batteryCapacity);
            battery.setPrice(10000);

            //Physical Memory Details
            int cap;
            string typ;
            StorageDevice storageDevice;

            cout << "Enter the capacity of the storage device (128/256/512/1024): ";
            cin >> cap;
            storageDevice.setCapacity(cap);
            cout << "Enter the type of the storage device (HDD/SSD): ";
            cin >> typ;
            storageDevice.setType(typ);
            storageDevice.setPrice(15000);

            // Case Details
            string formFactor, caseColor;
            cout << "Enter the form factor of the case (ATX/Micro ATX): ";
            cin >> formFactor;
            cout << "Enter the color of the case: ";
            cin >> caseColor;
            Case laptopCase(formFactor, caseColor);

            // Display Laptop details
            cout << "\nLaptop Details:" << endl;
            cout << "--------------------------" << endl;

            // Display CPU details
            cout << "----------------CPU Details:" << endl;
            cout << "----------------ALU Details: " << endl;
            cout << "Adders: " << cpuALU.getNoOfAdders() << endl;
            cout << "Subtractors: " << cpuALU.getNoOfSubtractor() << endl;
            cout << "Registers: " << cpuALU.getNoOfRegisters() << endl;
            cout << "Size of Registers: " << cpuALU.getsizeOfRegisters() << endl << endl;

            cout << "----------------CU Details: " << endl;
            cout << "Clockspeed of CU: " << cpuControlUnit.getclock() << endl << endl;

            // Display GPU details
            cout << "----------------GPU Details:" << endl;
            cout << "Brand of GPU: " << cpuGPU.getBrand() << endl;
            cout << "Memory size of GPU: " << cpuGPU.getMemorySize() << endl;
            cout << "Price of GPU: " << cpuGPU.getPrice() << endl << endl;

            // Display Main Memory details
            cout << "----------------Main Memory Details:" << endl;
            cout << "Capacity of Main Memory: " << mainMemory.getCapacity() << endl;
            cout << "Technology type of Main Memory: " << mainMemory.getTechnologyType() << endl << endl;

            // Display Network Card details
            cout << "----------------Network Card Details:" << endl;
            cout << "Type of Network Card: " << networkCard.getType() << endl;
            cout << "Speed of Network Card: " << networkCard.getSpeed() << endl << endl;
            cout << "Price of Network Card:" << networkCard.getPrice() << endl << endl;
            // Display Motherboard details
            cout << "----------------Motherboard Details:" << endl;
            cout << "Number of ports: " << numPorts << endl << endl;
            // Display details of each port
            cout << "----------------Details of Ports:" << endl;
            for (int i = 0; i < numPorts; ++i) {
                Port port = intelMotherBoard.getPort(i);
                cout << "Port " << i + 1 << ": Type - " << port.getType() << ", Baud Rate - " << port.getBaudRate() << endl;
            }
            cout << endl;

            // Display Physical Memory details
            cout << "----------------Physical Memory Details:" << endl;
            cout << "Capacity of Storage Device: " << storageDevice.getCapacity() << endl;
            cout << "Type of Storage Device: " << storageDevice.getType() << endl << endl;

            // Display Battery details
            cout << "----------------Battery Details:" << endl;
            cout << "Efficiency rating of the battery: " << battery.getEfficiencyRating() << endl;
            cout << "Price of the battery: " << battery.getPrice() << endl;
            cout << "Capacity of the battery: " << battery.getCapacity() << endl << endl;

            // Display Case details
            cout << "----------------Case Details:" << endl;
            cout << "Form factor of the case: " << laptopCase.getFormFactor() << endl;
            cout << "Color of the case: " << laptopCase.getColor() << endl << endl;
            }
    else {
                cout << "Invalid computer type!" << endl;
                return 1;
                }

                cout << "<--------------------Thank You!!!!------------------------------------->" << endl;
                return 0;
}


