#pragma once

class PhysicalMemory {
protected:
    int capacity;

public:

    //constructors
    PhysicalMemory();
    PhysicalMemory(int c);

    //getters and setters
    int getCapacity() ; 
    void setCapacity(int);
};
