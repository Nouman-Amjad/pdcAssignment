#include "Port.h"
#include <iostream>

Port::Port() : baudRate(0) {}

Port::Port(const std::string& type, int baudRate) : type(type), baudRate(baudRate) {}

std::string Port::getType() const {
    return type;
}

int Port::getBaudRate() const {
    return baudRate;
}

void Port::setType(const std::string& type) {
    this->type = type;
}

void Port::setBaudRate(int baudRate) {
    this->baudRate = baudRate;
}

