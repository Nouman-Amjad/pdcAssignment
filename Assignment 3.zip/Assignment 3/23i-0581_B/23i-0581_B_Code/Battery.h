#pragma once

#include "PowerSupply.h"

class Battery : public PowerSupply {
private:
    int capacity;

public:
    // Constructors
    Battery();
    Battery(int wattage, const string& efficiencyRating, double price, int capacity);

    // Getter
    int getCapacity() const;

    // Setter
    void setCapacity(int capacity);
};

