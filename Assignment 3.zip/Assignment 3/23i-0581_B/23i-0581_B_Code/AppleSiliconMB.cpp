#include "AppleSiliconMB.h"

// Default constructor
AppleSiliconMB::AppleSiliconMB() {}

// Parameterized constructor
AppleSiliconMB::AppleSiliconMB(const MainMemory& mm, int numPorts, const NetworkCard& nic, const AppleSiliconCPU& cpu)
    : MotherBoard(mm, numPorts, nic), cpu(cpu) {}

// Getter for CPU
AppleSiliconCPU AppleSiliconMB::getCPU() const {
    return cpu;
}

// Setter for CPU
void AppleSiliconMB::setCPU(const AppleSiliconCPU& cpu) {
    this->cpu = cpu;
}