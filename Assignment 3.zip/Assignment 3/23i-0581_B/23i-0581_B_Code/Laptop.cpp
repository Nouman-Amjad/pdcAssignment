#include "Laptop.h"

Laptop::Laptop() {}

Laptop::Laptop(const IntelMB& motherBoard, const PhysicalMemory& mem, const IntellCPU& cpu)
    : motherBoard(motherBoard), mem(mem), cpu(cpu) {}

IntelMB Laptop::getMotherBoard() const {
    return motherBoard;
}

void Laptop::setMotherBoard(const IntelMB& motherBoard) {
    this->motherBoard = motherBoard;
}

PhysicalMemory Laptop::getMemory() const {
    return mem;
}

void Laptop::setMemory(const PhysicalMemory& mem) {
    this->mem = mem;
}

IntellCPU Laptop::getCPU() const {
    return cpu;
}

void Laptop::setCPU(const IntellCPU& cpu) {
    this->cpu = cpu;
}
