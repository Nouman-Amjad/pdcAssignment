#pragma once
#include "MotherBoard.h"
#include "IntellCPU.h"
#include "GraphicsCard.h"

class IntelMB : public MotherBoard {
private:
    IntellCPU cpu;
    GraphicsCard GPU;

public:
    // Constructors
    IntelMB();
    IntelMB(const MainMemory& mm, int numPorts, const NetworkCard& nic, const IntellCPU& cpu, const GraphicsCard& gpu);

    // Getters and Setters
    IntellCPU getCPU() const;
    void setCPU(const IntellCPU& cpu);
    GraphicsCard getGPU() const;
    void setGPU(const GraphicsCard& gpu);
};
