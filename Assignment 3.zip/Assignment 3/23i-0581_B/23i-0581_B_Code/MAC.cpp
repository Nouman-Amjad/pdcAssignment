#include "MAC.h"

// Default constructor
MAC::MAC() {}

// Parameterized constructor
MAC::MAC(const AppleSiliconMB& motherBoard, const PhysicalMemory& mem, const AppleSiliconCPU& cpu, const GraphicsCard& gpu)
    : motherBoard(motherBoard), mem(mem), cpu(cpu), gpu(gpu) {}

// Getters and setters for motherBoard
AppleSiliconMB MAC::getMotherBoard() const {
    return motherBoard;
}

void MAC::setMotherBoard(const AppleSiliconMB& motherBoard) {
    this->motherBoard = motherBoard;
}

// Getters and setters for memory
PhysicalMemory MAC::getMemory() const {
    return mem;
}

void MAC::setMemory(const PhysicalMemory& mem) {
    this->mem = mem;
}

// Getters and setters for CPU
AppleSiliconCPU MAC::getCPU() const {
    return cpu;
}

void MAC::setCPU(const AppleSiliconCPU& cpu) {
    this->cpu = cpu;
}

// Getters and setters for GPU
GraphicsCard MAC::getGPU() const {
    return gpu;
}

void MAC::setGPU(const GraphicsCard& gpu) {
    this->gpu = gpu;
}
