#include "NetworkCard.h"
#include <iostream>
using namespace std;
NetworkCard::NetworkCard() : speed(0), price(0.0) {}

NetworkCard::NetworkCard(const std::string& type, int speed, double price)
    : type(type), speed(speed), price(price) {}

std::string NetworkCard::getType() const {
    return type;
}

int NetworkCard::getSpeed() const {
    return speed;
}

double NetworkCard::getPrice() const {
    return price;
}

void NetworkCard::setType(const std::string& type) {
    this->type = type;
}

void NetworkCard::setSpeed(int speed) {
    // Input validation: Limit speed to be greater than 10 and less than 100
    if (speed <= 10 || speed >= 100) {
        cout << "Invalid network card speed. Setting to default (10)." <<endl;
        this->speed = 10;
    }
    else {
        this->speed = speed;
    }
}

void NetworkCard::setPrice(double price) {
    this->price = price;
}
