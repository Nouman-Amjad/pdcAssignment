#pragma once

#include <string>
using namespace std;

class Case {
private:
    string formFactor;
    string color;

public:
    // Constructors
    Case();
    Case(const string& formFactor, const std::string& color);

    // Getters
    string getFormFactor();
    string getColor();

    // Setters
    void setFormFactor(const string& formFactor);
    void setColor(const string& color);
};

