#include "MainMemory.h"
#include <iostream>
using namespace std;
MainMemory::MainMemory() : capacity(0) {}

MainMemory::MainMemory(int capacity, const std::string& technologyType)
    : capacity(capacity), technologyType(technologyType) {}

int MainMemory::getCapacity() const {
    return capacity;
}

std::string MainMemory::getTechnologyType() const {
    return technologyType;
}

void MainMemory::setCapacity(int capacity) {
    if (capacity != 4 && capacity != 8 && capacity != 16 && capacity != 32 && capacity != 64) {
        cout << "Invalid main memory capacity. Setting to default (8)." << endl;
        this->capacity = 8;
    }
    else {
        this->capacity = capacity;
    }
}

void MainMemory::setTechnologyType(const std::string& technologyType) {
    this->technologyType = technologyType;
}
