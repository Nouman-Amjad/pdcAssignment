
#include "MotherBoard.h"

MotherBoard::MotherBoard() : ports(nullptr), numPorts(0) {}

MotherBoard::MotherBoard(const MainMemory& mm, int numPorts, const NetworkCard& nic)
    : mm(mm), numPorts(numPorts), nic(nic) {
    ports = new Port[numPorts];
}

MotherBoard::~MotherBoard() {
    delete[] ports;
}

MainMemory MotherBoard::getMainMemory() const {
    return mm;
}

void MotherBoard::setMainMemory(const MainMemory& mm) {
    this->mm = mm;
}

Port MotherBoard::getPort(int index) const {
    return ports[index];
}

void MotherBoard::setPort(int index, const Port& port) {
    ports[index] = port;
}

NetworkCard MotherBoard::getNetworkCard() const {
    return nic;
}

void MotherBoard::setNetworkCard(const NetworkCard& nic) {
    this->nic = nic;
}

int MotherBoard::getNumPorts() const {
    return numPorts;
}
