#include "ALU.h"
#include <iostream>

using namespace std;

ALU::ALU() : NoOfAdders(0), NoOfSubtractor(0), NoOfRegisters(0), sizeOfRegisters(0) {}

ALU::ALU(int add, int sub, int reg, int s_reg) {
    setNoOfAdders(add);
    setNoOfSubtractor(sub);
    setNoOfRegisters(reg);
    setsizeOfRegisters(s_reg);
}

int ALU::getNoOfAdders() {
    return NoOfAdders;
}

int ALU::getNoOfSubtractor() {
    return NoOfSubtractor;
}

int ALU::getNoOfRegisters() {
    return NoOfRegisters;
}

int ALU::getsizeOfRegisters() {
    return sizeOfRegisters;
}

void ALU::setNoOfAdders(int add) {
    // Input validation: Limit adders between 1 and 4
    if (add < 1 || add > 4) {
        cout << "Invalid number of adders. Setting to default (4)." << endl;
        NoOfAdders = 4;
    }
    else {
        NoOfAdders = add;
    }
}

void ALU::setNoOfSubtractor(int sub) {
    // Input validation: Limit subtractors between 1 and 4
    if (sub < 1 || sub > 4) {
        cout << "Invalid number of subtractors. Setting to default (4)." << endl;
        NoOfSubtractor = 4;
    }
    else {
        NoOfSubtractor = sub;
    }
}

void ALU::setNoOfRegisters(int reg) {
    // Input validation: Limit registers to either 32 or 64
    if (reg != 32 && reg != 64) {
        cout << "Invalid number of registers. Setting to default (64)." << endl;
        NoOfRegisters = 64;
    }
    else {
        NoOfRegisters = reg;
    }
}

void ALU::setsizeOfRegisters(int s_reg) {
    // Input validation: Limit register size to 8, 16, 32, or 64
    if (s_reg != 8 && s_reg != 16 && s_reg != 32 && s_reg != 64) {
        cout << "Invalid size of registers. Setting to default (64)." << endl;
        sizeOfRegisters = 64;
    }
    else {
        sizeOfRegisters = s_reg;
    }
}
