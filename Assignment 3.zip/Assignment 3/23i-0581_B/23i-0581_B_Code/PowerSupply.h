#pragma once
#include <string>
using namespace std;
class PowerSupply {
private:
    int wattage;
    string efficiencyRating;
    double price;

public:

    //constructors
    PowerSupply();
    PowerSupply(int wattage, const string& efficiencyRating, double price); 

    //getters and setters
    int getWattage() const;
    string getEfficiencyRating() const;
    double getPrice() const;
    void setWattage(int wattage);
    void setEfficiencyRating(const string& efficiencyRating);
    void setPrice(double price);
};

