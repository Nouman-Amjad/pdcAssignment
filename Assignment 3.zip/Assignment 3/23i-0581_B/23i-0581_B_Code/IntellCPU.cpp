#include "IntellCPU.h"
IntellCPU::IntellCPU() {}
IntellCPU::IntellCPU(const ALU& alu, const ControlUnit& cu) : CPU(alu, cu) {}
