#include "PhysicalMemory.h"
#include <iostream>
using namespace std;
PhysicalMemory::PhysicalMemory() : capacity(0) {}

PhysicalMemory::PhysicalMemory(int c) {
    setCapacity(c);
}

int PhysicalMemory::getCapacity() {
    return capacity;
}

void PhysicalMemory::setCapacity(int c) {
    if (c != 64 && c != 128 && c != 256 && c != 512 && c != 1024) {
        cout << "Invalid input: Setting to default value(128): " << endl;
        capacity = 128;
    }
    else {
        capacity = c;
    }
}
