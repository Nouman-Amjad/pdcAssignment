#pragma once
#include "Computer.h"
#include "IntelMB.h"
#include "PhysicalMemory.h"
#include "IntellCPU.h"
#include "NetworkCard.h" 

class PC : public Computer {
private:
    IntelMB motherBoard;
    PhysicalMemory mem;
    IntellCPU cpu;
    NetworkCard nic;

public:
    // Constructors
    PC();
    PC(const IntelMB& motherBoard, const PhysicalMemory& mem, const IntellCPU& cpu, const NetworkCard& nic);

    // Getters and setters
    IntelMB getMotherBoard() const;
    void setMotherBoard(const IntelMB& motherBoard);
    PhysicalMemory getMemory() const;
    void setMemory(const PhysicalMemory& mem);
    IntellCPU getCPU() const;
    void setCPU(const IntellCPU& cpu);
    NetworkCard getNIC() const;
    void setNIC(const NetworkCard& nic);
};


