#pragma once
#include <string>
using namespace std;

class GraphicsCard {
private:
    string brand;
    int memorySize;
    double price;

public:
    // Constructors
    GraphicsCard();
    GraphicsCard(const string& brand, int memorySize, double price);

    // Getters
    string getBrand() const;
    int getMemorySize() const;
    double getPrice() const;

    // Setters
    void setBrand(const string& brand);
    void setMemorySize(int memorySize);
    void setPrice(double price);
};
