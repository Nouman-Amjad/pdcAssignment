#include "AppleSiliconMB.h"

// Default constructor
AppleSiliconCPU::AppleSiliconCPU() {}

// Parameterized constructor
AppleSiliconCPU::AppleSiliconCPU(const ALU& alu, const ControlUnit& cu, const GraphicsCard& gpu)
    : CPU(alu, cu), GPU(gpu) {}

// Getter for GraphicsCard
GraphicsCard AppleSiliconCPU::getGraphicsCard() const {
    return GPU;
}

// Setter for GraphicsCard
void AppleSiliconCPU::setGraphicsCard(const GraphicsCard& gpu) {
    GPU = gpu;
}