#pragma once

class ControlUnit {
private:
    float clock;

public:
    // Constructors
    ControlUnit();
    ControlUnit(float);

    // Getter and Setter
    float getclock();
    void setclock(float);
};
