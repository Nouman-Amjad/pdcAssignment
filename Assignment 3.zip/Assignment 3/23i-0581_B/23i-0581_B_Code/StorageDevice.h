#pragma once
#include "PhysicalMemory.h"
#include <string>
using namespace std;
class StorageDevice : public PhysicalMemory {
private:
    string type;
    double price;

public:

    //Constructors
    StorageDevice();
    StorageDevice(const string& type, double price, int capacity);

    //setters and getters
    string getType() const;
    int getCapacity() const;
    double getPrice() const;
    void setType(const string& type);
    void setCapacity(int capacity);
    void setPrice(double price);
};

