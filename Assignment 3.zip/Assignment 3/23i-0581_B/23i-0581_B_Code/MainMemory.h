#pragma once
#include <string>
using namespace std;

class MainMemory {
private:
    int capacity;
    string technologyType;

public:
    // Constructors
    MainMemory();
    MainMemory(int capacity, const string& technologyType);

    // Getters
    int getCapacity() const;
    string getTechnologyType() const;

    // Setters
    void setCapacity(int capacity);
    void setTechnologyType(const string& technologyType);
};
