#include "PC.h"

PC::PC() {}

PC::PC(const IntelMB& motherBoard, const PhysicalMemory& mem, const IntellCPU& cpu, const NetworkCard& nic)
    : motherBoard(motherBoard), mem(mem), cpu(cpu), nic(nic) {}

IntelMB PC::getMotherBoard() const {
    return motherBoard;
}

void PC::setMotherBoard(const IntelMB& motherBoard) {
    this->motherBoard = motherBoard;
}

PhysicalMemory PC::getMemory() const {
    return mem;
}

void PC::setMemory(const PhysicalMemory& mem) {
    this->mem = mem;
}

IntellCPU PC::getCPU() const {
    return cpu;
}

void PC::setCPU(const IntellCPU& cpu) {
    this->cpu = cpu;
}

// Getter and setter for NIC
NetworkCard PC::getNIC() const {
    return nic;
}

void PC::setNIC(const NetworkCard& nic) {
    this->nic = nic;
}
