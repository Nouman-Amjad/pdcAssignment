#include "Computer.h"

Computer::Computer() {}
