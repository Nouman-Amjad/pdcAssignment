#include "Battery.h"
#include <iostream>
using namespace std;
Battery::Battery() : PowerSupply(), capacity(0) {}

Battery::Battery(int wattage, const std::string& efficiencyRating, double price, int capacity)
    : PowerSupply(wattage, efficiencyRating, price), capacity(capacity) {}

int Battery::getCapacity() const {
    return capacity;
}

void Battery::setCapacity(int capacity) {
    // Input validation: Limit battery capacity to 2000, 4000, or 6000
    if (capacity != 2000 && capacity != 4000 && capacity != 6000) {
        cout << "Invalid battery capacity. Setting to default (2000)." << endl;
        this->capacity = 2000;
    }
    else {
        this->capacity = capacity;
    }
}
