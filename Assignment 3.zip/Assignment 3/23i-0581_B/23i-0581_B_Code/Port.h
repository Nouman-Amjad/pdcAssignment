#include <string.h>
#include <iostream>
using namespace std;
class Port {
private:
    std::string type;
    int baudRate;

public:
    
    //construcors
    Port();
    Port(const std::string& type, int baudRate);

    //setters and getters
    std::string getType() const;
    int getBaudRate() const;
    void setType(const std::string& type);
    void setBaudRate(int baudRate);
};