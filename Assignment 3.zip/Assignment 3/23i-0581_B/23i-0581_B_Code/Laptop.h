#pragma once
#include "Computer.h"
#include "IntelMB.h"
#include "PhysicalMemory.h"
#include "IntellCPU.h"

class Laptop : public Computer {
private:
    IntelMB motherBoard;
    PhysicalMemory mem;
    IntellCPU cpu;

public:
    // Constructors
    Laptop();
    Laptop(const IntelMB& motherBoard, const PhysicalMemory& mem, const IntellCPU& cpu);

    // Getters and Setters
    IntelMB getMotherBoard() const;
    void setMotherBoard(const IntelMB& motherBoard);
    PhysicalMemory getMemory() const;
    void setMemory(const PhysicalMemory& mem);
    IntellCPU getCPU() const;
    void setCPU(const IntellCPU& cpu);
};
