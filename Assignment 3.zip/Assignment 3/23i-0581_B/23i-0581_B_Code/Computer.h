#pragma once

class Computer {
public:
    // Constructor
    Computer();
};
