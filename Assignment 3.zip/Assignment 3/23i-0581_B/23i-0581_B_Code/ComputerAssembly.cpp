#include "ComputerAssembly.h"

ComputerAssembly::ComputerAssembly() : totalPrice(0), physicalMem(nullptr), power(nullptr), c_case(nullptr), Comp(nullptr) {}

ComputerAssembly::ComputerAssembly(double totalPrice, PhysicalMemory* physicalMem, PowerSupply* power, Case* c_case, Computer* comp)
    : totalPrice(totalPrice), physicalMem(physicalMem), power(power), c_case(c_case), Comp(comp) {}

Computer* ComputerAssembly::getComputer() const {
    return Comp;
}

void ComputerAssembly::setComputer(Computer* comp) {
    Comp = comp;
}

double ComputerAssembly::getTotalPrice() const {
    return totalPrice;
}

PhysicalMemory* ComputerAssembly::getPhysicalMemory() const {
    return physicalMem;
}

PowerSupply* ComputerAssembly::getPowerSupply() const {
    return power;
}

Case* ComputerAssembly::getCase() const {
    return c_case;
}

void ComputerAssembly::setTotalPrice(double price) {
    totalPrice = price;
}

void ComputerAssembly::setPhysicalMemory(PhysicalMemory* memory) {
    physicalMem = memory;
}

void ComputerAssembly::setPowerSupply(PowerSupply* powerSupply) {
    power = powerSupply;
}

void ComputerAssembly::setCase(Case* c) {
    c_case = c;
}
