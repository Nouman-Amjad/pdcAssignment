#pragma once
#include "CPU.h"

class IntellCPU : public CPU {
public:
    // Constructors
    IntellCPU();
    IntellCPU(const ALU& alu, const ControlUnit& cu);
};
