#include "StorageDevice.h"
#include <iostream>
using namespace std;
StorageDevice::StorageDevice() : PhysicalMemory(), price(0.0) {}

StorageDevice::StorageDevice(const std::string& type, double price, int capacity)
    : PhysicalMemory(capacity), type(type), price(price) {}

std::string StorageDevice::getType() const {
    return type;
}

int StorageDevice::getCapacity() const {
    return capacity;
}

double StorageDevice::getPrice() const {
    return price;
}

void StorageDevice::setType(const std::string& type) {
    this->type = type;
}

void StorageDevice::setCapacity(int capacity) {
    if (capacity != 128 && capacity != 256 && capacity != 512 && capacity != 1024) {
        cout << "Invalid storage capacity. Setting to default (128)." << endl;
        this->capacity = 128;
    }
    else {
        this->capacity = capacity;
    }
}

void StorageDevice::setPrice(double price) {
    this->price = price;
}
