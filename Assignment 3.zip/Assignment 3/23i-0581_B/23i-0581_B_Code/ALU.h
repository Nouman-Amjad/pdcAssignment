#pragma once
class ALU
{
private:
	int NoOfAdders;
	int NoOfSubtractor;
	int NoOfRegisters;
	int sizeOfRegisters;
public:

	//constructors
	ALU();
	ALU(int, int, int, int);

	//getters
	int getNoOfAdders();
	int getNoOfSubtractor();
	int getNoOfRegisters();
	int getsizeOfRegisters();

	//setters
	void setNoOfAdders(int);
	void setNoOfSubtractor(int);
	void setNoOfRegisters(int);
	void setsizeOfRegisters(int);
};
