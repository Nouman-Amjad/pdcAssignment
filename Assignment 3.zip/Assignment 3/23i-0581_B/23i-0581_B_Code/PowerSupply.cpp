#include "PowerSupply.h"
#include <iostream>
PowerSupply::PowerSupply() : wattage(0), price(0.0) {}

PowerSupply::PowerSupply(int wattage, const string& efficiencyRating, double price)
    : wattage(wattage), efficiencyRating(efficiencyRating), price(price) {}

int PowerSupply::getWattage() const {
    return wattage;
}

string PowerSupply::getEfficiencyRating() const {
    return efficiencyRating;
}

double PowerSupply::getPrice() const {
    return price;
}

void PowerSupply::setWattage(int wattage) {
    cout << "Invalid input. Setting it to the default value(100)." << endl;
    if (wattage < 100 || wattage > 1800) {
        this->wattage = 100;
    }
    else {
        this->wattage = wattage;
    }
}

void PowerSupply::setEfficiencyRating(const string& efficiencyRating) {
    this->efficiencyRating = efficiencyRating;
}

void PowerSupply::setPrice(double price) {
    this->price = price;
}
