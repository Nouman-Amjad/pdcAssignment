#include "GraphicsCard.h"
#include <iostream>
using namespace std;
GraphicsCard::GraphicsCard() : memorySize(0), price(0.0) {}

GraphicsCard::GraphicsCard(const std::string& brand, int memorySize, double price)
    : brand(brand), memorySize(memorySize), price(price) {}

std::string GraphicsCard::getBrand() const {
    return brand;
}

int GraphicsCard::getMemorySize() const {
    return memorySize;
}

double GraphicsCard::getPrice() const {
    return price;
}

void GraphicsCard::setBrand(const std::string& brand) {
    this->brand = brand;
}

void GraphicsCard::setMemorySize(int memorySize) {
    if (memorySize != 4 && memorySize != 6) {
        cout << "Invalid graphics card memory size. Setting to default (4)." << endl;
        this->memorySize = 4;
    }
    else {
        this->memorySize = memorySize;
    }
}

void GraphicsCard::setPrice(double price) {
    this->price = price;
}
