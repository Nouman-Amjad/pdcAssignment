#include "Case.h"
Case::Case() {
}

Case::Case(const std::string& formFactor, const std::string& color)
    : formFactor(formFactor), color(color) {
}

std::string Case::getFormFactor(){
    return formFactor;
}
std::string Case::getColor(){
    return color;
}
void Case::setFormFactor(const string& formFactor) {
    this->formFactor = formFactor;
}

void Case::setColor(const string& color) {
    this->color = color;
}
