#include "IntelMB.h"

IntelMB::IntelMB() {}

IntelMB::IntelMB(const MainMemory& mm, int numPorts, const NetworkCard& nic, const IntellCPU& cpu, const GraphicsCard& gpu)
    : MotherBoard(mm, numPorts, nic), cpu(cpu), GPU(gpu) {}

IntellCPU IntelMB::getCPU() const {
    return cpu;
}

void IntelMB::setCPU(const IntellCPU& cpu) {
    this->cpu = cpu;
}

GraphicsCard IntelMB::getGPU() const {
    return GPU;
}

void IntelMB::setGPU(const GraphicsCard& gpu) {
    GPU = gpu;
}
