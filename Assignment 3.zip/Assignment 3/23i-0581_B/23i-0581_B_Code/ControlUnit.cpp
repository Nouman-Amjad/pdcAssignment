#include "ControlUnit.h"
#include <iostream>
using namespace std;
ControlUnit::ControlUnit() : clock(0.0f) {}

ControlUnit::ControlUnit(float clk) {
    setclock(clk);
}

float ControlUnit::getclock() {
    return clock;
}

void ControlUnit::setclock(float clk) {
    // Input validation: Limit clock speed to 2.4, 3.5, or 4
    if (clk != 2.4f && clk != 3.5f && clk != 4.0f) {
        cout << "Invalid clock speed. Setting to default (2.4)." << endl;
        clock = 2.4f;
    }
    else {
        clock = clk;
    }
}
