#pragma once
#include <string>

class NetworkCard {
private:
    std::string type;
    int speed;
    double price;

public:
    // Constructors
    NetworkCard();
    NetworkCard(const std::string& type, int speed, double price);

    // Getters
    std::string getType() const;
    int getSpeed() const;
    double getPrice() const;

    // Setters
    void setType(const std::string& type);
    void setSpeed(int speed);
    void setPrice(double price);
};

