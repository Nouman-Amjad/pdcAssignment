// In MotherBoard.h
#pragma once
#include "Port.h"
#include "NetworkCard.h"
#include "MainMemory.h"

class MotherBoard {
private:
    Port* ports;
    int numPorts;
    MainMemory mm;
    NetworkCard nic;

public:
    // Constructors
    MotherBoard();
    MotherBoard(const MainMemory& mm, int numPorts, const NetworkCard& nic);

    // Destructor
    ~MotherBoard();

    // Getters
    MainMemory getMainMemory() const;
    Port getPort(int index) const;
    NetworkCard getNetworkCard() const;
    int getNumPorts() const;

    // Setters
    void setMainMemory(const MainMemory& mm);
    void setPort(int index, const Port& port);
    void setNetworkCard(const NetworkCard& nic);
};
