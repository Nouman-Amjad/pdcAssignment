#include "CPU.h"

CPU::CPU() {
}

CPU::CPU(const ALU& alu, const ControlUnit& cu) : alu(alu), cu(cu) {}

ALU CPU::getALU() const {
    return alu;
}

void CPU::setALU(const ALU& alu) {
    this->alu = alu;
}

ControlUnit CPU::getControlUnit() const {
    return cu;
}

void CPU::setControlUnit(const ControlUnit& cu) {
    this->cu = cu;
}
