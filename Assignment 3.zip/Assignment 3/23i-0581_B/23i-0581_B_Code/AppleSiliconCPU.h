#pragma once
#include "CPU.h"
#include "GraphicsCard.h"

class AppleSiliconCPU : public CPU {
private:
    GraphicsCard GPU;

public:

    //constructors
    AppleSiliconCPU();
    AppleSiliconCPU(const ALU& alu, const ControlUnit& cu, const GraphicsCard& gpu);

    //getters
    GraphicsCard getGraphicsCard() const;

    //setters
    void setGraphicsCard(const GraphicsCard& gpu);
};

