#pragma once
#include "ALU.h"
#include "ControlUnit.h"

class CPU {
private:
    ALU alu;
    ControlUnit cu;

public:
    // Constructors
    CPU();
    CPU(const ALU& alu, const ControlUnit& cu);

    // Getters and Setters
    ALU getALU() const;
    void setALU(const ALU& alu);
    ControlUnit getControlUnit() const;
    void setControlUnit(const ControlUnit& cu);
};
