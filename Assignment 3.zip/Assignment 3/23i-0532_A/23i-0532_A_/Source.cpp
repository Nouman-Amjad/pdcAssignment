#include "ALU.h"
#include "Battery.h"
#include "Case.h"
#include "ControlUnit.h"
#include "CPU.h"
#include "GraphicsCard.h"
#include "MainMemory.h"
#include "MotherBoard.h"
#include "NetworkCard.h"
#include "PhysicalMemory.h"
#include "Port.h"
#include "PowerSupply.h"
#include "StorageDevice.h"
#include "SiliconChip.h"
#include "Computer.h"
#include <iostream>
#include <cmath>
using namespace std;

int main()
{
    bool design;
    cout << "What type of computer are you designing?\n0) PC\n1) Mac: ";
    cin >> design;

    string ff, c;
    cout << "Enter details for your computer case:\n";
    while (!(ff == "ATX" || ff == "Micro ATX" || ff == "atx" || ff == "micro atx"))
    {
        cout << "Enter the form factor for the case: ";
        cin >> ff;
    }
    while (!(c == "White" || c == "Black" || c == "white" || c == "black"))
    {
        cout << "Enter the color for your case (White/Black): ";
        cin >> c;
    }
    Case ca(ff, c);

    int cap;
    cout << "\nEnter details for your computer battery:\n";
    while (!(cap > 0 && cap <= 100))
    {
        cout << "Enter the capacity of the battery (1-100): ";
        cin >> cap;
    }
    Battery ba(cap);

    string nt;
    int speed;
    cout << "\nEnter details for your computer network card:\n";
    while (!(nt == "Ethernet" || nt == "Wifi" || nt == "ethernet" || nt == "wifi"))
    {
        cout << "Input the type of network card (Ethernet/Wifi): ";
        cin >> nt;
    }
    while (!(speed == 10 || speed == 100 || speed == 1000 || speed == 10000 || speed == 40000 || speed == 100000))
    {
        cout << "Input the speed of " << nt << " (in Mbps): ";
        cin >> speed;
    }
    NetworkCard nc(nt, speed);

    string st;
    int scap;
    cout << "\nEnter details for your computer storage device:\n";
    while (!(st == "HDD" || st == "SSD" || st == "hdd" || st == "ssd"))
    {
        cout << "Input the type of the storage device (HDD/SSD): ";
        cin >> st;
    }
    cout << "Input the capacity of the storage device (in GBs, must be a power of 2): ";
    cin >> scap;

    string tt;
    int mcap;
    cout << "\nEnter details for your computer main memory:\n";
    while (!(tt == "Semiconductor" || tt == "Silicon" || tt == "semiconductor" || tt == "silicon"))
    {
        cout << "Input the technology type of the main memory (Semiconductor/Silicon): ";
        cin >> tt;
    }
    cout << "Input the capacity of the main memory (in GBs, must be a power of 2): ";
    cin >> mcap;
    MainMemory mm(mcap, tt);

    float clock;
    cout << "\nEnter details for your computer control unit:\n";
    cout << "Input the clock frequency of the control unit (in GHz): ";
    cin >> clock;

    int add, sub, reg, regsize;
    cout << "\nEnter details for your computer arithmetic logic unit:\n";
    cout << "Input the number of adders in the ALU: ";
    cin >> add;
    cout << "Input the number of subtractors in the ALU: ";
    cin >> sub;
    cout << "Enter the number of registers in the ALU: ";
    cin >> reg;
    cout << "Enter the size of the registers: ";
    cin >> regsize;

    int watt;
    string eff;
    cout << "\nEnter details for your computer power supply:\n";
    while (!(eff == "80 plus bronze" || eff == "80 plus gold" || eff == "80 Plus Bronze" || eff == "80 Plus Gold"))
    {
        cout << "Input the efficiency rating of the power supply (80 Plus Bronze/Gold): ";
        cin >> eff;
    }
    cout << "Input the wattage of the power supply: ";
    cin >> watt;
    PowerSupply ps(watt, eff);

    string pn[4];
    int br[4];
    for (int i = 0; i < 4; ++i)
    {
        while (!(pn[i] == "vgi" || pn[i] == "i/o" || pn[i] == "usb" || pn[i] == "hdmi" || pn[i] == "VGI" || pn[i] == "I/O" || pn[i] == "USB" || pn[i] == "HDMI" || pn[i] == "Vgi" || pn[i] == "I/O" || pn[i] == "Usb" || pn[i] == "Hdmi"))
        {
            cout << "Input the type of Port " << i + 1 << ": ";
            cin >> pn[i];
        }
        while (!(br[i] >= 1200 && br[i] <= 115200 && (br[i] & (br[i] - 1)) == 0))
        {
            cout << "Input the baud rate for Port " << i + 1 << " (must be a power of 2, between 1200 and 115200): ";
            cin >> br[i];
        }
    }

    bool gp;
    string brand;
    int s;
    cout << "\nDo you want a graphics card for your computer?\n1) Yes\n0) No: ";
    cin >> gp;
    GraphicsCard gc;
    if (!design && gp)
    {
        cout << "Enter details for your computer graphics card:\n";
        while (!(brand == "Nvidia" || brand == "AMD" || brand == "nvidia" || brand == "amd"))
        {
            cout << "Enter the brand of the graphics card (Nvidia/AMD): ";
            cin >> brand;
        }
        cout << "Enter the size of the graphics card (in GBs): ";
        cin >> s;
        gc = GraphicsCard(brand, s);
    }

    brand = "AppleGPU";
    s = 64;
    SiliconChip sc(brand, s);

    Computer cp(add, sub, reg, regsize, clock, pn, br, nc, gc, mcap, tt, st, scap, ps, ca, ba);
    cout << "Your price will be: " << cp.getPrice() << endl;

    return 0;
}
