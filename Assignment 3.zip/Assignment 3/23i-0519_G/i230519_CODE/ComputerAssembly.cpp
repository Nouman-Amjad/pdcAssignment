#include "ComputerAssembly.h"
ComputerAssembly::ComputerAssembly()
    : totalPrice(0.0), storageDevice(nullptr), networkCard(nullptr), powerSupply(nullptr),
    battery(nullptr), caseObj(nullptr), motherBoard(nullptr) {
   
}

ComputerAssembly::ComputerAssembly(double totalPrice, StorageDevice* storageDevice, NetworkCard* networkCard,
    PowerSupply* powerSupply, Battery* battery, Case* pcCase, MotherBoard* motherBoard)
    : totalPrice(totalPrice), storageDevice(storageDevice), networkCard(networkCard),
    powerSupply(powerSupply), battery(battery), caseObj(caseObj), motherBoard(motherBoard) {
   
}

// Getter method definition
double ComputerAssembly::getTotalPrice()  {
    return totalPrice;
}


