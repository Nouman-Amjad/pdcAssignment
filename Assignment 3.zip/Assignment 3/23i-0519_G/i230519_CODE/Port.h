#pragma once
#include<iostream>
using namespace std;

class Port
{
    string typePort;
    int baud_rate;
    int sizePorts;

public:
 
    Port();
    Port(string typePort, int baud_rate);

  
    int getBaud_rate() const;
    string getTypePort() const;
    int getSizePorts();

    void setBaud_rate(int baud_rate);
    void setTypePort(string typePort);
};

