#include "Port.h"
#include<iostream>
using namespace std;
Port::Port() : typePort(""), baud_rate(0) {
    sizePorts = 4;
}

Port::Port(string typePort, int baud_rate) : typePort(typePort), baud_rate(baud_rate) {
    sizePorts = 4;
}

int Port::getBaud_rate() const {
    return baud_rate;
}

string Port::getTypePort() const {
    return typePort;
}

int Port::getSizePorts()
{
    return sizePorts;
}


void Port::setBaud_rate(int baud_rate) {
    this->baud_rate = baud_rate;
}

void Port::setTypePort(string typePort) {
    this->typePort = typePort;
}
