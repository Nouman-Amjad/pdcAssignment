#include "Case.h"
#include<iostream>
using namespace std;

Case::Case() : formFactor(""), color(""), price(0.0) {
}
Case::Case(std::string formFactor, std::string color) : formFactor(formFactor), color(color) {
    if (formFactor == "ATX")
        price = 200;
    else
        price = 100;

}


string Case::getFormFactor() {
    return formFactor;
}

std::string Case::getColor() {
    return color;
}

double Case::getPrice() {
    return price;
}


void Case::setFormFactor(string formFactor) {
    this->formFactor = formFactor;
    if (formFactor == "ATX")
        price = 200;
    else
        price = 100;
}

void Case::setColor(string color) {
    this->color = color;
}

