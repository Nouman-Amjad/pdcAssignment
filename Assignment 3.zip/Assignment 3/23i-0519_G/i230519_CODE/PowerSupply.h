#pragma once
#include<iostream>
using namespace std;
class PowerSupply
{
    int wattage;
    string efficiencyRating;
    double price;

public:
   
    PowerSupply();
    PowerSupply(int wattage, string efficiencyRating);

    int getWattage() ;
    string getEfficiencyRating() ;
    double getPrice() ;

    void setWattage(int wattage);
    void setEfficiencyRating(string efficiencyRating);

};


