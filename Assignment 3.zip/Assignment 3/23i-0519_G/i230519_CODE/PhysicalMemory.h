#pragma once
class PhysicalMemory
{
protected:
	int memoryCapacity;
public:
	PhysicalMemory();
	PhysicalMemory(int capacity);
	
	int getMemoryCapacity();
	void setMemoryCapacity(int capacity);

};

