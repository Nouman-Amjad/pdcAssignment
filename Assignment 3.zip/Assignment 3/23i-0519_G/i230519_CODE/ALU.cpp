#include "ALU.h"
ALU::ALU() :noOfAdders(64), noOfSubtractors(64), noOfRegisters(100), sizeOfRegisters(400) {}
ALU::ALU(int noOfAdders, int noOfSubtractors, int noOfRegisters, int sizeOfRegisters) :noOfAdders(noOfAdders), noOfSubtractors(noOfSubtractors), noOfRegisters(noOfRegisters), sizeOfRegisters(sizeOfRegisters) {}

int ALU::get_NoOfAdders() { return this->noOfAdders; }
int ALU::get_NoOfSubtractors() { return this->noOfSubtractors; }
int ALU::get_SizeOfRegisters()  { return this->sizeOfRegisters; }
int ALU::get_NoOfRegisters() { return this->noOfRegisters; }
void ALU::set_NoOfAdders(int noOfAdders) { this->noOfAdders = noOfAdders; }
void ALU::set_NoOfSubtractors(int noOfSubtractors) { this->noOfSubtractors = noOfSubtractors; }
void ALU::set_SizeOfRegisters(int sizeOfRegisters) { this->sizeOfRegisters = sizeOfRegisters; }
void ALU::set_NoOfRegisters(int noOfRegisters) { this->noOfRegisters = noOfRegisters; }