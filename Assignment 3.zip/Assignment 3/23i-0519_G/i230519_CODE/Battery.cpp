#include "Battery.h"

Battery::Battery() : capacity(0), price(0.0) {


}
    

Battery::Battery(int capacity) : capacity(capacity) {
    price = capacity * 0.01;
}


int Battery::getCapacity()  {
    return capacity;
}

double Battery::getPrice()  {
    return price;
}

void Battery::setCapacity(int capacity) {
    this->capacity = capacity;
    price = capacity * 0.01;
}

