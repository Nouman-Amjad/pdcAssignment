#pragma once
class ControlUnit
{
	float clock;
public:
	ControlUnit();
	ControlUnit(float clock);
	float getClock();
	void setClock(float clock);
};

