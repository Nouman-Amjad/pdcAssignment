#pragma once
#include<iostream>
using namespace std;
class NetworkCard
{
	string type;
	int speed;
	double price;
public:
	NetworkCard();
	NetworkCard(string type, int speed);
	string getType();
	int getSpeed();
	int getPrice();
	void setType(string type);
	void setSpeed(int speed);
	
};

