#pragma once
#include"GraphicCardIntelORAMD.h"
#include "DDR.h"
#include"CPU.h"
#include<iostream>
using namespace std;
class IntelOrAMD :
    public CPU
{
    GraphicCardIntelORAMD* graphicCard;
    DDR* ram;
    string type;
    string architecture;
  
public:
 
    IntelOrAMD();
    IntelOrAMD(DDR* ram, GraphicCardIntelORAMD* graphicCard,string type);
    string getType();
    string getArchitecture();
    double getPriceGc();
    void displayGraphicCard();
    void displayCpuIntelOrAMD();
    void setType(string type);
    void setGraphicCard(GraphicCardIntelORAMD* graphicCard);
    void setRam(DDR* ram);
   
};

