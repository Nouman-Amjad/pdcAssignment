#include "StorageDevice.h"
#include<iostream>
using namespace std;
StorageDevice::StorageDevice() :type("\0"), capacity(0), price(0) {}
StorageDevice::StorageDevice(string type, int capacity) :type(type), capacity(capacity) { price = capacity * 25; }
string StorageDevice::getType() { return this->type; }
int StorageDevice::getCapacity() { return this->capacity; }
double StorageDevice::getPrice() { return this->price; }
void StorageDevice::setType(string type) { this->type = type; }
void StorageDevice::setCapacity(int capacity) { this->capacity = capacity;
	price = capacity * 0.0976;
}
