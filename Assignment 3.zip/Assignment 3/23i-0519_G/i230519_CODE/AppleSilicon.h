#pragma once
#include "CPU.h"
#include"LPDDR.h"
#include"GraphicCardApple.h"
class AppleSilicon :
    public CPU
{
    GraphicCardApple graphicCard;
    LPDDR *ram;
    string architecture;
public:
    AppleSilicon();
    AppleSilicon(LPDDR* ram);

    // Getter method
    string getArchitecture();
    double getPriceGc();
    void displayCpuMAC();
    void displayGraphicCard();
};

