#include "PowerSupply.h"
#include<iostream>
using namespace std;
PowerSupply::PowerSupply() : wattage(0), efficiencyRating(""), price(0.0) {}

PowerSupply::PowerSupply(int wattage, string efficiencyRating) : wattage(wattage), efficiencyRating(efficiencyRating){ price = wattage * 5; }


int PowerSupply::getWattage() {
    return wattage;
}

string PowerSupply::getEfficiencyRating()  {
    return efficiencyRating;
}

double PowerSupply::getPrice(){
    return price;
}


void PowerSupply::setWattage(int wattage) {
    this->wattage = wattage;
    price = wattage * 5;
}

void PowerSupply::setEfficiencyRating(string efficiencyRating) {
    this->efficiencyRating = efficiencyRating;
}

