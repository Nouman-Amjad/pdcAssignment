#include "LPDDR.h"
LPDDR::LPDDR() :  lpddrType(0) {  }
LPDDR::LPDDR( int lpddrType) : lpddrType(lpddrType) { }
int LPDDR::getDDRType() { return this->lpddrType; }

void LPDDR::setDDRType(int lpddrType) { this->lpddrType = lpddrType; }

