#include<iostream>
#include<string>
#include"../i230519_Q1/ALU.h"
#include"../i230519_Q1/AppleSilicon.h"
#include"../i230519_Q1/Battery.h"
#include"../i230519_Q1/Case.h"
#include"../i230519_Q1/ComputerAssembly.h"
#include"../i230519_Q1/ControlUnit.h"
#include"../i230519_Q1/CPU.h"
#include"../i230519_Q1/DDR.h"
#include"../i230519_Q1/GraphicCardApple.h"
#include"../i230519_Q1/GraphicCardIntelORAMD.h"
#include"../i230519_Q1/LPDDR.h"
#include"../i230519_Q1/MAC.h"
#include"../i230519_Q1/MainMemory.h"
#include"../i230519_Q1/MotherBoard.h"
#include"../i230519_Q1/NetworkCard.h"
#include"../i230519_Q1/PC.h"
#include"../i230519_Q1/PhysicalMemory.h"
#include"../i230519_Q1/Port.h"
#include"../i230519_Q1/PowerSupply.h"
#include"../i230519_Q1/StorageDevice.h"
#include"../i230519_Q1/IntelOrAMD.h"

using namespace std;
int main()
{
	//storageDevixe
	int storgaeCapacity = 0;
	string storageType="\0";

	//Power supply
	string efficiencyRating = "\0";
	int wattage = 0;
	
	//Network Card
	string networkCardType = "\0";
	int speedNetworkCard = 0;

	//Case
	string caseColor = "\0";
	string caseFormFactor = "\0";

	//Battery
	int batteryCapacity = 0;

	//MianMemory
	string mainMemoryTechType = "\0";
	int mainMemoryCapacity = 0;

	//PC Graphic Card
	string gcBrand = "\0";
	int gcMemorySize = 0;
	string gcType = "\0";

	//DDR ram
	int pcDDRType = 0;
	int pcMemoryCapacity = 0;

	//INtelOrAMD CPu type
	string cpuType = "\0";
	
	//LPDDR ram
	int macDDRType=0;
	int macMemoryCapacity=0;

	//Laptop Or Not
	bool pcLaptop = false;
	bool macLaptop = false;

	//Choice PC or MAC
	string choicPcOrMac = "\0";
	string choicLaptop = "\0";
	
	

	//Inputs




	cout << "WELCOME TO CUSTOMIZE PC SHOP NOW ENTER SPECS FOR PC AND MAC !!!! : " << endl;
	cout << " Hello would you like to make PC or MAC for PC write PC and fro MAc write MAC : ";
	getline(cin, choicPcOrMac);
	while (true)
	{
		if (choicPcOrMac == "PC" || choicPcOrMac == "MAC")
			break;
		cout << "Re Enter the Choice : ";
		getline(cin, choicPcOrMac);
	}
	cout << "Would you like to make " << choicPcOrMac << " laptop or desktop write Yes or No" << endl;
	getline(cin, choicLaptop);
	while (true)
	{
		if (choicLaptop == "Yes" || choicLaptop == "No")
			break;
		cout << "Re Enter the Choice : ";
		getline(cin, choicLaptop);
	}


	//Storage Device
	cout << "Storage Device!!" << endl;
	cout << "Enter the storage type : ";
	getline(cin,storageType);
	while (true)
	{
		if (storageType == "SSD" || storageType == "HDD")
			break;
		cout << "Re Enter the Choice : ";
		getline(cin, storageType);
	}
	cout << "Enter the storage capacity : ";
	cin >> storgaeCapacity;
	cin.ignore();
	cout << endl;

	//Power Supply
	cout << "Power Supply!!" << endl;
	cout << "Enter the power supply Efficiency Rating : ";
	getline(cin,efficiencyRating);
	cout << "Enter the wattage : ";
	cin >> wattage;
	cout << endl;
	cin.ignore();

	//Case Obj
	cout << "Case !!" << endl;
	cout << "Enter the Case Color : ";
	getline(cin,caseColor);
	cout << "Enter the Case form factor : ";
	getline(cin,caseFormFactor);
	while (true)
	{
		if (caseFormFactor== "ATX" || caseFormFactor== "Micro ATX" || caseFormFactor=="Mini ITX")
			break;
		cout << "Re Enter the Choice : ";
		getline(cin, caseFormFactor);
	}
	cout << endl;

	//Battery
	if (choicLaptop == "Yes")
	{
		cout << "Battery!!" << endl;
		cout << "Enter the Battery Capacity : ";
		cin >> batteryCapacity;
		cout << endl;
		cin.ignore();
	}
	
	//Network Card
	cout << "Network Card !!" << endl;
	cout << "Enter Network card type : ";
	getline(cin,networkCardType);
	cout << "Enter the network card speed : ";
	cin >> speedNetworkCard;
	cout << endl;
	cin.ignore();

	//Mian Memory
	cout << "Main Memory !!" << endl;
	cout << "Main Memory Tech Type: ";
	getline(cin, mainMemoryTechType);
	cout << "Enter the Main memory capacity : ";
	cin >> mainMemoryCapacity;
	cout << endl;
	cin.ignore();

	//Strogae Device Set
	StorageDevice storageDevice;
	storageDevice.setCapacity(storgaeCapacity);
	storageDevice.setType(storageType);

	//Power Supply Set
	PowerSupply powerSupply;
	powerSupply.setEfficiencyRating(efficiencyRating);
	powerSupply.setWattage(wattage);

	//Case Set
	Case caseObj;
	caseObj.setColor(caseColor);
	caseObj.setFormFactor(caseFormFactor);

	//Battery Set
	Battery battery;
	battery.setCapacity(batteryCapacity);

	//Networl Card Set
	NetworkCard networkCard;
	networkCard.setType(networkCardType);
	networkCard.setSpeed(speedNetworkCard);

	//Main Memory
	MainMemory mainMemory;
	mainMemory.setTechType(mainMemoryTechType);
	mainMemory.setCapacity(mainMemoryCapacity);

	//MotherBoard
	MotherBoard motherBoard;
	motherBoard.setMainMemory(&mainMemory);

	if (choicPcOrMac == "PC")
	{
		//CPu type
		cout << "CPU Type!! " << endl;
		cout << "Enter the cpu type type Intel/AMD: ";
		getline(cin, cpuType);
		while (true)
		{
			if (cpuType == "Intel" || cpuType == "AMD")
				break;
			cout << "Re enter the choice : ";
			getline(cin, cpuType);

		}
		cout << endl;
		//Graphic  Card
		cout << "Graphic Card!! " << endl;
		cout << "Enter the graphic card type Nvidia/AMD: ";
		getline(cin, gcType);
		while (true)
		{
			if (gcType == "Nvidia" || gcType == "AMD")
				break;
			cout << "Re enter the choice : ";
			getline(cin, gcType);

		}
		cout << "Enter the graphic card brand : ";
		getline(cin, gcBrand);
		cout << "Enter the graphic card memory caapcity : ";
		cin >> gcMemorySize;
		cout << endl;
		
		//DDR ram
		cout << "DDR RAM!! " << endl;
		cout << "Enter the DDR type 4 or 5 : ";
		cin >> pcDDRType;
		cout << "Enter the DDR memory capacity : ";
		cin >> pcMemoryCapacity;
		cout << endl;
	
		
		cout << "----------------------------------------Desktop / LAPTOP PC------------------------------------------" << endl;

		//Graphic Card Set
		GraphicCardIntelORAMD dellGc;
		dellGc.setBrand(gcBrand);
		dellGc.setMemorySize(gcMemorySize);
		dellGc.setType(gcType);

		//Ram Set
		DDR ramDell;
		//ramDell.setDataRates(pcDataRates);
		ramDell.setDDRType(pcDDRType);
		ramDell.setMemoryCapacity(pcMemoryCapacity);
		//ramDell.setVoltage(pcVoltage);

		//Cpu set
		IntelOrAMD dellCpu(&ramDell, &dellGc, cpuType);
		dellCpu.setType(cpuType);




		//Dell desktop
		PC dell(dellCpu, pcLaptop);
		dell.setStorageDevice(&storageDevice);
		dell.setPowerSupply(&powerSupply);
		dell.setNetworkCard(&networkCard);
		dell.setCase(&caseObj);
		dell.setMotherBoard(&motherBoard);
		if (dell.getIsLaptop() == true)
			dell.setBattery(&battery);

		cout << dell;

		cout << "----------------------------------------------------------Desktop / LAPTOP PC END-------------------------------" << endl;
	}
	if (choicPcOrMac == "MAC")
	{
		//LPDDR ram
		cout << "LPDDR RAM!! " << endl;
		cout << "Enter the LPDDR type 4 or 5 : ";
		cin >> macDDRType;
		cout << "Enter the LPDDR memory capacity : ";
		cin >> macMemoryCapacity;
		cout << endl;

		cout << "----------------------------------------MAC / LAPTOP PC------------------------------------------" << endl;

		//Mac Ram
		LPDDR macRam;
		//macRam.setDataRates(macDataRates);
		macRam.setDDRType(macDDRType);
		//macRam.setVoltage(macVoltage);
		macRam.setMemoryCapacity(macMemoryCapacity);

		//Mac Cpu
		AppleSilicon macCpu(&macRam);
	

		MAC macApple(macCpu, macLaptop);
		macApple.setStorageDevice(&storageDevice);
		macApple.setPowerSupply(&powerSupply);
		macApple.setNetworkCard(&networkCard);
		macApple.setCase(&caseObj);
		macApple.setMotherBoard(&motherBoard);
		if (macApple.getIsLaptop() == true)
			macApple.setBattery(&battery);

		cout << macApple;


		cout << "----------------------------------------MAC/ LAPTOP PC END-----------------------------------------" << endl;
	}
}