#pragma once
class ALU
{
	int noOfAdders;
	int noOfSubtractors;
	int noOfRegisters;
	int sizeOfRegisters;
    
public:
	ALU();
	ALU(int noOfAdders, int noOfSubtractors, int noOfRegisters, int sizeOfRegisters);
	
	int get_NoOfAdders();
	int get_NoOfSubtractors();
	int get_SizeOfRegisters();
	int get_NoOfRegisters();
	void set_NoOfAdders(int noOfAdders);
	void set_NoOfSubtractors(int noOfSubtractors);
	void set_SizeOfRegisters(int sizeOfRegisters);
	void set_NoOfRegisters(int noOfRegisters);
};

