#include "MAC.h"
MAC::MAC() : isLaptop(false) {
  
}

MAC::MAC(AppleSilicon appleCpu, bool isLaptop) : appleCpu(appleCpu), isLaptop(isLaptop) {
   
}

bool MAC::getIsLaptop()  {
    return this->isLaptop;
}


void MAC::setIsLaptop(bool isLaptop) {
    this->isLaptop = isLaptop;
}

void MAC::setPowerSupply(PowerSupply* powerSupply)
{
    this->powerSupply = powerSupply;
}

void  MAC::setNetworkCard(NetworkCard* networkCard)
{
    this->networkCard = networkCard;
}

void  MAC::setCase(Case* caseObj)
{

    this->caseObj = caseObj;
}

void MAC::setBattery(Battery* battery)
{
    if (isLaptop == 1)
    {
        this->battery = battery;
    }
    else
        cout << "For Desktop PC Battery Can not set Error:" << endl;
}

void  MAC::setMotherBoard(MotherBoard* motherBoard)
{
    this->motherBoard = motherBoard;
}

void  MAC::setStorageDevice(StorageDevice* storageDevice)
{
    this->storageDevice = storageDevice;
}

void MAC::displayCpu()
{

    appleCpu.displayCpuMAC();
    cout << "----------------------" << endl;
    cout << "Architecture : ";
    cout << appleCpu.getArchitecture() << endl;
    cout << "CPU Price : ";
    cout << "$" << appleCpu.getPriceCpu() << endl;
    cout << "------------CPU END------------" << endl;



}

void MAC::displayGraphicCard()
{
    appleCpu.displayGraphicCard();

}

void MAC::displayStorage()
{
    cout << "----------Storage Device---------" << endl;
    cout << "Storgae device type: ";
    cout << storageDevice->getType() << endl;
    cout << "Storage Capacity : ";
    cout << storageDevice->getCapacity() << endl;
    cout << "Storage Device Price: ";
    cout << "$" << storageDevice->getPrice() << endl;

    cout << "------------Storage Device end--------" << endl;
}

void MAC::displayPowerSupply()
{

    cout << "----------Power Supply---------" << endl;
    cout << "Power Supply watte: ";
    cout << powerSupply->getWattage() << endl;
    cout << "Power Supply Efficencey rating : ";
    cout << powerSupply->getEfficiencyRating() << endl;
    cout << "Power Supply Price: ";
    cout << "$" << powerSupply->getPrice() << endl;
    cout << "------------Power Supply  end--------" << endl;

}

void MAC::displayCase()
{
    cout << "----------Case---------" << endl;
    cout << "Case Form Factor: ";
    cout << caseObj->getFormFactor() << endl;
    cout << "Case Color ";
    cout << caseObj->getColor() << endl;
    if (isLaptop == false)
    {
        cout << "Case Price : ";
        cout << "$" << caseObj->getPrice() << endl;
    }
    else
    {
        cout << "Case Price : 0" << endl;
    }
    cout << "------------Case end--------" << endl;
}

void MAC::displayNetworkCard()
{
    cout << "----------Network Card---------" << endl;
    cout << "Network Card Type: ";
    cout << networkCard->getType() << endl;
    cout << "Network Card speed : ";
    cout << networkCard->getSpeed() << endl;
    cout << "Network Card Price: ";
    cout << "$" << networkCard->getPrice() << endl;
    cout << "------------Network Card end--------" << endl;
}

void MAC::displayBattery()
{
    if (isLaptop == true)
    {
        cout << "----------Battery--------" << endl;
        cout << "Battery Capacity : ";
        cout << battery->getCapacity() << endl;
        cout << "Battery Price: ";
        cout << battery->getPrice() << endl;
        cout << "Battery Price: ";
        cout << "$" << battery->getPrice() << endl;
        cout << "------------Case end--------" << endl;
    }
}

void MAC::displayMotherBoard()
{
    motherBoard->displayMainMemoryPorts();
}
void MAC::DisplayTotalPrice() {
    if (isLaptop == false)
        totalPrice = appleCpu.getPriceGc() + powerSupply->getPrice() + storageDevice->getPrice() + networkCard->getPrice() + caseObj->getPrice()+appleCpu.getPriceCpu() +motherBoard->getPriceMotherBoard();
    else
        totalPrice = appleCpu.getPriceGc() + powerSupply->getPrice() + storageDevice->getPrice() + networkCard->getPrice() + battery->getPrice()+appleCpu.getPriceCpu() +motherBoard->getPriceMotherBoard();


    cout << "--------------Total Price---------------" << endl;
    cout << "Total Price : ";
    cout <<"$"<< totalPrice << endl;
}
ostream& operator<<(ostream& output, MAC &mac)
{
    cout << "-----------Spec of Dell!!----------------" << endl;
    mac.displayCpu();
    mac.displayGraphicCard();
    mac.displayStorage();
    mac.displayPowerSupply();
    mac.displayCase();
    mac.displayNetworkCard();
    mac.displayMotherBoard();
    if (mac.getIsLaptop() == true)
        mac.displayBattery();

    mac.DisplayTotalPrice();
    output << "";
    return output;
}


