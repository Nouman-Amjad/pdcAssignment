#pragma once
#include<iostream>
using namespace std;
class StorageDevice
{
	string type;
	int capacity;
	double price;
public:
	StorageDevice();
	StorageDevice(string type, int capacity);
	string getType();
	int getCapacity();
	double getPrice();
	void setType(string type);
	void setCapacity(int capacity);
	
};

