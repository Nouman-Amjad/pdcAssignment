#include "GraphicCardApple.h"
#include<iostream>
using namespace std;
GraphicCardApple::GraphicCardApple() :brand("MAC Graphic Card"), memorySize(4), price(300), type("Apple Gpu")
{

}

string GraphicCardApple::getBrand()
{
    return brand;
}

int GraphicCardApple::getMemorySize()
{
    return memorySize;
}

double GraphicCardApple::getPrice()
{
    return price;
}

string GraphicCardApple::getType()
{
    return string();
}

