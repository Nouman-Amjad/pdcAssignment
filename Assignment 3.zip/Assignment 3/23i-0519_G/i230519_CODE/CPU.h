#pragma once
#include<iostream>
#include"ALU.h"
#include"ControlUnit.h"
using namespace std;

class CPU
{
protected:
	ALU alu;
	ControlUnit cu;
	double priceCpu;
public:

	CPU();
	CPU(ALU alu, ControlUnit cu);
	double getPriceCpu();
	int get_NoOfAdders();
	int get_NoOfSubtractors();
	int get_SizeOfRegisters();
	int get_NoOfRegisters();
	float getClock();
	void set_NoOfAdders(int noOfAdders);
	void set_NoOfSubtractors(int noOfSubtractors);
	void set_SizeOfRegisters(int sizeOfRegisters);
	void set_NoOfRegisters(int noOfRegisters);
	void setClock(float clock);


};

