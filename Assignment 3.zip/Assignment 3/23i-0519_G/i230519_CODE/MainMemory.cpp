#include "MainMemory.h"
#include<iostream>
using namespace std;
MainMemory::MainMemory() : capacity(0), technologyType("") {
   
}

MainMemory::MainMemory(int capacity, string technologyType): capacity(capacity), technologyType(technologyType) {
    
}

int MainMemory::getCapacity() const {
    return capacity;
}

string MainMemory::getTechType() const {
    return technologyType;
}


void MainMemory::setCapacity(int capacity) {
    this->capacity = capacity;
}

void MainMemory::setTechType(string technologyType) {
    this->technologyType = technologyType;
}

