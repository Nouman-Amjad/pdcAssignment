#include "NetworkCard.h"
#include<iostream>
using namespace std;
NetworkCard::NetworkCard() :type("\0"), speed(0), price(0) {}
NetworkCard::NetworkCard(string type, int speed) :type(type), speed(speed) { price = speed * 10; }
string NetworkCard::getType() { return this->type; }
int NetworkCard::getSpeed() { return this->speed; }
int NetworkCard::getPrice() { return this->price; }
void NetworkCard::setType(string type) { this->type = type; }
void NetworkCard::setSpeed(int speed) { this->speed = speed;
	price = speed * 10;
}
