#pragma once
#include<iostream>
using namespace std;
class GraphicCardIntelORAMD
{
	string brand;
	string type;
	int memorySize;
	double price;
	
public:

	
	
	GraphicCardIntelORAMD();
	GraphicCardIntelORAMD(string brand, int memorySize,string type);
	string getBrand() ;
	int getMemorySize() ;
	double getPrice();
	string getType();
	void setBrand(string brand);
	void setMemorySize(int memorySize);
	void setType(string type);
};

