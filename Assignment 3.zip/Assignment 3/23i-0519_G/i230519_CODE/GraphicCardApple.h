#pragma once
#include<iostream>
using namespace std;
class GraphicCardApple
{
	string brand;
	string type;
	int memorySize;
	double price;

public:



	GraphicCardApple();
	string getBrand();
	int getMemorySize();
	double getPrice();
	string getType();


};

