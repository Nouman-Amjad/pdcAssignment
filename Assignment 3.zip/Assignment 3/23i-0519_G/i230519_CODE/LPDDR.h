#pragma once
#include "PhysicalMemory.h"
class LPDDR :
    public PhysicalMemory
{
  
    int lpddrType;
public:
    LPDDR();
    LPDDR(int lpddrType);
    int getDDRType();
    void setDDRType(int ddrType);
};

