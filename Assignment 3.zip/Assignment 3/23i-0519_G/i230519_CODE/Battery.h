#pragma once
class Battery
{
    int capacity;
    double price;

public:

   
    Battery();
    Battery(int capacity);
    int getCapacity() ;
    double getPrice() ;
    void setCapacity(int capacity);
};

