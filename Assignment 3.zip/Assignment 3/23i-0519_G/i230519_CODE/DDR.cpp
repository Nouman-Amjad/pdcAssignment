#include "DDR.h"
DDR::DDR() : ddrType(0) {}
DDR::DDR(int ddrType) : ddrType(ddrType) {}

int DDR::getDDRType() { return this->ddrType; }
void DDR::setDDRType(int ddrType) { this->ddrType = ddrType; }


