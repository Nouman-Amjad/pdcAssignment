#include "GraphicCardIntelORAMD.h"
#include<iostream>
using namespace std;
GraphicCardIntelORAMD::GraphicCardIntelORAMD() :brand("\0"), memorySize(0), price(0),type("\0") {}
GraphicCardIntelORAMD::GraphicCardIntelORAMD(string brand, int memorySize,string type) :brand(brand), memorySize(memorySize),type(type) {

}
string GraphicCardIntelORAMD::getBrand() { return this->brand; }
int GraphicCardIntelORAMD::getMemorySize() { return this->memorySize; }
double GraphicCardIntelORAMD::getPrice(){ return this->price; }
string GraphicCardIntelORAMD ::getType() { return this->type; }
void GraphicCardIntelORAMD::setBrand(string brand) { this->brand = brand;
}
void GraphicCardIntelORAMD::setMemorySize(int memorySize) { this->memorySize = memorySize; }
//void GraphicCard::setPrice(double price) { this->price = price; }
void GraphicCardIntelORAMD ::setType(string type) { this->type = type; 
    if (type == "Nvidia" || type == "nvidia")
    {
        price = memorySize * 100;
    }

    if (type == "AMD" || type == "amd")
    {
        price = memorySize * 150;
    }
}