#pragma once
#include<iostream>
using namespace std;
class MainMemory
{
    int capacity;
    string technologyType;

public:
   
    MainMemory();
    MainMemory(int capacity, string technologyType);
    int getCapacity() const;
    string getTechType() const;
    void setCapacity(int capacity);
    void setTechType(string technologyType);
};

