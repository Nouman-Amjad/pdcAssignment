#include "AppleSilicon.h"
AppleSilicon::AppleSilicon() : ram(nullptr), graphicCard(), architecture("ARM64") {
    alu.set_NoOfAdders(64);
    alu.set_NoOfSubtractors(64);
    alu.set_NoOfRegisters(100);
    alu.set_SizeOfRegisters(400);
    cu.setClock(45.5);
    priceCpu = 150;
}

AppleSilicon::AppleSilicon(LPDDR* ram): ram(ram) {
    architecture = "ARM64";
    alu.set_NoOfAdders(64);
    alu.set_NoOfSubtractors(64);
    alu.set_NoOfRegisters(100);
    alu.set_SizeOfRegisters(400);
    cu.setClock(45.5);
   priceCpu = 150;
}

string AppleSilicon::getArchitecture()  {
    return this->architecture;

}
double AppleSilicon::getPriceGc()
{
    return graphicCard.getPrice();
}

void AppleSilicon::displayCpuMAC()
{
    


        cout << "---------------CPU Specs-----------" << endl;
        cout << "----ALU----" << endl;
        cout << "Number of Adders: ";
        cout << alu.get_NoOfAdders() << endl;
        cout << "Number of Subtractors: ";
        cout << alu.get_NoOfSubtractors() << endl;
        cout << "Number of Registers: ";
        cout << alu.get_NoOfRegisters() << endl;
        cout << "Size of Registers: ";
        cout << alu.get_SizeOfRegisters() << endl;
        cout << "----Control Unit-----" << endl;
        cout << "Clock : ";
        cout << cu.getClock() << endl;


    
}

void AppleSilicon::displayGraphicCard()
{
    cout << "------Graphic card--------" << endl;
    cout << "Brand : ";
    cout << graphicCard.getBrand() << endl;
    cout << "Memory Size: ";
    cout << graphicCard.getMemorySize() << endl;
    cout << "Graphic Card price : ";
    cout << "$" << graphicCard.getPrice() << endl;
    cout << "--------Graphic Card End-------" << endl;
}