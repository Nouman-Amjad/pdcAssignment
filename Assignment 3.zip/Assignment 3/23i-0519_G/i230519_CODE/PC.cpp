#include "PC.h"

PC::PC() : isLaptop(false) {
}

PC::PC(IntelOrAMD cpu, bool isLaptop) : cpu(cpu), isLaptop(isLaptop) {
  
  
    
}


bool PC::getIsLaptop()  {
    return this->isLaptop;
}


void PC::setIsLaptop(bool isLaptop) {
    this->isLaptop = isLaptop;
}
void PC::setPowerSupply(PowerSupply* powerSupply)
{
    this->powerSupply = powerSupply;
}

void  PC::setNetworkCard(NetworkCard* networkCard)
{
    this->networkCard = networkCard;
}

void  PC::setCase(Case* caseObj)
{

    this->caseObj = caseObj;
}

void  PC::setBattery(Battery* battery)
{
    if (isLaptop == 1)
    {
        this->battery = battery;
    }
    else
        cout << "For Desktop PC Battery Can not set Error:" << endl;
}

void  PC::setMotherBoard(MotherBoard* motherBoard)
{
    this->motherBoard = motherBoard;
}

void  PC::setStorageDevice(StorageDevice* storageDevice)
{
    this->storageDevice = storageDevice;
}


void PC::displayCpu()
{
    
    cpu.displayCpuIntelOrAMD();
    cout << "----------------------" << endl;
        cout << "CPU type: ";
        cout << cpu.getType() << endl;
        cout << "Architecture : ";
        cout << cpu.getArchitecture() << endl;
        cout << "CPU Price : ";
        cout <<"$"<< cpu.getPriceCpu() << endl;
        cout << "------------CPU END------------" << endl;


    
}

void PC::displayGraphicCard()
{
    cpu.displayGraphicCard();

}

void PC::displayStorage()
{
    cout << "----------Storage Device---------" << endl;
    cout << "Storgae device type: ";
    cout << storageDevice->getType() << endl;
    cout << "Storage Capacity : ";
    cout << storageDevice->getCapacity() << endl;
    cout << "Storage Device Price: ";
    cout << "$" << storageDevice->getPrice() << endl;

    cout << "------------Storage Device end--------" << endl;
}

void PC::displayPowerSupply()
{

    cout << "----------Power Supply---------" << endl;
    cout << "Power Supply watte: ";
    cout << powerSupply->getWattage() << endl;
    cout << "Power Supply Efficencey rating : ";
    cout << powerSupply->getEfficiencyRating() << endl;
    cout << "Power Supply Price: ";
    cout << "$" << powerSupply->getPrice() << endl;
    cout << "------------Power Supply  end--------" << endl;

}

void PC::displayCase()
{
    cout << "----------Case---------" << endl;
    cout << "Case Form Factor: ";
    cout << caseObj->getFormFactor() << endl;
    cout << "Case Color : ";
    cout << caseObj->getColor() << endl;
    if (isLaptop == false)
    {
        cout << "Case Price : ";
        cout << "$" << caseObj->getPrice() << endl;
    }
    else
    {
        cout << "Case Price : $0" << endl;
    }
    cout << "------------Case end--------" << endl;
}

void PC::displayNetworkCard()
{
    cout << "----------Network Card---------" << endl;
    cout << "Network Card Type: ";
    cout << networkCard->getType()<< endl;
    cout << "Network Card speed : ";
    cout <<networkCard->getSpeed() << endl;
    cout << "Network Card Price: ";
    cout << "$" << networkCard->getPrice() << endl;
    cout << "------------Network Card end--------" << endl;
}

void PC::displayBattery()
{
    if (isLaptop == true)
    {
        cout << "----------Battery--------" << endl;
        cout << "Battery Capacity : ";
        cout <<battery->getCapacity() << endl;
        cout << "Battery Price: ";
        cout << battery->getPrice()<< endl;
        cout << "Battery Price: ";
        cout << "$" << battery->getPrice() << endl;
        cout << "------------Case end--------" << endl;
    }
}

void PC::displayMotherBoard()
{
    motherBoard->displayMainMemoryPorts();
}
void PC::DisplayTotalPrice() {
    if (isLaptop == false)
        totalPrice = cpu.getPriceGc() + powerSupply->getPrice() + storageDevice->getPrice() + networkCard->getPrice() + caseObj->getPrice()+ cpu.getPriceCpu()+motherBoard->getPriceMotherBoard();
    else
        totalPrice = cpu.getPriceGc() + powerSupply->getPrice() + storageDevice->getPrice() + networkCard->getPrice() + battery->getPrice() +cpu.getPriceCpu() +motherBoard->getPriceMotherBoard();


    cout << "--------------Total Price---------------" << endl;
    cout << "Total Price : ";
    cout << "$" << totalPrice << endl;
}
ostream& operator<<(ostream& output,  PC& pc)
{
    cout << "-----------Spec of Dell!!----------------" << endl;
    pc.displayCpu();
    pc.displayGraphicCard();
    pc.displayStorage();
    pc.displayPowerSupply();
    pc.displayCase();
    pc.displayNetworkCard();
    pc.displayMotherBoard();
    if (pc.getIsLaptop() == true)
        pc.displayBattery();

    pc.DisplayTotalPrice();
    output << "";
    return output;
}


