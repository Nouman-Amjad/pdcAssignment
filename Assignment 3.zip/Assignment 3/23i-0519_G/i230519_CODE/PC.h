#pragma once
#include "ComputerAssembly.h"
#include"IntelOrAMD.h"
class PC :
    public ComputerAssembly
{
    IntelOrAMD cpu;
    bool isLaptop;
    
public:
    PC();
    PC(IntelOrAMD cpu, bool isLaptop);


    bool getIsLaptop() ;
    


    void setIsLaptop(bool isLaptop);
    void setPowerSupply(PowerSupply* powerSupply);
    void setNetworkCard(NetworkCard* networkCard);
    void setCase(Case* caseObj);
    void setBattery(Battery* battery);
    void setMotherBoard(MotherBoard* motherBoard);
    void setStorageDevice(StorageDevice* storageDevice);

    void displayCpu();
    void displayGraphicCard();
    void displayStorage();
    void displayPowerSupply();
    void displayCase();
    void displayNetworkCard();
    void displayBattery();
    void displayMotherBoard();
    void DisplayTotalPrice();

    friend ostream& operator<<(ostream& output,  PC& pc);
   
    

};

