#pragma once
//#include"GraphicCard.h"
#include"Battery.h"
#include"PowerSupply.h"
#include"NetworkCard.h"
#include"Case.h"
#include"StorageDevice.h"
#include"MotherBoard.h"
class ComputerAssembly
{
protected:
	
	PowerSupply* powerSupply;
	NetworkCard *networkCard;
	Battery *battery;
	Case *caseObj;
	StorageDevice *storageDevice;
	MotherBoard*motherBoard;
	double totalPrice;
public:
	ComputerAssembly();
	ComputerAssembly(double totalPrice, StorageDevice* storageDevice, NetworkCard* networkCard,
		PowerSupply* powerSupply, Battery* battery, Case* caseObj, MotherBoard* motherBoard);

	
	double getTotalPrice();

	
	
	
};

