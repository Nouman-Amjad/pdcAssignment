#include "CPU.h"

CPU::CPU():alu(64,64,100,400),cu(46.5)
{

}

CPU::CPU(ALU alu, ControlUnit cu) :alu(alu), cu(cu)
{

}

double CPU::getPriceCpu()
{
    return this->priceCpu;
}

int CPU::get_NoOfAdders()
{
    return alu.get_NoOfAdders();
}

int CPU::get_NoOfSubtractors()
{
    return alu.get_NoOfSubtractors();
}

int CPU::get_SizeOfRegisters()
{
    return alu.get_SizeOfRegisters();
}

int CPU::get_NoOfRegisters()
{
    return alu.get_NoOfRegisters();
}

void CPU::set_NoOfAdders(int noOfAdders)
{
    alu.set_NoOfAdders(noOfAdders);
}

float CPU::getClock()
{
    return cu.getClock();
}

void CPU::set_NoOfSubtractors(int noOfSubtractors)
{
    alu.set_NoOfSubtractors(noOfSubtractors);
}

void CPU::set_SizeOfRegisters(int sizeOfRegisters)
{
   alu. set_SizeOfRegisters(sizeOfRegisters);
}



void CPU::set_NoOfRegisters(int noOfRegisters)
{
    alu.set_NoOfRegisters(noOfRegisters);
}

void CPU::setClock(float clock)
{
    cu.setClock(clock);
}


