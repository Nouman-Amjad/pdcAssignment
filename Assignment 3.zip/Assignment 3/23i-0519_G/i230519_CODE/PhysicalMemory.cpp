#include "PhysicalMemory.h"
PhysicalMemory::PhysicalMemory() :memoryCapacity(0) {}
PhysicalMemory::PhysicalMemory(int capacity) :memoryCapacity(capacity) {}

int PhysicalMemory::getMemoryCapacity() { return this->memoryCapacity; }
void PhysicalMemory::setMemoryCapacity(int capacity) { this->memoryCapacity = capacity; }
