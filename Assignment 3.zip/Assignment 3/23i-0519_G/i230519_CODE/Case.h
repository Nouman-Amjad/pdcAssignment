#pragma once
#include<iostream>
using namespace std;
class Case
{
    string formFactor;
    string color;
    double price;

public:

    Case();
    Case(std::string formFactor, std::string color);
    string getFormFactor();
    string getColor();
    double getPrice();
    void setFormFactor(std::string formFactor);
    void setColor(std::string color);
   
};

