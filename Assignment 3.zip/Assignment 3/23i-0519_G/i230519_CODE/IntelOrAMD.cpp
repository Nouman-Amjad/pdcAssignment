#include "IntelOrAMD.h"
#include<iostream>
using namespace std;
// Constructor definitions
IntelOrAMD::IntelOrAMD() : ram(nullptr), graphicCard(nullptr), type(""),architecture("x86"){
  
  priceCpu = 100;
   
}

IntelOrAMD::IntelOrAMD(DDR* ram, GraphicCardIntelORAMD* graphicCard, string type) : ram(ram), graphicCard(graphicCard), type("") {
    this->architecture = "x86";
   
   priceCpu = 100;
}

string IntelOrAMD::getType()  {
    return type;
}

string IntelOrAMD::getArchitecture()
{
    return architecture;
}

double IntelOrAMD::getPriceGc()
{
    return graphicCard->getPrice();
}



void IntelOrAMD::displayGraphicCard()
{
    cout << "------Graphic card--------" << endl;
    cout << "Brand : ";
    cout << graphicCard->getBrand() << endl;
    cout << "Memory Size: ";
    cout << graphicCard->getMemorySize() << endl;
    cout << "Graphic Card type : ";
    cout << graphicCard->getType() << endl;
    cout << "Graphic Card price : ";
    cout << "$" << graphicCard->getPrice()<< endl;
    cout << "--------Graphic Card End-------" << endl;
}

void IntelOrAMD::displayCpuIntelOrAMD()
{
  
   
    cout << "---------------CPU Specs-----------" << endl;
    cout << "----ALU----" << endl;
    cout << "Number of Adders: ";
    cout << alu.get_NoOfAdders() << endl;
    cout << "Number of Subtractors: ";
    cout << alu.get_NoOfSubtractors() << endl;
    cout << "Number of Registers: ";
    cout << alu.get_NoOfRegisters() << endl;
    cout << "Size of Registers: ";
    cout << alu.get_SizeOfRegisters() << endl;
    cout << "----Control Unit-----" << endl;
    cout << "Clock : ";
    cout << cu.getClock() << endl;
    
    
}


void IntelOrAMD::setType(string type) {
    this->type = type;
}

void IntelOrAMD::setGraphicCard(GraphicCardIntelORAMD* graphicCard)
{
    this->graphicCard = graphicCard;
}

void IntelOrAMD::setRam(DDR* ram)
{
    this->ram = ram;
}

