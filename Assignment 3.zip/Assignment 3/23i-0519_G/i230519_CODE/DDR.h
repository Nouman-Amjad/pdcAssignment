#pragma once
#include "PhysicalMemory.h"
class DDR :
    public PhysicalMemory
{
    int ddrType;
public:
    DDR();
    DDR(int ddrType);
    int getDDRType();
    void setDDRType(int ddrType);
};

