#include "MotherBoard.h"

MotherBoard::MotherBoard():mm(NULL) {
    int sizeofPorts = 4;
    ports = new Port[sizeofPorts];
    ports[0].setTypePort("VGI Port");
    ports[0].setBaud_rate(10);
    ports[1].setTypePort("I/O Port");
    ports[1].setBaud_rate(10);
    ports[2].setTypePort("USB Port");
    ports[2].setBaud_rate(10);
    ports[3].setTypePort("HDMI Port");
    ports[3].setBaud_rate(10);

    priceMainMemory =0;
    pricePorts = ports->getSizePorts() * 5;
    priceMotherBoard = priceMainMemory + pricePorts;
   
}

MotherBoard::MotherBoard(MainMemory*mm) : mm(mm){
    int sizeofPorts = 4;
    ports = new Port[sizeofPorts];
    ports[0].setTypePort("VGI Port");
    ports[0].setBaud_rate(10);
    ports[1].setTypePort("I/O Port");
    ports[1].setBaud_rate(10);
    ports[2].setTypePort("USB Port");
    ports[2].setBaud_rate(10);
    ports[3].setTypePort("HDMI Port");
    ports[3].setBaud_rate(10);

    priceMainMemory = mm->getCapacity() * 1;
    pricePorts = ports->getSizePorts() * 5;
    priceMotherBoard = priceMainMemory + pricePorts;
}

void MotherBoard::setMainMemory(MainMemory* mm)
{
    this->mm = mm;
    priceMainMemory = mm->getCapacity() * 1;
    pricePorts = ports->getSizePorts() * 5;
    priceMotherBoard = priceMainMemory + pricePorts;
  
}

void MotherBoard::displayMainMemoryPorts()
{
    cout << "----------Mother Board--------" << endl;
    cout << "---------Mian Memory----------" << endl;
    cout << "Main Memory Capcity : ";
    cout << mm->getCapacity() << endl;
    cout << "Main Memory Type : ";
    cout << mm->getTechType() << endl;
    cout << "Main Memory Price : ";
    cout << "$" << getPriceMainMemory() << endl;
    cout << "------------Main Memory End-------" << endl;
    cout << "-------------Ports-----------------" << endl;
    for (int i = 0;i <4;i++)
    {
        cout << "Port "<<i+1<<" Type :";
        cout << ports[i].getTypePort() << endl;
        cout << "Port "<<i+1<<" Baud Rate : ";
        cout << ports[i].getBaud_rate() << endl;
    }
    cout << "Ports Price : ";
    cout << "$" << getPricePorts() << endl;
    cout << "-----------------Ports End----------" << endl;
    cout << "Total price of Mother Board : ";
    cout << "$" << getPriceMotherBoard() << endl;
    cout << "---------------Mother Board End------------" << endl;
    
}

double MotherBoard::getPriceMainMemory()
{
    return this->priceMainMemory;
}

double MotherBoard::getPricePorts()
{
    return this->pricePorts;
}

double MotherBoard::getPriceMotherBoard()
{
    return this->priceMotherBoard;
}
