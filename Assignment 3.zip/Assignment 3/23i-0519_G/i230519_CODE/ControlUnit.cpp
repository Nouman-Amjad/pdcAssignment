#include "ControlUnit.h"
ControlUnit::ControlUnit() :clock(46.5) {}
ControlUnit::ControlUnit(float clock) :clock(clock) {}
float ControlUnit::getClock() { return this->clock; }
void ControlUnit::setClock(float clock) { this->clock = clock; }