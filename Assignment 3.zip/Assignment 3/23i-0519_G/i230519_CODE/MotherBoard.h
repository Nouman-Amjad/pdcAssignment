#pragma once
#include"MainMemory.h"
#include"Port.h"
class MotherBoard
{
    MainMemory *mm;
    Port *ports;
    double priceMainMemory;
    double pricePorts;
    double priceMotherBoard;
    

public:

    MotherBoard();
    MotherBoard(MainMemory* mm);
    void setMainMemory(MainMemory*mm);
    void displayMainMemoryPorts();
    double getPriceMainMemory();
    double getPricePorts();
    double getPriceMotherBoard();

    
};

