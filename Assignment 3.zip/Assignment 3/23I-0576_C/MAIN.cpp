
// NAME : Abdul Ghufran
// ROLL-NO : 23I-0576 
// SECTION : CS-C
// INSTRUCTOR NAME : Sir Shehriar Rashid
// TA NAME : Noman Amjad


#include <iostream>
#include "MySystem.h"

using namespace std;

int main() 
{
    // Variables to store user input
    string system , brand, architecture, integratedGPU, technologyType, cpuBrand , memoryType , storageType , hddType, GPUtype , caseFormFactor, caseColor;
    int mmCapacity, pmCapacity, numPorts, memorySize, storageCapacity, networkSpeed, wattage , gen , batteryCapacity , baud_rate;
    double cpuClock, cpuPrice, memoryPrice , portsPrice , motherboardPrice , pmPrice , graphicsCardPrice, storagePrice, networkCardPrice, powerSupplyPrice, batteryPrice, casePrice = 0.0;

    bool Input = true;
    while (Input)
    {
        cout << "Enter the system you want to make (PC / MAC): ";
        cin >> system;

        if (system == "mac")
        {
            cout << "Enter CPU Brand (intel / applesilicon): ";
            cin >> cpuBrand;

            if (cpuBrand != "intel" && cpuBrand != "applesilicon")
            {
                Input = true;
                cout << "Incorrect input for MAC system!!!" << endl;
            }
            else
                Input = false;
        }

        else if (system == "pc")
        {
            cout << "Enter CPU Brand (intel / amd / AppleSilicon): ";
            cin >> cpuBrand;

            if (cpuBrand != "intel" && cpuBrand != "amd" && cpuBrand != "applesilicon")
            {
                Input = true;
                cout << "Incorrect input for PC system!!!" << endl;
            }
            else
                Input = false;
        }

        else
        {
            cout << "Invalid system choice! Please enter either PC or MAC." << endl;
        }
    }


    Input = true;
    while (Input)
    {
        cout << "Enter CPU Architecture ( x86 / ARM64): ";
        cin >> architecture;

        if ((cpuBrand == "intel" && architecture != "x86") || (cpuBrand == "amd" && architecture != "x86") || (cpuBrand == "applesilicon" && architecture != "arm64"))
        {
            Input = true;
            cout << "Incorrect input!!!" << endl;
        }
        else
            Input = false;
    }

    if (cpuBrand == "intel" || cpuBrand == "AMD")
        integratedGPU = "no GPU";
    else
        integratedGPU = "AppleGPU";

    cout << "Enter CPU Clock Speed (GHz): ";
    cin >> cpuClock;

    if (cpuBrand == "intel" || cpuBrand == "AMD")
        cpuPrice = 100.00;
    else 
        cpuPrice = 150.75;
    
    CPU* cpu = new CPU(CPU(ALU(), ControlUnit(cpuClock), cpuBrand, architecture, integratedGPU));


    Input = true;
    while (Input)
    {
        cout << "Enter Main Memory Capacity (GB): ";
        cin >> mmCapacity;

        if (mmCapacity > 16)
        {
            Input = true;
            cout << "Incorrect input!!!" << endl;
        }
        else
            Input = false;
    }

    Input = true;
    while (Input)
    {
        cout << "Enter Main Memory Technology Type (Semiconductor / Silicon)): ";
        cin >> technologyType;

        if (technologyType != "semiconductor" && technologyType != "silicon" )
        {
            Input = true;
            cout << "Incorrect input!!!" << endl << endl;
        }
        else
            Input = false;
    }

    if (mmCapacity <= 8)
        memoryPrice = 100.00;
    else
        memoryPrice = 230.56;

    MainMemory* memory = new MainMemory(mmCapacity, technologyType);



    Input = true;
    while (Input)
    {
        cout << "Enter Number of Ports: ";
        cin >> numPorts;

        if (numPorts > 5)
        {
            Input = true;
            cout << "Incorrect input!!!" << endl << endl;
        }
        else
            Input = false;
    }

    string portNames[5]; 
    for (int i = 0; i < numPorts; i++) 
    {
        cout << "Enter Port Name " << i + 1 << ": ";
        cin >> portNames[i];
    }

    cout << "Enter baud rate: ";
    cin >> baud_rate;
    
    if (numPorts <= 3)
        portsPrice = 30.00;
    else
        portsPrice = 74.72;

    MotherBoard* motherboard = new MotherBoard(mmCapacity, technologyType, numPorts);



    Input = true;
    while (Input)
    {
        cout << "Enter Physical Memory Capacity (GB): ";
        cin >> pmCapacity;

        if (pmCapacity > 16)
        {
            Input = true;
            cout << "Incorrect input!!!" << endl;
        }
        else
            Input = false;
    }

    Input = true;
    while (Input)
    {
        cout << "Enter Physical Memory Type (DDR / LPDDR): ";
        cin >> memoryType;
        
        if (memoryType != "ddr" && memoryType != "lpddr")
        {
            Input = true;
            cout << "Incorrect input!!!" << endl << endl;
        }
        else
            Input = false;
    }


    Input = true;
    while (Input)
    {
        cout << "Enter generation (4 / 5): ";
        cin >> gen;

        if (gen != 4 && gen != 5)
        {
            Input = true;
            cout << "Incorrect input!!!" << endl << endl;
        }
        else
            Input = false;
    }

    if (pmCapacity <= 8)
        pmPrice = 100.00;
    else
        pmPrice = 230.56;


    cout << "Enter Graphics Card Brand: ";
    cin >> brand;

    Input = true;
    while (Input)
    {
        cout << "Enter Graphics Card Memory Size (GB): ";
        cin >> memorySize;

        if (memorySize > 24)
        {
            Input = true;
            cout << "Incorrect input!!!" << endl;
        }
        else
            Input = false;
    }
    
    if (memorySize <= 12)
        graphicsCardPrice = 480.50;
    else
        graphicsCardPrice = 850.43;


    if (cpuBrand == "intel" || cpuBrand == "AMD")
        GPUtype = "descrete";
    else
        GPUtype = "integrated";


    GraphicsCard* graphicsCard = new GraphicsCard(brand, memorySize, graphicsCardPrice, GPUtype);


    Input = true;
    while (Input)
    {
        cout << "Enter Storage Device Type (hdd / ssd): ";
        cin >> storageType;

        if (storageType != "hdd" && storageType != "ssd")
        {
            Input = true;
            cout << "Incorrect input!!!" << endl << endl;
        }
        else
            Input = false;
    }

    if (storageType == "hdd")
    {
        cout << "Enter hdd type (Consumer HDD or NAS HDD): ";
        cin >> hddType;
    }

    cout << "Enter Storage Device Capacity (GB): ";
    cin >> storageCapacity;

    if (storageCapacity <= 256)
        storagePrice = 670.89;
    else
        storagePrice = 1320.56;

    StorageDevice* storageDevice = new StorageDevice(storageType, storageCapacity, storagePrice);



    Input = true;
    while (Input)
    {
        cout << "Enter Network Card Type (Ethernet / Wi-Fi): ";
        cin >> brand;

        if (brand != "ethernet" && brand != "wifi")
        {
            Input = true;
            cout << "Incorrect input!!!" << endl << endl;
        }
        else
            Input = false;
    }

    
    cout << "Enter Network Card Speed (Mbps): ";
    cin >> networkSpeed;

    if (networkSpeed <= 15)
        networkCardPrice = 320.78;
    else
        networkCardPrice = 790.12;

    NetworkCard* networkCard = new NetworkCard(brand, networkSpeed, networkCardPrice);




    cout << "Enter Power Supply Wattage: ";
    cin >> wattage;

    Input = true;
    while (Input)
    {
        cout << "Enter Power Supply Efficiency Rating i.e 80 Plus (Bronze / Gold): ";
        cin >> brand;

        if (brand != "bronze" && brand != "gold")
        {
            Input = true;
            cout << "Incorrect input!!!" << endl << endl;
        }
        else
            Input = false;
    }

    if (brand == "gold")
        powerSupplyPrice = 230.00;
    else
        powerSupplyPrice = 130.90;

    PowerSupply* powerSupply = new PowerSupply(wattage, brand, powerSupplyPrice);




    cout << "Enter Battery Capacity (mAh): ";
    cin >> batteryCapacity;

    if (batteryCapacity <= 5000)
        batteryPrice = 89.00;
    else
        batteryPrice = 210.56;

    Battery* battery = new Battery(batteryCapacity, batteryPrice);



    Input = true;
    while (Input)
    {
        cout << "Enter Case Form Factor (ATX / Micro ATX)): ";
        cin >> caseFormFactor;

        if (caseFormFactor != "atx" && caseFormFactor != "microatx")
        {
            Input = true;
            cout << "Incorrect input!!!" << endl << endl;
        }
        else
            Input = false;
    }
    
    cout << "Enter Case Color: ";
    cin >> caseColor;

    if (system == "pc")
    {
        if (caseFormFactor == "atx")
            casePrice = 45.00;
        else
            casePrice = 98.90;
    }

    Case* pcCase = new Case(caseFormFactor, caseColor);


    // Calculate total price
    double totalPrice = cpuPrice + memoryPrice + portsPrice + pmPrice + graphicsCardPrice + storagePrice + networkCardPrice + powerSupplyPrice + batteryPrice + casePrice;

    // Create Computer Assembly object
    ComputerAssembly* computer = new ComputerAssembly(cpu, memory, motherboard, graphicsCard, storageDevice, networkCard, powerSupply, battery, pcCase, totalPrice);

    // Display specifications and price of the computer
    cout << endl << "Specifications of the Computer:" << endl;
    cout << "------------------------------------------------------------------------------------------------" << endl;
    cout << "CPU Brand: " << computer->getCPU()->getBrand() << endl;
    cout << "CPU Clock Speed: " << computer->getCPU()->getCU().getClock() << " GHz" << endl;
    cout << "Main Memory Tech Type: " << computer->getMemory()->getTechnologyType() << endl;
    cout << "Main Memory Capacity: " << computer->getMemory()->getCapacity() << " GB" << endl;
    cout << "Total number of ports: " << computer->getMotherboard()->getNumPorts() << endl;
    cout << "Ports:" << endl;

    for (int i = 0; i < numPorts; i++) 
    {
        cout << "Port " << i + 1 << ": " << portNames[i] << endl;
    }

    cout << "Physical Memory Type: " << memoryType << gen << endl;
    cout << "Physical Memory Capacity: " << pmCapacity << " GB" << endl;
    cout << "Graphics Card Brand: " << computer->getGraphicsCard()->getBrand() << endl;
    cout << "Graphics Card Memory Size: " << computer->getGraphicsCard()->getMemorySize() << " GB" << endl;
    cout << "Storage Device Type: " << computer->getStorageDevice()->getType() << endl;

    if (storageType == "hdd")
        cout << "HDD type : " << hddType << endl;

    cout << "Storage Device Capacity: " << computer->getStorageDevice()->getCapacity() << " GB" << endl;
    cout << "Network Card Type: " << computer->getNetworkCard()->getType() << endl;
    cout << "Network Card Speed: " << computer->getNetworkCard()->getSpeed() << " Mbps" << endl;
    cout << "Power Supply Wattage: " << computer->getPowerSupply()->getWattage() << " W" << endl;
    cout << "Battery Capacity: " << computer->getBattery()->getCapacity() << " mAh" << endl;
    cout << "Case Form Factor: " << computer->getCase()->getFormFactor() << endl;
    cout << "Case Color: " << computer->getCase()->getColor() << endl;
    cout << "------------------------------------------------------------------------------------------------" << endl;
    cout << "Total Price: " << computer->getTotalPrice()<< " $" << endl;

    // Clean up memory
    delete cpu;
    delete memory;
    delete motherboard;
    delete graphicsCard;
    delete storageDevice;
    delete networkCard;
    delete powerSupply;
    delete battery; 
    delete pcCase;
    delete computer;

    return 0;
}
