#pragma once
#include <iostream>
using namespace std;

// ALU class
class ALU
{
private:
    int NoOfAdders;
    int NoOfSubtractors;
    int NoOfRegisters;
    int sizeOfRegisters;

public:
    ALU(int adders = 0, int subtractors = 0, int registers = 0, int size = 0);
    int getNoOfAdders();
    void setNoOfAdders(int adders);
    int getNoOfSubtractors();
    void setNoOfSubtractors(int subtractors);
    int getNoOfRegisters();
    void setNoOfRegisters(int registers);
    int getSizeOfRegisters();
    void setSizeOfRegisters(int size);
};




// ControlUnit class
class ControlUnit
{
private:
    double clock;

public:
    ControlUnit(double c = 0.0);
    double getClock();
    void setClock(double c);
};




// CPU class
class CPU
{
private:
    ALU alu;
    ControlUnit cu;
    string brand;
    string architecture;
    string integratedGPU;

public:
    CPU(const ALU& a = ALU(), const ControlUnit& c = ControlUnit(), const string& brand = "", const string& architecture = "", const string& integratedGPU = "");
    ALU getALU();
    void setALU(const ALU& a);
    ControlUnit getCU();
    void setCU(const ControlUnit& c);
    string getBrand();
    string getArchitecture();
    string getIntegratedGPU();
};

// Derived class for Intel CPUs
class IntelCPU : public CPU
{
public:
    IntelCPU();
};

// Derived class for AMD CPUs
class AMDCPU : public CPU
{
public:
    AMDCPU();
};

// Derived class for AppleSilicon CPUs
class AppleSiliconCPU : public CPU
{
public:
    AppleSiliconCPU();
};




class MainMemory
{
private:
    int capacity;
    string technologyType;

public:
    MainMemory();
    MainMemory(int cap, const string& tech);
    int getCapacity();
    void setCapacity(int cap);
    string getTechnologyType();
    void setTechnologyType(const string& tech);
};



class Port
{
private:
    string type;
    int baud_rate;

public:
    Port();
    Port(const string& t, int baud);
    string getType();
    void setType(const string& t);
    int getBaudRate();
    void setBaudRate(int baud);
};




class MotherBoard
{
private:
    MainMemory* mm;
    Port* ports;
    int NumPorts;

public:
    MotherBoard();
    MotherBoard(int capacity, const string& tech, int numPorts);

    MainMemory* getMainMemory();
    void setMainMemory(MainMemory* memory);
    Port* getPort(int index);
    void setPort(int index, Port* port);
    int getNumPorts();
    void setNumPorts(int num);

    ~MotherBoard();
};




// Base Memory class
class Memory
{
protected:
    string memoryType;

public:
    Memory();
    Memory(const string& type);
    string getMemoryType();
    void setMemoryType(const string& type);
};

// DDR4/5 Memory class
class DDRMemory : public Memory
{
public:
    DDRMemory();
};

// LPDDR4/5 Memory class
class LPDDRMemory : public Memory
{
public:
    LPDDRMemory();
};

// PhysicalMemory class
class PhysicalMemory : public Memory
{
private:
    int capacity;

public:
    PhysicalMemory();
    PhysicalMemory(int cap, const string& type);
    int getCapacity();
    void setCapacity(int cap);

};




class Computer
{
private:
    PhysicalMemory* pm;
    MotherBoard* mb;
    CPU* cpu;

public:
    Computer();
    Computer(int pmcapacity, const string& pmtech, int mbcapacity, const string& mbtech, int NumOfPorts, const string& Tech, const string& mbType, const string& cpuBrand);
    Computer(PhysicalMemory* pm, MotherBoard* mb, CPU* cpu);

    PhysicalMemory* getPhysicalMemory();
    void setPhysicalMemory(PhysicalMemory* pm);
    MotherBoard* getMotherBoard();
    void setMotherBoard(MotherBoard* mb);
    CPU* getCPU();
    void setCPU(CPU* cpu);
};




class GraphicsCard 
{
private:
    string brand;
    int memorySize;
    double price;
    string gpuType;

public:
    GraphicsCard();
    GraphicsCard(const string& brand, int memorySize, double price, const string& gpuType);
    string getBrand();
    void setBrand(const string& brand);
    int getMemorySize();
    void setMemorySize(int memorySize);
    double getPrice();
    void setPrice(double price);
    string getGPUType();
    void setGPUType(const string& gpuType);
};

//Nvidia GPUs
class NvidiaGPU : public GraphicsCard
{
public:
    NvidiaGPU(int memorySize, double price);
};

//AMD GPUs
class AMDGPU : public GraphicsCard
{
public:
    AMDGPU(int memorySize, double price);
};

//Apple GPUs
class AppleGPU : public GraphicsCard
{
public:
    AppleGPU(int memorySize, double price);
};





class StorageDevice
{
private:
    string type;
    int capacity;
    double price;

public:
    StorageDevice();
    StorageDevice(const string& type, int capacity, double price);
    string getType();
    void setType(const string& type);
    int getCapacity();
    void setCapacity(int capacity);
    double getPrice();
    void setPrice(double price);
};





class NetworkCard
{
private:
    string type;
    int speed;
    double price;

public:
    NetworkCard();
    NetworkCard(const string& type, int speed, double price);
    string getType();
    void setType(const string& type);
    int getSpeed();
    void setSpeed(int speed);
    double getPrice();
    void setPrice(double price);
};





class PowerSupply
{
private:
    int wattage;
    string efficiencyRating;
    double price;

public:
    PowerSupply();
    PowerSupply(int wattage, const string& efficiencyRating, double price);
    int getWattage();
    void setWattage(int wattage);
    string getEfficiencyRating();
    void setEfficiencyRating(const string& efficiencyRating);
    double getPrice();
    void setPrice(double price);
};





class Battery
{
private:
    int capacity;
    double price;

public:
    Battery();
    Battery(int capacity , double price);
    int getCapacity();
    void setCapacity(int capacity);
    double getPrice();
    void setPrice(double price);

};






class Case
{
private:
    string formFactor;
    string color;

public:
    Case();
    Case(const string& ff, const string& c);
    string getFormFactor();
    void setFormFactor(const string& ff);
    string getColor();
    void setColor(const string& c);
};







class ComputerAssembly 
{
private:
    CPU* cpu;
    MainMemory* memory;
    MotherBoard* motherboard;
    GraphicsCard* graphicsCard;
    StorageDevice* storageDevice;
    NetworkCard* networkCard;
    PowerSupply* powerSupply;
    Battery* battery;
    Case* PC_Case;
    double totalPrice;

public:
    ComputerAssembly();
    ComputerAssembly(CPU* cpu, MainMemory* memory, MotherBoard* motherboard, GraphicsCard* graphicsCard,
        StorageDevice* storageDevice, NetworkCard* networkCard, PowerSupply* powerSupply,
        Battery* battery, Case* pcCase, double totalPrice);

    CPU* getCPU();
    void setCPU(CPU* cpu);
    MainMemory* getMemory();
    void setMemory(MainMemory* memory);
    MotherBoard* getMotherboard();
    void setMotherboard(MotherBoard* motherboard);
    GraphicsCard* getGraphicsCard();
    void setGraphicsCard(GraphicsCard* graphicsCard);
    StorageDevice* getStorageDevice();
    void setStorageDevice(StorageDevice* storageDevice);
    NetworkCard* getNetworkCard();
    void setNetworkCard(NetworkCard* networkCard);
    PowerSupply* getPowerSupply();
    void setPowerSupply(PowerSupply* powerSupply);
    Battery* getBattery();
    void setBattery(Battery* battery);
    Case* getCase();
    void setCase(Case* pcCase);
    double getTotalPrice();
    void setTotalPrice(double totalPrice);
};





