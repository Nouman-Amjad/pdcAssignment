#include "MySystem.h"

// ALU class methods implementation
ALU::ALU(int adders, int subtractors, int registers, int size)
{
    NoOfAdders = adders;
    NoOfSubtractors = subtractors;
    NoOfRegisters = registers;
    sizeOfRegisters = size;

}

int ALU::getNoOfAdders()
{
    return NoOfAdders;
}

void ALU::setNoOfAdders(int adders)
{
    NoOfAdders = adders;
}

int ALU::getNoOfSubtractors()
{
    return NoOfSubtractors;
}
void ALU::setNoOfSubtractors(int subtractors)
{
    NoOfSubtractors = subtractors;
}

int ALU::getNoOfRegisters()
{
    return NoOfRegisters;
}

void ALU::setNoOfRegisters(int registers)
{
    NoOfRegisters = registers;
}

int ALU::getSizeOfRegisters()
{
    return sizeOfRegisters;
}

void ALU::setSizeOfRegisters(int size)
{
    sizeOfRegisters = size;
}




// ControlUnit class methods implementation
ControlUnit::ControlUnit(double c)
{
    clock = c;
}

double ControlUnit::getClock()
{
    return clock;
}
void ControlUnit::setClock(double c)
{
    clock = c;
}




// CPU class methods implementation
CPU::CPU(const ALU& a, const ControlUnit& c, const string& b, const string& arch, const string& gpu) : alu(a), cu(c), brand(b), architecture(arch), integratedGPU(gpu) {}

ALU CPU::getALU()
{
    return alu;
}

void CPU::setALU(const ALU& a)
{
    alu = a;
}

ControlUnit CPU::getCU()
{
    return cu;
}

void CPU::setCU(const ControlUnit& c)
{
    cu = c;
}

string CPU::getBrand()
{
    return brand;
}

string CPU::getArchitecture()
{
    return architecture;
}

string CPU::getIntegratedGPU()
{
    return integratedGPU;
}

// Constructor implementations for derived CPU classes
IntelCPU::IntelCPU() :CPU(ALU(), ControlUnit(), "Intel", "x86", "None")
{}

AMDCPU::AMDCPU() : CPU(ALU(), ControlUnit(), "AMD", "x86", "None")
{}

AppleSiliconCPU::AppleSiliconCPU() : CPU(ALU(), ControlUnit(), "Apple", "ARM64", "AppleGPU")
{}






MainMemory::MainMemory()
{
    capacity = 0;
    technologyType = "";
}

MainMemory::MainMemory(int cap, const string& tech)
{
    capacity = cap;
    technologyType = tech;
}

int MainMemory::getCapacity()
{
    return capacity;
}

void MainMemory::setCapacity(int cap)
{
    capacity = cap;
}

string MainMemory::getTechnologyType()
{
    return technologyType;
}

void MainMemory::setTechnologyType(const string& tech)
{
    technologyType = tech;
}






Port::Port()
{
    type = "";
    baud_rate = 0;
}

Port::Port(const string& t, int baud)
{
    type = t;
    baud_rate = baud;
}

string Port::getType()
{
    return type;
}

void Port::setType(const string& t)
{
    type = t;
}

int Port::getBaudRate()
{
    return baud_rate;
}

void Port::setBaudRate(int baud)
{
    baud_rate = baud;
}




MotherBoard::MotherBoard()
{
    mm = nullptr;
    ports = nullptr;
    NumPorts = 0;
}

MotherBoard::MotherBoard(int capacity, const string& tech, int numPorts) : mm(new MainMemory(capacity, tech))
{
    ports = new Port[numPorts]; // Dynamically allocate ports array
    NumPorts = numPorts;
}

MainMemory* MotherBoard::getMainMemory()
{
    return mm;
}

void MotherBoard::setMainMemory(MainMemory* memory)
{
    mm = memory;
}

Port* MotherBoard::getPort(int i)
{
    if (i >= 0 && i < NumPorts)
    {
        return &ports[i];
    }
    return nullptr;
}

void MotherBoard::setPort(int i, Port* p)
{
    if (i >= 0 && i < NumPorts && p != nullptr)
    {
        ports[i] = *p;
    }
}

int MotherBoard::getNumPorts()
{
    return NumPorts;
}

void MotherBoard::setNumPorts(int num)
{
    NumPorts = num;
}

MotherBoard::~MotherBoard()
{
    delete[] ports;
}




Memory::Memory()
{
    memoryType = "";
}

Memory::Memory(const string& type)
{
    memoryType = type;
}

string Memory::getMemoryType()
{
    return memoryType;
}

void Memory::setMemoryType(const string& type)
{
    memoryType = type;
}



PhysicalMemory::PhysicalMemory()
{
    capacity = 0;
}
 
PhysicalMemory::PhysicalMemory(int cap, const string& type) : Memory(type)
{
    capacity = cap;
}

int PhysicalMemory::getCapacity()
{
    return capacity;
}

void PhysicalMemory::setCapacity(int cap)
{
    capacity = cap;
}

// DDR Memory 
DDRMemory::DDRMemory() : Memory("DDR4/5")
{

}

// LPDDR Memory 
LPDDRMemory::LPDDRMemory() : Memory("LPDDR4/5")
{

}





Computer::Computer()
{
    pm = nullptr;
    mb = nullptr;
    cpu = nullptr;
}

Computer::Computer(int pmcapacity, const string& pmtech, int mbcapacity, const string& mbtech, int numPorts, const string& cpuBrand, const string& cpuArchitecture, const string& cpuIntegratedGPU)
{
    pm = new PhysicalMemory(pmcapacity, pmtech);
    mb = new MotherBoard(mbcapacity, mbtech, numPorts);
    cpu = new CPU(ALU(), ControlUnit(), cpuBrand, cpuArchitecture, cpuIntegratedGPU);
}

Computer::Computer(PhysicalMemory* p_m, MotherBoard* m_b, CPU* Cpu)
{
    pm = p_m;
    mb = m_b;
    cpu = Cpu;
}

PhysicalMemory* Computer::getPhysicalMemory()
{
    return pm;
}

void Computer::setPhysicalMemory(PhysicalMemory* pm)
{
    this->pm = pm;
}

MotherBoard* Computer::getMotherBoard()
{
    return mb;
}

void Computer::setMotherBoard(MotherBoard* mb)
{
    this->mb = mb;
}

CPU* Computer::getCPU()
{
    return cpu;
}

void Computer::setCPU(CPU* cpu)
{
    this->cpu = cpu;
}





GraphicsCard::GraphicsCard()
{
    brand = "";
    memorySize = 0;
    price = 0.0;
    gpuType = "";
}

GraphicsCard::GraphicsCard(const string& b, int size, double p, const string& type)
{
    brand = b;
    memorySize = size;
    price = p;
    gpuType = type;
}

string GraphicsCard::getBrand()
{
    return brand;
}

void GraphicsCard::setBrand(const string& brand)
{
    this->brand = brand;
}

int GraphicsCard::getMemorySize()
{
    return memorySize;
}

void GraphicsCard::setMemorySize(int memorySize)
{
    this->memorySize = memorySize;
}

double GraphicsCard::getPrice()
{
    return price;
}

void GraphicsCard::setPrice(double price)
{
    this->price = price;
}

string GraphicsCard::getGPUType()
{
    return gpuType;
}

void GraphicsCard::setGPUType(const string& gpuType)
{
    this->gpuType = gpuType;
}


NvidiaGPU::NvidiaGPU(int memorySize, double price) : GraphicsCard("Nvidia", memorySize, price, "Discrete")
{}

AMDGPU::AMDGPU(int memorySize, double price) : GraphicsCard("AMD", memorySize, price, "Discrete")

{}

AppleGPU::AppleGPU(int memorySize, double price) : GraphicsCard("Apple", memorySize, price, "Integrated")
{}





StorageDevice::StorageDevice()
{
    type = "";
    capacity = 0;
    price = 0.0;
}

StorageDevice::StorageDevice(const string& t, int c, double p)
{
    type = t;
    capacity = c;
    price = p;
}

string StorageDevice::getType()
{
    return type;
}

void StorageDevice::setType(const string& t)
{
    this->type = t;
}

int StorageDevice::getCapacity()
{
    return capacity;
}

void StorageDevice::setCapacity(int cap)
{
    this->capacity = cap;
}

double StorageDevice::getPrice()
{
    return price;
}

void StorageDevice::setPrice(double p)
{
    this->price = p;
}






NetworkCard::NetworkCard()
{
    type = "";
    speed = 0;
    price = 0.0;
}

NetworkCard::NetworkCard(const string& t, int s, double p)
{
    type = t;
    speed = s;
    price = p;
}

string NetworkCard::getType()
{
    return type;
}

void NetworkCard::setType(const string& t)
{
    this->type = t;
}

int NetworkCard::getSpeed()
{
    return speed;
}

void NetworkCard::setSpeed(int s)
{
    this->speed = s;
}

double NetworkCard::getPrice()
{
    return price;
}

void NetworkCard::setPrice(double p)
{
    this->price = p;
}






PowerSupply::PowerSupply()
{
    wattage = 0;
    efficiencyRating = "";
    price = 0.0;
}

PowerSupply::PowerSupply(int watt, const string& eff_Rating, double p)
{
    wattage = watt;
    efficiencyRating = eff_Rating;
    price = p;
}

int PowerSupply::getWattage()
{
    return wattage;
}

void PowerSupply::setWattage(int watt)
{
    this->wattage = watt;
}

string PowerSupply::getEfficiencyRating()
{
    return efficiencyRating;
}

void PowerSupply::setEfficiencyRating(const string& eff_Rating)
{
    this->efficiencyRating = eff_Rating;
}

double PowerSupply::getPrice()
{
    return price;
}

void PowerSupply::setPrice(double p)
{
    this->price = p;
}






Battery::Battery()
{
    capacity = 0;
    price = 0;
}


Battery::Battery(int cap , double p)
{
    capacity = cap;
    price = p;
}

int Battery::getCapacity()
{
    return capacity;
}

void Battery::setCapacity(int cap)
{
    this->capacity = cap;
}

double Battery::getPrice()
{
    return price;
}

void Battery::setPrice(double p)
{
    this->price = p;
}






// Default constructor
Case::Case() 
{
    formFactor = "";
    color = "";
}

Case::Case(const string& ff, const string& c)
{
    formFactor = ff;
    color = c;
}

string Case::getFormFactor() 
{
    return formFactor;
}

void Case::setFormFactor(const string& ff) 
{
    formFactor = ff;
}

string Case::getColor() 
{
    return color;
}

void Case::setColor(const string& c) 
{
    color = c;
}






ComputerAssembly::ComputerAssembly() 
{
    cpu = nullptr;
    memory = nullptr;
    motherboard = nullptr;
    graphicsCard = nullptr;
    storageDevice = nullptr;
    networkCard = nullptr;
    powerSupply = nullptr;
    battery = nullptr;
    PC_Case = nullptr;
    totalPrice = 0.0 ;
}

// Overloaded constructor
ComputerAssembly::ComputerAssembly(CPU* CPU, MainMemory* Memory, MotherBoard* mb, GraphicsCard* gCard,
    StorageDevice* strgDevice, NetworkCard* nCard, PowerSupply* power, Battery* batt, Case* pcCase, double totalP)
    
{
    this->cpu = CPU;
    this->memory = Memory;
    this->motherboard = mb;
    this->graphicsCard = gCard;
    this->storageDevice = strgDevice;
    this->networkCard = nCard;
    this->powerSupply = power;
    this->battery = batt;
    this->PC_Case = pcCase;
    this->totalPrice = totalP;
}

CPU* ComputerAssembly::getCPU() 
{
    return cpu; 
}

void ComputerAssembly::setCPU(CPU* CPU) 
{ 
    this->cpu = cpu; 
}

MainMemory* ComputerAssembly::getMemory() 
{
    return memory; 
}

void ComputerAssembly::setMemory(MainMemory* Memory) 
{
    this->memory = Memory; 
}

MotherBoard* ComputerAssembly::getMotherboard() 
{
    return motherboard;
}

void ComputerAssembly::setMotherboard(MotherBoard* board) 
{
    this->motherboard = board; 
}

GraphicsCard* ComputerAssembly::getGraphicsCard() 
{
    return graphicsCard;
}

void ComputerAssembly::setGraphicsCard(GraphicsCard* gCard) 
{
    this->graphicsCard = gCard; 
}

StorageDevice* ComputerAssembly::getStorageDevice() 
{
    return storageDevice; 
}

void ComputerAssembly::setStorageDevice(StorageDevice* Device) 
{
    this->storageDevice = Device; 
}

NetworkCard* ComputerAssembly::getNetworkCard() 
{
    return networkCard; 
}

void ComputerAssembly::setNetworkCard(NetworkCard* NCard) 
{
    this->networkCard = NCard; 
}

PowerSupply* ComputerAssembly::getPowerSupply()
{
    return powerSupply; 
}

void ComputerAssembly::setPowerSupply(PowerSupply* power) 
{
    this->powerSupply = power; 
}

Battery* ComputerAssembly::getBattery() 
{
    return battery; 
}

void ComputerAssembly::setBattery(Battery* b) 
{
    this->battery = b;
}

Case* ComputerAssembly::getCase() 
{
    return PC_Case;
}

void ComputerAssembly::setCase(Case* pcCase) 
{
    PC_Case = pcCase; 
}

double ComputerAssembly::getTotalPrice() 
{
    return totalPrice;
}

void ComputerAssembly::setTotalPrice(double totalP) 
{
    this->totalPrice = totalP; 
}
