/*
-------Assignment3-------
Name: Mustafa Ahsan Khan
Section: CS-B
ID: 23i-0549
Instructor Name: Sir Ali Zeeshan 
TA Name: Muhammad Mohsin Ramzan i20-2354
*/

#include <iostream>
using namespace std;

#include "../assignment3_project/ComputerAssembly.h"

int main()
{
	ComputerAssembly myPC;
	myPC.selectOption();
	myPC.Display();

	return 0;
}