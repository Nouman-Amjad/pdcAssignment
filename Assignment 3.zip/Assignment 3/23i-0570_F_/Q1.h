#pragma once
#include<iostream>
using namespace std;

									/*
										Name: Areeba Javed
										Roll No: 23I-0570
										Section: F
										TA Name: Ariyan Chaudhary
									*/

class ALU
{
	int no_of_adders;
	int no_of_subtractors;
	int no_of_registers;
	int size_of_registers;

public:
	ALU()
	{
		no_of_adders = 1;
		no_of_subtractors = 1;
		no_of_registers = 8;
		size_of_registers = 32;
	}
	ALU(int adders, int subtractors, int registers, int sizeregis)
	{
		if (adders <= 0)
		{
			cout << "Adders can't be negative or zero in a computer" << endl << "Therefore setting default values" << endl;
			no_of_adders = 1;
		}
		else {
			no_of_adders = adders;
		}
		if (subtractors <= 0)
		{
			cout << "Subtractors can't be negative or zero in a computer" << endl << "Therefore setting default values" << endl;
			no_of_subtractors = 1;
		}
		else {
			no_of_subtractors = subtractors;
		}
		no_of_registers = registers;
		size_of_registers = sizeregis;

	}
	void set_adders(int add)
	{
		if (add > 0)
		{
			no_of_adders = add;
		}
		else {
			cout << "Adders can't be negative or zero in a computer" << endl << "Therefore setting default values" << endl;
			no_of_adders = 1;
		}
	}
	void set_subtractors(int sub)
	{
		if (sub > 0)
		{
			no_of_subtractors = sub;
		}
		else
		{
			cout << "Subtractors can't be negative or zero in a computer" << endl << "Therefore setting default values" << endl;
			no_of_subtractors = 1;
		}
	}
	void set_registers(int reg)
	{
		no_of_registers = reg;
	}
	void set_registerssize(int regs)
	{
		size_of_registers = regs;
	}

	int getadders()
	{
		return no_of_adders;
	}
	int getsubtractors()
	{
		return no_of_subtractors;
	}
	int getregisters()
	{
		return no_of_registers;
	}
	int getregisterssize()
	{
		return size_of_registers;
	}
};
class ControlUnit
{
	float clock;
public:
	ControlUnit()
	{
		clock = 1.0;
	}
	ControlUnit(float ck)
	{
		if (ck > 0)
		{
			clock = ck;
		}
		else {
			cout << "Not a definite value of clock enter again" << endl;
			int ck1;
			cin >> ck1;
			clock = ck1;
		}
	}
	void setclock(float ck)
	{
		clock = ck;
	}
	float getclock()
	{
		return clock;
	}
};
class CPU
{
	ALU alu;
	ControlUnit cu;

public:
	CPU():alu(),cu()
	{
	
	}
	CPU(ALU au, ControlUnit c) 
	{

	};
	
};
class AppleCPU :public CPU
{
	string architecture;
	GraphicsCard gpu;

public:
	AppleCPU()
	{
		architecture = "ARM64";
		gpu.setbrand("AppleGPU");
		
	}
};
class AMDCPU :public CPU
{
	string architecture;
	

public:
	AMDCPU()
	{
		architecture = "x86";
	}
};
class MainMemory
{
	int capacity;
	string TechnologyType;

public:
	MainMemory()
	{
		capacity = 4;
		TechnologyType = "silicon";
	}
	MainMemory(int cap, string type)
	{
		if (type != " Silicon" || type != "Semiconductor" || type != "silicon" || type != "semiconductor")
		{
			cout << "Enter a valid technology type" << endl;
			string t;
			cin >> t;
		}
		else {
			TechnologyType = type;
		}
		int temp = cap;
		while (cap % 2 == 0)
			cap /= 2;
		if (cap == 1)
		{
			capacity = temp;

		}
		else {
			cout << "Not a valid capacity enter again!!!" << endl;
			int no;
			cin >> no;
			capacity = no;
		}
	}
	void setCapacity(int cap)
	{
		int temp = cap;
		while (cap % 2 == 0)
			cap /= 2;
		if (cap == 1)
		{
			capacity = temp;

		}
		else {
			cout << "Not a valid capacity enter again!!!" << endl;
			int no;
			cin >> no;
			capacity = no;
		}
	}
	void setTechnologyType(string type)
	{
		if (type != " Silicon" || type != "Semiconductor" || type != "silicon" || type != "semiconductor")
		{
			cout << "Enter a valid technology type" << endl;
			string t;
			cin >> t;
		}
		else {
			TechnologyType = type;
		}
	}
	int getCapacity()
	{
		return capacity;
	}
	string getTechnologyType() {
		return TechnologyType;
	}
};
class Port {
	string type;
	int baud_rate;
	
public:
	Port()
	{
		type = "VGI Port";
		baud_rate = 115200;

	}
	Port(string tp, int bdr)
	{
		if (bdr <= 0 || bdr != static_cast<int>(bdr) || bdr > 1000000)
		{
			cout << "Invalid baud_rate enter again" << endl;
			int br;
			cin >> br;
			bdr = br;
		}
		else {
			baud_rate = bdr;
		}
		type = tp;
		
	}
	void setBaudRate(int bdr)
	{
		if (bdr <= 0 || bdr != static_cast<int>(bdr) || bdr > 1000000)
		{
			cout << "Invalid baud_rate enter again" << endl;
			int br;
			cin >> br;
			bdr = br;
		}
		else {
			baud_rate = bdr;
		}
	}
	
	void setType(string tp)
	{
		type = tp;
	}
	int getBaudRate()
	{
		return baud_rate;
	}
	string getType()
	{
		return type;
	}
};
class MotherBoard
{
	MainMemory*mm;
	Port* ports;
	
public:
	MotherBoard()
	{
		mm = nullptr;
		ports = nullptr;
	}
	MotherBoard(MainMemory* m, Port* pt)
	{
		mm = m;
		ports = pt;
	}

};
class PhysicalMmemory
{
	int capacity;

};
class Computer
{
	PhysicalMmemory pm;
	MotherBoard mb;
	CPU cpu;

public:
	Computer() :pm(), mb(), cpu()
	{
	};

	
};
class GraphicsCard
{
	string brand;
	int memorysize;
	double price;

public:

	GraphicsCard()
	{
		brand = "AMD";
		memorysize = 2;
		price = 50;
	}
	GraphicsCard(string bd, int ms)
	{
		brand = bd;
		if (ms < 0 && ms >16)
		{
			cout << "Invalid memory Enter again!" << endl;
			cin >> memorysize;
		}
		else
		memorysize = ms;
		price = 100 + memorysize;
		
	}
	void setbrand(string bd)
	{
		brand = bd;
	}
	void setmemorysize(int ms)
	{
		if (ms < 0 && ms >16)
		{
			cout << "Invalid memory Enter again!" << endl;
			cin >> memorysize;
		}
		else
			memorysize = ms;
	}
	double getprice()
	{
		return price;
	}
	int getmemorysize()
	{
		return memorysize;
	}
	string getbrand()
	{
		return brand;
	}
};								
class StorageDevice
{
	string type;
	int capacity;
	double price;
public:

	StorageDevice()
	{
		type = "HDD";
		capacity = 128;
		price = 100;
	}
	StorageDevice(string tp, int cap)
	{
		type = tp;
		if(cap>0)
		capacity = cap;
		else
		{
			cout << "Invalid Capacity Enter again!" << endl;
			
			cin >> capacity;
		}
		price = capacity + 50;
	}
	double getPrice()
	{
		return price;
	}
};							
class NetworkCard
{
	string type;
	int speed;
	double price;
public:
	NetworkCard()
	{
		type = "Wifi";
		speed = 100;
		price = 20;
	}
	NetworkCard(string tp,int sp)
	{
		type = tp; 
		if(sp>10 && sp>0 && sp<10000)
		speed = sp;
		else {
			cout << "Invalid Speed Enter again!" << endl;

			cin >> speed;
		}
		price = 200 - speed;
	}
	string gettype()
	{
		return type;
	}
	int getspeed()
	{
		return speed;
	}
	double getPrice()
	{
		return price;
	}


};							
class PowerSupply
{
	int Wattage;
	string EfficiencyRating;
	double Price;

public:
	PowerSupply()
	{
		Wattage = 450;
		EfficiencyRating = "80 Plus Bronze";
		Price = 50;
	};
	PowerSupply(int wt, string ER)
	{
		if (wt > 450 && wt < 1000)
			Wattage = wt;
		else
		{
			cout << "Inavlid Wattage Enter again!" << endl;
			cin >> Wattage;
		}
		EfficiencyRating = ER;
		if (Wattage <= 450)
		{
			Price = 50;
		}
		if (Wattage >= 500 || Wattage <= 650)
		{
			Price = 100;
		}
		else if(Wattage >= 651 || Wattage <= 800) {
			Price = 150;
		}
		else if(Wattage>800) {
			Price = 200;;
		}
		EfficiencyRating = ER;
	};
	int getWattage()
	{
		return Wattage;
	}
	string getEF()
	{
		return EfficiencyRating;
	}
	double getPrice()
	{
		return Price;
	}
};							
class Battery
{
	int capacity;
public:
	Battery()
	{
		capacity = 2000;
	}
	Battery(int cp)
	{
		if (cp >= 2000 && cp <= 10000)
			capacity = cp;
		else {
			cout << "Invalid capacity for battery.Enter again" << endl;
			cin >> capacity;
		}
	}
	int getcapacity()
	{
		return capacity;
	}
 };										
class Case
{
	string formFactor;
	string color;

public:
	Case()
	{
		formFactor = "ATX";
		color = "blue";
	}
	Case(string ff, string nm)
	{
		formFactor = ff;
		color = nm;
	}
	string getformfactor()
	{
		return formFactor;
	}
	string getcolor()
	{
		return color;
	}
};

class ComputerAssembly
{
public:
	Battery bt;
	Case cs;
	Computer c;
	PowerSupply ps;
	NetworkCard nc;
	double TotalPrice;
	string obj;
	string OperatingSystem;
	ComputerAssembly() {
		TotalPrice = ps.getPrice() + nc.getPrice();
		obj = "Desktop";  
		OperatingSystem = "Android";  
	}

	// Overloaded constructor
	ComputerAssembly(string obj, string os, int btCapacity, string csFormFactor,
		string csColor, int psWattage, string psEfficiency,
		string ncType, int ncSpeed)
		: obj(obj), OperatingSystem(os), bt(btCapacity), cs(csFormFactor, csColor),
		ps(psWattage, psEfficiency), nc(ncType, ncSpeed) {
		TotalPrice = ps.getPrice() + nc.getPrice();
	}
	void displaySpecs() {
		cout << "Object Type: " << obj << endl;
		cout << "Operating System: " << OperatingSystem << endl;
		cout << "Battery Capacity: " << bt.getcapacity() << " mAh" << endl;
		cout << "Case Form Factor: " << cs.getformfactor() << endl;
		cout << "Case Color: " << cs.getcolor() << endl;
		cout << "Power Supply Wattage: " << ps.getWattage() << "W" << endl;
		cout << "Power Supply Efficiency Rating: " << ps.getEF() << endl;
		cout << "Network Card Type: " << nc.gettype() << endl;
		cout << "Network Card Speed: " << nc.getspeed() << " Mbps" << endl;
		cout << "Total Price: $" << TotalPrice << endl;
	}
};
/*
* class Desktop:public ComputerAssembly
{
	string OperatingSystem;
public:
	void setOS(string os)
	{
		OperatingSystem = os;
	}
	string getOS() {
		return OperatingSystem;
	}
	
};
class Laptop :public ComputerAssembly
{
	string OperatingSystem;
public:
	void setOS(string os)
	{
		OperatingSystem = os;
	}
	string getOS() {
		return OperatingSystem;
	}
};
class Tablet :public ComputerAssembly
{
	string OperatingSystem;
public:
	void setOS(string os)
	{
		OperatingSystem = os;
	}
	string getOS() {
		return OperatingSystem;
	}
};
class Phone :public ComputerAssembly
{
	string OperatingSystem;
public:
	void setOS(string os)
	{
		OperatingSystem = os;
	}
	string getOS() {
		return OperatingSystem;
	}
};
*/
