
#include<iostream>
#include"Q1.h"
using namespace std;

int main()
{
	cout << "What device you want today!" << endl;
	cout << "Here are some options for you" << endl;
	cout << "1. Desktop/PC" << endl << "2. Laptop" << endl << "3. Tablet" << endl << "4.MobilePhone" << endl;
	cout << "Enter the number given above for a device you want" << endl;
	int number;
	string Os;
	cout << "Enter the operating system you want\n You have two choices Android or Apple" << endl;
	cin >> Os;
	cin >> number;
	ComputerAssembly c;
	if (number == 1)
		c.obj = "Desktop";
	c.OperatingSystem = Os;
	if (Os == "Android" || Os == "android")
		AMDCPU cpu1;
	

	ALU androidALU(4, 2, 16,64); // 4 adders, 2 subtractors, 16 registers
	ControlUnit androidCU(2.0); // clock speed in GHz
	CPU androidCPU(androidALU, androidCU);
		int cpm;
		cout << "Enter the main memory for your desktop" << endl;
		cin >> cpm;
		string typemm;
		cout << "Enter the type of main memory you want silicon or semiconductor" << endl;
		cin >> typemm;
	MainMemory RAM(cpm, typemm);

	string brandgpu;
		int sizegpu;
	cout << "Enter the brand of GPU you want" << endl;
	cin >> brandgpu;
	cout << "Enter the size of gpu you want " << endl;
	cin >> sizegpu;
	GraphicsCard GPU(brandgpu, sizegpu);

	string typenc;
	 int spnc;
	cout << "Enter the type for your network card " << endl;
	cin >> typenc;
	cout << "Enter the speed you want for network card" << endl;
	cin >> spnc;
	NetworkCard wifiCard(typenc, spnc); 

	PowerSupply psu(500, "80 Plus Bronze");
	string colorc;
	cout << "Enter the color you want for your case" << endl;
	cin >> colorc;
	Case atxCase("ATX", colorc);
	int btCap;
	cout << "Enter the capacity for the battery" << endl;
	cin >> btCap;

	ComputerAssembly comp("Desktop", Os, btCap,"ATX" , colorc, 500,"80 Plus Bronze" , typenc, spnc);
	comp.displaySpecs();
}
