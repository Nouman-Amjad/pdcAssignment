#pragma once
#include<iostream>
using namespace std;

class Case
{
private:
	string formfactor;
	string color;
public:
	void input();


};

