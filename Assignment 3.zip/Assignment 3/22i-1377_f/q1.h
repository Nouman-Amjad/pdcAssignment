// skeleton code for class structure ,  eg prototpyes
#include <iostream>
#include <string>
using namespace std;

// class of alu
class ALU
{
private:
    int NoOfAdders;
    int NoOfSubtractors;
    int NoOfRegisters;
    int sizeOfRegisters;

public:
    // default constructor
    ALU() : NoOfAdders(0), NoOfSubtractors(0), NoOfRegisters(0), sizeOfRegisters(0) {}

    // overloaded constructor
    ALU(int adders, int subtractors, int registers, int size) : NoOfAdders(adders), NoOfSubtractors(subtractors), NoOfRegisters(registers), sizeOfRegisters(size) {}

    ALU(ALU*allen){

    NoOfAdders = allen->NoOfAdders;
    NoOfRegisters = allen->NoOfRegisters;
    NoOfSubtractors = allen->NoOfSubtractors;
    sizeOfRegisters = allen ->sizeOfRegisters;

    }

    // getter
    int getNoOfAdders() { return NoOfAdders; }
    int getNoOfSubtractors() { return NoOfSubtractors; }
    int getNoOfRegisters() { return NoOfRegisters; }
    int getSizeOfRegisters() { return sizeOfRegisters; }

    // setter
    void setNoOfSubtractors(int num) { NoOfSubtractors = num; }
    void setNoOfRegisters(int num) { NoOfRegisters = num; }
    void setSizeOfRegisters(int num) { sizeOfRegisters = num; }
    void setNoOfAdders(int num) { NoOfAdders = num; }


    void displaySpecs()  {
        cout << "Adders: " << NoOfAdders << endl;
        cout << "Subtractors: " << NoOfSubtractors << endl;
        cout << "Registers: " << NoOfRegisters << endl;
        cout << "Size of Registers: " << sizeOfRegisters << " bits" << endl;
    }

};




// controlunit class
class ControlUnit
{
private:
    float clock;

public:
    // default
    ControlUnit() : clock(0.0) {}

    // overloaded
    ControlUnit(float CLK) : clock(CLK) {}

    ControlUnit(ControlUnit* cu){
        clock=cu->clock;
    }

    // getter/setter
    float getClock() { return clock; }
    void setClock(float nu) { clock = nu; }


};




// cpu class
class CPU
{
protected:
    ALU alu;
    ControlUnit cu;

public:
    // defaulyt constructor
    CPU() {}

    // overload
    CPU(ALU &ALUobject, ControlUnit &CUobject) : alu(ALUobject), cu(CUobject) {}


    CPU(ALU *ALUobject, ControlUnit *CUobject) : alu(ALUobject), cu(CUobject) {}

    // set
    void setALU(ALU &aluObj) { alu = aluObj; }
    void setCU(ControlUnit &cuObj) { cu = cuObj; }

    // get
    ALU getALU() { return alu; }
    ControlUnit getCU() { return cu; }
};








class Intel : public CPU
{
private:
    string brand;

public:
    // default constructor
    Intel() : CPU() {}

    // overload
    Intel( string thebrand, ALU ALUobject, ControlUnit CUobject) : brand("intel"), CPU(ALUobject, CUobject) {}

    // set
    void setBrand(string newBrand) { brand = newBrand; }

    // get
    string getBrand() { return brand; }
};



class ARM : public CPU
{
private:
    string brand;

public:
    // default constructor
    ARM() : CPU() {}

    // overload
    ARM(string thebrand,  ALU ALUobject, ControlUnit CUobject) : brand("arm"), CPU(ALUobject, CUobject) {}

    // set
    void setBrand(string newBrand) { brand = newBrand; }

    // get
    string getBrand() { return brand; }
};













// mainmemory class , going to be the ram
class MainMemory
{
private:
    int capacity;
    string technologyType;

public:
    // def
    MainMemory() : capacity(0), technologyType("Semiconductor") {}

    // overloaded
    MainMemory(int cap, string tech) : capacity(cap), technologyType(tech) {}

    // get
    int getCapacity() { return capacity; }
    string getTechnologyType() { return technologyType; }

    // set
    void setCapacity(int value) { capacity = value; }
    void setTechnologyType(string &value) { technologyType = value; }

    void displaySpecs(){
        cout<<"Capacity: "<<capacity<<endl;
        cout<<"Type: "<<technologyType<<endl;
    }
};



// port
class Port
{
private:
    string type;
    int baud_rate;

public:
    // def
    Port() : baud_rate(0), type("emptyport") {}

    // overload
    Port(string typeName, int baud) : type(typeName), baud_rate(baud) {}

    // get
    string getType() { return type; }
    int getBaudRate() { return baud_rate; }

    // set
    void setBaudRate(int value) { baud_rate = value; }
    void setType(string value) { type = value; }
};



// MotherBoard Class
class MotherBoard
{
private:
    MainMemory *mm;
    Port *PortsArray;
    int NumOfPorts;

public:
    // def
    MotherBoard() : mm(nullptr), PortsArray(nullptr), NumOfPorts(0) {}

    // overloaded
    MotherBoard(MainMemory *memory, Port *nameofports, int portamount)
    {
        mm = memory;
        NumOfPorts = portamount;
        PortsArray = new Port[NumOfPorts];

        for (int i = 0; i < NumOfPorts; i++)
        {
            PortsArray[i] = nameofports[i];
        }
    }

    ~MotherBoard()
    {
        delete mm;
        delete[] PortsArray;
    }

    // Getters and Setters
    MainMemory *getMainMemory() { return mm; }
    Port *getPortsArray() { return PortsArray; }
    int getNumofPorts() { return NumOfPorts; }


    void setNumofPorts(int num) { NumOfPorts = num; }

    void setMainMemory(MainMemory* memory) { 
        if (mm!=nullptr)
            delete mm;

        mm = memory; 
        }

    void setPortsArray(Port *portList, int num) { 

        delete [] PortsArray;
        NumOfPorts=num;
        PortsArray = new Port[NumOfPorts];
        
        for (int i =0; i<NumOfPorts;i++)
        PortsArray[i] = portList[i];
        }

    void displaySpecs(){
         for (int i =0; i<NumOfPorts;i++)
        cout<<"port type "<<PortsArray[i].getType()<<endl ;
        
    }

};



// physical memeory 
class PhysicalMemory
{
private:
    int capacity;

public:
    //def
    PhysicalMemory() : capacity(0) {}

   
    PhysicalMemory(int c) : capacity(c) {}

    
    int getCapacity()  { return capacity; }
    void setCapacity(int n) { capacity = n; }
};



// Computer Class
class Computer {
private:
    PhysicalMemory* pm;
    MotherBoard* mb;  
    CPU* cpu;

public:
    
    Computer() : pm(nullptr), mb(nullptr), cpu(nullptr) {}

   
    Computer(PhysicalMemory* mem, MotherBoard* mobo , CPU* chip)
        : pm(mem), mb(mobo), cpu(chip) {}

    
    // ~Computer() {
    //     delete pm;  
    //     delete mb;  
    //     delete cpu;  
    // }

    
    PhysicalMemory* getPhysicalMemory() const { return pm; }
    MotherBoard* getMotherBoard() const { return mb; }
    CPU* getCPU() const { return cpu; }




    void setMotherBoard(MotherBoard* mobo) {
        if (mb) delete mb;  
        mb = mobo;
    }

    void setPhysicalMemory(PhysicalMemory* memory) {
        if (pm) delete pm;  
        pm = memory;
    }

    void setCPU(CPU* chip) {
        if (cpu) delete cpu;  
        cpu = chip;
    }
};


// GraphicsCard Class
class GraphicsCard
{
private:
    string brand;
    int memorySize;
    double price;

public:
    
    GraphicsCard() : brand(""), memorySize(0), price(0.0) {}

   
    GraphicsCard(string name, int s, double money) : brand(name), memorySize(s), price(money) {}

    

    double getPrice()  { return price; }
    string getBrand()  { return brand; }
    int getMemorySize() { return memorySize; }
    
    
    void setBrand(string name) { brand = name; }
    void setMemorySize(int size) { memorySize = size; }
    void setPrice(double cost) { price = cost; }

    void displaySpecs(){
        cout<<"Brand: "<<brand<<endl;
        cout<<"Memory: "<<memorySize<<"GB"<<endl;
        cout<<"Price: "<<price<<endl;
    }
};


// StorageDevice Class
class StorageDevice
{
private:
    string type;
    int capacity;
    double price;

public:
    
    StorageDevice() : type (""), capacity(0), price(0.0) {}

   
    StorageDevice(string name,  int c, double p) : type(name), capacity(c), price(p) {}


   
    string getType()  { return type; }
    int getCapacity(){ return capacity; }
    double getPrice()  { return price; }


    void setCapacity(int num) { capacity = num; }
    void setPrice(double costs) { price = costs; }
    void setType(string name) { type = name; }

    void displaySpecs(){
        cout<<"Type: "<<type<<endl;
        cout<<"Capacity: "<<capacity<<endl;
        cout<<"Price: "<<price<<endl;
    }
};




// network 

class NetworkCard {
private:
    string type;
    int speed;
    double price;

public:
    
    NetworkCard() : type(""), speed(0), price(0.0) {}

    
    NetworkCard(string name, int s, double p) : type(name), speed(s), price(p) {}

   
    int getSpeed() const { return speed; }
    string getType()  { return type; }
    double getPrice() const { return price; }



    void setType(string t) { type = t; }
    void setSpeed(int s) { speed = s; }
    void setPrice(double p) { price = p; }

    void displaySpecs(){
        cout<<"Type: "<<type<<endl;
        cout<<"NetSpeec: "<<speed<<endl;
        cout<<"Price: "<<price<<endl;
    }
};


// power suply
class PowerSupply {
private:
    int wattage;
   string efficiencyRating;
    double price;

public:
    
    PowerSupply() : wattage(0), efficiencyRating(""), price(0.0) {}

   
    PowerSupply(int watts, string rating, double cost) : wattage(watts), efficiencyRating(rating), price(cost ) {}

  
    int getWattage()  { return wattage; }
    string getEfficiencyRating() { return efficiencyRating; }
    double getPrice() { return price; }


    void setEfficiencyRating(string rate) { efficiencyRating = rate; }
    void setPrice(double cost) { price = cost; }
    void setWattage(int elctr) { wattage = elctr; }

    void displaySpecs(){
        cout<<"Watts: "<<wattage<<endl;
        cout<<"Efficiency: "<<efficiencyRating<<endl;
        cout<<"Price: "<<price<<endl;
    }

};



// battery
class Battery {
private:
    int capacity;

public:
  
    Battery() : capacity(0) {}


    Battery(int charge) : capacity(charge) {}

    
    int getCapacity() { return capacity; }
    void setCapacity(int num) { capacity = num; }

    void displaySpecs(){
        cout<<"Capacity: "<<capacity<<endl;
        
    }
};



// case
class Case {
private:
    string formFactor;
    string color;
    double price; //only for pc/computer, not for laptop or tablet 

public:
    
    Case() : formFactor(""), color(""), price(0.0) {}

    Case(string type , string c, double cost) : formFactor(type), color(c), price(cost) {}

   


    string getFormFactor()  { return formFactor; }
    double getPrice() { return price; }
    string getColor()  { return color; }


    void setColor(string col) { color = col; }
    void setFormFactor(string typ) { formFactor = typ; }
    void setPrice(double pr) { price = pr; }

    void displaySpecs(){
        cout<<"Form: "<<formFactor<<endl;
        cout<<"Color: "<<color<<endl;
        cout<<"Price: "<<price<<endl;
    }
};




//=============================================


//main master class fo the assembly of the elctronic computer/device 

class ComputerAssembly {
private:

    double totalPrice;

    CPU* cpu;
    PhysicalMemory* pm; 
    MainMemory* mm;    
    MotherBoard* mb;

    StorageDevice* storageDevice;
    NetworkCard* networkCard;
    GraphicsCard* graphicsCard;
    PowerSupply* powerSupply;

    Battery* battery;   // for laptop, tablet
    Case* computerCase; // for computer/PC cases

public:
   
  // default 

    ComputerAssembly() 
        
          {

            cpu= nullptr;
            mb= nullptr; 
            pm= nullptr;  
            mm= nullptr; 
            graphicsCard= nullptr; 
            storageDevice= nullptr; 
            networkCard= nullptr; 
            powerSupply= nullptr; 
            battery= nullptr; 
            computerCase= nullptr;  
            totalPrice =0.0; 


          }

    // overload
    ComputerAssembly(CPU* chip, MotherBoard* mobo, PhysicalMemory* phymem, MainMemory* ram, GraphicsCard* gpu, StorageDevice* ssd, 
    NetworkCard* netcard, PowerSupply* pwrsply, Battery* b, Case* c, double cost)
{
         cpu=chip, mb=mobo, pm=phymem, mm=ram, graphicsCard=gpu, storageDevice=ssd, networkCard=netcard;
         powerSupply=pwrsply, battery=b, computerCase=c, totalPrice=cost; 

}

    
    
    // destruct
    ~ComputerAssembly() {
        delete cpu;
        delete mb;
        delete pm; 
        delete mm; 
        delete graphicsCard;
        delete storageDevice;
        delete networkCard;
        delete powerSupply;
        delete battery;
        delete computerCase;
    }


    // get/set
    CPU* getCPU()  { return cpu; }
    void setCPU(CPU* c) { cpu = c; }


    MotherBoard* getMotherBoard() { return mb; }
    void setMotherBoard(MotherBoard* mobo) { mb = mobo; }


    PhysicalMemory* getPhysicalMemory() { return pm; } 
    void setPhysicalMemory(PhysicalMemory* phymem) { pm = phymem; } 


    MainMemory* getMainMemory() { return mm; } 
    void setMainMemory(MainMemory* ram) { mm = ram; } 


    GraphicsCard* getGraphicsCard(){ return graphicsCard; }
    void setGraphicsCard(GraphicsCard* gpu) { graphicsCard = gpu; }


    StorageDevice* getStorageDevice()  { return storageDevice; }
    void setStorageDevice(StorageDevice* ssd) { storageDevice = ssd; }


    NetworkCard* getNetworkCard()  { return networkCard; }
    void setNetworkCard(NetworkCard* net) { networkCard = net; }


    PowerSupply* getPowerSupply() { return powerSupply; }
    void setPowerSupply(PowerSupply* power) { powerSupply = power; }


    Battery* getBattery()  { return battery; }
    void setBattery(Battery* b) { battery = b; }


    Case* getComputerCase(){ return computerCase; }
    void setComputerCase(Case* c) { computerCase = c; }


    double getTotalPrice()  { return totalPrice; }
    void setTotalPrice(double price) { totalPrice = price; }


    void displaySpecifications(string type) {
        cout << "\nComputer Specifications:\n";
        cout << "CPU----------"<<endl;
        if (type=="mac")
        cout<<"ARM architecture"<<endl;
        else
        cout<<"x64 architecture"<<endl;
        cpu->getALU().displaySpecs();

        cout << "Clock Speed: " << cpu->getCU().getClock() * 1000 << " MHz\n";
        cout << "Main Memory----------\n";
        mb->getMainMemory()->displaySpecs();
        cout<<"MotherBoard----------"<<endl;
        cout << "Number of Ports: " << mb->getNumofPorts() << endl; mb->displaySpecs();


        cout << "Graphics Card----------\n";
        graphicsCard->displaySpecs();
        cout << "Network Card----------\n";
        networkCard->displaySpecs();
        cout << "Storage Device----------\n";
        storageDevice->displaySpecs();
        cout << "Power Supply----------\n";
        powerSupply->displaySpecs();
        cout << "Battery ----------\n";
        battery->displaySpecs();
        cout << "Case ----------\n";
        computerCase->displaySpecs();
        cout << "Total Price: $" << totalPrice << endl;
    }


};









