//taaha zaman csf 22i1377 maam marium   ariyan chaudry


#include <iostream>
#include <string>
#include "q1.h"
using namespace std;





int main() {
    string type;
    
    while (true) {
        cout<<endl<<endl<<endl<<endl;
        cout << "Enter the type of computer (PC/Mac/Tablet/Laptop): ";
        cin >> type;

        if (type != "pc" && type != "mac" && type != "tablet" && type != "laptop") {
            cout << "Invalid input. Please enter PC, Mac, Tablet, or Laptop." << endl;
            continue;
        }

        break;
    }
    
    


int adders=10, subtractors=10, registers=10, sizeOfRegisters=10, clock=1000;
    int mmCapacity, storageCapacity, networkSpeed=10, wattage, batteryCapacity, noOfPorts;
    double graphicsMemorySize, storagePrice=10, networkPrice=10, powerPrice=10, casePrice=100;

   

    while (true) {
    cout << "Enter main memory capacity (GB): ";
    cin >> mmCapacity;

    cout << "Enter graphics memory size (GB): ";
    cin >> graphicsMemorySize;

    cout << "Enter storage capacity (GB): ";
    cin >> storageCapacity;

    cout<<"Enter number of Ports: ";
    cin>>noOfPorts;


    cout << "Enter power supply wattage (W): ";
    cin >> wattage;

    cout << "Enter battery capacity (mAh): ";
    cin >> batteryCapacity;



    if (mmCapacity<0||graphicsMemorySize<0||storageCapacity<0||noOfPorts<0||networkSpeed<0||wattage<0||
        batteryCapacity<0||storagePrice<0||networkPrice<0||powerPrice<0||casePrice<0){
            continue;
        }
        break;
    }


    Port* array;
    array = new Port[noOfPorts];

    for (int i = 0; i < noOfPorts; ++i) {
        string name; int baud;
        cout << "enter port name " << i + 1 << ": ";
        cin >> name;
        cout << "enter baud: ";
        cin >> baud;
        array[i] = Port(name, baud);
    }


    string armstructure = "ARM";
    string intelstructure="INTEL";

    CPU* cpu = new CPU(new ALU(adders, subtractors, registers, sizeOfRegisters), new ControlUnit(static_cast<float>(clock) / 1000.0));


    ARM * armchip = new ARM(armstructure, ALU(adders, subtractors, registers, sizeOfRegisters), ControlUnit(static_cast<float>(clock) / 1000.0));
    Intel * intelchip = new Intel(intelstructure, ALU(adders, subtractors, registers, sizeOfRegisters), ControlUnit(static_cast<float>(clock) / 1000.0));


    

     MotherBoard* mb = new MotherBoard;

if (type =="mac"){
   
    mb->setMainMemory(new MainMemory(mmCapacity, "LPDDR5"));
    mb->setNumofPorts(noOfPorts);
    mb->setPortsArray(array,noOfPorts);
}

else 
{
    
    mb->setMainMemory(new MainMemory(mmCapacity, "DDR5"));
    mb->setNumofPorts(noOfPorts);
    mb->setPortsArray(array,noOfPorts);
}



    PhysicalMemory* pm = new PhysicalMemory(mmCapacity+storageCapacity);
    MainMemory* mm = new MainMemory(mmCapacity, "Semiconductor");



GraphicsCard* graphicsCard;

if (type == "mac"){
    graphicsCard = new GraphicsCard("Integrated", static_cast<int>(graphicsMemorySize), graphicsMemorySize * 10.0);
}
else 
   graphicsCard = new GraphicsCard("Dedicated", static_cast<int>(graphicsMemorySize), graphicsMemorySize * 10.0);






    NetworkCard* networkCard = new NetworkCard("Wi-Fi", networkSpeed, networkPrice);

    StorageDevice* storageDevice = new StorageDevice("SSD", storageCapacity, storagePrice);

    Battery* battery = new Battery(batteryCapacity);

    Case* computerCase = (type == "laptop" || type == "tablet"|| type=="mac") ? new Case("mobile computer", "Silver", 0.0) : new Case("ATX", "Black", casePrice);

 PowerSupply* powerSupply;

if(type=="pc"){
   powerSupply = new PowerSupply(wattage, "80+ Gold", powerPrice);
}

else {

 powerSupply = new PowerSupply(wattage, "standard", powerPrice);
}
 



    double totalPrice = 0.0;

    // Calculate total price
    totalPrice += adders ;
    totalPrice += subtractors ;
    totalPrice += registers ;
    totalPrice += sizeOfRegisters ;
    totalPrice += clock ;

    totalPrice += mmCapacity * 10;
    totalPrice += graphicsMemorySize * 10;
    totalPrice += storageCapacity * 10;
    totalPrice += networkSpeed * 0.1;
    totalPrice += wattage * 0.1;
    totalPrice += batteryCapacity * 0.1;
    totalPrice += storagePrice;
    totalPrice += networkPrice;
    totalPrice += powerPrice;
    totalPrice += casePrice;

    // Create ComputerAssembly object
    ComputerAssembly* computer;


    if (type=="mac"){
    computer = new ComputerAssembly(armchip, mb, pm, mm, graphicsCard, storageDevice, networkCard, powerSupply, battery, computerCase, totalPrice);
    }
    else 
    {
     computer = new ComputerAssembly(intelchip, mb, pm, mm, graphicsCard, storageDevice, networkCard, powerSupply, battery, computerCase, totalPrice);

    }

    // Display specifications
    cout<<endl<<endl<<endl;
    computer->displaySpecifications(type);
    cout << "Type of electronic device is: " << type << endl;
    



    // Cleanup
    delete [] array;
    delete cpu;
    delete mb;
    delete pm;
    delete mm;
    delete graphicsCard;
    delete storageDevice;
    delete networkCard;
    delete powerSupply;
    delete battery;
    delete computerCase;
    delete computer;


    return 0;
}


