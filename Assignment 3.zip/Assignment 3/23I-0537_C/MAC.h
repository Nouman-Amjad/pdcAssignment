#pragma once

#include "ComputerAssembly.h"
#include "AppleSilicon.h"

class MAC : public ComputerAssembly
{

protected:                         // data members
	AppleSilicon* Chip;
public:                           // members functions
	MAC();
	MAC(const AppleSilicon& chip);
	void setChip(const AppleSilicon& chip);
	AppleSilicon getChip();
	~MAC();
};

