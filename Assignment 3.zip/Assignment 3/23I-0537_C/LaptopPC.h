#pragma once

#include "general.h"
#include "PC.h"
#include"Battery.h"

class LaptopPC:public PC
{
protected:                            // data members
	Battery* battery;
public:
	LaptopPC();                                 // member functions
	LaptopPC(const Battery& battery);
	void setBattery(Battery& battery);
	Battery getBattery() const;
	~LaptopPC();
};

