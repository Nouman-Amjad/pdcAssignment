#ifndef GRAPHICSCARD_H
#define GRAPHICSCARD_H

#include"general.h"

class GraphicsCard
{
protected:                    // data memebers
    string brand;
    int memorySize;
    double price;

public:                              // memeber functions
    GraphicsCard();
    GraphicsCard(string brand, int memorySize, double price);
    string getBrand() const;
    void setBrand(string brand);
    int getMemorySize() const;
    void setMemorySize(int size);
    double getPrice() const;
    void setPrice(double price);

};

#endif
