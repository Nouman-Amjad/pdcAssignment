#ifndef POWERSUPPLY_H
#define POWERSUPPLY_H

#include "general.h"

class PowerSupply 
{                                             // data members
protected:
    int wattage;
    string efficiencyRating;
    double price;

public:                                    // member functions
    PowerSupply();
    PowerSupply(int wattage, string efficiencyRating, double price);
    int getWattage() const;
    void setWattage(int wattage);
    string getEfficiencyRating() const;
    void setEfficiencyRating(string efficiencyRating);
    double getPrice() const;
    void setPrice(double price);
};

#endif 