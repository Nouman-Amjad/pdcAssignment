#ifndef NETWORKCARD_H
#define NETWORKCARD_H

#include "general.h"

class NetworkCard
{
protected:          // data members 
    
    string type;
    int speed;
    double price;

public:                        // member functions
    NetworkCard();
    NetworkCard(string type, int speed, double price);
    string getType() const;
    void setType(string type);
    int getSpeed() const;
    void setSpeed(int speed);
    double getPrice() const;
    void setPrice(double price);
};

#endif 
