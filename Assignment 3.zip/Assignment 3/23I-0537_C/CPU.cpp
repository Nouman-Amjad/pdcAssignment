#include "CPU.h"

CPU::CPU()                // default constructor
{

}

CPU::CPU(const ALU& a, const ControlUnit& c)          // parameterized constructor
{
    this->alu = a;
    this->cu = c;
}

const ALU& CPU::getALU() const                   // getters and setters
{
    return this->alu;
}

void CPU::setALU(const ALU& a)
{
    this->alu = a;
}

const ControlUnit& CPU::getCU() const
{
    return this->cu;
}

void CPU::setCU(const ControlUnit& c) 
{
    this->cu = c;
}