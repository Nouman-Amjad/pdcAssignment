#include "DesktopMac.h"


DesktopMac::DesktopMac()     // default constructor
{
	this->c = new Case;
	this->powerSupply = new PowerSupply;
}

DesktopMac::DesktopMac(const PowerSupply& power, const Case& c)        // parameterized constreuctor
{
	this->c = new Case(c);
	this->powerSupply = new PowerSupply(power);
}
//                                                                  getters and setters
PowerSupply DesktopMac::getPowerSupply() const
{
    return *(this->powerSupply);
}

Case DesktopMac::getCase() const
{
    return *(this->c);
}

void DesktopMac::setPowerSupply(const PowerSupply& ps)
{
    if (this->powerSupply == nullptr)
        this->powerSupply = new PowerSupply(ps);
    else
    {
        delete this->powerSupply;
        this->powerSupply = new PowerSupply(ps);
    }
}

void DesktopMac::setCase(const Case& newC)
{
    if (this->c == nullptr)
        this->c = new Case(newC);
    else
    {
        delete this->c;
        this->c = new Case(newC);
    }
}

DesktopMac::~DesktopMac()          // destructor
{
	delete this->c;
	delete this->powerSupply;
}