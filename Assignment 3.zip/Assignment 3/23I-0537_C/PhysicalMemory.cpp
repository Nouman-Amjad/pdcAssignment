#include "PhysicalMemory.h"

PhysicalMemory::PhysicalMemory()      // deafult constructor
{
    this->capacity = 0;
}

PhysicalMemory::PhysicalMemory(int cap)           // parameterized copnstructor
{
    this->capacity = cap;
}

int PhysicalMemory::getCapacity() const         // getters and setters
{
    return this->capacity;
}

void PhysicalMemory::setCapacity(int cap) 
{
    this->capacity = cap;

}