#ifndef ALU_H
#define ALU_H

#include "general.h"

class ALU
{
protected:            // data memebers

	int NoOfAdders;
	int NoOfSubtractor;
	int NoOfRegisters;
	int sizeOfRegisters;

public:     // memeber functions

    ALU();
    ALU(int adders, int subtractors, int registers, int regSize);
    int getNoOfAdders() const;
    void setNoOfAdders(int adders);
    int getNoOfSubtractors() const;
    void setNoOfSubtractors(int subtractors);
    int getNoOfRegisters() const;
    void setNoOfRegisters(int registers);
    int getSizeOfRegisters() const;
    void setSizeOfRegisters(int regSize);
};

#endif