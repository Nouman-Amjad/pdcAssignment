#include "AppleSilicon.h"
 
AppleSilicon::AppleSilicon()          // default constructor
{
                     
}

AppleSilicon::AppleSilicon(CPU& cpu, GraphicsCard& gpu) : CPU(cpu), AppleGPU(gpu)
{
          // parameterized constructor
}

GraphicsCard AppleSilicon::getGPU() const      // getter
{
    return this->AppleGPU;
}

void AppleSilicon::setGPU(GraphicsCard& gpu)   // setter
{
    this->AppleGPU = gpu;
}