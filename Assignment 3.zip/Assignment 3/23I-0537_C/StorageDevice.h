#ifndef STORAGEDEVICE_H
#define STORAGEDEVICE_H

#include"general.h"

class StorageDevice
{
protected:          // data members 
    string type;
    int capacity;
    double price;

public:                          // member functions
    StorageDevice();
    StorageDevice(string type, int capacity, double price);
    string getType() const;
    void setType(string type);
    int getCapacity() const;
    void setCapacity(int capacity);
    double getPrice() const;
    void setPrice(double price);
};

#endif