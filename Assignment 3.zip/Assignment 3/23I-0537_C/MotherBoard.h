#ifndef MOTHERBOARD_H
#define MOTHERBOARD_H

#include "MainMemory.h"
#include "Port.h"

class MotherBoard
{
protected:              // data members
    MainMemory *mm;
    Port *ports; 

public:                      // member functions
    int portCount;
    MotherBoard();
    MotherBoard( MainMemory& memory, int portCount);
    MainMemory getMainMemory() const;
    void setMainMemory(const MainMemory& memory);
    Port getPorts(int portNo) const;
    void setPorts(Port p, int portNo);
    ~MotherBoard();
};

#endif