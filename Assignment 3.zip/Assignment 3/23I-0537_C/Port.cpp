#include "Port.h"

Port::Port()                   // default constructor
{
    this->baud_rate = 0;
    this->type = "";
}

Port::Port(string type, int baudRate)       // parameterized constructor
{
    this->baud_rate = baudRate;
    this->type = type;
}

string Port::getType() const              // getters and setters
{
    return this->type;
}

void Port::setType(string type) 
{
    this->type = type;
}

int Port::getBaudRate() const 
{
    return this->baud_rate;
}

void Port::setBaudRate(int baud) 
{
    this->baud_rate = baud;
}