#include "ALU.h"

ALU::ALU()                            // default constructor
{
	this->NoOfAdders = 0;
	this->NoOfSubtractor = 0;
	this->NoOfRegisters = 0;
	this->sizeOfRegisters = 0;
}

ALU::ALU(int adders, int subtractors, int registers, int regSize)             // parameteried constructor
{

	this->NoOfAdders = adders;
	this->NoOfSubtractor = subtractors;
	this->NoOfRegisters = registers;
	this->sizeOfRegisters = regSize;
}
                                           // getters and setters
int ALU::getNoOfAdders() const
{
	return this->NoOfAdders;
}

void ALU::setNoOfAdders(int adders)
{
	this->NoOfAdders = adders;
}

int ALU::getNoOfSubtractors() const
{
	return this->NoOfSubtractor;
}

void ALU::setNoOfSubtractors(int subtractors)
{
	this->NoOfSubtractor;
}

int ALU::getNoOfRegisters() const
{
	return this->NoOfRegisters;
}

void ALU::setNoOfRegisters(int registers)
{
	this->NoOfRegisters = registers;
}

int ALU::getSizeOfRegisters() const
{
	return this->sizeOfRegisters;
}

void ALU::setSizeOfRegisters(int regSize)
{
	this->sizeOfRegisters = regSize;
}

