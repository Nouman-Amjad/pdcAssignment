#include "Battery.h"

Battery::Battery()                       // default constructor
{
    this->capacity = 0;
}

Battery::Battery(int cap)              // parameterized constructor
{
    this->capacity = cap;
}
                                               // getters and setters
int Battery::getCapacity() const
{
    return this->capacity;
}

void Battery::setCapacity(int cap)
{
    this->capacity = cap;
}