#include "Case.h"

Case::Case()                        // default constructor
{
    this->color = "";
    this->formFactor = "";
    this->price = 0;
}

Case::Case(string ff, string c, double p)        // parameterized constructor
{
    this->color = c;
    this->formFactor = ff;
    this->price = p;
}
                                                  // getters and setters
string Case::getFormFactor() const
{
    return this->formFactor;
}

void Case::setFormFactor(string ff) 
{
    this->formFactor = ff;
}

string Case::getColor() const 
{
    return this->color;
}

void Case::setColor(string c) 
{
    this->color = c;
}

double Case::getPrice() const 
{
    return this->price;
}

void Case::setPrice(double p) 
{
    this->price = p;
}