#include "DesktopPC.h"


DesktopPC::DesktopPC()          // default constructor
{ 
    this->c = new Case;
    this->powerSupply = new PowerSupply;
}

DesktopPC::DesktopPC(const PowerSupply& power, const Case& c)   // parameterized constructor
{
    this->c = new Case(c);
    this->powerSupply = new PowerSupply(power);
}
                                                               // getters and setters
PowerSupply DesktopPC::getPowerSupply() const 
{
    return *(this->powerSupply);
}

Case DesktopPC::getCase() const 
{
    return *(this->c);
}

void DesktopPC::setPowerSupply(const PowerSupply& ps) 
{
    if (this->powerSupply==nullptr)
     this->powerSupply = new PowerSupply(ps);
    else
    {
        delete this->powerSupply;
        this->powerSupply = new PowerSupply(ps);
    }
}

void DesktopPC::setCase(const Case& newC) 
{
    if (this->c == nullptr)
        this->c = new Case(newC);
    else 
    {
        delete this->c;
        this->c = new Case(newC);
    }
}

DesktopPC::~DesktopPC()              // destructor
{
    delete this->c;
    delete this->powerSupply;
}