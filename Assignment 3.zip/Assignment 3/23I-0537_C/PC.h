#ifndef PC_H
#define PC_H

#include "Intel_AMD.h"
#include "ComputerAssembly.h"

class PC : public ComputerAssembly
{
protected:                    // data members
    Intel_AMD* Chip;
public:                     // member functions
    PC();
    PC(const Intel_AMD& chip);
    void setChip(const Intel_AMD& chip);
    Intel_AMD getChip() const;
    ~PC();
};

#endif
