#include"general.h"
class Port
{
protected:              // data members
    string type;
    int baud_rate;

public:                    // member functions
    Port();
    Port(string type, int baud);
    string getType() const;
    void setType(string type);
    int getBaudRate() const;
    void setBaudRate(int baudrate);
};

