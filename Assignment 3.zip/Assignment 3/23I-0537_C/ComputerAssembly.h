#ifndef COMPUTERASSEMBLY_H
#define COMPUTERASSEMBLY_H

#include "Computer.h"
#include "StorageDevice.h"
#include "NetworkCard.h"

class ComputerAssembly  
{
protected:                                  // data members
    Computer* computer;
    StorageDevice* Storage;
    NetworkCard* NC;
    double totalPrice;

public:                             // memeber functions
    ComputerAssembly();
    ComputerAssembly(Computer& comp, StorageDevice& sd, NetworkCard& nc, double price=0);
    Computer getComputer() const;
    void setComputer(Computer& comp);
    NetworkCard getNetworkCard() const;
    void setNetworkCard(NetworkCard& nc);
    StorageDevice getStorageDevice() const;
    void setStorageDevice(StorageDevice& sd);
    double getTotalPrice() const;
    void setTotalPrice(double price);
    ~ComputerAssembly();
};

#endif 
