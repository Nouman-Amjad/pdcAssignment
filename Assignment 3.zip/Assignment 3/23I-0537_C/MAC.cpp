#include "MAC.h"

MAC::MAC()                                     // default constructor
{
	this->Chip = new AppleSilicon;
	this->computer->setCPU(*Chip);
}
 
MAC::MAC(const AppleSilicon &chip)                   // parameterized constructor
{
	this->Chip = new AppleSilicon(chip);
	this->computer->setCPU(*Chip);

}
                                                            // getters and setters
void MAC::setChip(const AppleSilicon& chip)
{
	if (this->Chip == nullptr)
	{
		this->Chip = new AppleSilicon(chip);
		this->computer->setCPU(*Chip);
	}
	else
	{
		delete Chip;
		this->Chip = new AppleSilicon(chip);
		this->computer->setCPU(*Chip);
	}
}

AppleSilicon MAC::getChip()
{
	return *(this->Chip);
}

MAC::~MAC()
{                                      // destructor 
	delete this->Chip;
}