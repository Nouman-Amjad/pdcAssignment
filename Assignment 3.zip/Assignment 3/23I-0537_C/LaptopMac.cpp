#include "LaptopMac.h"

LaptopMac::LaptopMac()              // default constructor
{
	this->battery = new Battery;
}

LaptopMac::LaptopMac(const Battery& battery)            // parameterized constructor
{
	this->battery = new Battery(battery);
}

void LaptopMac::setBattery(Battery& battery)               //  setters and getters
{
    if (this->battery == nullptr)
        this->battery = new Battery(battery);
    else
    {
        delete this->battery;
        this->battery = new Battery(battery);
    }
}

Battery LaptopMac::getBattery() const
{
    return *(this->battery);
}

LaptopMac::~LaptopMac()           // destructors
{
	delete this->battery;
}