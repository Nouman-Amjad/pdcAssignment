#ifndef COMPUTER_H
#define COMPUTER_H

#include "PhysicalMemory.h"
#include "CPU.h"
#include "MotherBoard.h"

class Computer 
{
protected:                          // data members
    PhysicalMemory *pm;
    CPU *cpu;
    MotherBoard *mb;

public:                                    // memeber functions
    Computer();
    Computer(PhysicalMemory& memory, CPU& processor, MotherBoard& motherboard);
    PhysicalMemory getPhysicalMemory() const;
    void setPhysicalMemory(const PhysicalMemory& memory);
    CPU getCPU() const;
    void setCPU(const CPU& processor);
    MotherBoard getMotherBoard() const;
    void setMotherBoard(const MotherBoard& motherboard);
    ~Computer();
};

#endif 