//Name : MAHAD MALIK
//Student Id : 23I-0537
//Section : BSCS-C
//Instructor Name : MR. SHERYAR RASHID
//TA Name : MUHAMMAD ABDUR RAFAY

#include "DesktopMac.h"
#include "DesktopPC.h"
#include "LaptopMac.h"
#include "LaptopPC.h"

int main()
{
    int adders, subtractors, registers, regSize; // Taking Input for ALU

    do                                                             // loop for validation
    {
        cout << "Enter the number of adders: ";
        cin >> adders;
        if (adders < 0) 
        {
            cout << "Invalid input. Please enter a non-negative integer.\n";
            cin >> adders;
        }
    } while (adders < 0);

    do 
    {
        cout << "Enter the number of subtractors: ";
        cin >> subtractors;
        if (subtractors < 0) 
        {
            cout << "Invalid input. Please enter a non-negative integer.\n";
            cin >> subtractors;
        }
    } while (subtractors < 0);

    do {
        cout << "Enter the number of registers: ";
        cin >> registers;
        if (registers < 0)
        {
            cout << "Invalid input. Please enter a non-negative integer.\n";
            cin >> registers;
        }
    } while (registers < 0);

    do {
        cout << "Enter the size of registers: ";
        cin >> regSize;
        if (regSize < 0)
        {
            cout << "Invalid input. Please enter a non-negative integer.\n";
            cin >> regSize;
        }
    } while (regSize < 0);

    ALU alu(adders, subtractors, registers, regSize);  // making ALU

    float clockValue;

    do
    {
        cout << "Enter the clock value: ";
        cin >> clockValue;
        if (clockValue < 0.0) 
        {
            cout << "Invalid input. Please enter a non-negative float.\n";
            cin >> clockValue;
        }
    } while (clockValue < 0);

    ControlUnit cu(clockValue);   // making cu

    int choice;
    cout << "\nWhat do you want to make : \n a) Press 1 for MAC\n b) Press 2 for PC\nEnter Choice :";
    while (choice != 1 || choice != 0)
    {
       cout << "Invalid input. Please enter the correct choice.\n";
       cin >> choice;
    }

    if (choice == 1)
    {
        string brand;
        int memorySize;
        double price;

        cout << "Enter the brand: ";
        cin>>brand;

        do {
            cout << "Enter the memory size: ";
            cin >> memorySize;
            if (memorySize < 0)
            {
                cout << "Invalid input. Please enter a non-negative integer.\n";
                cin >> memorySize;
            }
        } while (memorySize < 0);

        do {
            cout << "Enter the price: ";
            cin >> price;
            if (price < 0) {
                cout << "Invalid input. Please enter a non-negative float.\n";
                cin >> price;
            }
        } while (price < 0.0);

        // Creating APPLE GPU
        GraphicsCard AppleGPU(brand, memorySize, price);
        CPU Processor(alu, cu);
        AppleSilicon Processeor(Processor,AppleGPU);
    }


	return 0;
