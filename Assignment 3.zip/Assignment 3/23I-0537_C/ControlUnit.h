#ifndef CONTROLUNIT_H
#define CONTROLUNIT_H

class ControlUnit
{
protected:                   // data members

	float clock;

public:
	                                    // member functions
	ControlUnit();
	ControlUnit(float c);
	float getClock();
	void setClock(float c);
};

#endif
