#include "GraphicsCard.h"

GraphicsCard::GraphicsCard()       // default constructor
{
    this->brand = "";
    this->price = 0;
    this->memorySize = 0;
}

GraphicsCard::GraphicsCard(string b, int size, double p)      // parameterized constructor
{
    this->brand = b;
    this->price = size;
    this->memorySize = p;
}

string GraphicsCard::getBrand() const             // getters and setters
{
    return this->brand;
}

void GraphicsCard::setBrand(string b)
{
    this->brand = b;
}

int GraphicsCard::getMemorySize() const 
{
    return this->memorySize;
}

void GraphicsCard::setMemorySize(int size) 
{
    this->memorySize = size;
}

double GraphicsCard::getPrice() const 
{
    return this->price;
}

void GraphicsCard::setPrice(double p)
{
    this->price = p;
}