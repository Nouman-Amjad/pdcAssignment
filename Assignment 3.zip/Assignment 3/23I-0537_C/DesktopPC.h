#pragma once

#include "general.h"
#include "PC.h"
#include"Case.h"
#include"PowerSupply.h"

class DesktopPC:public PC
{
protected:                        // data members 
	Case* c;
	PowerSupply* powerSupply;
public:                             // member functions
	DesktopPC();
	DesktopPC(const PowerSupply& power, const Case& c);
	Case getCase() const;
	PowerSupply getPowerSupply() const;
	void setCase(const Case& newC);
	void setPowerSupply(const PowerSupply& ps);
	~DesktopPC();
};

