#include "ControlUnit.h"

ControlUnit::ControlUnit()   // default constructor
{
	this->clock = 0;
}

ControlUnit::ControlUnit(float c)        // parameterized constructor
{
	this->clock = c;
}
                                      // getters and setters
float ControlUnit::getClock()
{
	return this->clock;
}

void ControlUnit::setClock(float c)
{
	this->clock = c;
}