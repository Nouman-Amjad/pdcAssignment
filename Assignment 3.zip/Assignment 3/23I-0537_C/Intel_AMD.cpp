#include "Intel_AMD.h"

Intel_AMD::Intel_AMD()                      // defualt constructor
{
    this->GPU = nullptr;
}

Intel_AMD::Intel_AMD(CPU cpu, GraphicsCard gpu) : CPU(cpu), GPU(new GraphicsCard(gpu))    // parameterized constructor
{

}

GraphicsCard Intel_AMD::getGPU() const           // getters and setters
{
    return *(this->GPU);
}

void Intel_AMD::setGPU(GraphicsCard& gpu)
{
    if (this->GPU == nullptr)
        this->GPU = new GraphicsCard(gpu);
   else
   {
        delete this->GPU;
        this->GPU = new GraphicsCard(gpu);
   }
}

Intel_AMD::~Intel_AMD()        // destructor
{
    delete this->GPU;
}