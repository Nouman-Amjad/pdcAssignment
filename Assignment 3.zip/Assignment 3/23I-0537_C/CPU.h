#ifndef CPU_H
#define CPU_H

#include"ALU.h"
#include"ControlUnit.h"

class CPU
{
protected:                          // data members
	ALU alu;
	ControlUnit cu;

public:                               // memeber functions

    CPU();
    CPU(const ALU& alu, const ControlUnit& cu);
    const ALU& getALU() const;
    void setALU(const ALU& alu);
    const ControlUnit& getCU() const;
    void setCU(const ControlUnit& cu);

};

#endif
