#ifndef Intel_AMD_H
#define Intel_AMD_H

#include "CPU.h"
#include "GraphicsCard.h"

class Intel_AMD:public CPU
{
protected:                                // data members
	GraphicsCard* GPU;
public:                                   // member functions
	Intel_AMD();
	Intel_AMD(CPU cpu, GraphicsCard gpu);
	GraphicsCard getGPU() const;
	void setGPU(GraphicsCard& gpu);
	~Intel_AMD();
};

#endif