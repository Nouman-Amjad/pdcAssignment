#ifndef APPLESILICON_H
#define APPLESILICON_H

#include "CPU.h"
#include "GraphicsCard.h"

class AppleSilicon:public CPU
{
protected:                            // data members
	GraphicsCard AppleGPU;
public:                             // member functions
	AppleSilicon();
	AppleSilicon(CPU& cpu, GraphicsCard& gpu);
	GraphicsCard getGPU() const;
	void setGPU(GraphicsCard& gpu);
};

#endif
