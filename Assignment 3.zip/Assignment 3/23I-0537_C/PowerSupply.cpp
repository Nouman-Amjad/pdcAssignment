#include "PowerSupply.h"

PowerSupply::PowerSupply()                 // default constructor
{
    this->efficiencyRating = " ";
    this->price = 0;
    this->wattage = 0;
}

PowerSupply::PowerSupply(int w, string rating, double p)           // parameterized constructor
{
    this->efficiencyRating = rating;
    this->price = 0;
    this->wattage = 0;
}

int PowerSupply::getWattage() const              // getters amd setters
{
    return this->wattage;
}

void PowerSupply::setWattage(int w)
{
    this->wattage = w;
}

string PowerSupply::getEfficiencyRating() const
{
    return this->efficiencyRating;
}

void PowerSupply::setEfficiencyRating(string rating)
{
    this->efficiencyRating = rating;
}

double PowerSupply::getPrice() const
{
    return this->price;
}

void PowerSupply::setPrice(double p) 
{
    this->price = p;
}