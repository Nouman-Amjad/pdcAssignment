#ifndef CASE_H
#define CASE_H

#include "general.h"

class Case 
{
protected:             // data members
    string formFactor;
    string color;
    double price;

public:                      // member functions
    Case();
    Case(string formFactor, string color, double price);
    string getFormFactor() const;
    void setFormFactor(string formFactor);
    string getColor() const;
    void setColor(string color);
    double getPrice() const;
    void setPrice(double price);
};

#endif // CASE_H
