#include "StorageDevice.h"

StorageDevice::StorageDevice()      // deafult constructor
{
    this->capacity = 0;
    this->price = 0;
    this->type = "";
}

StorageDevice::StorageDevice(string t, int cap, double p)       // parameterized constructor
{
    this->capacity = cap;
    this->price = p;
    this->type = t;
}

string StorageDevice::getType() const              // getters and setters
{
    return this->type;
}

void StorageDevice::setType(string t) 
{
    this->type = t;
}

int StorageDevice::getCapacity() const
{
    return this->capacity;
}

void StorageDevice::setCapacity(int cap)
{
    this->capacity = cap;
}

double StorageDevice::getPrice() const
{
    return this->price;
}

void StorageDevice::setPrice(double p) 
{
    this->price = p;
}