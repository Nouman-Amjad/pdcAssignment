#include"general.h"

class MainMemory
{
protected:                  // data members
    int capacity;
    string technologyType;

public:                            // member functions
    MainMemory();
    MainMemory(int cap,string tech);
    int getCapacity() const;
    void setCapacity(int cap);
    string getTechnologyType() const;
    void setTechnologyType( string tech);
};

