#ifndef PHYSICALMEMORY_H
#define PHYSICALMEMORY_H

class PhysicalMemory 
{
protected:                    // data members
    int capacity;

public:                      //member functions
    PhysicalMemory();
    PhysicalMemory(int cap);
    int getCapacity() const;
    void setCapacity(int cap);
};

#endif 
