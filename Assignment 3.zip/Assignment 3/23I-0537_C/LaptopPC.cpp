#include "LaptopPC.h"

LaptopPC::LaptopPC() 
{
    this->battery = new Battery;              // default constructor

}

LaptopPC::LaptopPC(const Battery& battery)                        // parameterized constructor
{
    this->battery = new Battery(battery);
}

void LaptopPC::setBattery(Battery& battery)
{
    if (this->battery == nullptr)
        this->battery = new Battery(battery);
    else
    {
        delete this->battery;
        this->battery = new Battery(battery);
    }
}

Battery LaptopPC::getBattery() const
{
    return *(this->battery);
}

LaptopPC::~LaptopPC()                 // destructor
{
    delete this->battery;
}