#pragma once

#include "general.h"
#include "MAC.h"
#include "PowerSupply.h"
#include "Case.h"

class DesktopMac: public MAC
{

protected:                             // data members
	Case* c;
	PowerSupply* powerSupply;
public:                                   // member functions
	DesktopMac();
	DesktopMac(const PowerSupply& power, const Case& c);
	PowerSupply getPowerSupply() const;
	Case getCase() const;
	void setPowerSupply(const PowerSupply& ps);
	void setCase(const Case& newC);
	~DesktopMac();
};

