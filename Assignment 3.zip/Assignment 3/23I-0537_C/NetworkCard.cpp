#include "NetworkCard.h"

#include "NetworkCard.h"

NetworkCard::NetworkCard()                 // default constructor
{
    this->price = 0;
    this->speed = 0;
    this->type = "";
}

NetworkCard::NetworkCard(string t, int s, double p)             // parameterized constructor
{
    this->type = t;
    this->speed = 0;
    this->price = p;
}

string NetworkCard::getType() const       // getters and setters
{
    return this->type;
}

void NetworkCard::setType(string t) 
{
    this->type = t;
}

int NetworkCard::getSpeed() const 
{
    return this->speed;
}

void NetworkCard::setSpeed(int s) 
{
    this->speed = s;
}

double NetworkCard::getPrice() const
{
    return this->price;
}

void NetworkCard::setPrice(double p)
{
    this->price = p;
}
