#include "MotherBoard.h"

MotherBoard::MotherBoard()                 // deafult constructor
{
    this->mm = new MainMemory;
    this->ports = nullptr;
    this->portCount = 0;
}

MotherBoard::MotherBoard(MainMemory& memory, int portCount)                  // parameterized constructor
{
    this->portCount = portCount;
    this->mm = new MainMemory(memory);
    this->ports = new Port[portCount];
}

MainMemory MotherBoard::getMainMemory() const                       // getters and setters
{
    return *(this->mm);
}

void MotherBoard::setMainMemory(const MainMemory& memory)
{
    this->mm->setCapacity(memory.getCapacity());
    this->mm->setTechnologyType(memory.getTechnologyType());
}

Port MotherBoard::getPorts(int portNo) const 
{
    return this->ports[portNo];
}

void MotherBoard::setPorts( Port p, int portNo) 
{
    this->ports[portNo].setBaudRate(p.getBaudRate());
    this->ports[portNo].setType(p.getType());
}

MotherBoard::~MotherBoard()                // destructor
{
    delete this->mm;
    delete[] this->ports;
}