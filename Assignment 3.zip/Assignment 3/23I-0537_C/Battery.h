#ifndef BATTERY_H
#define BATTERY_H

class Battery 
{
protected:
    int capacity;          // data members

public:
    Battery();                    //  member functions
    Battery(int capacity);
    int getCapacity() const;
    void setCapacity(int capacity);
};

#endif 
