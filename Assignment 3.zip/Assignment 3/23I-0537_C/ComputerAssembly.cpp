#include "ComputerAssembly.h"

ComputerAssembly::ComputerAssembly()         // default constructor
{
    this->totalPrice = 0;
    this->NC = new NetworkCard;
    this->Storage = new StorageDevice;
    this->computer = new Computer;
}

ComputerAssembly::ComputerAssembly(Computer& comp, StorageDevice& sd, NetworkCard& nc, double price)  // parametrized constructor
{
    this->totalPrice = price;
    this->NC = new NetworkCard(nc);
    this->Storage = new StorageDevice(sd);
    this->computer = new Computer(comp);
}
//                                              getters and setters
Computer ComputerAssembly::getComputer() const 
{
    return *(this->computer);
}

void ComputerAssembly::setComputer( Computer& comp) 
{
    if (this->computer == nullptr)
        this->computer = new Computer(comp);
    else
    {
        delete this->computer;
        this->computer = new Computer(comp);
    }

}

double ComputerAssembly::getTotalPrice() const 
{
    return this->totalPrice;
}

void ComputerAssembly::setTotalPrice(double price) 
{
    this->totalPrice = price;
}

NetworkCard ComputerAssembly::getNetworkCard() const
{
    return *(this->NC);
}

void ComputerAssembly::setNetworkCard(NetworkCard& nc)
{
    if (this->NC == nullptr)
        this->NC = new NetworkCard(nc);
    else 
    {
        delete this->NC;
        this->NC = new NetworkCard(nc);
    }
}

StorageDevice ComputerAssembly::getStorageDevice() const
{
    return *(this->Storage);
}

void ComputerAssembly::setStorageDevice(StorageDevice& sd)
{
    if (this->Storage == nullptr)
        this->Storage = new StorageDevice(sd);
    else
    {
        delete this->Storage;
        this->Storage = new StorageDevice(sd);
    }
}

ComputerAssembly::~ComputerAssembly()
{
    delete this->computer;
    delete this->Storage;
    delete this->NC;
}