#pragma once

#include "general.h"
#include "MAC.h"
#include"Battery.h"

class LaptopMac:public MAC
{
protected:                      // data members
	Battery* battery;
public:                               // member functions
	LaptopMac();
	LaptopMac(const Battery& battery);
	void setBattery(Battery& battery);
	Battery getBattery() const;
	~LaptopMac();
};

