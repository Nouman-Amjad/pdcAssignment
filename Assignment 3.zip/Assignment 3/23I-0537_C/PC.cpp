#include "PC.h"

PC::PC() 
{                                                   // default constructor
    this->Chip = new Intel_AMD;
    this->computer->setCPU(*Chip);
}

PC::PC(const Intel_AMD& chip)
{                                               // parameterized constructor
  
    this->Chip = new Intel_AMD(chip);
    this->computer->setCPU(*Chip);
}

void PC::setChip(const Intel_AMD& chip)                    // getters and setters
{
	if (this->Chip == nullptr)
	{
		this->Chip = new Intel_AMD(chip);
		this->computer->setCPU(*Chip);
	}
	else
	{
		delete Chip;
		this->Chip = new Intel_AMD(chip);
		this->computer->setCPU(*Chip);
	}
}

Intel_AMD PC::getChip() const
{
	return *(this->Chip);
}

PC::~PC()
{                                    // destructor
    delete this->Chip;
}