#include "Computer.h"

Computer::Computer()               // default constructor
{
    this->cpu = new CPU;
    this->mb = new MotherBoard;
    this->pm = new PhysicalMemory;
}

Computer::Computer( PhysicalMemory& memory,CPU& processor, MotherBoard& motherboard)   // parametrized constructors
{
    this->cpu = new CPU(processor);
    this->mb = new MotherBoard(motherboard);
    this->pm = new PhysicalMemory(memory);
}
                                                                  // getters and setters
PhysicalMemory Computer::getPhysicalMemory() const 
{
    return *(this->pm);
}

void Computer::setPhysicalMemory( const PhysicalMemory& memory) 
{
   if(this->pm==nullptr)
       this->pm = new PhysicalMemory(memory);
   else
   {
       delete this->pm;
       this->pm = new PhysicalMemory(memory);
   }
}

CPU Computer::getCPU() const
{
    return *(this->cpu);
}

void Computer::setCPU(const CPU& processor) 
{
    if (this->cpu == nullptr)
        this->cpu = new CPU(processor);
    else
    {
        delete this->cpu;
        this->cpu = new CPU(processor);
    }
}

MotherBoard Computer::getMotherBoard() const 
{
    return *(this->mb);
}

void Computer::setMotherBoard(const MotherBoard& motherboard)
{
    if (this->mb == nullptr)
        this->mb = new MotherBoard(motherboard);
    else
    {
        delete this->mb;
        this->mb = new MotherBoard(motherboard);
    }
}

Computer::~Computer()
{
    delete pm;
    delete cpu;
    delete mb;
}