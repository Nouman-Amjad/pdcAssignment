#include "MainMemory.h"

MainMemory::MainMemory()         // default constructor
{
    this->capacity = 0;
    this->technologyType = "";
}

MainMemory::MainMemory(int cap, string tech)       // parameterized constructor
{
    this->capacity = cap;
    this->technologyType = tech;
}

int MainMemory::getCapacity() const                     // getters and setters
{
    return this->capacity;
}

void MainMemory::setCapacity(int cap) 
{
    this->capacity = cap;
}

string MainMemory::getTechnologyType() const 
{
    return this->technologyType;
}

void MainMemory::setTechnologyType(string tech)
{
    this->technologyType = tech;
}