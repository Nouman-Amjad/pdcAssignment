#include<iostream>
#include"Q1.h"
using namespace std;

// khaula bilqees, CS-F, 23i-0574, Marium hida, Muhammad Abdur Rafey

int main() {
	ComputerAssembly comp;
	cout << "Do you want to build a PC or MAC: ";
	string ty;
	cin >> ty;
	cin >> comp;

	comp.display();


}