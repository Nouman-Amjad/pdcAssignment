#pragma once
#include "ComputerAssembly.h"

//Publically inherited 
class MAC : public Computer {
public:
    //default constructor 
    MAC();
    //paraetrized constructor 
    MAC(const CPU& cpu,MotherBoard& mb,PhysicalMemory& pm);
};
