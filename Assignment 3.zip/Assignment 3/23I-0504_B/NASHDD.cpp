#include "NASHDD.h"

//constructor 
NASHDD::NASHDD(const std::string& type, int capacity, double price)
    : StorageDevice(type, capacity, price) {
}