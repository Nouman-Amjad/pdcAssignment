#pragma once
#include "StorageDevice.h"

//publically inherited
class ConsumerHDD : public StorageDevice {
public:
    //default constructor
    ConsumerHDD();
    //parametrized function
    ConsumerHDD(const std::string& type, int capacity, double price);
};
