#pragma once
#include "PhysicalMemory.h"

//publically inherited
class DDRMemory : public PhysicalMemory {
public:
    //default constructor
    //DDRMemory();
    //parametrized constructor
    DDRMemory(int cap);
};