#include "AppleSilicon.h"

//default constructor 
AppleSilicon::AppleSilicon() {}

//paramrtrized constructor 
AppleSilicon::AppleSilicon(const ALU& aluObj, const ControlUnit& cuObj, const std::string& arch, const AppleGPU& gpu)
    : CPU(aluObj, cuObj), architecture(arch), integratedGPU(gpu) {}

//getter 
std::string AppleSilicon::getArchitecture() const {
    return architecture;
}

AppleGPU AppleSilicon::getIntegratedGPU() const {
    return integratedGPU;
}

//setter 
void AppleSilicon::setIntegratedGPU(const AppleGPU& newGpu) {
    integratedGPU = newGpu;
}