#pragma once
#include<iostream>
#include<cstring>
using namespace std;
class Case {
private:
    string formFactor; 
    string color;

public:
    //default constructor
    Case();
    //parametrized constructor 
    Case(const string& formFactor, const string& color);

    //getter functions
    string getFormFactor() const;
    string getColor() const;

    //setter functions
    void setFormFactor(const string& formFactor);
    void setColor(const string& color);
};

