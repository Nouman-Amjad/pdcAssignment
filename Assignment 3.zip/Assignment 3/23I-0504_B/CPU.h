#pragma once
#include"../assign 3/ControlUnit.h"
#include"../assign 3/ALU.h"
class CPU {
protected:
    ALU alu;
    ControlUnit cu;

public:
    //default constructor
    CPU();

    //parametrized constructor 
    CPU(const ALU& alu, const ControlUnit& cu);

    //getter functions
    ALU getALU() const;
    ControlUnit getControlUnit() const;

    //setter functions
    void setALU(const ALU& newAlu);
    void setControlUnit(const ControlUnit& newCu);
};
