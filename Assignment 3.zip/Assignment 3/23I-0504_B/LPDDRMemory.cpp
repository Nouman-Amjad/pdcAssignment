#include "LPDDRMemory.h"
//constructor
LPDDRMemory::LPDDRMemory(int cap) : PhysicalMemory(cap) {}
