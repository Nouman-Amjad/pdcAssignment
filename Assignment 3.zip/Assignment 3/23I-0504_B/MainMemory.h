#pragma once
#include<cstring>
#include<iostream>
using namespace std;

class MainMemory {
public:
    int capacity;
    string technologyType;

    //default constructor
    MainMemory();
    //parametrized constructor
    MainMemory(int capacity, const string& technologyType);

    //getter and setter functions
    int getCapacity();
    void setCapacity(int cap);
    string getTechnologyType() const;
    void setTechnologyType(const string& type);
};