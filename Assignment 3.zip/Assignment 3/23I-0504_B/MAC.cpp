#include "MAC.h"

//constructors
MAC::MAC() {}
MAC::MAC(const CPU& cpu,MotherBoard& mb, PhysicalMemory& pm)
    : Computer(cpu, mb, pm) {}