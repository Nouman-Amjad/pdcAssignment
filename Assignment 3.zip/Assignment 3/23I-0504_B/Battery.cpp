#include "Battery.h"
//default 
Battery::Battery() : capacity(0) { 
}
//parametrized 
Battery::Battery(int capacity) : capacity(capacity) {}

//getter 
int Battery::getCapacity() const {
    return capacity;
}
// setter 
void Battery::setCapacity(int c) {
    capacity = c;
}