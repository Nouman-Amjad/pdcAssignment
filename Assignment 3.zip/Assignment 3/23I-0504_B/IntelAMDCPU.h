#pragma once
#include<iostream>
#include <cstring>
using namespace std;
#include "CPU.h"
#include "GraphicsCard.h"

//publically inherited 
class IntelAMDCPU : public CPU, public GraphicsCard {
private:
     string architecture;
public:
    //default construtor
    IntelAMDCPU();
    //parametrized constructor 
    IntelAMDCPU(const std::string& arch, const std::string& brand, int memorySize, double price);
    //getter function
    string getArchitecture() const;
};

