#include <iostream>
#include <string>
#include "Case.h"
#include "PowerSupply.h"
#include "Computer.h"
#include "PC.h"
#include "MAC.h"
#include "ComputerAssembly.h"
using namespace std;

//*********    NAME: Areej Fahim             ***********
//*********    SECTION: CS-'B'               ***********
//*********    ROLL NO.: 23I-0504            ***********
//*********    INSTRUCTOR: Sir Ali Zeeshan   ***********
//*********    TA: Muhammad Mohsin Ramzan    ***********

int main() {
    string formFactor, color, type, efficiencyrating;
    double casePrice, powerSupplyWattage, powerSupplyPrice;
    string motherboard, memory, cpu, gpu, networkCard, Porttype, Graphicstype;
    int DDR, LPDDR, capacity;

    cout << "Welcome to the Computer Assembly!!" << endl;

    // Getting Case specifications from user
    cout << "Enter the case form factor (e.g., ATX, MicroATX): ";
    cin >> formFactor;
    cout << "Enter the case color: ";
    cin>>color;


    // Creating a Case object
    Case computerCase(formFactor, color); // constructor called

    // Getting PowerSupply specifications from user
    cout << "Enter the power supply wattage: ";
    cin >> powerSupplyWattage;
    cin.ignore(100, '\n');          //max 100 words consider
    cout << "Enter the power supply price: ";
    cin >> powerSupplyPrice;
    cin.ignore(100, '\n');
    cout << "Enter the power supply efficiency rating(eg 80 Plus Bronze,80 Plus Gold): ";
    cin >> efficiencyrating;
    cin.ignore(100, '\n');
    // Creating a PowerSupply object
    PowerSupply powerSupply(powerSupplyWattage);   //constructor called

    //Getting the Battery specifications from the user
    cout << "Enter the Battery capcity" << endl;
    cin >> capacity;
    cin.ignore(100, '\n');
    // Creating a Battery object
    Battery Battery(int capacity);  // constructor called

    //Getting the user input for other specifications
    cout << "Enter the motherboard brand (e.g., Intel, Apple Silicon): ";
    cin >> motherboard;
    cin.ignore(100, '\n');
    //creating the motherboard object
    MotherBoard board(); // constructor called
    cout << "Enter the memory size (e.g., 8GB, 16GB): ";
    cin >> memory;
    cin.ignore(100, '\n');
    //creating object of mainmemory
    MainMemory Mainmemory(); // construvtor called

    //getting cpu gpu input
    cout << "Enter the CPU brand (e.g., IntelAMD, Apple Silicon): ";
    cin >> cpu;
    cin.ignore(100, '\n');
    cout << "Enter the GPU brand (Apple GPU, Intel): ";
    cin >> gpu;
    cin.ignore(100, '\n');
    // creating new objects
    ALU ALU(); // construvtor called
    ControlUnit CU();  //constructor called

    cout << "Enter the graphicsCard type :(NVIDIA,AMD etc)";
    cin >> Graphicstype;
    cin.ignore(100, '\n');
    cout << "Enter the port Type(eg VGI Port, I/O Port,UAB Port,HDMI Port)";
    cin >> Porttype;
    cin.ignore(100, '\n');
    Port port();// creating new object 
    //constructor called

    // input for the computer type 
    cout << "Enter the computer type (PC or Mac): ";
    cin >> type;
    cin.ignore(100, '\n');
    
    //creating a new object of computer
    Computer* myComputer = nullptr;

    //seperate conditions according to the computer tyoe 
    if (type == "PC") {
        cout << "Enter the network card specifications (e.g., Ethernet 1000 Mbps): ";
        cin >> networkCard;  //specific to PC
        myComputer = new PC(); //creating the object of PC
        cout << "Enter the capacity of DDR" << endl;
        cin >> DDR; // specific to PC
        PhysicalMemory DDR();
        cout << "Enter the price: ";
        cin >> casePrice; // specific to PC
        cin.ignore(100, '\n');
        CPU IntelAMD();  // constructor called
    }
    //specific conditions for Mac type
    else if (type == "Mac") {
        myComputer = new MAC(); //creating the object of Mac
        cout << "Enter the capacity of LPDDR" << endl;
        cin >> LPDDR;// specific to Mac 
        PhysicalMemory LPDDR();
        CPU AppleSilcon(); // constructor called

    }
    else {
        cout << "Invalid computer type entered."<<endl;
        return 1;  // Input Validation
    }

    //Displaying the specifictaions of the computer type
    cout << type << " Components:\n"
        << "Motherboard: " << motherboard << "\n"
        << "Memory: " << memory << "\n"
        << "CPU: " << cpu << "\n"
        << "GPU: " << gpu << "\n"
        << "Graphics Type" << Graphicstype << endl
        << "Port Type" << Porttype << endl
        << "Battery Capacity" << capacity << endl;

    // specific display of the pc 
    //displaying the traitsspecific to pc
    if (type == "PC") {
        cout << "Network Card: " << networkCard << "\n";
        cout << "Case Price:" << casePrice << endl;

    }
    
    delete myComputer;

    return 0; 
}