#pragma once
#include"../assign 3/CPU.h"
#include"../assign 3/PhysicalMemory.h"
#include"../assign 3/MotherBoard.h"
class Computer {
private:
    CPU cpu;
    MotherBoard mb;
    PhysicalMemory pm;

public:
    // Default Constructor 
    Computer();
    //parametirzed function
    Computer(const CPU& cpu, const MotherBoard& mb, const PhysicalMemory& pm);

    // Getter functions
    const CPU& getCPU() const;
    const MotherBoard& getMotherBoard() const;
    const PhysicalMemory& getPhysicalMemory() const;

    //setter functions 
    void setCPU(const CPU& newCPU);
    void setMotherBoard(const MotherBoard& newMotherBoard);
    void setPhysicalMemory(const PhysicalMemory& newPhysicalMemory);
};

