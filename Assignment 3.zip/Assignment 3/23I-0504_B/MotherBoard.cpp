#include "MotherBoard.h"
MotherBoard::MotherBoard() {}
MotherBoard::MotherBoard(const MainMemory& mm, const Port ports[], int numPorts)
    : mm(mm), numPorts(numPorts) {
}

//getters 
const MainMemory& MotherBoard::getMainMemory() const {
    return mm;
}

Port* MotherBoard::getPorts() {
    return ports;
}

int MotherBoard::getNumPorts() const {
    return numPorts;
}

//setters
void MotherBoard::setMainMemory(const MainMemory& newMM) {
    mm = newMM;
}

void MotherBoard::setPorts(const Port inputPorts[], int newNumPorts) {
    if (newNumPorts > PORTS) {
        return; 
    }
}

void MotherBoard::setNumPorts(int newNumPorts) {
    if (newNumPorts > PORTS || newNumPorts < 0) {
        return;
    }
    numPorts = newNumPorts;
}