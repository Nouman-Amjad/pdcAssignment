#include "ConsumerHDD.h"

//default 
ConsumerHDD::ConsumerHDD() {};

//parametrized 
ConsumerHDD::ConsumerHDD(const std::string& type, int capacity, double price)
    : StorageDevice(type, capacity, price) {
}