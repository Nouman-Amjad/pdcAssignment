#pragma once
#include<iostream>
#include<cstring>
using namespace std;
#include"Battery.h"
class PowerSupply {
private:
    int wattage; 
    string efficiencyRating; 
    double price; 
    Battery battery;

public:
    //default constructor 
    PowerSupply();
        //parametrized constructor 
    PowerSupply(int wattage, string efficiencyRating, double price);
    PowerSupply(int wattage);

    //getter functions
    int getWattage() const;
    string getEfficiencyRating() const;
    double getPrice() const;
    Battery getBattery() const;

    //setter functions
    void setWattage(int w);
    void setEfficiencyRating(const string& eff);
    void setPrice(double p);
};