#include "PC.h"

//constyructors
PC::PC() {}
PC::PC(const CPU& cpu, const MotherBoard& mb, const PhysicalMemory& pm)
    : Computer(cpu, mb, pm) {}
