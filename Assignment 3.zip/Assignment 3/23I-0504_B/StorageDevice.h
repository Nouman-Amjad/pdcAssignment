#pragma once
#include<iostream>
#include<cstring>
using namespace std;
class StorageDevice {
private:
    string type; 
    int capacity; 
    double price; 

public:
    //dafult constructor
    StorageDevice();
    //parametrized constructor 
    StorageDevice(string type, int capacity, double price);

    //getter functions
    string getType() const;
    int getCapacity() const;
    double getPrice() const;

    //setter functions
    void setType(const string& t);
    void setCapacity(int c);
    void setPrice(double p);
};