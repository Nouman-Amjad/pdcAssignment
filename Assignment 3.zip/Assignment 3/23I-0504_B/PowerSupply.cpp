#include "PowerSupply.h"
//constructors
PowerSupply::PowerSupply() {}
PowerSupply::PowerSupply(int wattage, string efficiencyRating, double price)
    : wattage(wattage), efficiencyRating(efficiencyRating), price(price) {}

PowerSupply::PowerSupply(int wattage) : wattage(wattage), efficiencyRating(), price() {}

//getters 
int PowerSupply::getWattage() const {
    return wattage;
}

string PowerSupply::getEfficiencyRating() const {
    return efficiencyRating;
}

double PowerSupply::getPrice() const {
    return price;
}

//setters
void PowerSupply::setWattage(int w) {
    wattage = w;
}

void PowerSupply::setEfficiencyRating(const string& eff) {
    efficiencyRating = eff;
}

void PowerSupply::setPrice(double p) {
    price = p;
}
Battery PowerSupply::getBattery() const {
    return battery;
}
