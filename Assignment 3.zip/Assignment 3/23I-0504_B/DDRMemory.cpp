#include "DDRMemory.h"

//comstructor 
DDRMemory::DDRMemory(int cap) : PhysicalMemory(cap) {}
