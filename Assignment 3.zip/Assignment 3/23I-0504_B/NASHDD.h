#pragma once
#include"StorageDevice.h"

class NASHDD : public StorageDevice {
public:
    //CONSTRUCTORS
    NASHDD();
    NASHDD(const std::string& type, int capacity, double price);
};
