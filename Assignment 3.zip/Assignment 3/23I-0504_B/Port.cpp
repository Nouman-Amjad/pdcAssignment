#include "Port.h"
#include<iostream>
using namespace std;

//constructors
Port::Port() {}
Port::Port(string t, int baud) : type(t), baudRate(baud) {}

//getter
string Port::getType() const {
    return type;
}

int Port::getBaudRate() const {
    return baudRate;
}

//setter
void Port::setType(string& t) {
    type = t;
}

void Port::setBaudRate(int baud) {
    if (baud >= 0) {
        baudRate = baud;
    }
    else {
        baudRate = 0; 
    }
}