#pragma once
class PhysicalMemory {
private:
    int capacity; 

public:
    //default constuctor 
    PhysicalMemory();
    //
    PhysicalMemory(const PhysicalMemory&);
    //parametrized constructor  
    PhysicalMemory(int cap);

    //getter
    int getCapacity() const;
    //setter
    void setCapacity(int newCapacity);
};
