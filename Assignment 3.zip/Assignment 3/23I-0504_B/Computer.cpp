#include "Computer.h"
#include"../assign 3/CPU.h"
// Default constructor 
Computer::Computer() {}
//parametrized constructor 
Computer::Computer(const CPU& cpu, const MotherBoard& mb, const PhysicalMemory& pm)
    : cpu(cpu), mb(mb), pm(pm) {}

// Getters 
const CPU& Computer::getCPU() const {
    return cpu;
}

const MotherBoard& Computer::getMotherBoard() const {
    return mb;
}

const PhysicalMemory& Computer::getPhysicalMemory() const {
    return pm;
}

//setters 
void Computer::setCPU(const CPU& newCPU) {
    cpu = newCPU;
}

void Computer::setMotherBoard(const MotherBoard& newMotherBoard) {
    mb = newMotherBoard;
}

void Computer::setPhysicalMemory(const PhysicalMemory& newPhysicalMemory) {
    pm = newPhysicalMemory;
}