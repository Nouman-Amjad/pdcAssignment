#include "ALU.h"
#include<iostream>
using namespace std;
// Default Constructor
ALU::ALU() : noOfAdders(1), noOfSubtractors(1), noOfRegisters(4), sizeOfRegisters(32) {}

// Overloaded Constructor
ALU::ALU(int adders, int subtractors, int registers, int size) :
    noOfAdders(adders), noOfSubtractors(subtractors), noOfRegisters(registers), sizeOfRegisters(size) {}

// Getters
int ALU::getNoOfAdders() const {
    return noOfAdders; 
}
int ALU::getNoOfSubtractors() const { 
    return noOfSubtractors;
}
int ALU::getNoOfRegisters() const { 
    return noOfRegisters; 
}
int ALU::getSizeOfRegisters() const { 
    return sizeOfRegisters;
}

// Setters
void ALU::setNoOfAdders(int adders) {
    noOfAdders = adders; 
}
void ALU::setNoOfSubtractors(int subtractors) { 
    noOfSubtractors = subtractors;
}
void ALU::setNoOfRegisters(int registers) { 
    noOfRegisters = registers;
}
void ALU::setSizeOfRegisters(int size) {
    sizeOfRegisters = size;
}