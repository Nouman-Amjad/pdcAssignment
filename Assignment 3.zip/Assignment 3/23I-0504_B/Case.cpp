#include "Case.h"
//default 
Case::Case() {}
//parametrized
Case::Case(const std::string& formFactor, const std::string& color)
    : formFactor(formFactor), color(color) {}

//getters 
string Case::getFormFactor() const {
    return formFactor;
}

string Case::getColor() const {
    return color;
}

//setters 
void Case::setFormFactor(const string& formFactor) {
    this->formFactor = formFactor;
}

void Case::setColor(const string& color) {
    this->color = color;
}
