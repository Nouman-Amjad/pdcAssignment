#pragma once
#include<iostream>
#include<cstring>
using namespace std;
class NetworkCard {
private:
    string type; 
    int speed; 
    double price; 

public:
    //default constructor
    NetworkCard();
    //prametrized constructor 
    NetworkCard(string type, int speed, double price);

    //getter functions
    string getType() const;
    int getSpeed() const;
    double getPrice() const;

    //setter functions
    void setType(const string& t);
    void setSpeed(int s);
    void setPrice(double p);
};