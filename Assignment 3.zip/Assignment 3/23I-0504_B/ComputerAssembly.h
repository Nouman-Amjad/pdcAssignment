#pragma once
#include"../assign 3/Computer.h"
#include "Case.h"
#include "PowerSupply.h"
#include "Computer.h"

class ComputerAssembly {
private:
    Case computerCase;           // Composition
    PowerSupply powerSupply;     // Composition
    Computer* computer;          // Aggregation

public:
    //default constructor 
    ComputerAssembly();
    //parametrized constructor 
    ComputerAssembly(const Case& compCase, const PowerSupply& pSupply, Computer* comp);
    // Virtual destructor
    virtual ~ComputerAssembly(); 

    //getter functions
    Case getComputerCase() const;
    PowerSupply getPowerSupply() const;
    Computer* getComputer() const;

    //setter functions
    void setComputerCase(const Case& compCase);
    void setPowerSupply(const PowerSupply& pSupply);
    void setComputer(Computer* comp);
};
