#include "NetworkCard.h"
//default 
NetworkCard::NetworkCard() {}
//para,etrixzed 
NetworkCard::NetworkCard(string type, int speed, double price)
    : type(type), speed(speed), price(price) {}

//gettere 
string NetworkCard::getType() const {
    return type;
}

int NetworkCard::getSpeed() const {
    return speed;
}

double NetworkCard::getPrice() const {
    return price;
}

//setters 
void NetworkCard::setType(const string& t) {
    type = t;
}

void NetworkCard::setSpeed(int s) {
    speed = s;
}

void NetworkCard::setPrice(double p) {
    price = p;
}