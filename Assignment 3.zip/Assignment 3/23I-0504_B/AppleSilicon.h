#pragma once
#include<iostream>
#include "CPU.h"
#include "AppleGPU.h"
#include<cstring>

using namespace std;
// publically inherited 
class AppleSilicon : public CPU {
private:
    string architecture;
    AppleGPU integratedGPU;

public:
    //default constructor
    AppleSilicon();
    //Parametrized constructor
    AppleSilicon(const ALU& alu, const ControlUnit& cu, const string& arch, const AppleGPU& gpu);

    //getter functions
    string getArchitecture() const;
    AppleGPU getIntegratedGPU() const;

    //setter function
    void setIntegratedGPU(const AppleGPU& newGpu);
};