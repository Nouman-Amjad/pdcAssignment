#include "MainMemory.h"

//default 
MainMemory::MainMemory() : capacity(0), technologyType() {}

//para,etrized
MainMemory::MainMemory(int cap, const std::string& type)
    : capacity(cap), technologyType(type) {}

//getter 
int MainMemory::getCapacity() {
    return capacity;
}

std::string MainMemory::getTechnologyType() const {
    return technologyType;
}

//setter 
void MainMemory::setCapacity(int cap) {
    capacity = cap;
}

void MainMemory::setTechnologyType(const std::string& techType) {
    technologyType = techType;
}