#include "ComputerAssembly.h"

//default 
ComputerAssembly::ComputerAssembly() {};

//para,etrized 
ComputerAssembly::ComputerAssembly(const Case& compCase, const PowerSupply& pSupply, Computer* comp)
    : computerCase(compCase), powerSupply(pSupply), computer(comp) {
}

//destructor 
ComputerAssembly::~ComputerAssembly() {
  
}

//getters 
Case ComputerAssembly::getComputerCase() const {
    return computerCase;
}

PowerSupply ComputerAssembly::getPowerSupply() const {
    return powerSupply;
}

Computer* ComputerAssembly::getComputer() const {
    return computer;
}

//setters 
void ComputerAssembly::setComputerCase(const Case& compCase) {
    computerCase = compCase;
}

void ComputerAssembly::setPowerSupply(const PowerSupply& pSupply) {
    powerSupply = pSupply;
}

void ComputerAssembly::setComputer(Computer* comp) {
    computer = comp;
}
