#pragma once
#include "PhysicalMemory.h"

//publically inherited 
class LPDDRMemory : public PhysicalMemory {
public:
    //dfault constructor 
   /* LPDDRMemory();*/
    //parametrized costructor 
    LPDDRMemory(int cap);
};
