#include "GraphicsCard.h"
//default 
GraphicsCard::GraphicsCard() {}

//para,etrized 
GraphicsCard::GraphicsCard(std::string brand, int memorySize, double price)
    : brand(brand), memorySize(memorySize), price(price) {}


//getters 
string GraphicsCard::getBrand() const {
    return brand;
}

int GraphicsCard::getMemorySize() const {
    return memorySize;
}

double GraphicsCard::getPrice() const {
    return price;
}

//setters 
void GraphicsCard::setBrand(const std::string& b) {
    brand = b;
}

void GraphicsCard::setMemorySize(int size) {
    memorySize = size;
}

void GraphicsCard::setPrice(double p) {
    price = p;
}