#pragma once
#include<iostream>
using namespace std;
#include<cstring>

class Port {
private:
    string type; 
    int baudRate;  

public:
    //default constructor 
    Port();
    //parametrized constructor 
    Port(string t, int baud);

    //getter function
    string getType() const;
    int getBaudRate() const;
  //setter function 
    void setType(string&t);
    void setBaudRate(int baud);
};