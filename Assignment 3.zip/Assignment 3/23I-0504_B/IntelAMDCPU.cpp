#include "IntelAMDCPU.h"
IntelAMDCPU::IntelAMDCPU() : CPU(), architecture() {
    // Default
}

//para,etrized
IntelAMDCPU::IntelAMDCPU(const string& arch, const string& brand, int memorySize, double price)
    : CPU(), GraphicsCard(brand, memorySize, price), architecture(arch) {
}

//getter 
string IntelAMDCPU::getArchitecture() const {
    return architecture;
}


