#include "StorageDevice.h"
//constructors
StorageDevice::StorageDevice() {}
StorageDevice::StorageDevice(string type, int capacity, double price) : type(type), capacity(capacity), price(price) {}


//getters 
string StorageDevice::getType() const {
    return type;
}

int StorageDevice::getCapacity() const {
    return capacity;
}

double StorageDevice::getPrice() const {
    return price;
}
//setters
void StorageDevice::setType(const string& t) {
    type = t;
}

void StorageDevice::setCapacity(int c) {
    capacity = c;
}

void StorageDevice::setPrice(double p) {
    price = p;
}