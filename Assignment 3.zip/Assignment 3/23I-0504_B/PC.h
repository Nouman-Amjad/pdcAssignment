#pragma once
#include "ComputerAssembly.h"

//publically inherited
class PC : public Computer {
private:
    double price; // Specific to PC

public:
    //default constructor
    PC();
    //Parametried constructor 
    PC(const CPU& cpu, const MotherBoard& mb, const PhysicalMemory& pm);
};