#include "AppleGPU.h"

//derfault constructor 
AppleGPU::AppleGPU() : coreCount(0), memorySize(0) {}

//para,etrized constructor 
AppleGPU::AppleGPU(int memory, int cores) : memorySize(memory), coreCount(cores) {}

//getters
int AppleGPU::getMemorySize() const {
    return memorySize;
}

int AppleGPU::getCoreCount() const {
    return coreCount;
}

//setters 
void AppleGPU::setMemorySize(int newMemorySize) {
    memorySize = newMemorySize;
}

void AppleGPU::setCoreCount(int newCoreCount) {
    coreCount = newCoreCount;
}