#pragma once
class ControlUnit {
private:
    float clock;

public:
    // Default Constructor
    ControlUnit();

    // Parametrized Constructor
    ControlUnit(float clk);

    // Getter
    float getClock() const;

    // Setter
    void setClock(float clk);
};
