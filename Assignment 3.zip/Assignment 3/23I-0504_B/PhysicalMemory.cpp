#include "PhysicalMemory.h"

// Default constructor
PhysicalMemory::PhysicalMemory() : capacity(0) {

}

// Copy constructor
PhysicalMemory::PhysicalMemory(const PhysicalMemory& other) : capacity(other.capacity) {
}

// parametrized Constructor 
PhysicalMemory::PhysicalMemory(int cap) : capacity(cap) {
   
}

// Getter 
int PhysicalMemory::getCapacity() const {
    return capacity;
}

// Setter 
void PhysicalMemory::setCapacity(int newCapacity) {
    capacity = newCapacity;
}