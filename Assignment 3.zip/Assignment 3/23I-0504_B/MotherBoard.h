#pragma once
#include"../assign 3/MainMemory.h"
#include"../assign 3/Port.h"

const int PORTS = 10;
class MotherBoard {
private:
    MainMemory mm;
    Port ports[PORTS];
    int numPorts; // Actual number of ports in use

public:
    //default constructor 
    MotherBoard();
    //parametrized constructor
    MotherBoard(const MainMemory& mm, const Port ports[], int numPorts);

    //getter functions
    const MainMemory& getMainMemory() const;
    Port* getPorts();
    int getNumPorts() const;

        //setter functions
    void setMainMemory(const MainMemory& newMM);
    void setPorts(const Port inputPorts[], int newNumPorts);
    void setNumPorts(int newNumPorts);
};