#pragma once
class Battery {
private:
    int capacity; 

public:
    //default constructor 
    Battery();
    //parametrized constructor 
    Battery(int capacity);

    //getter function 
    int getCapacity() const;
    //setter function
    void setCapacity(int c);
};
