#pragma once
#include<iostream>
#include<cstring>
using namespace std;
class GraphicsCard {
private:
    string brand;
    int memorySize; 
    double price; 

public:
    //default constructor
    GraphicsCard();
    //Parametrizwd constructor
    GraphicsCard(string brand, int memorySize, double price );

    //getter functions
    string getBrand() const;
    int getMemorySize() const;
    double getPrice() const;

    //setter functions
    void setBrand(const string& b);
    void setMemorySize(int size);
    void setPrice(double p);
};

