#include "ControlUnit.h"
#include<iostream>
using namespace std;
// Default Constructor
ControlUnit::ControlUnit() {}

// parametrized Constructor
ControlUnit::ControlUnit(float clk) : clock(clk) {}

// Getter
float ControlUnit::getClock() const {
    return clock;
}

// Setter
void ControlUnit::setClock(float clk) {
    clock = clk;
}