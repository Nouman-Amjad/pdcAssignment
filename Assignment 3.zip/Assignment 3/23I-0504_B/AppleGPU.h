#pragma once
class AppleGPU {
private:
    int coreCount;
    int memorySize; 

public:
    //Default constructor 
    AppleGPU();
    //Parametrized Function
    AppleGPU(int memory, int cores);

    //getter functions
    int getMemorySize() const;
    int getCoreCount() const;

    //setter function
    void setMemorySize(int newMemorySize);
    void setCoreCount(int newCoreCount);
};