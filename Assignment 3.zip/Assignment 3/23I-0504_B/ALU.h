#pragma once
class ALU {
private:
    int noOfAdders;
    int noOfSubtractors;
    int noOfRegisters;
    int sizeOfRegisters;

public:
    // Default Constructor
    ALU();

    // Parametrized Constructor
    ALU(int adders, int subtractors, int registers, int size) ;

    // Getter functions
    int getNoOfAdders() const;
    int getNoOfSubtractors() const ;
    int getNoOfRegisters() const ;
    int getSizeOfRegisters() const ;

    // Setter functions
    void setNoOfAdders(int adders) ;
    void setNoOfSubtractors(int subtractors) ;
    void setNoOfRegisters(int registers) ;
    void setSizeOfRegisters(int size) ;
};
