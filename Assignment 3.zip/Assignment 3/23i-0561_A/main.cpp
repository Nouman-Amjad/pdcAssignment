#include<iostream>
#include"Header.h"
using namespace std;

int main()
{
	ComputerAssembly obj;
	obj.getInput();
	cout << endl;
}