#pragma once
#include<iostream>
using namespace std;


class NetworkCard
{
private:
	string type;
	int speed;
	double price;

public:
	NetworkCard();
	//NetworkCard(string, int, double);
	void getInput(int);
	string getType();
	void setType(string);
	int getSpeed();
	void setSpeed(int);
	double getPrice();
	void setPrice(double);
	void printDetails();
};

class GraphicsCard
{
protected:
	string brand;
	int memorySize;
	double price;
public:
	GraphicsCard();
	//GraphicsCard(string, int, double);
	bool getInput(int);
	string getBrand();
	void setBrand(string);
	int getMemorySize();
	void setMemorySize(int);
	double getPrice();
	void setPrice(double);
	void printDetails();
};

class Battery
{
private:
	int capacity;
	double price;
public:
	Battery();
	//Battery(int, ComputerAssembly*);
	void getInput(int);
	int getCapacity();
	void setCapacity(int);
	double getPrice();
	void setPrice(double);
	void printDetails();
};

class PowerSupply
{
private:
	int wattage;
	string efficiencyRating;
	double price;
public:
	PowerSupply();
	//PowerSupply(int, string, double, ComputerAssembly*);
	void getInput(int);
	int getWattage();
	void setWattage(int);
	string getEfficiencyRating();
	void setEfficiencyRating(string);
	double getPrice();
	void setPrice(double);
	void printDetails();
};

class Case
{
private:
	string formFactor;
	string color;
	double price;
public:
	Case();
	//Case(string, string);
	void getInput();
	string getformFactor();
	string getcolor();
	double getPrice();
	void setPrice(double);
	void setformFactor(string);
	void setcolor(string);
	void printDetails();
};

class ALU
{
private:
	int NoOfAdders;
	int NoOfSubtractor;
	int NoOfRegisters;
	int sizeOfRegisters;
public:
	ALU();
	//ALU(int, int, int, int, CPU*);
	void getInput();
	int getNoOfAdders();
	int getNoOfSubtractor();
	int getNoOfRegisters();
	int getsizeOfRegisters();
	void setNoOfAdders(int);
	void setNoOfSubtractor(int);
	void setNoOfRegisters(int);
	void setsizeOfRegisters(int);
	void printDetails();
};

class ControlUnit
{
private:
	float clock;
public:
	ControlUnit();
	//ControlUnit(float);
	void getInput();
	float getclock();
	void setclock(float);
	void printDetails();
};

class CPU
{
private:
	string type;
	double price;
protected:
	ALU alu;
	ControlUnit cu;
public:
	CPU();
	//CPU(ALU, ControlUnit, Computer*);
	bool getInput(int);
	void setType(string);
	string getType();
	void setPrice(double);
	double getPrice();
	void printDetails();
};

class Port
{
private:
	string type;
	int baud_rate;
public:
	Port();
	//Port(string, int, MotherBoard*);
	void getInput();
	string getType();
	void setType(string);
	int getbaud_rate();
	void setbaud_rate(int);
	void printDetails();
};

class MainMemory
{
protected:
	int capacity;
	string technologyType;
public:
	MainMemory();
	//MainMemory(int, string, MotherBoard*);
	void getInput();
	int getcapacity();
	void setcapacity(int);
	string getTechnologyType();
	void setTechnologyType(string);
	void printDetails();
};

class StorageDevice
{
protected:
	string dvtype;
	int dvcapacity;
	double dvprice;
public:
	StorageDevice();
	void getInput();
	void printDetails();
	int getdvCapacity();
	void setdvCapacity(int);
	string dvgetDeviceType();
	void dvsetDeviceType(string);
	void dvsetPrice(double);
	double dvgetPrice();
};

class PhysicalMemory : public StorageDevice
{
protected:
	int pmcapacity;
	string pmtype;
	double pmprice;
public:
	PhysicalMemory();
	//PhysicalMemory(int);
	bool getInput(int);
	void setType(string);
	string getType();
	int getpmCapacity();
	void setpmCapacity(int);
	void pmsetPrice(double);
	double pmgetPrice();
	void printDetails();

};

class MotherBoard
{
private:
	double price;
protected:
	MainMemory mm;
	Port* ports;
	int numPorts;
public:
	MotherBoard();
	//MotherBoard(MainMemory, Port*);
	void getInput(int);
	void setPrice(double);
	double getPrice();
	void printDetails();
};

class Computer
{
protected:
	CPU cpu;
	MotherBoard mb;
	PhysicalMemory pm;
public:
	Computer();
	//Computer(int);
	bool getInput(int);
	void showOutput();
};

class ComputerAssembly
{
protected:
	Battery battery;
	NetworkCard networkCard;
	GraphicsCard graphicsCard;
	StorageDevice storageDevice;
	PhysicalMemory physicalMemory;
	PowerSupply powerSupply;
	Case casee;
	double totalPrice;
public:
	ComputerAssembly();
	//ComputerAssembly(double, PhysicalMemory*, MotherBoard*, CPU*, GraphicsCard*, StorageDevice*, NetworkCard*, PowerSupply*, Battery*, Case*);
	double getTotalPrice();
	void setTotalPrice(double);
	void calculatePrice();
	void getInput();
};

class PC : public ComputerAssembly
{
private:
	int choice;
public:
	PC(int);
	double getTotalPrice();
	void setTotalPrice(double);

};

class MAC : public ComputerAssembly
{
private:
	int choice;
public:
	MAC(int);
	double getTotalPrice();
	void setTotalPrice(double);
};
