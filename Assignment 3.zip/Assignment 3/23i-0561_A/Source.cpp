#include<iostream>
#include"Header.h"
using namespace std;

ComputerAssembly::ComputerAssembly()
{
	totalPrice = 0;
}
double ComputerAssembly::getTotalPrice()
{
	return this->totalPrice;
}
void ComputerAssembly::setTotalPrice(double newEntry)
{
	this->totalPrice += newEntry;
}
void ComputerAssembly::calculatePrice()
{
	double val = networkCard.getPrice();

	setTotalPrice(val);
}
void ComputerAssembly::getInput()
{
	int choice = 0;
	cout << "choose either of two: " << endl;
	cout << "1--> PC" << endl;
	cout << "2--> MAC" << endl;
	cin >> choice;

	if (choice == 1)
	{
		PC obj(choice);
	}
	else if (choice == 2)
	{
		MAC obj(choice);
	}
	else
	{
		cout << "re-enter! invalid option" << endl;
	}

}


PC::PC(int a)
{
	bool result = false;

	this->choice = a;

	networkCard.getInput(this->choice);
	setTotalPrice(networkCard.getPrice());

	battery.getInput(this->choice);
	setTotalPrice(battery.getPrice());

	powerSupply.getInput(this->choice);
	setTotalPrice(powerSupply.getPrice());

	casee.getInput();
	setTotalPrice(casee.getPrice());

	result = graphicsCard.getInput(this->choice);
	setTotalPrice(graphicsCard.getPrice());

	if(result)
	{
		Computer obj;
		result = obj.getInput(this->choice);

		if(result)
		{
			cout << "Computer Deatils: " << endl;
			cout << endl;
			networkCard.printDetails();
			cout << endl;
			graphicsCard.printDetails();
			cout << endl;
			battery.printDetails();
			cout << endl;
			powerSupply.printDetails();
			cout << endl;
			casee.printDetails();
			cout << endl;
			obj.showOutput();
			cout << endl;

			cout << "Total Cost of your Computer is: " << getTotalPrice() << endl;
		}
		else
		{
			cout << "Oops! You entered a wrong component" << endl;
		}
	}
	else
	{
		cout << "Oops! You entered a wrong component" << endl;
	}

}
void PC::setTotalPrice(double p)
{
	this->totalPrice += p;
}
double PC::getTotalPrice()
{
	return this->totalPrice;
}

MAC::MAC(int a)
{
	bool result = false;

	this->choice = a;

	networkCard.getInput(this->choice);
	setTotalPrice(networkCard.getPrice());

	battery.getInput(this->choice);
	setTotalPrice(battery.getPrice());

	powerSupply.getInput(this->choice);
	setTotalPrice(powerSupply.getPrice());

	result = graphicsCard.getInput(this->choice);
	setTotalPrice(graphicsCard.getPrice());

	if (result)
	{
		Computer obj;
		result = obj.getInput(this->choice);

		if (result)
		{
			cout << "Computer Deatils: " << endl;
			cout << endl;
			networkCard.printDetails();
			cout << endl;
			graphicsCard.printDetails();
			cout << endl;
			battery.printDetails();
			cout << endl;
			powerSupply.printDetails();
			cout << endl;
			obj.showOutput();
			cout << endl;

			cout << "Total Cost of your Computer is: " << getTotalPrice() << endl;
		}
		else
		{
			cout << "Oops! You entered a wrong component" << endl;
		}
	}
	else
	{
		cout << "Oops! You entered a wrong component" << endl;
	}

}
void MAC::setTotalPrice(double p)
{
	this->totalPrice += p;
}
double MAC::getTotalPrice()
{
	return this->totalPrice;
}


Computer::Computer()
{
}
bool Computer::getInput(int choice)
{
	bool result = false;
	result = cpu.getInput(choice);
	
	if(result)
	{
		mb.getInput(choice);
		result = pm.getInput(choice);
	}
	return result;
}
void Computer::showOutput()
{
	cpu.printDetails();
	cout << endl;

	mb.printDetails();
	cout << endl;

	pm.printDetails();
	cout << endl;
}

PhysicalMemory::PhysicalMemory()
{
}
bool PhysicalMemory::getInput(int tell)
{
	string s;
	int val;
	int choice = 0;
	bool check = false;

	cout << "Enter the physical memory type e.g DDR4, DDR5, LDDR4, LDDR5:" << endl;;
	cout << "Choose any one: " << endl;
	cout << "1->DDR4" << endl;
	cout << "2->DDR5" << endl;
	cout << "3->LDDR4" << endl;
	cout << "4->LDDR5" << endl;
	cin >> choice;

	if ((tell == 1 && (choice == 1 || choice == 2)) || (tell == 2 && (choice == 3 || choice == 4)))
	{
		check =true;
	}
	else
	{
		cout << "Oops! Entered a wrong component" << endl;
	}

	if(check)
	{
		switch (choice)
		{
		case 1:
			this->setType("DDR4");
			this->pmsetPrice(5000);
			break;
		case 2:
			this->setType("DDR5");
			this->pmsetPrice(8000);
			break;
		case 3:
			this->setType("LDDR5");
			this->pmsetPrice(10000);
			break;
		case 4:
			this->setType("LDDR5");
			this->pmsetPrice(12000);
			break;
		default:
			cout << "invalid choice" << endl;
			break;
		}

		cout << "Enter the storage device type e.g HDD, SSD: ";
		cout << "Choose any one: " << endl;
		cout << "1->HDD" << endl;
		cout << "2->SSD" << endl;
		cin >> choice;

		switch (choice)
		{
		case 1:
			this->dvsetDeviceType("HDD");
			this->dvsetPrice(5000);
			break;
		case 2:
			this->dvsetDeviceType("SSD");
			this->dvsetPrice(5000);
			break;
		default:
			cout << "invalid choice" << endl;
			break;
		}

		cout << "Enter the capacity of your storage device in TB's: ";
		cout << "Range is 1-16 TB " << endl;
		do
		{
			cin >> val;
		} while (!(val >= 1 && val <= 16));
		this->setdvCapacity(val);

		cout << "Enter the capacity of your physical memory in GB's: ";
		cout << "Range is 2-64 TB " << endl;
		do
		{
			cin >> val;
		} while (!(val >= 2 && val <= 64));
		this->setpmCapacity(val);
	}
	return check;
}
void PhysicalMemory::setType(string s)
{
	this->pmtype = s;

}
string PhysicalMemory::getType()
{
	return this->pmtype;
}
int PhysicalMemory::getpmCapacity()
{
	return this->pmcapacity;
}
void PhysicalMemory::setpmCapacity(int a)
{
	this->pmcapacity = a;
}
void PhysicalMemory::pmsetPrice(double p)
{
	this->pmprice = p;
}
double PhysicalMemory::pmgetPrice()
{
	return this->pmprice;
}
void PhysicalMemory::printDetails()
{
	cout << "Memory Details: " << endl;
	cout << endl;
	cout << "Physical Memory Details: " << endl;
	cout << "Type of your Physical Memory is: " << this->getType() << endl;
	cout << "Price of your Physical Memory is: " << this->pmgetPrice() << endl;
	cout << "capacity of your Physical Memory is: " << this->getpmCapacity() << endl;
	StorageDevice::printDetails();
}

StorageDevice::StorageDevice()
{
}
int StorageDevice::getdvCapacity()
{
	return this->dvcapacity;
}
void StorageDevice::setdvCapacity(int a)
{
	this->dvcapacity = a;
}
string StorageDevice::dvgetDeviceType()
{
	return this->dvtype;
}
void StorageDevice::dvsetDeviceType(string s)
{
	this->dvtype = s;
}
void StorageDevice::dvsetPrice(double p)
{
	this->dvprice = p;
}
double StorageDevice::dvgetPrice()
{
	return this->dvprice;
}
void StorageDevice::printDetails()
{
	cout << endl;
	cout << "Storage Device Details: " << endl;
	cout << "Type of your Storage Device is: " << this->dvgetDeviceType() << endl;
	cout << "Price of your Storage Device is: " << this->dvgetPrice() << endl;
	cout << "capacity of your Storage Device is: " << this->getdvCapacity() << endl;
}

MotherBoard::MotherBoard()
{
	int num = 0;
	cout << "Enter the amount of ports you want: ";
	cin >> this->numPorts;
	num = this->numPorts;

	ports = new Port[num];
}
void MotherBoard::getInput(int tell)
{
	for (int i = 0; i < numPorts; i++)
	{
		ports[i].getInput();
	}
}
void MotherBoard::setPrice(double a)
{
	this->price = a;
}
double MotherBoard::getPrice()
{
	return this->price;
}
void MotherBoard::printDetails()
{
	cout << endl;
	cout << "Motherboard details are: " << endl;
	mm.printDetails();
	cout << endl << endl;
	for (int i = 0; i < numPorts; i++) {
		cout << "Port " << (i+1) << " Details:" << endl;
		ports[i].printDetails();
		cout << endl;
	}
}

MainMemory::MainMemory()
{
	this->getInput();
}
void MainMemory::getInput()
{
	int val;
	cout << "Enter the capacity of your main memory (Range is 4GB to 128GB): " << endl;
	do
	{
		cin >> val;
	} while (!(val >= 4 && val <= 128));
	this->setcapacity(val);

	string s;
	cout << "Enter the techonolgy type of you main memory: " << endl;
	cout << "Possible values are  (semiconductor, silicon) " << endl;
	cin >> s;
	this->setTechnologyType(s);
}
int MainMemory::getcapacity()
{
	return this->capacity;
}
void MainMemory::setcapacity(int a)
{
	this->capacity = a;
}
string MainMemory::getTechnologyType()
{
	return this->technologyType;
}
void MainMemory::setTechnologyType(string s)
{
	this->technologyType = s;
}
void MainMemory::printDetails()
{
	cout << endl;
	cout << "Main Memory details are: " << endl;
	cout << "The techonolgy type of your main memory is: " << this->getTechnologyType() << endl;
	cout << "the capacity of your main memory is: " << this->getcapacity() << endl;

}

Port::Port()
{
}
void Port::getInput()
{
	cout << "Enter type of port: (i.e  VGI Port, I/O Port, USB Port, HDMI Port etc ): ";
	cin >> type;

	cout << "Enter baud rate: ";
	cin >> baud_rate;
}
string Port::getType()
{
	return type;
}
void Port::setType(string s)
{
	type = s;
}
int Port::getbaud_rate()
{
	return baud_rate;
}
void Port::setbaud_rate(int rate)
{
	baud_rate = rate;
}
void Port::printDetails()
{
	cout << "Type of Port: " << getType() << endl;
	cout << "Baud Rate: " << getbaud_rate() << endl;
}


CPU::CPU()
{
}
bool CPU::getInput(int a)
{
	int choice = 0;
	bool check = false;
	cout << "choose between Intel, AMD or AppleSilicon CPU" << endl;
	cout << "1-->Intel" << endl;
	cout << "2--> AMD" << endl;
	cout << "3--> AppleSilicon" << endl;
	cin >> choice;

	if ((a == 1 && (choice == 1 || choice == 2)) || (a == 2 && choice == 3))
	{
		check = true;
	}
	else
	{
		cout << "Oops! Entered a wrong component" << endl;
	}

	if (check)
	{
		switch (choice)
		{
		case 1:
			this->setPrice(30000);
			this->setType("Intel");
			break;

		case 2:
			this->setPrice(38000);
			this->setType("AMD");
			break;

		case 3:
			this->setPrice(45000);
			this->setType("AppleSilicon");
			break;

		default:
			cout << "invalid choice" << endl;
		}
	}

	return check;

	//if (a == 1)
	//{
	//	cout << "choose between Intel or AMD" << endl;
	//	cout << "1-->Intel" << endl;
	//	cout << "2--> AMD" << endl;
	//	do
	//	{
	//		cin >> choice;
	//	} while (!(choice == 1 || choice == 2));
	//	if (choice == 1)
	//	{
	//		this->setPrice(30000);
	//		this->setType("Intel");
	//	}
	//	else
	//	{
	//		this->setPrice(30000);
	//		this->setType("AMD");
	//	}
	//}
	//else if (a == 2)
	//{
	//	this->setPrice(45000);
	//	this->setType("AppleSilicon");
	//}
	//else
	//{
	//	cout << "invalid choice" << endl;
	//}
}
void CPU::setType(string t)
{
	this->type = t;
}
string CPU::getType()
{
	return this->type;
}
void CPU::setPrice(double p)
{
	this->price = p;
}
double CPU::getPrice()
{
	return this->price;
}
void CPU::printDetails()
{
	cout << "CPU details are: " << endl;
	cout << "The type of CPU is: " << this->getType() << endl;
	alu.printDetails();
	cu.printDetails();
	cout << "The price of CPU is: " << this->getPrice() << endl;
}

ALU::ALU()
{
	this->getInput();
}
void ALU::getInput()
{
	cout << endl;
	int num;
	cout << "Enter no of adders. Range is: 1-16"<<endl;
	do
	{
		cin >> num;
	} while (!(num >= 1 && num <= 16));
	this->setNoOfAdders(num);

	cout << "Enter no of subtarctors. Range is: 0-4" << endl;
	do
	{
		cin >> num;
	} while (!(num >= 0 && num <= 4));
	this->setNoOfSubtractor(num);

	cout << "Enter no of registors. Range is: 16-64" << endl;
	do
	{
		cin >> num;
	} while (!(num >= 16 && num <= 64));
	this->setNoOfRegisters(num);

	cout << "Enter type of registors. it's either 32bit or 64bit. choose one" << endl;
	do
	{
		cin >> num;
	} while (!(num == 32 || num == 64));
	this->setsizeOfRegisters(num);

}
int ALU::getNoOfAdders()
{
	return this->NoOfAdders;
}
int ALU::getNoOfSubtractor()
{
	return this->NoOfSubtractor;
}
int ALU::getNoOfRegisters()
{
	return this->NoOfRegisters;
}
int ALU::getsizeOfRegisters()
{
	return this->sizeOfRegisters;
}
void ALU::setNoOfAdders(int a)
{
	this->NoOfAdders = a;
}
void ALU::setNoOfSubtractor(int a)
{
	this->NoOfSubtractor = a;
}
void ALU::setNoOfRegisters(int a)
{
	this->NoOfRegisters = a;
}
void ALU::setsizeOfRegisters(int a)
{
	this->sizeOfRegisters = a;
}
void ALU::printDetails()
{
	cout << "ALU details are: " << endl;
	cout << "no of adders are: " << this->getNoOfAdders() << endl;
	cout << "no of subtactors are: " << this->getNoOfSubtractor() << endl;
	cout << "no of registors are: " << this->getNoOfRegisters() << endl;
	cout << "size of no of registors are: " << this->getsizeOfRegisters() << endl;
	//cout << "Current total price is: " << PC::getTotalPrice() << endl;
}

ControlUnit::ControlUnit()
{
	this->getInput();
}
void ControlUnit::getInput()
{
	float val;
	cout << "Enter the clock time value of control unit: ";
	cin >> val;
	this->setclock(val);
}
float ControlUnit::getclock()
{
	return this->clock;
}
void ControlUnit::setclock(float v)
{
	this->clock = v;
}
void ControlUnit::printDetails()
{
	cout << endl;
	cout << "Control Unit details are: " << endl;
	cout << "Control Unit details are: " << endl;
	cout << "Clock time is: " << this->getclock() << endl;
}

NetworkCard::NetworkCard()
{
}
//NetworkCard::NetworkCard(string t, int s, double p)
//{
//	this->type = t;
//	this->speed = s;
//	this->price = p;
//}
void NetworkCard::getInput(int)
{
	int choice = 0;
	cout << "Enter the network card type: " << endl;
	cout << "1--> NIC (Enthernet)" << endl;
	cout << "2--> Wireless NIC" << endl;
	cout << "3--> Fiber NIC" << endl;
	cout << "Enter the corresponding integer value to set it's price: ";
	do
	{
		cin >> choice;

	}while (!(choice == 1 || choice == 2 || choice == 3));
	switch (choice)
	{
	case 1: 
		this->price = 3000;
		this->setPrice(this->price);
		this->setSpeed(choice);
		this->setType("Ethernet");
		break;

	case 2: 
		this->price = 5000;
		this->setPrice(this->price);
		this->setSpeed(choice);
		this->setType("Wireless");
		break;

	case 3: 
		this->price = 10000;
		this->setPrice(this->price);
		this->setSpeed(choice);
		this->setType("Fiber");
		break;
	default:
		cout << "Error! You have not entered a valid input" << endl;
	}
}
void NetworkCard::setType(string name)
{
	this->type = name;
}
void NetworkCard::setSpeed(int choice)
{
	switch (choice)
	{
	case 1: this->speed = 100;
		break;
	case 2: this->speed = 500;
		break;
	case 3: this->speed = 1000;
		break;
	default:
		cout << "invalid choice!";
	}
}
double NetworkCard::getPrice()
{
	return this->price;
}
void NetworkCard::setPrice(double p)
{
	this->price = p;
}
string NetworkCard::getType()
{
	return this->type;
}
int NetworkCard::getSpeed()
{
	return this->speed;
}
void NetworkCard::printDetails()
{
	cout << "The type of you network card is: " << this->getType() << endl;
	cout << "The speed of your network card is: " << this->getSpeed() << endl;
	cout << "The price of your netwrok card is: " << this->getPrice() << endl;
	//cout << "Current total price is: " << PC::getTotalPrice() << endl;
}


Battery::Battery()
{
	this->capacity = 0;
}
//Battery::Battery(int c, ComputerAssembly*)
//{
//	this->capacity = c;
//}
void Battery::getInput(int)
{
	int num = 0;
	cout << "Enter the battery capcity you want to choose. (Make sure it lies between 30Wh to 100Wh): ";
	cout << endl;
	
	do
	{
		cin >> num;

	} while (!(num >= 30 && num <= 100));

	this->setCapacity(num);
	this->setPrice(8000);
}
int Battery::getCapacity()
{
	return this->capacity;
}
void Battery::setCapacity(int num)
{
	this->capacity = num;
}
double Battery::getPrice()
{
	return price;
}
void Battery::setPrice(double p)
{
	this->price = p;
}
void Battery::printDetails()
{
	cout << "The capacity of you battery is: " << this->getCapacity() << endl;
	cout << "The price of your battery is: " << this->getPrice() << endl;
}



PowerSupply::PowerSupply()
{

}
//PowerSupply::PowerSupply(int wat, string e_r, double pr, ComputerAssembly*)
//{
//	this->wattage = wat;
//	this->efficiencyRating = e_r;
//	this->price = pr;
//}
void PowerSupply::printDetails()
{
	cout << "The wattage of you PowerSupply is: " << this->getWattage() << endl;
	cout << "The efficiency rating of your PowerSupply is: " << this->getEfficiencyRating() << endl;
	cout << "The price of your PowerSupply is: " << this->getPrice() << endl;
}
void PowerSupply::getInput(int)
{
	int num;
	cout << "Enter the wattage between 250 Watts to 1200 Watts. Make sure to write the rounded off form." << endl;
	do
	{
		cin >> num;
	} while (!(num >= 250 && num <= 1200));
	this->setWattage(num);

	cout << "Enter the efficiency rating. Make sure to follow this syntax given below: " << endl;
	cout << "e.g: 80plusbronze, 80plussilver 80plusgold " << endl;
	cout << "NOTE: (price will be set accordingly): " << endl;

	string sent;

	cin >> sent;
	this->setEfficiencyRating(sent);

	if (this->getEfficiencyRating() == "80plusbronze")
	{
		this->setPrice(5000);
		//this->computerAssembly->setTotalPrice(this->getPrice());
	}
	else if (this->getEfficiencyRating() == "80plussilver")
	{
		this->setPrice(7000);
		//this->computerAssembly->setTotalPrice(this->getPrice());
	}
	else if (this->getEfficiencyRating() == "80plusgold")
	{
		this->setPrice(9000);
		//this->computerAssembly->setTotalPrice(this->getPrice());
	}
	else
	{
		cout << "rating is invalid" << endl;
	}
}
int PowerSupply::getWattage()
{
	return this->wattage;
}
void PowerSupply::setWattage(int wat)
{
	this->wattage = wat;
}
string PowerSupply::getEfficiencyRating()
{
	return this->efficiencyRating;
}
void PowerSupply::setEfficiencyRating(string s)
{
	this->efficiencyRating = s;
}
double PowerSupply::getPrice()
{
	return this->price;
}
void PowerSupply::setPrice(double p)
{
	this->price = p;
}

GraphicsCard::GraphicsCard()
{
}
//GraphicsCard::GraphicsCard(string bd, int ms, double p)
//{
//	brand = bd;
//	memorySize = ms;
//	price = p;
//}
bool GraphicsCard::getInput(int tell)
{
	cout << tell;
	int choice = 0;
	bool check = false;
	cout << "Enter the GPU you want for your computer according to the given list. Enter an integer." << endl;
	cout << "1--> Nvidia" << endl;
	cout << "2--> AMD" << endl;
	cout << "3--> AppleGPU" << endl;
	do
	{
		cin >> choice;
	} while (!(choice == 1 || choice == 2 || choice == 3));

	if ((tell == 1 && (choice == 1 || choice == 2)) || (tell == 2 && choice == 3))
	{
		check = true;
	}
	else
	{
		cout << "Oops! Entered a wrong component" << endl;
	}

	if(check)
	{
		switch (choice)
		{
		case 1:
		{
			this->setBrand("Nvidia");
			this->setPrice(100000);

			cout << "Entery the memory of graphic card you want " << endl << "NOTE: (keep it between 2 and 24)" << endl;
			do
			{
				cin >> tell;

			} while (!(tell >= 2 && tell <= 24));
			this->setMemorySize(tell);
			break;
		}

		case 2:
		{
			this->setBrand("AMD");
			this->setPrice(125000);
			tell = 0;
			cout << "Entery the memory of graphic card you want " << endl << "NOTE: (keep it between 2 and 24)" << endl;
			do
			{
				cin >> tell;

			} while (!(tell >= 2 && tell <= 24));
			this->setMemorySize(tell);
			break;
		}
		case 3:
		{
			this->setBrand("AppleGPU");
			this->setPrice(125000);

			cout << "Entery the memory of graphic card you want " << endl << "NOTE: (keep it between 2 and 24)" << endl;
			do
			{
				cin >> tell;

			} while (!(tell >= 2 && tell <= 24));
			this->setMemorySize(tell);
			break;
		}
		default:
			cout << "Invalid Input" << endl;
			break;
		}
	}

	return check;
}
void GraphicsCard::setBrand(string bd)
{
	this->brand = bd;
}
void GraphicsCard::setMemorySize(int size)
{
	this->memorySize = size;
}
void GraphicsCard::setPrice(double pr)
{
	this->price = pr;
}
double GraphicsCard::getPrice()
{
	return this->price;
}
string GraphicsCard::getBrand()
{
	return this->brand;
}
int GraphicsCard::getMemorySize()
{
	return this->memorySize;
}
void GraphicsCard::printDetails()
{
	cout << "The brand of you graphic card is: " << this->getBrand() << endl;
	cout << "The memory size of your graphic card is: " << this->getMemorySize() << endl;
	cout << "The price of your netwrok card is: " << this->getPrice() << endl;
}

Case::Case()
{

}
//Case::Case(string, string)
//{
//
//}
void Case::getInput()
{
	string set;
	cout << "which form factor of case do you want? " << endl;
	cout << "e.g ATX, MicroATX" << endl;
	cin >> set;
	this->setformFactor(set);

	cout << "Also enter a valid color for your case: " << endl;
	cin >> set;
	this->setcolor(set);

	this->setPrice(7000);
}
string Case::getformFactor()
{
	return formFactor;
}
string Case::getcolor()
{
	return color;
}
double Case::getPrice()
{
	return price;
}
void Case::setPrice(double p)
{
	this->price = p;
}
void Case::setformFactor(string s)
{
	this->formFactor = s;
}
void Case::setcolor(string s)
{
	this->color = s;
}
void Case::printDetails()
{
	cout << "The form factor of you case is: " << this->getformFactor() << endl;
	cout << "The color of your case is: " << this->getcolor() << endl;
	cout << "The price of your case is: " << this->getPrice() << endl;
}








