/*Muhammad Abdullah
CS-E
23I-0521
Marium Hida
Muhammad Abdur Rafey*/


#include<iostream>
using namespace std;
#include"Header.h"

int main()
{
    ComputerAssembly A1;

    A1.setupComputerAssembly();

    A1.display();

    return 0;
}
