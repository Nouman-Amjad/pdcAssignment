#pragma once
#include<iostream>
using namespace std;

class ALU
{
	int myNoOfAdders;
	int myNoOfSubtractor;
	int myNoOfRegisters;
	int mysizeOfRegisters;
public:
	ALU()
	{
		myNoOfAdders = 0;
		myNoOfSubtractor = 0;
		myNoOfRegisters = 0;
		mysizeOfRegisters = 0;
	}

	ALU(int theAdder, int theSubtractor, int theRegister1, int theSize)
	{
		myNoOfAdders = theAdder;
		myNoOfSubtractor = theSubtractor;
		myNoOfRegisters = theRegister1;
		mysizeOfRegisters = theSize;
	}

	int getNoOfAdders() const
	{
		return myNoOfAdders;
	}
	int getNoOfSubtractors() const
	{
		return myNoOfSubtractor;
	}
	int getNoOfRegisters() const
	{
		return myNoOfRegisters;
	}
	int getSizeOfRegisters() const
	{
		return mysizeOfRegisters;
	}

	void setNoOfAdders(int adders)
	{
		myNoOfAdders = adders;
	}
	void setNoOfSubtractors(int subtractors)
	{
		myNoOfSubtractor = subtractors;
	}
	void setNoOfRegisters(int registers)
	{
		myNoOfRegisters = registers;
	}
	void setSizeOfRegisters(int size)
	{
		mysizeOfRegisters = size;
	}
};

class ControlUnit
{
	float myClock;

public:
	ControlUnit()
	{
		myClock = 0.0;
	}

	ControlUnit(float theClock)
	{
		myClock = theClock;
	}

	float getClock() const
	{
		return myClock;
	}

	void setClock(float theClock)
	{
		myClock = theClock;
	}
};

class CPU
{
	ALU myALU;
	ControlUnit myControlUnit;

public:
	CPU() {}

	CPU(ALU thisALU, ControlUnit thisControlUnit)
	{
		myALU = thisALU;
		myControlUnit = thisControlUnit;
	}

	ALU getALU() const
	{
		return myALU;
	}

	void setALU(ALU theALU)
	{
		myALU = theALU;
	}

	ControlUnit getControlUnit() const
	{
		return myControlUnit;
	}

	void setControlUnit(ControlUnit theControlUnit)
	{
		myControlUnit = theControlUnit;
	}
};

class MainMemory
{
	int myCapacity;
	string myTechnologyType;

public:
	MainMemory()
	{
		myCapacity = 0;
		myTechnologyType = "Semiconductor";
	}

	MainMemory(int theCapacity, string theTechnologyType)
	{
		myCapacity = theCapacity;
		myTechnologyType = theTechnologyType;
	}

	int getCapacity() const
	{
		return myCapacity;
	}
	string getTechnologyType() const
	{
		return myTechnologyType;
	}

	void setCapacity(int theCapacity)
	{
		myCapacity = theCapacity;
	}
	void setTechnologyType(string theTechnologyType)
	{
		myTechnologyType = theTechnologyType;
	}
};

class Port
{
	string myType;
	int myBaudRate;

public:
	Port()
	{
		myType = "VGI Port";
		myBaudRate = 9600;
	}

	Port(string theType, int theRate)
	{
		myType = theType;
		myBaudRate = theRate;
	}

	string getType() const
	{
		return myType;
	}
	int getBaudRate() const
	{
		return myBaudRate;
	}

	void setType(string theType)
	{
		myType = theType;
	}
	void setBaudRate(int theRate)
	{
		myBaudRate = theRate;
	}
};

class MotherBoard
{
	MainMemory myMainMemory;
	Port myPorts[10];

public:
	MotherBoard() {}

	MotherBoard(MainMemory theMainMemory, const Port* thePorts)
	{
		myMainMemory = theMainMemory;

		for (int i = 0; i < 10; i++)
		{
			myPorts[i] = thePorts[i];
		}
	}

	MainMemory getMainMemory() const
	{
		return myMainMemory;
	}

	void setMainMemory(MainMemory theMainMemory)
	{
		myMainMemory = theMainMemory;
	}

	const Port* getPorts() const 
	{ 
		return myPorts;
	}

	void setPorts(Port* thePorts)
	{
		for (int i = 0; i < 10; ++i)
		{
			myPorts[i] = thePorts[i];
		}
	}
};

class PhysicalMemory
{
	int myCapacity;

public:
	PhysicalMemory()
	{
		myCapacity = 0;
	}

	PhysicalMemory(int theCapacity)
	{
		myCapacity = theCapacity;
	}

	int getCapacity() const 
	{
		return myCapacity;
	}

	void setCapacity(int theCapacity) 
	{
		myCapacity = theCapacity;
	}
};

class Computer 
{
private:
	PhysicalMemory myPhysicalMemory;
	MotherBoard myMotherBoard;
	CPU myCPU;

public:
	
	Computer() {}

	Computer(PhysicalMemory mem, MotherBoard mb, CPU cpu)
	{
		myPhysicalMemory = mem;
		myMotherBoard = mb;
		myCPU = cpu;
	}

	// Getters for components
	PhysicalMemory getPhysicalMemory() const {
		return myPhysicalMemory;
	}

	MotherBoard getMotherBoard() const {
		return myMotherBoard;
	}

	CPU getCPU() const {
		return myCPU;
	}

	// Setters for components
	void setPhysicalMemory(PhysicalMemory mem) {
		myPhysicalMemory = mem;
	}

	void setMotherBoard(MotherBoard mb) {
		myMotherBoard = mb;
	}

	void setCPU(CPU cpu) {
		myCPU = cpu;
	}
};

class GraphicsCard 
{
private:
	string myBrand;
	int myMemorySize;
	double myPrice;

public:
	GraphicsCard()
	{
		myBrand = "";
		myMemorySize = 0;
		myPrice = 0.0;

	}

	GraphicsCard(string theBrand, int theSize, double thePrice)
	{
		myBrand = theBrand;
		myMemorySize = theSize;
		myPrice = thePrice;
	}

	string getBrand() const
	{
		return myBrand;
	}
	int getMemorySize() const
	{
		return myMemorySize;
	}
	double getPrice() const
	{
		return myPrice;
	}

	void setBrand(string theBrand)
	{
		myBrand = theBrand;
	}
	void setMemorySize(int theSize)
	{
		myMemorySize = theSize;
	}
	void setPrice(double thePrice)
	{
		myPrice = thePrice;
	}
};

class StorageDevice
{
private:
	string myType;
	int myCapacity;
	double myPrice;

public:
	StorageDevice()
	{
		myType = "";
		myCapacity = 0;
		myPrice = 0.0;
	}

	StorageDevice(string theType, int theCapacity, double thePrice)
	{
		myType = theType;
		myCapacity = theCapacity;
		myPrice = thePrice;
	}

	string getType() const
	{
		return myType;
	}
	int getCapacity() const
	{
		return myCapacity;
	}
	double getPrice() const
	{
		return myPrice;
	}

	void setType(string theType)
	{
		myType = theType;
	}
	void setCapacity(int theCapacity)
	{
		myCapacity = theCapacity;
	}
	void setPrice(double thePrice)
	{
		myPrice = thePrice;
	}
};

class NetworkCard
{
private:
	string myType;
	int mySpeed;
	double myPrice;

public:
	NetworkCard()
	{
		myType = "";
		mySpeed = 0;
		myPrice = 0.0;
	}

	NetworkCard(string theType, int theSpeed, double thePrice)
	{
		myType = theType;
		mySpeed = theSpeed;
		myPrice = thePrice;
	}

	string getType() const
	{
		return myType;
	}
	int getSpeed() const
	{
		return mySpeed;
	}
	double getPrice() const
	{
		return myPrice;
	}

	void setType( string theType)
	{
		myType = theType;
	}
	void setSpeed(int theSpeed)
	{
		mySpeed = theSpeed;
	}
	void setPrice(double thePrice)
	{
		myPrice = thePrice;
	}
};

class PowerSupply
{
private:
	int myWattage;
	string myEfficiencyRating;
	double myPrice;

public:
	PowerSupply()
	{
		myWattage = 0;
		myEfficiencyRating = "";
		myPrice = 0.0;
	}
	PowerSupply(int theWattage, string theEfficiencyRating, double thePrice)
	{
		myWattage = theWattage;
		myEfficiencyRating = theEfficiencyRating;
		myPrice = thePrice;
	}

	int getWattage() const
	{
		return myWattage;
	}
	string getEfficiencyRating() const
	{
		return myEfficiencyRating;
	}
	double getPrice() const
	{
		return myPrice;
	}

	void setWattage(int theWattage)
	{
		myWattage = theWattage;
	}
	void setEfficiencyRating(string theEfficiencyRating)
	{
		myEfficiencyRating = theEfficiencyRating;
	}
	void setPrice(double thePrice)
	{
		myPrice = thePrice;
	}
};

class Battery
{
private:
	int myCapacity;

public:
	Battery()
	{
		myCapacity = 0;
	}

	Battery(int theCapacity)
	{
		myCapacity = theCapacity;
	}

	int getCapacity() const
	{
		return myCapacity;
	}

	void setCapacity(int theCapacity)
	{
		myCapacity = theCapacity;
	}
};

class Case
{
private:
	string myFormFactor;
	string myColor;

public:
	Case()
	{
		myFormFactor = "";
		myColor = "";
	}

	Case(string theFormFactor, string theColor)
	{
		myFormFactor = theFormFactor;
		myColor = theColor;
	}

	string getFormFactor() const
	{
		return myFormFactor;
	}
	string getColor() const
	{
		return myColor;
	}

	void setFormFactor(string myFormFactor)
	{
		myFormFactor = myFormFactor;
	}
	void setColor(string theColor)
	{
		myColor = theColor;
	}
};

class ComputerAssembly 
{
private:
	double myPrice;
	CPU myCPU;
	MotherBoard myMotherBoard;
	PhysicalMemory myPhysicalMemory;
	GraphicsCard myGraphicsCard;
	StorageDevice myStorageDevice;
	NetworkCard myNetworkCard;
	PowerSupply myPowerSupply;
	Battery myBattery;
	Case myCase;

public:
	ComputerAssembly()
	{
		myPrice = 0.0;
	}
	int checkDevice = 0;
	
	double getTotalPrice() const
	{
		return myPrice;
	}

	void setupComputerAssembly()
	{
		cout << "Choose the Device : \n1)Computer\n2)Mac\n\nEnter 1 or 2 : ";
		do {
			cin >> checkDevice;
			if (checkDevice != 1 && checkDevice != 2)
			{
				cout << "Invalid Input\nTry Again\n";
			}
		} while (checkDevice != 1 && checkDevice != 2);

		// Inputs for CPU
		int theAdders, theSubtractors, theRegisters, theSize;
		do {
			cout << "\nEnter number of adders : ";
			cin >> theAdders;
			cout << "Enter number of subtractors : ";
			cin >> theSubtractors;
			cout << "Enter number of registers : ";
			cin >> theRegisters;
			cout << "Enter size of registers (Bits): ";
			cin >> theSize;

			if (theAdders <= 0 || theSubtractors <= 0 || theRegisters <= 0 || theSize <= 0)
			{
				cout << "\nInvalid Input\nInput can't be 0 or less\nTry Again\n";
			}
		} while (theAdders <= 0 || theSubtractors <= 0 || theRegisters <= 0 || theSize <= 0);

		ALU alu(theAdders, theSubtractors, theRegisters, theSize);

		float theClock;
		do {
			cout << "\nEnter clock speed (GHz): ";
			cin >> theClock;

			if (theClock <= 0)
			{
				cout << "\nInvalid Input\nInput can't be 0 or less\nTry Again\n";
			}
		} while (theClock <= 0);

		ControlUnit cu(theClock);

		myCPU = CPU(alu, cu);

		//Inputs for Main Memory
		int theCapacity;
		string theTechnology;
		Port thePort[10];
		int checkTechnology;
		do {
			cout << "\nEnter capacity of main memory (Gb): ";
			cin >> theCapacity;
			if (theCapacity <= 0)
			{
				cout << "\nInvalid Input\nInput can't be 0 or less\nTry Again\n";
			}
		} while (theCapacity <= 0);

		do {
			cout << "\nEnter technology type of main memory : \n1)Semiconductor\n2)Silicon\nEnter 1 or 2 : ";
			cin >> checkTechnology;
			if (checkTechnology == 1)
				theTechnology = "Semiconductor";
			else if (checkTechnology == 2)
				theTechnology = "Silicon";
			else
				cout << "Invalid Input\nTry Again\n";
		} while (checkTechnology != 1 && checkTechnology != 2);

		//Inputs for Ports
		for (int i = 0; i < 10; ++i) {
			int checkPort;
			do {
				cout << "\nEnter the type of port " << i + 1 << " for main memory : \n1) VGA Port\n2) I/O Port\n3) USB Port\n4) HDMI Port\nEnter 1, 2, 3, or 4: ";
				cin >> checkPort;
				if (checkPort < 1 || checkPort > 4)
				{
					cout << "\nInvalid Input\nPlease enter a number between 1 and 4\n";
				}
			} while (checkPort < 1 || checkPort > 4);

			string thePortType;
			int theRate = 0;;
			switch (checkPort) {
			case 1:
				thePortType = "VGA Port";
				theRate = 9600;
				break;
			case 2:
				thePortType = "I/O Port";
				theRate = 1200;
				break;
			case 3:
				thePortType = "USB Port";
				theRate = 11500;
				break;
			case 4:
				thePortType = "HDMI Port";
				theRate = 10000;
				break;
			default:
				cout << "\nInvalid Input\n";
				break;
			}

			thePort[i] = Port(thePortType,theRate);
		}

		myMotherBoard = MotherBoard(MainMemory(theCapacity, theTechnology), thePort);

		//Inputs for Physical Memory
		do {
			cout << "\nEnter capacity of physical memory (Gb): ";
			cin >> theCapacity;
			if (theCapacity <= 0)
			{
				cout << "\nInvalid Input\nInput can't be 0 or less\nTry Again\n";
			}
		} while (theCapacity <= 0);

		myPhysicalMemory = PhysicalMemory(theCapacity);

		//Inputs for Graphics Card
		string theBrand;
		int theMemorySize;
		double thePrice;

		int checkBrand;
		do {
			cout << "\nEnter brand of graphics card : \n1) Nvidia\n2) AMD\n3) AppleGPU\nEnter 1, 2, or 3: ";
			cin >> checkBrand;
			if (checkBrand != 1 && checkBrand != 2 && checkBrand != 3)
			{
				cout << "\nInvalid Input\nPlease enter 1, 2, or 3\n";
			}
		} while (checkBrand != 1 && checkBrand != 2 && checkBrand != 3);

		if (checkBrand == 1) {
			theBrand = "Nvidia";
			thePrice = 600;
		}
		else if (checkBrand == 2) {
			theBrand = "AMD";
			thePrice = 500;
		}
		else if (checkBrand == 3) {
			theBrand = "AppleGPU";
			thePrice = 800;
		}

		do {
			cout << "\nEnter memory size of graphics card (Gb): ";
			cin >> theMemorySize;
			if (theMemorySize <= 0)
			{
				cout << "\nInvalid Input\nMemory size must be greater than 0\nTry Again\n";
			}
		} while (theMemorySize <= 0);

		myPrice += thePrice;
		myGraphicsCard = GraphicsCard(theBrand, theMemorySize, thePrice);

		//Inputs for Storage Device
		string theType;
		int checkStorage;
		do {
			cout << "\nEnter type of storage device : \n1) HDD\n2) SSD\nEnter 1 or 2: ";
			cin >> checkStorage;
			if (checkStorage != 1 && checkStorage != 2)
			{
				cout << "\nInvalid Input\nPlease enter 1 or 2\n";
			}
		} while (checkStorage != 1 && checkStorage != 2);

		if (checkStorage == 1) {
			theType = "HDD";
			thePrice = 350;
		}
		else if (checkStorage == 2) {
			theType = "SSD";
			thePrice = 500;
		}

		do {
			cout << "\nEnter capacity of storage device (Gb): ";
			cin >> theCapacity;
			if (theCapacity <= 0)
			{
				cout << "\nInvalid Input\nCapacity must be greater than 0\nTry Again\n";
			}
		} while (theCapacity <= 0);

		myPrice += thePrice;
		myStorageDevice = StorageDevice(theType, theCapacity, thePrice);

		//Inputs for Network Card
		int theSpeed;
		do {
			cout << "\nEnter type of network card : \n1) Ethernet\n2) WiFi\nEnter 1 or 2: ";
			int checkNetwork;
			cin >> checkNetwork;
			if (checkNetwork == 1)
				theType = "Ethernet";
			else if (checkNetwork == 2)
				theType = "WiFi";
			else
				cout << "\nInvalid Input\nPlease enter 1 or 2\n";
		} while (theType != "Ethernet" && theType != "WiFi");

		do {
			cout << "\nEnter speed of network card (Gb/sec): ";
			cin >> theSpeed;
			if (theSpeed <= 0)
			{
				cout << "\nInvalid Input\nSpeed must be greater than 0\nTry Again\n";
			}
		} while (theSpeed <= 0);

		thePrice = 500;
		myPrice += thePrice;
		myNetworkCard = NetworkCard(theType, theSpeed, thePrice);

		//Inputs for Power Supply
		string theEfficiencyRating;
		int theWattage;

		do {
			cout << "\nEnter wattage of power supply (W): ";
			cin >> theWattage;
			if (theWattage <= 0)
			{
				cout << "\nInvalid Input\nWattage can't be 0 or less\nTry Again\n";
			}
		} while (theWattage <= 0);

		int checkEfficiency;
		do {
			cout << "\nEnter efficiency rating of power supply: \n1) 80 Plus Bronze\n2) 80 Plus Gold\nEnter 1 or 2: ";
			cin >> checkEfficiency;
			if (checkEfficiency == 1)
			{
				theEfficiencyRating = "80 Plus Bronze";
				thePrice = 150;
			}
			else if (checkEfficiency == 2)
			{
				theEfficiencyRating = "80 Plus Gold";
				thePrice = 300;
			}
			else
				cout << "\nInvalid Input\nPlease enter 1 or 2\n";
		} while (checkEfficiency != 1 && checkEfficiency != 2);

		myPrice += thePrice;
		myPowerSupply = PowerSupply(theWattage, theEfficiencyRating, thePrice);


		//Inputs for Battery
		if (checkDevice == 2) 
		{
			do {
				cout << "\nEnter capacity of battery (mAh): ";
				cin >> theCapacity;
				if (theCapacity <= 0)
				{
					cout << "\nInvalid Input\nInput can't be 0 or less\nTry Again\n";
				}
			} while (theCapacity <= 0);
			myBattery = Battery(theCapacity);
		}
		//Inputs for Case
		string theFormFactor, color;
		int checkFormFactor, checkColor;

		if (checkDevice == 1) 
		{
			do {
				cout << "\nEnter form factor of case : \n1) ATX\n2) Micro ATX\nEnter 1 or 2 : ";
				cin >> checkFormFactor;
				if (checkFormFactor == 1)
				{
					theFormFactor = "ATX";
					thePrice = 100;
				}
				else if (checkFormFactor == 2)
				{
					theFormFactor = "Micro ATX";
					thePrice = 80;
				}
				else
					cout << "Invalid Input\nTry Again\n";
			} while (checkFormFactor != 1 && checkFormFactor != 2);

			do {
				cout << "\nEnter color of case : \n1) Black\n2) White\nEnter 1 or 2 : ";
				cin >> checkColor;
				if (checkColor == 1)
					color = "Black";
				else if (checkColor == 2)
					color = "White";
				else
					cout << "Invalid Input\nTry Again\n";
			} while (checkColor != 1 && checkColor != 2);

			myPrice += thePrice;
			myCase = Case(theFormFactor, color);

			myPrice += 1000;
		}
	}

	void display() const
	{
		cout << "\n\nComputer Assembly Details :\n";

		if(checkDevice==1)
		cout << "\nCPU : Intel\n";
		else if(checkDevice==2)
			cout << "\nCPU : AppleSilicon\n";
		cout << "ALU -> Adders: " << myCPU.getALU().getNoOfAdders() << endl;
		cout << "ALU -> Subtractors: " << myCPU.getALU().getNoOfSubtractors() << endl;
		cout << "ALU -> Registers: " << myCPU.getALU().getNoOfRegisters() << endl;
		cout << "ALU -> Size of Registers: " << myCPU.getALU().getSizeOfRegisters() << endl;
		cout << "Control Unit -> Clock Speed: " << myCPU.getControlUnit().getClock() << " Bits"<< endl;

		cout << "\nMotherboard :\n";
		cout << "Main Memory - Capacity: " << myMotherBoard.getMainMemory().getCapacity() << " Gb" << endl;
		cout << "Main Memory - Technology Type: " << myMotherBoard.getMainMemory().getTechnologyType() << endl;
		cout << "\nPorts:\n";
		const Port* ports = myMotherBoard.getPorts();
		for (int i = 0; i < 10; ++i) 
		{
				cout << "\nPort " << i + 1 << " Type: " << ports[i].getType() << endl;
				cout << "Port " << i + 1 << " Baud Rate: " << ports[i].getBaudRate() << endl;
		}

		cout << "\nPhysical Memory:\n";
		cout << "Capacity: " << myPhysicalMemory.getCapacity() << " Gb" << endl;

		cout << "\nGraphics Card:\n";
		cout << "Brand: " << myGraphicsCard.getBrand() << endl;
		cout << "Memory Size: " << myGraphicsCard.getMemorySize() << " Gb" << endl;
		cout << "Price: $" << myGraphicsCard.getPrice() << endl;

		cout << "\nStorage Device:\n";
		cout << "Type: " << myStorageDevice.getType() << endl;
		cout << "Capacity: " << myStorageDevice.getCapacity() << " Gb" << endl;;
		cout << "Price: $" << myStorageDevice.getPrice() << endl;

		cout << "\nNetwork Card:\n";
		cout << "Type: " << myNetworkCard.getType() << endl;
		cout << "Speed: " << myNetworkCard.getSpeed() << " Gb/sec" << endl;
		cout << "Price: $" << myNetworkCard.getPrice() << endl;

		cout << "\nPower Supply:\n";
		cout << "Wattage: " << myPowerSupply.getWattage() << " W" << endl;
		cout << "Efficiency Rating: " << myPowerSupply.getEfficiencyRating() << endl;
		cout << "Price: $" << myPowerSupply.getPrice() << endl;

		if (checkDevice == 2)
		{
			cout << "\nBattery:\n";
			cout << "Capacity: " << myBattery.getCapacity() << " mAh" << endl;
		}
		else if (checkDevice == 1)
		{
			cout << "\nCase:\n";
			cout << "Form Factor: " << myCase.getFormFactor() << endl;
			cout << "Color: " << myCase.getColor() << endl;
		}
		cout << "\n\nTotal Price : $" << myPrice << endl;
	}
};
