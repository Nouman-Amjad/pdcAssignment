//Section     : E
//Roll number : 23i-0023
//Instructor  : Ma'am Marium Hida
//TA          : Muhammad Abdur Rafey , Ali Naveed

#include <iostream>
#include <string>
#include "Header.h"
using namespace std;

int main() {
    int c = 0;
    int s = 0;
    bool flag = true;

    while (flag == true) {

        int choice;
        cout << "Enter 1 for Mac or 2 for PC: ";
        cin >> choice;
        while (choice != 1 && choice != 2) {
            cout << "Enter 1 for Mac or 2 for PC: ";
            cin >> choice;
        }

        if (choice == 1) {

            // ALU
            int a, s, r, rs;
            cout << "Enter the number of adders                                : ";
            cin >> a;
            cout << "Enter the number of subtractors                           : ";
            cin >> s;
            cout << "Enter the number of registers                             : ";
            cin >> r;
            cout << "Enter the size of registers                               : ";
            cin >> rs;
            ALU alu(a, s, r, rs);

            // Control Unit
            float cl;
            cout << "Enter the clock speed                                     : ";
            cin >> cl;
            ControlUnit cu(cl);

            // CPU
            CPU cpu(&alu, &cu);
            string model;
            cout << "Enter Intel/Amd CPU model                                 : ";
            cin >> model;
            AppleSiliconCPU ac(cpu, model);
            
            // Main Memory
            int memCapacity;
            string memType;
            cout << "Enter the capacity of Main Memory (in GB)                 : ";
            cin >> memCapacity;
            cout << "Enter the technology type of Main Memory                  : ";
            cin >> memType;
            MainMemory mm(memCapacity, memType);

            // Ports
            Port ports[4];
            for (int i = 0; i < 4; ++i) {
                string portType;
                int baudRate;
                cout << "Enter the type of Port " << i + 1 << "                                  : ";
                cin >> portType;
                cout << "Enter the baud rate of Port " << i + 1 << "                             : ";
                cin >> baudRate;
                ports[i] = Port(portType, baudRate);
            }

            // Physical Memory
            int pc;
            cout << "Enter the capacity of Physical Memory (in GB)             : ";
            cin >> pc;
            PhysicalMemory pm(pc);

            // Motherboard
            MotherBoard mb(mm, ports);
            Computer Comp(&pm, &mb, &cpu);



            // Storage Device
            string st;
            int cap;
            double sp;
            cout << "Enter the type of storage device                          : ";
            cin >> st;
            cout << "Enter the capacity of the storage device (in GB)          : ";
            cin >> cap;
            cout << "Enter the price of the storage device                     : ";
            cin >> sp;
            StorageDevice storage(st, cap, sp);

            // Network Card
            string nt;
            int sP;
            double np;
            cout << "Enter the type of network card                            : ";
            cin >> nt;
            cout << "Enter the speed of the network card (in Mbps)             : ";
            cin >> sP;
            cout << "Enter the price of the network card                       : ";
            cin >> np;
            NetworkCard network(nt, sP, np);

            // Power Supply
            PowerSupply psu(0, "poty", 0.0);

            // Battery
            int batteryCapacity;
            cout << "Enter the capacity of the battery (in mAh)                : ";
            cin >> batteryCapacity;
            Battery battery(batteryCapacity);

            // Case
            string ff, cL;
            cout << "Enter the form factor of the case                         : ";
            cin >> ff;
            cout << "Enter the color of the case                               : ";
            cin >> cL;
            Case computerCase(ff, cL);

            // Graphics Card
            string b = "MacGpu";
            GraphicsCard gpu(b);

            // Computer Assembly
            double tp;
            tp = np + sp ;
            ComputerAssembly computerAssembly(&Comp, &gpu, &storage, &network, &psu, &battery, &computerCase, tp);

            // Display specifications and price of the computer assembly
            cout << "\nComputer Assembly Specifications for Computer " << ++c << ":\n";
            //Comp.displayComputer();
            computerAssembly.displayComputerAssembly();

            
        }
        else {
            // ALU
            int a, s, r, rs;
            cout << "Enter the number of adders                                : ";
            cin >> a;
            cout << "Enter the number of subtractors                           : ";
            cin >> s;
            cout << "Enter the number of registers                             : ";
            cin >> r;
            cout << "Enter the size of registers                               : ";
            cin >> rs;
            ALU alu(a, s, r, rs);

            // Control Unit
            float cl;
            cout << "Enter the clock speed                                     : ";
            cin >> cl;
            ControlUnit cu(cl);

            // CPU
            CPU cpu(&alu, &cu);
            string model;
            cout << "Enter Intel/Amd CPU model                                 : ";
            cin >> model;
            IntelCPU ic(cpu, model);

            // Main Memory
            int memCapacity;
            string memType;
            cout << "Enter the capacity of Main Memory (in GB)                 : ";
            cin >> memCapacity;
            cout << "Enter the technology type of Main Memory                  : ";
            cin >> memType;
            MainMemory mm(memCapacity, memType);

            // Ports
            Port ports[4];
            for (int i = 0; i < 4; ++i) {
                string portType;
                int baudRate;
                cout << "Enter the type of Port " << i + 1 << "                                  : ";
                cin >> portType;
                cout << "Enter the baud rate of Port " << i + 1 << "                             : ";
                cin >> baudRate;
                ports[i] = Port(portType, baudRate);
            }
            // Physical Memory
            int pc;
            cout << "Enter the capacity of Physical Memory (in GB)             : ";
            cin >> pc;
            PhysicalMemory pm(pc);

            // Motherboard
            MotherBoard mb(mm, ports);
            Computer Comp(&pm, &mb, &cpu);



            // Storage Device
            string st;
            int cap;
            double sp;
            cout << "Enter the type of storage device                          : ";
            cin >> st;
            cout << "Enter the capacity of the storage device (in GB)          : ";
            cin >> cap;
            cout << "Enter the price of the storage device                     : ";
            cin >> sp;
            StorageDevice storage(st, cap, sp);

            // Network Card
            string nt;
            int sP;
            double np;
            cout << "Enter the type of network card                            : ";
            cin >> nt;
            cout << "Enter the speed of the network card (in Mbps)             : ";
            cin >> sP;
            cout << "Enter the price of the network card                       : ";
            cin >> np;
            NetworkCard network(nt, sP, np);

            // Power Supply
            int w;
            string er;
            double pp;
            cout << "Enter the wattage of the power supply                     : ";
            cin >> w;
            cout << "Enter the efficiency rating of the power supply           : ";
            cin >> er;
            cout << "Enter the price of the power supply                       : ";
            cin >> pp;
            PowerSupply psu(w, er, pp);

            // Battery
            Battery battery(0);

            // Case
            string ff, cL;
            cout << "Enter the form factor of the case                         : ";
            cin >> ff;
            cout << "Enter the color of the case                               : ";
            cin >> cL;
            Case computerCase(ff, cL);

            // Graphics Card
            string b;
            int ms;
            double gp;
            cout << "Enter the brand of the graphics card                      : ";
            cin >> b;
            cout << "Enter the memory size of the graphics card (in GB)        : ";
            cin >> ms;
            cout << "Enter the price of the graphics card                      : ";
            cin >> gp;
            GraphicsCard gpu(b, ms, gp);

            // Computer Assembly
            double tp;
            tp = pp + np + sp  ;
            ComputerAssembly computerAssembly(&Comp,&gpu, &storage, &network, &psu, &battery, &computerCase, tp);

            // Display specifications and price of the computer assembly
            cout << "\nComputer Assembly Specifications for Computer " << ++c << ":\n";
            //Comp.displayComputer();
            computerAssembly.displayComputerAssembly();

        }

        cout << "\nPress any key if you want to add another computer? (Enter 0 to Exit): ";
        cin >> s;
        if (s == 0) {
            cout << "Program Finished";
            flag = false;
        }

    }

    return 0;
}