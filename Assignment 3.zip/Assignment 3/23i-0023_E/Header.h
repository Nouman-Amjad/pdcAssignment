//Section     : E
//Roll number : 23i-0023
//Instructor  : Ma'am Marium Hida
//TA          : Muhammad Abdur Rafey , Ali Naveed




#include <iostream>
#include <string>
using namespace std;

class ALU {
private:
    int NoOfAdders;
    int NoOfSubtractors;
    int NoOfRegisters;
    int SizeOfRegisters;
public:
    ALU() {
        int adders = 0;
        int subtractors = 0;
        int registers = 0;
        int size = 0;
    }

    ALU(int a, int s, int r, int S) :
        NoOfAdders(a), NoOfSubtractors(s), NoOfRegisters(r), SizeOfRegisters(S) {}

    int getNoOfAdders() const {
        return NoOfAdders;
    }

    int getNoOfSubtractors() const {
        return NoOfSubtractors;
    }

    int getNoOfRegisters() const {
        return NoOfRegisters;
    }

    int getSizeOfRegisters() const {
        return SizeOfRegisters;
    }

    void setNoOfAdders(int a) {
        NoOfAdders = a;
    }

    void setNoOfSubtractors(int s) {
        NoOfSubtractors = s;
    }

    void setNoOfRegisters(int r) {
        NoOfRegisters = r;
    }

    void setSizeOfRegisters(int s) {
        SizeOfRegisters = s;
    }
};

class ControlUnit {
private:
    float clock;
public:
    ControlUnit() {
        float clock = 0.0;
    }
    ControlUnit(float c) : clock(c) {}
    float getClock() const {
        return clock;
    }
    void setClock(float value) {
        clock = value;
    }
};

class CPU {
private:
    ALU* alu;
    ControlUnit* cu;

public:
    CPU() {
        ALU* alu = nullptr;
        ControlUnit* cu = nullptr;
    }

    CPU(ALU* a, ControlUnit* c) : alu(a), cu(c) {}

    ALU* getALU() const {
        return alu;
    }

    void setALU(ALU* a) {
        this->alu = a;
    }

    ControlUnit* getControlUnit() const {
        return cu;
    }

    void setControlUnit(ControlUnit* c) {
        this->cu = c;
    }
};

class IntelCPU : public CPU {
private:
    string model;
public:
    IntelCPU() {
        model = "";
    }
    IntelCPU(const CPU& b, const string& s) : CPU(b), model(s) {}

    string getSeries() const {
        return model;
    }

    void setSeries(const string& s) {
        model = s;
    }
};


class AppleSiliconCPU : public CPU {
private:
    string model = "MacGpu";

public:
    AppleSiliconCPU() {
        model = "MacGpu";
    }
    AppleSiliconCPU(const CPU& b, const string& m) : CPU(b), model(m) {}

    string getModel() const {
        return model;
    }

    void setModel(const string& m) {
        model = m;
    }
};

class Port {
private:
    string type;
    int baudRate;

public:
    Port() : type(""), baudRate(0) {}

    Port(const string& type, int baudRate) :
        type(type), baudRate(baudRate) {}

    string getType() const {
        return type;
    }

    void setType(const string& value) {
        type = value;
    }

    int getBaudRate() const {
        return baudRate;
    }

    void setBaudRate(int value) {
        baudRate = value;
    }
};

class MainMemory {
private:
    int capacity;
    string technologyType;

public:

    MainMemory() {
        int capacity = 0;
        string techType = nullptr;
    }

    MainMemory(int capacity, const string& techType) :
        capacity(capacity), technologyType(techType) {}

    int getCapacity() const {
        return capacity;
    }

    void setCapacity(int value) {
        capacity = value;
    }

    string getTechnologyType() const {
        return technologyType;
    }

    void setTechnologyType(const string& value) {
        technologyType = value;
    }
};

class PhysicalMemory {
private:
    int capacity;

public:
    PhysicalMemory() {
        int capacity = 0;
    }

    PhysicalMemory(int capacity) : capacity(capacity) {}

    int getCapacity() const {
        return capacity;
    }

    void setCapacity(int value) {
        capacity = value;
    }
};

class MotherBoard {
private:
    MainMemory mm;
    Port ports[4];

public:
    MotherBoard(const MainMemory& m, const Port* p) :
        mm(m) {
        if (p) {
            for (int i = 0; i < 4; ++i) {
                this->ports[i] = ports[i];
            }
        }
    }

    MainMemory getMainMemory() const {
        return mm;
    }

    void setMainMemory(const MainMemory& m) {
        mm = m;
    }

    Port getPort(int c) const {
        return ports[c];
    }

    void setPort(int c, const Port& p) {
        ports[c] = p;
    }
    void displayMotherBoard() const {
        cout << "Main Memory : \n";
        cout << "  - Main Memory Capacity                   : " << mm.getCapacity() << " GB" << endl;
        cout << "  - Main Memory Technology Type            : " << mm.getTechnologyType() << endl;
        cout << "Ports:" << endl;
        for (int i = 0; i < 4; ++i) {
            cout << "  - Port " << i + 1 << " Type        : " << ports[i].getType() << endl;
            cout << "  - Port " << i + 1 << " Baud Rate   : " << ports[i].getBaudRate() << endl;
        }
    }

};


class Computer
{
private:
    PhysicalMemory* pm;
    MotherBoard* mb;
    CPU* cpu;

public:
    Computer() {
        PhysicalMemory* pm = nullptr;
        MotherBoard* mb = nullptr;
        CPU* cpu = nullptr;
    }

    Computer(PhysicalMemory* pm, MotherBoard* mb, CPU* cpu) :
        pm(pm), mb(mb), cpu(cpu) {}

    PhysicalMemory* getPhysicalMemory() const {
        return pm;
    }

    void setPhysicalMemory(PhysicalMemory* m) {
        pm = m;
    }

    MotherBoard* getMotherBoard() const {
        return mb;
    }

    void setMotherBoard(MotherBoard* m) {
        mb = m;
    }

    CPU* getCPU() const {
        return cpu;
    }

    void setCPU(CPU* p) {
        cpu = p;
    }

    void displayComputer() const {

        cout << endl;
        if (pm) {
            cout << "Physical Memory Capacity: " << pm->getCapacity() << " GB" << endl;
        }
        if (mb) {
            mb->displayMotherBoard();
        }
        if (cpu) {
            ALU* alu = cpu->getALU();
            ControlUnit* cu = cpu->getControlUnit();
            if (alu) {
                cout << "ALU Specifications:" << endl;
                cout << "  - Number of Adders: " << alu->getNoOfAdders() << endl;
                cout << "  - Number of Subtractors: " << alu->getNoOfSubtractors() << endl;
                cout << "  - Number of Registers: " << alu->getNoOfRegisters() << endl;
                cout << "  - Size of Registers: " << alu->getSizeOfRegisters() << endl;
            }
            if (cu) {
                cout << "Control Unit Specifications:" << endl;
                cout << "  - Clock Speed: " << cu->getClock() << " GHz" << endl;
            }
        }
    }
};

class GraphicsCard {
private:
    string brand;
    int memorySize;
    double price;

public:
    GraphicsCard() {
        string brand = "";
        int memorySize = 0;
        double price = 0.0;
    }

    GraphicsCard(const string& b, int s, double p) :
        brand(b), memorySize(s), price(p) {}

    GraphicsCard(const string& b) :
        brand(b) {
        int memorySize = 0;
        double price = 0.0;
    }

    string getBrand() const {
        return brand;
    }

    void setBrand(const string& v) {
        brand = v;
    }

    int getMemorySize() const {
        return memorySize;
    }

    void setMemorySize(int v) {
        memorySize = v;
    }

    double getPrice() const {
        return price;
    }

    void setPrice(double v) {
        price = v;
    }
};

class StorageDevice {
private:
    string type;
    int capacity;
    double price;

public:
    StorageDevice() {
        string type = nullptr;
        int capacity = 0;
        double price = 0.0;

    }

    StorageDevice(const string& t, int c, double p) :
        type(t), capacity(c), price(p) {}

    string getType() const {
        return type;
    }

    void setType(const string& v) {
        type = v;
    }

    int getCapacity() const {
        return capacity;
    }

    void setCapacity(int v) {
        capacity = v;
    }

    double getPrice() const {
        return price;
    }

    void setPrice(double v) {
        price = v;
    }
};

class NetworkCard {
private:
    string type;
    int speed;
    double price;

public:
    NetworkCard() {
        string type = nullptr;
        int speed = 0;
        double price = 0.0;
    }

    NetworkCard(const string& t, int s, double p) :
        type(t), speed(s), price(p) {}

    string getType() const {
        return type;
    }

    void setType(const string& v) {
        type = v;
    }

    int getSpeed() const {
        return speed;
    }

    void setSpeed(int v) {
        speed = v;
    }

    double getPrice() const {
        return price;
    }

    void setPrice(double v) {
        price = v;
    }
};

class PowerSupply {
private:
    int wattage;
    string efficiencyRating;
    double price;

public:
    PowerSupply() {
        int wattage = 0;
        string efficiencyRating = nullptr;
        double price = 0.0;

    }

    PowerSupply(int w, const string& er, double p) :
        wattage(w), efficiencyRating(er), price(p) {}

    int getWattage() const {
        return wattage;
    }

    void setWattage(int v) {
        wattage = v;
    }

    string getEfficiencyRating() const {
        return efficiencyRating;
    }

    void setEfficiencyRating(const string& v) {
        efficiencyRating = v;
    }

    double getPrice() const {
        return price;
    }

    void setPrice(double v) {
        price = v;
    }
};
class Battery {
private:
    int capacity;

public:
    Battery() {
        int capacity = 0;
    }

    Battery(int c) : capacity(c) {}

    int getCapacity() const {
        return capacity;
    }

    void setCapacity(int v) {
        capacity = v;
    }
};

class Case {
private:
    string formFactor;
    string color;

public:
    Case() {
        string formFactor = nullptr;
        string color = nullptr;
    }

    Case(const string& f, const string& c) :
        formFactor(f), color(c) {}

    string getFormFactor() const {
        return formFactor;
    }

    void setFormFactor(const string& v) {
        formFactor = v;
    }

    string getColor() const {
        return color;
    }

    void setColor(const string& v) {
        color = v;
    }
};

class ComputerAssembly {
private:
    Computer* comp;
    GraphicsCard* gpu;
    StorageDevice* storage;
    NetworkCard* networkCard;
    PowerSupply* psu;
    Battery* battery;
    Case* computerCase;
    double totalPrice;

public:
    ComputerAssembly() {
        Computer* comp = nullptr;
        GraphicsCard* gpu = nullptr;
        StorageDevice* storage = nullptr;
        NetworkCard* networkCard = nullptr;
        PowerSupply* psu = nullptr;
        Battery* battery = nullptr;
        Case* computerCase = nullptr;
        double totalPrice = 0.0;
    }

    ComputerAssembly(Computer* co, GraphicsCard* g, StorageDevice* s, NetworkCard* n, PowerSupply* p, Battery* b, Case* c, double tp) :
        comp(co), gpu(g), storage(s), networkCard(n), psu(p), battery(b), computerCase(c), totalPrice(tp) {}

    Computer* getComputer() {
        return comp;
    }

    void setComputer(Computer* c) {
        comp = c;
    }

    GraphicsCard* getGraphicsCard() const {
        return gpu;
    }

    void setGraphicsCard(GraphicsCard* g) {
        gpu = g;
    }

    StorageDevice* getStorageDevice() const {
        return storage;
    }

    void setStorageDevice(StorageDevice* s) {
        storage = s;
    }

    NetworkCard* getNetworkCard() const {
        return networkCard;
    }

    void setNetworkCard(NetworkCard* n) {
        this->networkCard = n;
    }

    PowerSupply* getPowerSupply() const {
        return psu;
    }

    void setPowerSupply(PowerSupply* p) {
        psu = p;
    }

    Battery* getBattery() const {
        return battery;
    }

    void setBattery(Battery* b) {
        this->battery = b;
    }

    Case* getComputerCase() const {
        return computerCase;
    }

    void setComputerCase(Case* c) {
        this->computerCase = c;
    }

    double getTotalPrice() const {
        return totalPrice;
    }

    void setTotalPrice(double p) {
        totalPrice = p;
    }

    void displayComputerAssembly() const {
        cout << endl;

        cout << "Main Memory:" << endl;
        cout << "  - Capacity: " << comp->getMotherBoard()->getMainMemory().getCapacity() << " GB" << endl;
        cout << "  - Technology Type: " << comp->getMotherBoard()->getMainMemory().getTechnologyType() << endl;

        cout << "Physical Memory:" << endl;
        cout << "  - Capacity: " << comp->getPhysicalMemory()->getCapacity() << " GB" << endl;

        cout << "Graphics Card:" << endl;
        cout << "  - Brand: " << gpu->getBrand() << endl;
        if (gpu->getMemorySize() == 0) {
            cout << "  - Memory Size: " << gpu->getMemorySize() << " GB" << endl;
            cout << "  - Price: $" << gpu->getPrice() << endl;
        }

        cout << "Storage Device:" << endl;
        cout << "  - Type: " << storage->getType() << endl;
        cout << "  - Capacity: " << storage->getCapacity() << " GB" << endl;
        cout << "  - Price: $" << storage->getPrice() << endl;

        cout << "Network Card:" << endl;
        cout << "  - Type: " << networkCard->getType() << endl;
        cout << "  - Speed: " << networkCard->getSpeed() << " Mbps" << endl;
        cout << "  - Price: $" << networkCard->getPrice() << endl;

        if (psu->getWattage() != 0) {
            cout << "Power Supply:" << endl;
            cout << "  - Wattage: " << psu->getWattage() << " W" << endl;
            cout << "  - Efficiency Rating: " << psu->getEfficiencyRating() << endl;
            cout << "  - Price: $" << psu->getPrice() << endl;
        }

        if (battery->getCapacity() != 0) {
            cout << "Battery:" << endl;
            cout << "  - Capacity: " << battery->getCapacity() << " mAh" << endl;
        }

        cout << "Computer Case:" << endl;
        cout << "  - Form Factor: " << computerCase->getFormFactor() << endl;
        cout << "  - Color: " << computerCase->getColor() << endl;

        cout << "Total Price: $" << totalPrice << endl;
    }
};