#include "Mac.hxx"
#include "PC.hxx"

int main() {
	
	MotherBoard mb;
	GraphicsCard gc;
	StorageDevice sd;
	NetworkCard nc;
	PowerSupply ps;
	Battery btry;
	Case cs;

	bool built = false;

	while (!built) {
		int choice;
		cout << "PC or MAC? 1 OR 2?: ";
		cin >> choice;

		if (choice == 1) {
			IntelAMD cpu;
			DDR ddr;
			IntelAMDComputer computer1(&mb, &cpu, &ddr);
			PC myPC(&gc, &sd, &nc, &ps, &btry, &cs, &computer1);
			myPC.Input();
			if (myPC.Validation()) {
				myPC.Print();
				built = true;
			}
		}
		else if (choice==2){
			AppleSilicon acpu;
			LPDDR lpddr;
			AppleComputer computer2(&mb, &acpu, &lpddr);
			Mac myMac(&sd, &nc, &ps, &btry, &cs, &computer2);
			myMac.Input();
			if (myMac.Validation()) {
				myMac.Print();
				built = true;
			}
		}
	}


}