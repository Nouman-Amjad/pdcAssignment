#include "port.h"

port::port()
{
	this->name = "";
	this->baud_rate = 0;
}

port::port(string n, int rate)
{
	this->name = n;
	this->baud_rate = rate;
}

void port::setname(string n) 
{
	this->name = n;
}

void port::setrate(int n)
{
	this->baud_rate = n;
}

string port::getname()
{
	return name;
}

int port::getrate()
{
	return baud_rate;
}
