#pragma once
#include <iostream>
using namespace std;

class ALU {
	int NoOfAdders;
	int NoOfSubtractor;
	int NoOfRegisters;
	int sizeOfRegisters;
public:
	ALU();
	ALU(int add, int sub, int reg, int sizereg);
	void setadd(int add);
	void setsub(int sub);
	void setreg(int reg);
	void setsizereg(int sreg);
	int getadd();
	int getsub();
	int getreg();
	int getsizereg();
};


