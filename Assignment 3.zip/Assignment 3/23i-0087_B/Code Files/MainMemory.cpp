#include "MainMemory.h"

MainMemory::MainMemory()
{
	this->capacity = 0;
	this->n = "";
	this->price = 0;
}

MainMemory::MainMemory(int c, string n, double p)
{
	this->capacity = c;
	this->n = n;
	this->price = p;
}

void MainMemory::setcap(int c)
{
	this->capacity = c;
}

void MainMemory::setn(string temp)
{
	this->n = temp;
}

void MainMemory::setp(double p)
{
	this->price = p;
}

int MainMemory::getcap()
{
	return capacity;
}

string MainMemory::getn()
{
	return n;
}

double MainMemory::getp()
{
	return price;
}
