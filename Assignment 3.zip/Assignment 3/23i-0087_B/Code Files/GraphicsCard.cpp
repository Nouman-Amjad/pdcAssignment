#include "GraphicsCard.h"

GraphicsCard::GraphicsCard()
{
}

GraphicsCard::GraphicsCard(string b, int mem, double p)
{
	this->brand = b;
	this->memorySize = mem;
	this->price = p;
}

void GraphicsCard::setb(string b)
{
	this->brand = b;
}

void GraphicsCard::setmem(int m)
{
	this->memorySize = m;
}

void GraphicsCard::setp(int p)
{
	this->price = p;
}

string GraphicsCard::getb()
{
	return brand;
}

int GraphicsCard::getmem()
{
	return memorySize;
}

double GraphicsCard::getp()
{
	return memorySize*12;
}


