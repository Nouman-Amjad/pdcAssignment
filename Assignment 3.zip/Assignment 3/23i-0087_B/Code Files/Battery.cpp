#include "Battery.h"

Battery::Battery()
{
	this->capacity = 0;
}

Battery::Battery(int cap, double p)
{
	this->capacity = 0;
	this->price = 0;
}

void Battery::setcap(int cap)
{
	this->capacity = cap;
}

void Battery::setp(double p)
{
	this->price = p;
}

int Battery::getcap()
{
	return capacity;
}

double Battery::getp()
{
	return price;
}
