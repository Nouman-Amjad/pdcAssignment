#pragma once
#include "ComputerAssembly.h"

class StorageDevice {
	string type;
	int capacity; 
	double price;
public:
	StorageDevice();
	StorageDevice(string t, int cap, double p);
	void sett(string t);
	void setcap(int c);
	void setp(double p);
	string gett();
	int getcap();
	double getp();
};