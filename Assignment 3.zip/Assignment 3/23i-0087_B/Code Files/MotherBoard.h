#pragma once
#include "MainMemory.h"
#include "port.h"

class MotherBoard : public MainMemory, public port {
	MainMemory mainmemory;
	port* ports;
	int num;
	double price;
public:
	MotherBoard();
	MotherBoard(port* temp, MainMemory tempmm, int n); 
	void setmm(MainMemory temp);
	MainMemory getmm();
	double getp();
	void getport();
};



