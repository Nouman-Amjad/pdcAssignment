#include "PowerSupply.h"

PowerSupply::PowerSupply()
{
	this->wattage = 0;
	this->efficiencyRating = "";
	this->price = 0;
}

PowerSupply::PowerSupply(string er, int wat, double p)
{
	this->wattage = wat;
	this->efficiencyRating = er;
	this->price = p;
}

void PowerSupply::seter(string temp)
{
	this->efficiencyRating = temp;
}

void PowerSupply::setwat(int temp)
{
	this->wattage = temp;
}

void PowerSupply::setp(double temp)
{
	this->price = temp;
}

string PowerSupply::geter()
{
	return efficiencyRating;
}

int PowerSupply::getwat()
{
	return wattage;
}

double PowerSupply::getp()
{
	return price;
}
