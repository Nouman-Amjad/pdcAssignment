#pragma once
#include "ComputerAssembly.h"
class GraphicsCard {
	string brand;
	int memorySize;
	double price;
public:
	GraphicsCard();
	GraphicsCard(string b, int mem, double p);
	void setb(string b);
	void setmem(int m);
	void setp(int p);
	string getb();
	int getmem();
	double getp();
};