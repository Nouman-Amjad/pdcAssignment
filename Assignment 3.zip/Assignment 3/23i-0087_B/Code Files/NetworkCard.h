#pragma once
#include "ComputerAssembly.h"

class NetworkCard {
    string type; 
    int speed;
    double price;
public:
    NetworkCard();
    NetworkCard(string t, int s, double p);
    void sett(string t);
    void sets(int s);
    void setp(double p);
    string gett();
    int gets();
    double getp();
};