#include "StorageDevice.h"

StorageDevice::StorageDevice()
{
	type = "";
	capacity = 0;
	price = 0;
}

StorageDevice::StorageDevice(string t, int cap, double p)
{
	this->type = t;
	this->capacity = cap;
	this->price = p;
}

void StorageDevice::sett(string t)
{
	this->type = t;
}

void StorageDevice::setcap(int c)
{
	this->capacity = c;
}

void StorageDevice::setp(double p)
{
	this->price = p;
}

string StorageDevice::gett()
{
	return type;
}

int StorageDevice::getcap()
{
	return capacity;
}

double StorageDevice::getp()
{
	if (type == "HDD") 
	{
		return capacity * 7;
	}
	else {
		return capacity * 21;
	}
}
