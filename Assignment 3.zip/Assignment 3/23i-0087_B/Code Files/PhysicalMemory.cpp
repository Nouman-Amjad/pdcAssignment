#include "PhysicalMemory.h"

PhysicalMemory::PhysicalMemory()
{
	this->capacity = 0;
	this->price = 0;
}

PhysicalMemory::PhysicalMemory(int cap, double p)
{
	this->capacity = cap;
	this->price = p;
}

void PhysicalMemory::setphymem(int cap)
{
	this->capacity = cap;
}

void PhysicalMemory::setp(double p)
{
	this->price = p;
}

int PhysicalMemory::getphymem()
{
	return capacity;
}

double PhysicalMemory::getp()
{
	return price;
}
