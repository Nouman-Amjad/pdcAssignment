#pragma once
#include "ComputerAssembly.h"

class Case {
	string formFactor; 
	string color;
	double price;
public:
	Case();
	Case(string ff, string col, double p);
	void setff(string temp);
	void setcol(string temp);
	void setp(double p);
	string getff();
	string getcol();
	double getp();
};