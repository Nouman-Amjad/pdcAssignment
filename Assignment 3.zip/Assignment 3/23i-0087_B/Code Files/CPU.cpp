#include "CPU.h"
#include "CU.h"
#include "ALU.h"

CPU::CPU()
{
	{
		CU c1;
		int n;
		bool b = false;
		while (!b) {
			cout << "Enter Clock for Control Unit (range 1-4): " << endl;
			cin >> n;
			if (n > 4 || n < 1) {
				cout << "Invalid input please try again :)" << endl;
			}
			else {
				cu.setc(n);
				b = true;
			}
		}
		this->cu = c1;
	}

	{
		ALU a1;
		int n;
		bool b = false;
		while (!b) {
			cout << "Enter Numer of Adder for ALU (range 1-15): " << endl;
			cin >> n;
			if (n > 15 || n < 1) {
				cout << "Invalid input please try again :)" << endl;
			}
			else {
				alu.setadd(n);
				b = true;
			}
		}
		b = false;
		while (!b) {
			cout << "Enter Numer of Subtractor for ALU (range 1-15): " << endl;
			cin >> n;
			if (n > 15 || n < 1) {
				cout << "Invalid input please try again :)" << endl;
			}
			else {
				alu.setsub(n);
				b = true;
			}
		}
		b = false;
		while (!b) {
			cout << "Enter Numer of Register for ALU (range 1-15): " << endl;
			cin >> n;
			if (n > 15 || n < 1) {
				cout << "Invalid input please try again :)" << endl;
			}
			else {
				alu.setreg(n);
				b = true;
			}
		}
		b = false;
		while (!b) {
			cout << "Enter Size of Register for ALU (range 1-15): " << endl;
			cin >> n;
			if (n > 15 || n < 1) {
				cout << "Invalid input please try again :)" << endl;
			}
			else {
				alu.setsizereg(n);
				b = true;
			}
		}
		this->alu = a1;
	}
}

CPU::CPU(ALU a, CU c)
{
	this->alu = a;
	this->cu = c;
}

void CPU::setalu(ALU a)
{
	this->alu = a;
}

void CPU::setcu(CU c)
{
	this->cu = c;
}

ALU CPU::getalu()
{
	return alu;
}

CU CPU::getcu()
{
	return cu;
}

double CPU::getp()
{
	return 949.99;
}
