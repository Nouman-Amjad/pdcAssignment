#pragma once
#include "ComputerAssembly.h"
class port {
	int baud_rate;
public:
	string name;
	port();
	port(string n, int rate);
	void setname(string n);
	void setrate(int n);
	string getname();
	int getrate();
};

