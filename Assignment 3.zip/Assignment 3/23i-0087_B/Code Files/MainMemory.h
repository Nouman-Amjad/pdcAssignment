#pragma once
#include <iostream>
using namespace std;

class MainMemory {
	int capacity;
	double price;
	string n;
public:
	MainMemory();
	MainMemory(int c, string n, double p);
	void setcap(int c);
	void setn(string temp);
	void setp(double p);
	int getcap();
	string getn();
	double getp();
};