#pragma once
#include <iostream>
using namespace std;
#include "CPU.h"
#include "PhysicalMemory.h"
#include "MotherBoard.h"

class Computer {
	PhysicalMemory pm;
	MotherBoard mb;
	CPU cpu;
	double price;
public:
	Computer();
	Computer(PhysicalMemory temppm, MotherBoard tempmb, CPU tempcpu);
	void setpm(PhysicalMemory temp);
	void setmb(MotherBoard temp);
	void setcpu(CPU temp);
	CPU getcpu();
	MotherBoard getmb();
	PhysicalMemory getpm();
	double getp();
};
