#include <iostream>
#include "Computer.h"
#include "PhysicalMemory.h"
#include "MotherBoard.h"
#include "CPU.h"
using namespace std;

Computer::Computer()
{
	{
		PhysicalMemory pm1;
		int cap;
		bool b = false;
		while (!b) {
			cout << "Enter Capacity for Physical Memory (range 8GB, 16GB, 32GB, 48GB) " << endl;
			cin >> cap;
			if (cap == 48) {
				pm.setphymem(cap);
				pm.setp(249.99);
				b = true;
			}
			else if (cap == 32) {
				pm.setphymem(cap);
				pm.setp(190);
				b = true;
			}
			else if (cap == 16) {
				pm.setphymem(cap);
				pm.setp(108);
				b = true;
			}
			else if (cap == 8) {
				pm.setphymem(cap);
				pm.setp(55.99);
				b = true;
			}
			else {
				cout << "Invalid input please try again :)" << endl;
			}
		}
		this->pm = pm1;
	}
}

Computer::Computer(PhysicalMemory temppm, MotherBoard tempmb, CPU tempcpu)
{
	this->cpu = tempcpu;
	this->mb = tempmb;
	this->pm = temppm;
}

void Computer::setpm(PhysicalMemory temp)
{
	this->pm = temp;
}

void Computer::setmb(MotherBoard temp)
{
	this->mb = temp;
}

void Computer::setcpu(CPU temp)
{
	this->cpu = temp;
}

CPU Computer::getcpu()
{
	return cpu;
}

MotherBoard Computer::getmb()
{
	return mb;
}

PhysicalMemory Computer::getpm()
{
	return pm;
}

double Computer::getp()
{
	int temp = 0;
	temp += pm.getp() + mb.getp() + cpu.getp();
	return temp;
}
