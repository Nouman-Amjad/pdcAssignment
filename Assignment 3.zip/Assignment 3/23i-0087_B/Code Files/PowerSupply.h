#pragma once
#include "ComputerAssembly.h"

class PowerSupply {
	int wattage;
	string efficiencyRating;
	double price;
public:
	PowerSupply();
	PowerSupply(string er, int wat, double p);
	void seter(string temp);
	void setwat(int temp);
	void setp(double temp);
	string geter();
	int getwat();
	double getp();
};