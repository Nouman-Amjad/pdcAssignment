#include "ALU.h"

ALU::ALU()
{
	this->NoOfAdders = 0;
	this->NoOfSubtractor = 0;
	this->NoOfRegisters = 0;
	this->sizeOfRegisters = 0;
}

ALU::ALU(int add, int sub, int reg, int sizereg)
{
	this->NoOfAdders = add;
	this->NoOfSubtractor = sub;
	this->NoOfRegisters = reg;
	this->sizeOfRegisters = sizereg;
}

void ALU::setadd(int add)
{
	this->NoOfAdders = add;
}

void ALU::setsub(int sub)
{
	this->NoOfSubtractor = sub;
}

void ALU::setreg(int reg)
{
	this->NoOfRegisters = reg;
}

void ALU::setsizereg(int sreg)
{
	this->sizeOfRegisters = sreg;
}

int ALU::getadd()
{
	return NoOfAdders;
}

int ALU::getsub()
{
	return NoOfSubtractor;
}

int ALU::getreg()
{
	return NoOfRegisters;
}

int ALU::getsizereg()
{
	return sizeOfRegisters;
}
