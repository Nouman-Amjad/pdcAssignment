#pragma once
class PhysicalMemory {
	int capacity;
	double price;
public:
	PhysicalMemory();
	PhysicalMemory(int cap,double p);
	void setphymem(int cap);
	void setp(double p);
	int getphymem();
	double getp();
};