#include "MotherBoard.h"
#include "MainMemory.h"
#include "port.h"

MotherBoard::MotherBoard()
{
	{
		int n;
		bool b = false;
		while (!b) {
			cout << "Enter the number (1 to 4) of ports you want" << endl;
			cin >> n;
			if (n > 4 || n <= 0) {
				cout << "Invalid input please try again" << endl;
			}
			else {
				b = true;
			}
		}
		ports = new port[n];
		this->num = n;
		int* arr = new int[n];
		for (int i = 0; i < n; i++) {
			cout << "Enter the port you wants:\npress 1 for VGI Port\nPress 2 for I/O Port\nPress 3 for USB Port\nPress 4 for HDMI Port" << endl;
			cin >> arr[i];
			if (arr[i] <= 0 || arr[i] > 4) {
				cout << "Invalid input please try again" << endl;
				i--;
			}
			else if (arr[i] == 1) {
				ports[i].name = "VGI Port";
				ports[i].setrate(19200);
			}
			else if (arr[i] == 2) {
				ports[i].name = "I/O Port";
				ports[i].setrate(14400);
			}
			else if (arr[i] == 3) {
				ports[i].name = "USB Port";
				ports[i].setrate(2400);
			}
			else if (arr[i] == 4) {
				ports[i].name = "HDMI Port";
				ports[i].setrate(9600);
			}
		}
	}

	{
		MainMemory m1;
		int mm;
		bool b = false;
		while (!b) {
			cout << "Enter size for main memory (4GB, 8GB, 16GB, 32GB): " << endl;
			cin >> mm;
			if (mm == 4) {
				m1.setcap(4);
				m1.setp(90);
				b = true;
			}
			else if (mm == 8) {
				m1.setcap(8);
				m1.setp(160);
				b = true;
			}
			else if (mm == 16) {
				m1.setcap(16);
				m1.setp(270);
				b = true;
			}
			else if (mm == 32) {
				m1.setcap(32);
				m1.setp(370);
				b = true;
			}
			else {
				cout << "Invalid input please try again" << endl;
			}
		}
		int num;
		b = false;
		while (!b) {
			cout << "Enter type of main memory you want\nPress 1 for Semiconductor\nPress 2 for Silicon" << endl;
			cin >> num;
			if (num == 1) {
				m1.setn("Semiconductor");
				b = true;
			}
			else if (num == 2) {
				m1.setn("Silicon");
				b = true;
			}
			else {
				cout << "Invalid input please try again" << endl;
			}
		}
		this->mainmemory = m1;
	}
}

MotherBoard::MotherBoard(port* temp, MainMemory tempmm, int n)
{
	this->mainmemory = tempmm;
	this->num = n;
	this->ports = temp;
}

void MotherBoard::setmm(MainMemory temp)
{
	this->mainmemory = temp;
}

MainMemory MotherBoard::getmm()
{
	return mainmemory;
}

double MotherBoard::getp()
{
	int temp = mainmemory.getp() + 120;
	return temp;
}

void MotherBoard::getport()
{
	for (int i = 0; i < num; i++) 
	{
		cout << "Your Device has " << ports[i].getname() << "with Buad rate of " << ports[i].getrate() << endl;
	}
}
