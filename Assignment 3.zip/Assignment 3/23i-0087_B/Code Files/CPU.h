#pragma once
#include "ALU.h"
#include "CU.h"

class CPU {
	ALU alu;
	CU cu;
	double price;
public:
	CPU();
	CPU(ALU a, CU c);
	void setalu(ALU a);
	void setcu(CU c);
	ALU getalu();
	CU getcu();
	double getp();
};
