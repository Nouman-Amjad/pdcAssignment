#include "CU.h"

CU::CU()
{
	this->clock = 0;
}

CU::CU(float c)
{
	this->clock = c;
}

void CU::setc(float clock)
{
	this->clock = clock;
}

float CU::getc()
{
	return clock;
}
