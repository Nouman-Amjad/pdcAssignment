#include "ComputerAssembly.h"
#include "GraphicsCard.h"
#include "StorageDevice.h"
#include "NetworkCard.h"
#include "PowerSupply.h"
#include "Case.h"
#include "Battery.h"
#include "Computer.h"
#include "MotherBoard.h"
#include "CPU.h"
#include "PhysicalMemory.h"
#include "MainMemory.h"
#include "CU.h"
#include "ALU.h"
#include "port.h"

ComputerAssembly::ComputerAssembly()
{
	this->totalPrice = 0;
}

ComputerAssembly::ComputerAssembly(double tp)
{
	this->totalPrice = tp;
}

void ComputerAssembly::settp(double temp)
{
	this->totalPrice = temp;
}

double ComputerAssembly::gettp()
{
	return totalPrice;
}

void ComputerAssembly::makecomputer()
{
	totalPrice = 0;
	int n;
	bool b = false;
	while (!b) {
		cout << "********** WELCOME TO FAST COMPUTERS **********\n\nPress 1 for laptop\nPress 2 for Tablet\nPress 3 for PC\nPress 4 for Mac" << endl;
		cin >> n;
		if (n > 4 || n <= 0) {
			cout << "Invalid input please try again :)" << endl;
		}
		else {
			b = true;
		}
	}

	Computer com;
	GraphicsCard g1;
	StorageDevice s1;
	NetworkCard n1;
	PowerSupply p1;
	Case c1;
	Battery b1;

	switch (n) {
	case 1:  //Laptops
	{
		{
			bool b = false;
			string str;
			int mem;
			cout << "Enter Brand for your Graphic Card: " << endl;
			cin >> str;
			while (!b) {
				cout << "Enter Memory size for your Graphic Card(in GB): " << endl;
				cin >> mem;
				if (mem > 24 || mem < 2) {
					cout << "Invalid input, range for Graphics Card Memory is 2-24 BG :)" << endl;
				}
				else {
					b = true;
				}
			}
			g1.setb(str);
			g1.setmem(mem);
		}

		{
			bool b = false;
			int m;
			int mem;
			while (!b) {
				cout << "Press 1 for HDD Storage Type\nPress 2 for SSD Storage Type: " << endl;
				cin >> m;
				if (m == 1 || m == 2) {
					b = true;
				}
				else {
					cout << "Invalid input please try again :)" << endl;
				}
			}
			b = false;
			while (!b) {
				cout << "Enter Memory size for your Storage Device (in GB): " << endl;
				cin >> mem;
				if (m == 1) {
					s1.sett("HDD");
					if (mem > 6000 || mem < 16) {
						cout << "Invalid input, range for HDD Memory is 16 GB to 6000 GB" << endl;
					}
					else {
						b = true;
					}
				}
				else if (m == 2) {
					s1.sett("SSD");
					if (mem > 10000 || mem < 120) {
						cout << "Invalid input, range for SSD Memory is 120 GB to 10000 GB" << endl;
					}
					else {
						b = true;
					}
				}
			}
			s1.setcap(mem);
		}

		{
			int net;
			bool b = false;
			while (!b) {
				cout << "Enter Type of your Network Type\nPress 1 for Wifi\nPress 2 for Ethernet" << endl;
				cin >> net;
				if (net == 1 || net == 2) {
					b = true;
				}
				else {
					cout << "Invalid input please try again :)" << endl;
				}
			}
			if (net == 1) {
				n1.sett("Wifi");
				n1.sets(20);
				n1.setp(1599);
			}
			else if (net == 2) {
				n1.sett("Ethernet");
				n1.sets(100);
				n1.setp(3599);
			}
		}

		{
			int ER;
			bool b = false;
			while (!b) {
				cout << "Enter efficiencyRating of your Power Supply\nPress 1 for 80 Plus Bronze\nPress 2 for 80 Plus Gold " << endl;
				cin >> ER;
				if (ER == 1) {
					p1.seter("80 Plus Bronze");
					p1.setwat(225);
					p1.setp(8000);
					b = true;
				}
				else if (ER == 2) {
					p1.seter("80 Plus Gold");
					p1.setwat(550);
					p1.setp(14000);
					b = true;
				}
				else {
					cout << "Invalid input please try again :)" << endl;
				}
			}
		}

		{
			int ff;
			string col;
			bool b = false;
			while (!b) {
				cout << "Enter the Case Form Factor\nPress 1 for ATX\nPress 2 for micro ATX: " << endl;
				cin >> ff;
				if (ff == 1) {
					c1.setff("ATX");
					b = true;
				}
				else if (ff == 2) {
					c1.setff("micro ATX");
					b = true;
				}
				else {
					cout << "Invalid input please try again :)" << endl;
				}
			}
			cout << "Enter Colour for the case: " << endl;
			cin >> col;
			c1.setcol(col);
			c1.setp(0);
		}

		{
			b1.setcap(1200);
			b1.setp(40.59);
		}
	}
	case 2:  //Tablets
	{
		{
			bool b = false;
			string str;
			int mem;
			cout << "Enter Brand for your Graphic Card: " << endl;
			cin >> str;
			while (!b) {
				cout << "Enter Memory size for your Graphic Card(in GB): " << endl;
				cin >> mem;
				if (mem > 24 || mem < 2) {
					cout << "Invalid input, range for Graphics Card Memory is 2-24 BG :)" << endl;
				}
				else {
					b = true;
				}
			}
			g1.setb(str);
			g1.setmem(mem);
		}

		{
			bool b = false;
			int m;
			int mem;
			while (!b) {
				cout << "Press 1 for HDD Storage Type\nPress 2 for SSD Storage Type: " << endl;
				cin >> m;
				if (m == 1 || m == 2) {
					b = true;
				}
				else {
					cout << "Invalid input please try again :)" << endl;
				}
			}
			b = false;
			while (!b) {
				cout << "Enter Memory size for your Storage Device (in GB): " << endl;
				cin >> mem;
				if (m == 1) {
					s1.sett("HDD");
					if (mem > 6000 || mem < 16) {
						cout << "Invalid input, range for HDD Memory is 16 GB to 6000 GB" << endl;
					}
					else {
						b = true;
					}
				}
				else if (m == 2) {
					s1.sett("SSD");
					if (mem > 10000 || mem < 120) {
						cout << "Invalid input, range for SSD Memory is 120 GB to 10000 GB" << endl;
					}
					else {
						b = true;
					}
				}
			}
			s1.setcap(mem);
		}

		{
			int net;
			bool b = false;
			while (!b) {
				cout << "Enter Type of your Network Type\nPress 1 for Wifi\nPress 2 for Ethernet" << endl;
				cin >> net;
				if (net == 1 || net == 2) {
					b = true;
				}
				else {
					cout << "Invalid input please try again :)" << endl;
				}
			}
			if (net == 1) {
				n1.sett("Wifi");
				n1.sets(20);
				n1.setp(1599);
			}
			else if (net == 2) {
				n1.sett("Ethernet");
				n1.sets(100);
				n1.setp(3599);
			}
		}

		{
			int ER;
			bool b = false;
			while (!b) {
				cout << "Enter efficiencyRating of your Power Supply\nPress 1 for 80 Plus Bronze\nPress 2 for 80 Plus Gold " << endl;
				cin >> ER;
				if (ER == 1) {
					p1.seter("80 Plus Bronze");
					p1.setwat(225);
					p1.setp(8000);
					b = true;
				}
				else if (ER == 2) {
					p1.seter("80 Plus Gold");
					p1.setwat(550);
					p1.setp(14000);
					b = true;
				}
				else {
					cout << "Invalid input please try again :)" << endl;
				}
			}
		}

		{
			int ff;
			string col;
			bool b = false;
			while (!b) {
				cout << "Enter the Case Form Factor\nPress 1 for ATX\nPress 2 for micro ATX: " << endl;
				cin >> ff;
				if (ff == 1) {
					c1.setff("ATX");
					b = true;
				}
				else if (ff == 2) {
					c1.setff("micro ATX");
					b = true;
				}
				else {
					cout << "Invalid input please try again :)" << endl;
				}
			}
			cout << "Enter Colour for the case: " << endl;
			cin >> col;
			c1.setcol(col);
			c1.setp(0);
		}

		{
			b1.setcap(1200);
			b1.setp(40.59);
		}
	}
	case 3:  //Pc
	{
		{
			bool b = false;
			string str;
			int mem;
			cout << "Enter Brand for your Graphic Card: " << endl;
			cin >> str;
			while (!b) {
				cout << "Enter Memory size for your Graphic Card(in GB): " << endl;
				cin >> mem;
				if (mem > 24 || mem < 2) {
					cout << "Invalid input, range for Graphics Card Memory is 2-24 BG :)" << endl;
				}
				else {
					b = true;
				}
			}
			g1.setb(str);
			g1.setmem(mem);
		}

		{
			bool b = false;
			int m;
			int mem;
			while (!b) {
				cout << "Press 1 for HDD Storage Type\nPress 2 for SSD Storage Type: " << endl;
				cin >> m;
				if (m == 1 || m == 2) {
					b = true;
				}
				else {
					cout << "Invalid input please try again :)" << endl;
				}
			}
			b = false;
			while (!b) {
				cout << "Enter Memory size for your Storage Device (in GB): " << endl;
				cin >> mem;
				if (m == 1) {
					s1.sett("HDD");
					if (mem > 6000 || mem < 16) {
						cout << "Invalid input, range for HDD Memory is 16 GB to 6000 GB" << endl;
					}
					else {
						b = true;
					}
				}
				else if (m == 2) {
					s1.sett("SSD");
					if (mem > 10000 || mem < 120) {
						cout << "Invalid input, range for SSD Memory is 120 GB to 10000 GB" << endl;
					}
					else {
						b = true;
					}
				}
			}
			s1.setcap(mem);
		}

		{
			int net;
			bool b = false;
			while (!b) {
				cout << "Enter Type of your Network Type\nPress 1 for Wifi\nPress 2 for Ethernet" << endl;
				cin >> net;
				if (net == 1 || net == 2) {
					b = true;
				}
				else {
					cout << "Invalid input please try again :)" << endl;
				}
			}
			if (net == 1) {
				n1.sett("Wifi");
				n1.sets(20);
				n1.setp(1599);
			}
			else if (net == 2) {
				n1.sett("Ethernet");
				n1.sets(100);
				n1.setp(3599);
			}
		}

		{
			int ER;
			bool b = false;
			while (!b) {
				cout << "Enter efficiencyRating of your Power Supply\nPress 1 for 80 Plus Bronze\nPress 2 for 80 Plus Gold " << endl;
				cin >> ER;
				if (ER == 1) {
					p1.seter("80 Plus Bronze");
					p1.setwat(225);
					p1.setp(8000);
					b = true;
				}
				else if (ER == 2) {
					p1.seter("80 Plus Gold");
					p1.setwat(550);
					p1.setp(14000);
					b = true;
				}
				else {
					cout << "Invalid input please try again :)" << endl;
				}
			}
		}

		{
			int ff;
			string col;
			bool b = false;
			while (!b) {
				cout << "Enter the Case Form Factor\nPress 1 for ATX\nPress 2 for micro ATX: " << endl;
				cin >> ff;
				if (ff == 1) {
					c1.setff("ATX");
					b = true;
				}
				else if (ff == 2) {
					c1.setff("micro ATX");
					b = true;
				}
				else {
					cout << "Invalid input please try again :)" << endl;
				}
			}
			cout << "Enter Colour for the case: " << endl;
			cin >> col;
			c1.setcol(col);
			c1.setp(60);
		}

		{
			b1.setcap(1200);
			b1.setp(40.59);
		}
	}
	case(4):  //Mac
	{
		{
			g1.setb("AppleGPU");
			g1.setmem(32);
		}

		{
			bool b = false;
			int m;
			int mem;
			while (!b) {
				cout << "Press 1 for HDD Storage Type\nPress 2 for SSD Storage Type: " << endl;
				cin >> m;
				if (m == 1 || m == 2) {
					b = true;
				}
				else {
					cout << "Invalid input please try again :)" << endl;
				}
			}
			b = false;
			while (!b) {
				cout << "Enter Memory size for your Storage Device (in GB): " << endl;
				cin >> mem;
				if (m == 1) {
					s1.sett("HDD");
					if (mem > 6000 || mem < 16) {
						cout << "Invalid input, range for HDD Memory is 16 GB to 6000 GB" << endl;
					}
					else {
						b = true;
					}
				}
				else if (m == 2) {
					s1.sett("SSD");
					if (mem > 10000 || mem < 120) {
						cout << "Invalid input, range for SSD Memory is 120 GB to 10000 GB" << endl;
					}
					else {
						b = true;
					}
				}
			}
			s1.setcap(mem);
		}

		{
			int net;
			bool b = false;
			while (!b) {
				cout << "Enter Type of your Network Type\nPress 1 for Wifi\nPress 2 for Ethernet" << endl;
				cin >> net;
				if (net == 1 || net == 2) {
					b = true;
				}
				else {
					cout << "Invalid input please try again :)" << endl;
				}
			}
			if (net == 1) {
				n1.sett("Wifi");
				n1.sets(20);
				n1.setp(1599);
			}
			else if (net == 2) {
				n1.sett("Ethernet");
				n1.sets(100);
				n1.setp(3599);
			}
		}

		{
			int ER;
			bool b = false;
			while (!b) {
				cout << "Enter efficiencyRating of your Power Supply\nPress 1 for 80 Plus Bronze\nPress 2 for 80 Plus Gold " << endl;
				cin >> ER;
				if (ER == 1) {
					p1.seter("80 Plus Bronze");
					p1.setwat(225);
					p1.setp(8000);
					b = true;
				}
				else if (ER == 2) {
					p1.seter("80 Plus Gold");
					p1.setwat(550);
					p1.setp(14000);
					b = true;
				}
				else {
					cout << "Invalid input please try again :)" << endl;
				}
			}
		}

		{
			int ff;
			string col;
			bool b = false;
			while (!b) {
				cout << "Enter the Case Form Factor\nPress 1 for ATX\nPress 2 for micro ATX: " << endl;
				cin >> ff;
				if (ff == 1) {
					c1.setff("ATX");
					b = true;
				}
				else if (ff == 2) {
					c1.setff("micro ATX");
					b = true;
				}
				else {
					cout << "Invalid input please try again :)" << endl;
				}
			}
			cout << "Enter Colour for the case: " << endl;
			cin >> col;
			c1.setcol(col);
			c1.setp(0);
		}

		{
			b1.setcap(1200);
			b1.setp(40.59);
		}
	}
	}
	cout << "\n########### THIS IS YOUR REQUIRED DEVICE ##########\n" << endl;
	cout << "Graphic Card details:\nBrand: " << g1.getb() << "\nMemory Size: " << g1.getmem() << "\nPrice: $" << g1.getp() << endl;
	cout << "\nStorage Device details:\nType: " << s1.gett() << "\nCapacity: " << s1.getcap() << "\nPrice: $" << s1.getp() << endl;
	cout << "\nNetwork Card details:\nType: " << n1.gett() << "\nSpeed: " << n1.gets() << "\nPrice: $" << n1.getp() << endl;
	cout << "\nPower Supply details:\nEfficiency Rating: " << p1.geter() << "\nwattage: " << p1.getwat() << "\nPrice: $" << p1.getp() << endl;
	cout << "\nCase Details:\nForm Factor: " << c1.getff() << "\nColour: " << c1.getcol();
	if (n == 3) {
		cout << "\nPrice: $" << c1.getp();
	}
	cout << endl;
	cout << "\nBattery Details:\nCapacity: " << b1.getcap() << "\nPrice: $" << b1.getp() << endl;
	cout << "Computer price: $" << com.getp();

	totalPrice += g1.getp() + s1.getp() + n1.getp() + p1.getp() + c1.getp() + com.getp();
	cout << endl;
	cout << "\n********** TOTAL PRICE OF YOU DEVICE IS $" << totalPrice << " **********\nTHANKS FOR YOUR VISIT ;)" << endl;
}
