#pragma once
#include "ComputerAssembly.h"

class Battery {
	int capacity;
	double price;
public:
	Battery();
	Battery(int cap,double p);
	void setcap(int cap);
	void setp(double p);
	int getcap();
	double getp();
};
