#pragma once


class CU {
	float clock;
public:
	CU();
	CU(float c);
	void setc(float clock);
	float getc();
};
