#include <iostream>
#include "ComputerAssembly.h"
using namespace std;
int main() {

	ComputerAssembly obj;
	obj.makecomputer();

	return 0;
}