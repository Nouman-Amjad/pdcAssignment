#include "Case.h"

Case::Case()
{
	this->formFactor = "";
	this->color = "";
	this->price = 0;
}

Case::Case(string ff, string col, double p)
{
	this->formFactor = ff;
	this->color = col;
	this->price = p;
}

void Case::setff(string temp)
{
	this->formFactor = temp;
}

void Case::setcol(string temp)
{
	this->color = temp;
}

void Case::setp(double p)
{
	this->price = p;
}

string Case::getff()
{
	return formFactor;
}

string Case::getcol()
{
	return color;
}

double Case::getp()
{
	return price;
}
