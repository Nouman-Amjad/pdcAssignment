#pragma once
#include <iostream>
using namespace std;
class ComputerAssembly {
	double totalPrice;
public:
	ComputerAssembly();
	ComputerAssembly(double tp);
	void settp(double temp);
	double gettp();
	void makecomputer();
};
