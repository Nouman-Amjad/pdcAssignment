#include "NetworkCard.h"

NetworkCard::NetworkCard()
{
	type = "";
	speed = 0;
	price = 0;
}

NetworkCard::NetworkCard(string t, int s, double p)
{
	this->type = t;
	this->speed = s;
	this->price = p;
}

void NetworkCard::sett(string t)
{
	this->type = t;
}

void NetworkCard::sets(int s)
{
	this->speed = s;
}

void NetworkCard::setp(double p)
{
	this->price = p;
}

string NetworkCard::gett()
{
	return type;
}

int NetworkCard::gets()
{
	return speed;
}

double NetworkCard::getp()
{
	return price;
}
