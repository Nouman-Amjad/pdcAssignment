// Name :Saud Ur Rahman
// Section: G
// RollNumber : 23i-0540
#pragma once

#include <iostream>
#include <string>
using namespace std;

class ALU {
private:
    int NoOfAdders;
    int NoOfSubtractors;
    int NoOfRegisters;
    int sizeOfRegisters;
    int price;

public:
    // Constructor for input
    ALU() {
        cout << "Enter number of adders for ALU: ";
        cin >> NoOfAdders;
        cout << "Enter number of subtractors for ALU: ";
        cin >> NoOfSubtractors;
        cout << "Enter number of registers for ALU: ";
        cin >> NoOfRegisters;
        cout << "Enter size of registers for ALU (in bits): ";
        cin >> sizeOfRegisters;
        cout << "Enter price of the ALU ($): ";
        cin >> price;
    }

    // Parameterized constructor 
    ALU(int adders, int subtractors, int registers, int regSize, int pr)
        : NoOfAdders(adders), NoOfSubtractors(subtractors),
        NoOfRegisters(registers), sizeOfRegisters(regSize), price(pr) {}

    int getPrice() const {
        return price;
    }

    void display() const {
        cout << "ALU Configuration:" << endl;
        cout << "Number of Adders: " << NoOfAdders << endl;
        cout << "Number of Subtractors: " << NoOfSubtractors << endl;
        cout << "Number of Registers: " << NoOfRegisters << endl;
        cout << "Size of Registers: " << sizeOfRegisters << " bits" << endl;
        cout << "Price: $" << price << endl;
    }
  
};

// -----------------------------------------Control Unit class-------------------------------------------------------

class ControlUnit {
private:
    float clock;
    float price;

public:
    // Default constructor  for clock speed
    ControlUnit() {
        while (true) {
            cout << "Enter clock speed for Control Unit (3.5, 4.5, 5.5): ";
            cin >> clock;
            if (clock == 3.5 || clock == 4.5 || clock == 5.5) {
                setPrice();
                break;
            }
            else {
                cout << "Invalid input. Please enter one of the specified values." << endl;

            }
        }
    }

    // Parameterized constructor for speed
    ControlUnit(float clockSpeed) : clock(clockSpeed) {
        setPrice();  
    }

    // Set price based on clock speed
    void setPrice() {

        if (clock == 3.5) {
            price = 100;
        }
        else if (clock == 4.5) {
            price = 150;
        }
        else if (clock == 5.5) {
            price = 200;
        }
    }

   // function to get price
    float getPrice() const {
        return price;
    }
};

//--------------------------------------------CPU class-------------------------------------------------------------------
class CPU 
{
private:
    ALU alu;
    ControlUnit cu;
    int totalPrice;

protected:
    void setTotalPrice(int price) {
        totalPrice = price;
    }

public:
    CPU() {
        calculateTotalPrice();
    }
    CPU(int adders, int subtractors, int registers, int regSize, float clockSpeed) :
        alu(adders, subtractors, registers, regSize, calculateALUPrice(adders, subtractors, registers, regSize)),
        cu(clockSpeed) {
        calculateTotalPrice();
    }

    static int calculateALUPrice(int adders, int subtractors, int registers, int regSize) {
        return (adders + subtractors) * 10 + registers * 5 + regSize * 2;
    }

    void calculateTotalPrice() {
        totalPrice = alu.getPrice() + cu.getPrice();
    }

    int getTotalPrice() const {
        return totalPrice;
    }

    void display() const {
        cout << "CPU Total Price: $" << totalPrice << endl;

    }
};
// --------------------------------------------------------Graphics Card -----------------------------------------------------
class GraphicsCard {
private:
    string brand;
    int memorySize;
    double price;

public:
    // Interactive constructor
    GraphicsCard() {
        while (true) {
            cout << "Enter the brand of Graphic Card" << endl;
            cin >> brand;
            if (brand == "AMD" || brand == "Nvidia ")
                break;
       }

       bool validonput = false; // Reset validInput for memory size validation
        
        while (!validonput) {
            cout << "Enter the memory size of the Graphics Card (in GB, valid options are 4, 8, 64, 128): ";
            cin >> memorySize;

            if (memorySize == 4 || memorySize == 8 || memorySize == 64 || memorySize == 128) {
                validonput = true;
                break;
            }

            if (!validonput) {
                cout << "Invalid memory size entered. Please enter one of the valid options (4, 8, 64, 128).\n";
            }
        }

        price = calculatePrice(brand, memorySize);
    }

    // Parameterized Constructor 
    GraphicsCard(const string& b, int memSize)
        : brand(b), memorySize(memSize), price(calculatePrice(b, memSize)) {}

    double calculatePrice(const string& b, int memSize) {
        double basePrice = 200;  // Base price
        if (b == "Nvidia") {
            basePrice += memSize * 30;  // Nvidia price factor
        }
        else if (b == "AMD") {
            basePrice += memSize * 25;  // AMD price factor
        }
        return basePrice;
    }

    double getPrice() const {
        return price;
    }

    void display() const {
        cout << "Graphics Card Brand: " << brand << endl;
        cout << "Memory Size: " << memorySize << " GB" << endl;
        cout << "Price: $" << price << endl;
    }
};
//---------------------------------------------------AppleSilicon----------------------------------------------------------
class AppleSilicon : public CPU {
private:
    bool hasNeuralEngine;
    int gpuCores;
    GraphicsCard integratedGPU;

public:
    // Interactive constructor
    AppleSilicon() : CPU() {
        string neuralEngineInput;
        cout << "Does the Apple Silicon have a Neural Engine? (yes/no): ";
        while (true) {
            cin >> neuralEngineInput;
            if (neuralEngineInput == "yes" || neuralEngineInput == "no") {

                break;
            }
            else {
                cout << "Invalid input. Please enter 'yes' or 'no': ";
            }
        }

        cout << "Enter the number of GPU cores(should be less than 5) ";
        cin >> gpuCores;
        while (gpuCores < 0 || gpuCores > 5) {

            cout << "Invalid input. Please enter a positive integer for GPU cores: ";
        }



    }

    // Parameterized constructor
    AppleSilicon(int adders, int subtractors, int registers, int regSize, float clockSpeed, bool neuralEngine, int gpuCoreCount, const GraphicsCard& gpu)
        : CPU(adders, subtractors, registers, regSize, clockSpeed), hasNeuralEngine(neuralEngine), gpuCores(gpuCoreCount), integratedGPU(gpu) {
        calculateTotalPrice();
    }

    double calculateTotalPrice() const {
        double price = CPU::getTotalPrice();  
        price += hasNeuralEngine ? 200 : 0;  // Add price for Neural Engine
        price += integratedGPU.getPrice();  
        return price;
    }

    void display() const {
        CPU::display();
        cout << "--------------------------Apple Silicon Details---------------------------------------" << endl;
        cout << "Has Neural Engine: " << (hasNeuralEngine ? "Yes" : "No") << endl;
        cout << "GPU Cores: " << gpuCores << endl;
        integratedGPU.display();
    }
};

//---------------------------------------Port class-------------------------------------------------------
class Port {
private:
    std::string type;
    int baud_rate;
    int price;

public:

    Port() {

        calculatePrice();  
    }

    // Constructor with parameters
    Port(const std::string& portType, int baudRate, int portPrice = 0)
        : type(portType), baud_rate(baudRate), price(portPrice) {
        if (price == 0) { // Calculate price only if not provided.
            calculatePrice();
        }
    }

    
    void calculatePrice() {
        if (type == "USB") {
            price = 20 + (baud_rate / 1000); 
        }
        else if (type == "HDMI") {
            price = 30 + (baud_rate / 1000); 
        }
        else {
            price = 10;  // Default price if an unrecognized type is somehow entered
        }
    }

    // Display method to show port details
    void display() const {
        cout << "------------------------------------Port Details--------------------------------" << endl;
        cout << "Port Type: " << type << endl;
        cout << "Baud Rate: " << baud_rate << " bps" << endl;
        cout << "Price: $" << price << endl;
    }

    // Getters
    string getType() const { return type; }
    int getBaudRate() const { return baud_rate; }
    int getPrice() const { return price; }


    void setType(string portType) {
        type = portType;
        calculatePrice();  // calculate price when type changes
    }
    void setBaudRate(int baudRate) {
        baud_rate = baudRate;
        calculatePrice();  // Recalculate price when baud rate changes
    }
};
//------------------------------------------------Storage Device class-----------------------------------------------------
class StorageDevice {
private:
    std::string type;
    int capacity;
    double price;

public:
    // default constructor
    StorageDevice() {
        while (true) {
            cout << "Enter the type of storage device (SSD/HDD): ";
            cin >> type;
            
            if ((type == "SSD" || type == "HDD")) {
                break;
            }
            else {
                cout << "Invalid input. Please enter 'SSD' or 'HDD' and a positive integer for capacity.\n";
            }
        }cout << "Enter the capacity in GB:( less 1 million Gbs) ";
        cin >> capacity;
        price = calculatePrice(type, capacity);
    }

    // Parameterized constructor
    StorageDevice(const std::string& t, int c, double p = 0) : type(t), capacity(c) {
        if (p == 0) { // Calculate price if not provided
            price = calculatePrice(type, capacity);
        }
        else {
            price = p;
        }
    }

    // Method to calculate price based on type and capacity
    double calculatePrice(const std::string& type, int capacity) {
        if (type == "SSD") {
            return capacity * 0.20;
        }
        else if (type == "HDD") {
            return capacity * 0.05;
        }
        else {
            return capacity * 0.10;
        }
    }

    // Getters
    string getType() const {
        return type;
    }

    int getCapacity() const {
        return capacity;
    }

    double getPrice() const {
        return price;
    }

    void display() const {
        cout << "Type: " << type << std::endl
            << "Capacity: " << capacity << " GB" << endl
            << "Price: $" << price << endl;
    }
};

//----------------------------------------------MainMemory----------------------------------------------------------------
class MainMemory {
private:
    int capacity; // in GB
    std::string technologyType;
    int price; // Price in USD

public:

    MainMemory(std::string type, int cap) :capacity(cap), technologyType(type) {}
    MainMemory() {
        int choice;
        cout << "Select the memory type by number:\n";
        cout << "1. Semiconductor - 8GB - $50\n";
        cout << "2. Semiconductor - 16GB - $90\n";
        cout << "3. Semiconductor - 32GB - $160\n";
        cout << "4. DRAM - 8GB - $70\n";
        cout << "5. DRAM - 16GB - $120\n";
        cout << "6. DRAM - 32GB - $200\n";
        cout << "7. SRAM - 8GB - $100\n";
        cout << "8. SRAM - 16GB - $180\n";
        cout << "9. SRAM - 32GB - $300\n";

        cin >> choice;
        switch (choice) {
        case 1:
            initializeMemory(8, "Semiconductor", 50);
            break;
        case 2:
            initializeMemory(16, "Semiconductor", 90);
            break;
        case 3:
            initializeMemory(32, "Semiconductor", 160);
            break;
        case 4:
            initializeMemory(8, "DRAM", 70);
            break;
        case 5:
            initializeMemory(16, "DRAM", 120);
            break;
        case 6:
            initializeMemory(32, "DRAM", 200);
            break;
        case 7:
            initializeMemory(8, "SRAM", 100);
            break;
        case 8:
            initializeMemory(16, "SRAM", 180);
            break;
        case 9:
            initializeMemory(32, "SRAM", 300);
            break;
        default:
            cout << "Invalid selection, please try again." << std::endl;

        }
    }

    void initializeMemory(int cap, std::string techType, int pr) {
        capacity = cap;
        technologyType = techType;
        price = pr;
    }

    // Getters
    int getCapacity() const { return capacity; }
    std::string getTechnologyType() const { return technologyType; }
    int getPrice() const { return price; }

    // Display function to output details about the memory
    void display() const {
        cout << "-----------------------------Main Memory Details:---------------------------------------" << endl;
        cout << "Technology Type: " << technologyType << endl;
        cout << "Capacity: " << capacity << " GB" << endl;
        cout << "Price: $" << price << endl;
    }
};

//---------------------------------------------Network Class----------------------------------------------------
class NetworkCard {
private:
    std::string type;
    int speed; // Speed in Gbps
    double price;

public:
    // Default constructor
    NetworkCard() {
        while (true) {
            cout << "Enter the type of Network Card ('Ethernet' or 'Wireless'): ";
            cin >> type;
            if (type == "Ethernet" || type == "Wireless") {
                break;
            }
            else {
                cout << "Invalid input. Please enter 'Ethernet' or 'Wireless'.\n";
            }
        }

        while (true) {
            cout << "Enter the speed of the Network Card in Gbps (1-10): ";
            cin >> speed;
            if (speed >= 1 && speed <= 10) { // Validate that speed is between 1 and 10 Gbps
                break;
            }
            else {
                cout << "Invalid input. Please enter a speed between 1 and 10 Gbps.\n";
            }
        }

        price = calculatePrice(type, speed);
    }

    // Parameterized constructor
    NetworkCard(const std::string& t, int s, double p = 0.0) : type(t), speed(s) {
        if (p == 0) { // Calculate price if not provided
            price = calculatePrice(type, speed);
        }
        else {
            price = p; 
        }
    }

    // Method to calculate price based on type and speed
    double calculatePrice(const std::string& type, int speed) {
        double basePrice = 20.0; // Starting price for network cards
        if (type == "Ethernet") {
            basePrice += (speed <= 1000) ? 5.99 : 15.99; 
        }
        else if (type == "Wireless") {
            basePrice += (speed <= 300) ? 9.99 : 19.99; 
        }
        return basePrice;
    }

    // Getters and setters
    void setType(const std::string& t) {
        type = t;
        price = calculatePrice(t, speed); 
    }

    void setSpeed(int s) {
        speed = s;
        price = calculatePrice(type, s); // Recalculate price when speed changes
    }

    std::string getType() const { return type; }
    int getSpeed() const { return speed; }
    double getPrice() const { return price; }

    void display() const {
        std::cout << "Network Card Type: " << type << std::endl
            << "Speed: " << speed << " Gbps" << std::endl
            << "Price: $" << price << std::endl;
    }
};


class MotherBoard {
private:
    StorageDevice* storage;
    Port* ports;
    int numPorts;
    MainMemory* memory;
    NetworkCard* networkCard;

public:
    
    MotherBoard() {
        initializeInteractive();
    }

    // Parameterized constructor
    MotherBoard(int numPorts, const std::string& storageType, int storageCapacity,
        const std::string& memoryType, int memoryCapacity, const std::string& networkCardType, int networkCardSpeed)
        : numPorts(numPorts), storage(new StorageDevice(storageType, storageCapacity)),
        ports(new Port[numPorts]), memory(new MainMemory(memoryType, memoryCapacity)),
        networkCard(new NetworkCard(networkCardType, networkCardSpeed)) {


        for (int i = 0; i < numPorts; ++i) {
            ports[i] = Port("USB",9600);
        }
    }

    ~MotherBoard() {
        delete storage;
        delete[] ports;
        delete memory;
        delete networkCard;
    }

    void initializeInteractive() {
        cout << "Enter the number of ports: ";
        cin >> numPorts;
        if (numPorts <= 0) {
            numPorts = 1; 
        }
        ports = new Port[numPorts];
        for (int i = 0; i < numPorts; ++i) {
            string portType;
            int baudRate;

            // validation for portType
            while (true) {
                cout << "Enter type for port " << (i + 1) << " (USB/HDMI): ";
                cin >> portType;
                if (portType == "USB" || portType == "HDMI") {
                    break;  // Exit the loop if portType is valid
                }
                else {
                    cout << "Invalid port type entered. Please enter USB or HDMI.\n";
                }
            }

            // Input and validation for baudRate
            while (true) {
                cout << "Enter baud rate for port " << (i + 1) << " (4800, 9600): ";
                cin >> baudRate;
                if (baudRate == 4800 || baudRate == 9600) {
                    break;  // Exit the loop if baudRate is valid
                }
                else {
                    cout << "Invalid baud rate entered. Please enter 4800 or 9600.\n";
                }
            }

            ports[i] = Port(portType, baudRate);
        }

        storage = new StorageDevice();
        memory = new MainMemory();
        networkCard = new NetworkCard();
    }

    double calculateTotalPrice() const {
        double totalPrice = storage->getPrice() + memory->getPrice() + networkCard->getPrice();
        for (int i = 0; i < numPorts; ++i) {
            totalPrice += ports[i].getPrice();
        }
        return totalPrice;
    }

    void display() const {
        cout << "---------------------------MotherBoard Total Price: $-----------------------------" << calculateTotalPrice() << endl;
        storage->display();
        for (int i = 0; i < numPorts; ++i) {
            ports[i].display();
        }
        memory->display();
        networkCard->display();
    }
};

class PhysicalMemory {
private:
    int capacity; // in GB
    std::string type;
    double price;

    // Helper function to set price based on type
    void setPriceForType(const std::string& type) {
        if (type == "DDR4") {
            price = 50.0;
        }
        else if (type == "LPDDR4") {
            price = 70.0;
        }
        else if (type == "LPDDR5") {
            price = 90.0;
        }
        else {
            price = 0.0; // Default or unrecognized type
        }
    }

public:
    // Constructor that prompts for user input
    PhysicalMemory() {
        cout << "Enter the capacity of the Physical Memory in GB:(1 -10) ";
        cin >> capacity;
        while (capacity <= 0 || capacity > 10) {
            cout << "Invalid input. Please enter a positive integer for capacity: ";
            cin >> capacity;
        }

        cout << "Enter the type of Physical Memory ('DDR4', 'LPDDR4', 'LPDDR5'): ";
        cin >> type;
        while (type != "DDR4" && type != "LPDDR4" && type != "LPDDR5") {
            cout << "Invalid type entered. Please enter 'DDR4', 'LPDDR4', or 'LPDDR5': ";
            cin >> type;
        }

        setPriceForType(type);
    }

    double getCapacity() const { return capacity; }
    std::string getType() const { return type; }
    double getPrice() const { return price; }

    void setCapacity(int newCapacity) {
        if (newCapacity > 0) {
            capacity = newCapacity;
        }
    }

    void setType(const std::string& newType) {
        if (newType == "DDR4" || newType == "LPDDR4" || newType == "LPDDR5") {
            type = newType;
            setPriceForType(newType);
        }
    }

    void display() const {
        cout << "------------------------------Physical Memory Details:---------------------------------" << endl;
        cout << "  Capacity: " << capacity << " GB" << endl;
        cout << "  Type: " << type << endl;
        cout << "  Price: $" << price <<endl;
    }
};


//----------------------------------------PowerSupply-------------------------------------------------------
class PowerSupply {
private:
    int wattage;
    std::string efficiencyRating;
    double price;

public:
    // Constructor initializes from user input
    PowerSupply() {
        cout << "Enter wattage for the Power Supply ( 500W, 1000W, 1500W): ";
        cin >> wattage;
        while (wattage != 500 && wattage != 1000 && wattage != 1500) {
            cout << "Invalid input. Please enter a positive integer for capacity: ";
            cin >> wattage;
        }

        cout << "Enter efficiency rating (e.g., '80 Plus Platinum', '80 Plus Gold',80 Plus Titanium): ";

        std::getline(std::cin, efficiencyRating);
        while (efficiencyRating != "80 Plus Platinum" && efficiencyRating != "80 Plus Gold") {
            cout << "Invalid input." << endl;
            std::getline(std::cin, efficiencyRating);
        }

        price = calculatePrice(wattage, efficiencyRating);
    }

    static double calculatePrice(int wattage, const std::string& efficiency) {
        double basePrice = 30.0;
        basePrice += wattage * 0.05;
        if (efficiency == "80 Plus Gold") {
            basePrice += 20;
        }
        else if (efficiency == "80 Plus Platinum") {
            basePrice += 40;
        }
        else if (efficiency == "80 Plus Titanium") {
            basePrice += 60;
        }
        return basePrice;
    }
    double getPrice() const { return price; }


    void display() const {
        cout << "_______________________________Power Supply Details_____________________________________________" << endl;
        cout << "Power Supply Details:\n  Wattage: " << wattage << "W\n  Efficiency Rating: " << efficiencyRating << "\n  Price: $" << price << std::endl;
    }
};



class Case {
private:
    std::string formFactor; // e.g., ATX, Micro ATX, Mini ITX
    std::string color;
    double price;

public:
    // Default Constructor
    Case() {
        // Input and validation for formFactor
        while (true) {
            std::cout << "Enter formFactor (ATX, Micro ATX, Mini ITX): ";
            std::cin >> formFactor;
            if (formFactor == "ATX" || formFactor == "Micro ATX" || formFactor == "Mini ITX") {
                break;  // Valid input
            }
            else {
                cout << "Invalid input. Please enter a valid form factor.\n";
                cin >> formFactor;
            }
        }
       
        cout << "Enter color: ";

        
        while (true) {
            std::getline(std::cin, color);
            if (color == "Black" || color == "White") {
                break;  
            }
            else {
                std::cout << "Invalid input. Please enter 'Black' or 'White': ";
            }
        }
        // Calculate price based on inputs
        price = calculatePrice(formFactor, color);
    }

    // Constructor that allows an optional price override
    Case(const std::string& ff, const std::string& c, double p = -1.0)
        : formFactor(ff), color(c), price(p >= 0.0 ? p : calculatePrice(ff, c)) {}

    // Static method to calculate the price based on form factor and color
    static double calculatePrice(const std::string& formFactor, const std::string& color) {
        double basePrice = 40.0; 
        if (formFactor == "ATX") {
            basePrice += 10;
        }
        else if (formFactor == "Micro ATX") {
            basePrice += 5;
        }
        else if (formFactor == "Mini ITX") {
            basePrice += 15;
        }
        if (color == "White") {
            basePrice += 5; // Additional cost for white color
        }
        else if (color == "Black") {
            basePrice += 12;
        }
        return basePrice;
    }

    // Getters
    string getFormFactor() const { return formFactor; }
    string getColor() const { return color; }
    double getPrice() const { return price; }

    // Setters with price update logic
    void setFormFactor(const string& ff) {
        formFactor = ff;
        price = calculatePrice(ff, color);
    }
    void setColor(const string& c) {
        color = c;
        price = calculatePrice(formFactor, c);
    }

    // Display details
    
    void display() const {
        cout << "_______________________________Case Details___________________________________" << endl;
      
        cout << "  Form Factor: " << formFactor << endl;
        cout << "  Color: " << color << endl;
        cout << "  Price: $" << price << endl;
    }
};


//-----------------------------------------ComputerAssembly-----------------------------------------------------
class ComputerAssembly {
private:
    MotherBoard* motherboard;  
    PhysicalMemory* physicalMemory;  
    PowerSupply powerSupply; 
    Case computerCase; 
    double totalPrice;

public:
    // Default constructor
    ComputerAssembly()
        : motherboard(nullptr), physicalMemory(nullptr),
        powerSupply(), computerCase(), totalPrice(0.0) {}

    // Constructor initializing all components, aggregates are passed as pointers
    ComputerAssembly(MotherBoard* mb, PhysicalMemory* pm, const PowerSupply& ps, const Case& cc)
        : motherboard(mb), physicalMemory(pm), powerSupply(ps), computerCase(cc), totalPrice(0.0) {}

    

    // Setters for MotherBoard and PhysicalMemory
    void setMotherBoard(MotherBoard* mb) { motherboard = mb; }
    void setPhysicalMemory(PhysicalMemory* pm) { physicalMemory = pm; }

    // Calculate total price of the assembly
    double getTotalPrice() const {
        double total = 0.0;
        if (motherboard) total += motherboard->calculateTotalPrice();
        if (physicalMemory) total += physicalMemory->getPrice();
        total += powerSupply.getPrice();  // Add price of composed PowerSupply
        total += computerCase.getPrice(); // Add price of composed Case
        return total;
    }

    // Display detailed information about the assembly
    void display() const {
        cout << "_______________________________Computer Assembly________________________________________" << endl;
        if (motherboard) {
            std::cout << "MotherBoard Details:\n";
            motherboard->display();
        }
        else {
            std::cout << "No motherboard installed.\n";
        }

        if (physicalMemory) {
            physicalMemory->display();
        }
        else {
            cout << "No physical memory installed.\n";
        }

        powerSupply.display();
        computerCase.display();
        cout << "Total Assembly Price: $" << getTotalPrice() << std::endl;
    }
};

class PC : public ComputerAssembly {
private:
    CPU* cpu;
    GraphicsCard* graphicsCard;

public:
    PC(MotherBoard* mb, PhysicalMemory* pm, const PowerSupply& ps, const Case& cc)
        : ComputerAssembly(mb, pm, ps, cc) { 
        cpu = new CPU();  
        graphicsCard = new GraphicsCard();  // aggregat Graphics Card inside PC
    }

    ~PC() {
        delete cpu;
        delete graphicsCard;
    }

  
    double calculateTotalPrice()const {
        double totalPrice = ComputerAssembly::getTotalPrice();
        if (cpu) totalPrice += cpu->getTotalPrice();
        if (graphicsCard) totalPrice += graphicsCard->getPrice();
        return totalPrice;
    }

    // Display all information
    void display() const {
        ComputerAssembly::display();  // Display the base class components
        if (cpu) cpu->display();  // Display CPU details if available
        if (graphicsCard) graphicsCard->display();  // Display Graphics Card details if available
        cout << "------------------------Total PC Price: $-------------------------------" << endl;
            cout<< calculateTotalPrice() << endl;
    }
};


class Mac : public ComputerAssembly {
private:

    AppleSilicon aps;
public:
    Mac(MotherBoard* mb, PhysicalMemory* pm, const PowerSupply& ps, const Case& cc):ComputerAssembly(mb,pm,ps,cc){

       AppleSilicon aps();

        calculateTotalPrice();  
    }

 

    double calculateTotalPrice()const {
        double totalPrice = ComputerAssembly::getTotalPrice();
        totalPrice += aps.calculateTotalPrice();  // Add AppleSilicon price
        return totalPrice;
    }

    void display() const {
        ComputerAssembly::display();  // Display base class components
        aps.display();  // Display Apple Silicon details
        cout << "--------------Total Mac Price: $-------------------" << endl;
            cout<< calculateTotalPrice() << endl;
    }
};


