#include <iostream>
#include "Header.h"


using namespace std;
string choice;
int main() {
    while (true) {
        cout << "Would you like to build a Mac or a PC? (Enter 'Mac' or 'PC'): ";
        
        cin >> choice;
        if (choice == "PC" || choice == "Mac") {
            break;
       }
       
    }
       // creating motherboard and other compnents 
            MotherBoard* mb = new MotherBoard();
            PhysicalMemory* pm = new PhysicalMemory();
            PowerSupply ps;
            Case cs;
        
        if (choice == "Mac") {
           
            Mac mac(mb, pm, ps, cs);
            mac.display();
        }
        else if (choice == "PC") {
            PC pc(mb, pm, ps, cs);
            pc.display();
        }
        else {
            cout << "Invalid input. Please restart the program and enter 'Mac' or 'PC'." << endl;
        }

         delete mb;
        delete pm;
     
    
    return 0;
}
