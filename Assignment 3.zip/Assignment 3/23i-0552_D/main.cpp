#include <iostream>
#include "Header.h"
using namespace std;

int main()
{
    system("clear");
    //    ALU test(0, 1, 2, 4);
    //    test.printALU();

    // ControlUnit test1;
    // test1.printControlUnit();

    // CPUType bakar;
    // bakar.printCPUType();

    // CPU intel('a');
    // intel.printCPU();

    // intel.setCPUType("Bakar", "x87");
    // intel.setALU(3, 4, 5, 2);
    // intel.setCU(3.1);

    // intel.printCPU();

    // Port vga('a');
    // vga.printPort();
    // vga.setBaudRate(300000);
    // vga.setPortType("ehhh");
    // vga.printPort();

    // Port dp;
    // dp.printPort();
    // cin >> dp;
    // dp.printPort();

    // MainMemory ram;
    // ram.printMainMemory();

    // MainMemory bakar('a');
    // bakar.printMainMemory();
    // MainMemory ram1('a');
    // ram1.printMainMemory();
    // Motherboard first('a', ram1);
    // cout << endl;
    // first.printMobo();

    // PhysicalMemory bakar('a');
    // bakar.printPhysicalMemory();

    // MainMemory ehh;
    // cin >> ehh;
    // ehh.printMainMemory();

    // //>>>>>
    // Motherboard mobo('a', ehh);
    // mobo.printMobo();

    // PowerSupply xpg;
    // xpg.printPSU();
    // cin >> xpg;
    // xpg.printPSU();

    // GraphicsCard gpu;
    // gpu.printGraphicsCard();
    // cin >> gpu;
    // gpu.printGraphicsCard();

    // Battery wehh;
    // cin >> wehh;
    // wehh.printBattery();

    // Case oka;
    // cin >> oka;
    // oka.printCase();

    // Computer pc('a');
    // pc.printPC();
    // MainMemory bios('a');
    // Motherboard ASUS('a', bios);
    // pc.setMotherboard(ASUS);
    // cout << "===---=-=-=-=" << endl;
    // pc.printPC();

    // PC bakar('a');
    // bakar.printFinalPC();

    // Tablet aa('a');
    // aa.printTablet();

    ComputerAssembly comp;
    return 0;
}