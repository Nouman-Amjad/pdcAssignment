#include <iostream>
using namespace std;

//=== ALU ===
class ALU
{
    int noOfAdders;
    int noOfSubtractors;
    int noOfRegisters;
    int sizeOfRegisters;

public:
    ALU()
    {
        this->noOfAdders = 1;
        this->noOfSubtractors = 1;
        this->noOfRegisters = 2;
        this->sizeOfRegisters = 4;
    }

    ALU(char ch)
    {

        int adder, sub, numreg, sizeofreg;

        cout << "Input Number of Adders (Min 1): ";
        cin >> adder;
        while (adder < 1)
        {
            cout << "Invalid Adder Config. Input Number of Adders (Min 1): ";
            cin >> adder;
        }
        this->noOfAdders = adder;

        cout << "Input Number of Subtractors (Min 1): ";
        cin >> sub;
        while (sub < 1)
        {
            cout << "Invalid Subtractor Config. Input Number of Subtractors (Min 1): ";
            cin >> sub;
        }
        this->noOfSubtractors = sub;

        cout << "Input Number of Registers (Min 2): ";
        cin >> numreg;
        while (numreg < 2)
        {
            cout << "Invalid Register Config. Input Number of Registers (Min 2): ";
            cin >> numreg;
        }
        this->noOfRegisters = numreg;

        cout << "Input Size of Registers (Min 4-Bit): ";
        cin >> sizeofreg;
        while (sizeofreg < 4)
        {
            cout << "Invalid Register Size Config. Input Size of Registers (Min 4-Bit): ";
            cin >> sizeofreg;
        }
        this->sizeOfRegisters = sizeofreg;
    }

    ALU(int adders, int subtractors, int registers, int sizeregisters)
    {
        if (adders < 1 || subtractors < 1 || registers < 1 || sizeregisters < 1)
        {
            int choice;
            cout << "Incorrect ALU Configuration!" << endl;
            cout << "Type 1 to re-enter or 2 to use default values: ";
            cin >> choice;
            while (choice != 1 && choice != 2)
            {
                cout << "Type 1 to Re-Enter OR 2 to Use Default Values: ";
                cin >> choice;
            }
            bool validcheck = false;
            switch (choice)
            {
            case 1:
            {
                while (validcheck == false)
                {
                    validcheck = true;
                    cout << "Input No of Adders: ";
                    cin >> adders;
                    if (adders < 1)
                    {
                        cout << "Invalid No of Adders!" << endl;
                        validcheck = false;
                    }
                    else
                    {
                        this->setAdder(adders);
                    }

                    cout << "Input No of Subtractors: ";
                    cin >> subtractors;
                    if (subtractors < 1)
                    {
                        cout << "Invalid No of Subtractors!" << endl;
                        validcheck = false;
                    }
                    else
                    {
                        this->setSubtractor(subtractors);
                    }

                    cout << "Input No of Registers: ";
                    cin >> registers;
                    if (registers < 1)
                    {
                        cout << "Invalid No of Registers!" << endl;
                        validcheck = false;
                    }
                    else
                    {
                        this->setRegister(registers);
                    }

                    cout << "Input Size of Register: ";
                    cin >> sizeregisters;
                    if (sizeregisters < 1)
                    {
                        cout << "Invalid Size of Registers!" << endl;
                        validcheck = false;
                    }
                    else
                    {
                        this->setSizeRegister(sizeregisters);
                    }
                }
                break;
            }
            case 2:
            {
                *this = ALU(5);
                break;
            }
            }
        }
        else
        {
            this->noOfAdders = adders;
            this->noOfSubtractors = subtractors;
            this->noOfRegisters = registers;
            this->sizeOfRegisters = sizeregisters;
        }
    }

    // Accessors
    int getAdders() const
    {
        return this->noOfAdders;
    }

    int getSubtractors() const
    {
        return this->noOfSubtractors;
    }

    int getRegisters() const
    {
        return this->noOfRegisters;
    }

    int getSizeOfRegisters() const
    {
        return this->sizeOfRegisters;
    }

    // Mutators
    void setAdder(int addernum)
    {
        this->noOfAdders = addernum;
    }
    void setSubtractor(int subtractornum)
    {
        this->noOfSubtractors = subtractornum;
    }

    void setRegister(int registernum)
    {
        this->noOfRegisters = registernum;
    }

    void setSizeRegister(int registersize)
    {
        this->sizeOfRegisters = registersize;
    }

public:
    // Member Functions

    void printALU()
    {
        cout << "No of Adders: " << this->getAdders() << endl;
        cout << "No of Subtractors: " << this->getSubtractors() << endl;
        cout << "No of Registers: " << this->getRegisters() << endl;
        cout << "Size of Registers: " << this->getSizeOfRegisters() << endl;
    }
};

//=== Control Unit ===
class ControlUnit
{

    float clock;

public:
    ControlUnit()
    {
        clock = 1;
    }

    ControlUnit(char ch)
    {
        float clockspeed;
        cout << "Input Clock Speed [Min: 1GHz / Max: 7GHz]: ";
        cin >> clockspeed;
        while (clockspeed < 1 || clockspeed > 7)
        {
            cout << "Invalid Clock Speed Configuration [Min: 1GHz / Max: 7GHz]" << endl;
            cout << "Input Clock Speed (GHz): ";
            cin >> clockspeed;
        }
        this->clock = clockspeed;
    }
    ControlUnit(float clocks)
    {
        while (clocks < 1 || clocks > 7)
        {
            cout << "Invalid Clock Configuration [Min: 1GHz / Max: 7GHz]" << endl;
            cout << "Input Clock Speed (GHz): ";
            cin >> clocks;
        }
        this->clock = clocks;
    }

    // Accessors
    float getClock()
    {
        return this->clock;
    }

    // Mutators
    void setClock(float num)
    {
        while (num < 1 || num > 7)
        {
            cout << "Invalid Clock Speed [Min: 1GHz / Max: 7GHz]" << endl;
            cout << "Input Clock Speed (GHz): ";
            cin >> num;
        }
        this->clock = num;
    }

    void printControlUnit()
    {
        cout << "CPU Clock Speed: " << getClock() << "GHz" << endl;
    }
};

//=== CPU Type ===
class CPUType
{
    string type;         // Intel, AMD, AppleSilicon
    string architecture; // ARM64 or x86
    void adjustarchitecture(string &type, string &architecture)
    {
        if (type == "Intel" || type == "AMD")
        {
            if (architecture != "x64" && architecture != "x86")
            {
                cout << "Incorrect CPU Combination. " << type << " CPU Defaulting to x64." << endl;
                this->architecture = "x64";
            }
        }

        if (type == "AppleSilicon")
        {
            if (architecture != "ARM64")
            {
                cout << "Incorrect CPU Combination. AppleSilicon Defaulting to ARM64." << endl;
                this->architecture = "ARM64";
            }
        }
    }

public:
    CPUType()
    {
        this->type = "-";
        this->architecture = "-";
    }

    CPUType(char ch)
    {
        string cputype, cpuarchitecture;
        while (cputype != "Intel" && cputype != "AMD" && cputype != "AppleSilicon")
        {
            cout << "Input CPU Type (Intel, AMD, AppleSilicon): ";
            cin >> cputype;
        }
        this->type = cputype;

        while (cpuarchitecture != "ARM64" && cpuarchitecture != "x64" && cpuarchitecture != "x86")
        {
            cout << "Input CPU Architecture (ARM64, x64[64-bit], x86[32-bit]): ";
            cin >> cpuarchitecture;
        }
        this->architecture = cpuarchitecture;

        this->adjustarchitecture(cputype, cpuarchitecture);
    }

    CPUType(string type, string architecture)
    {
        while (type != "Intel" && type != "AMD" && type != "AppleSilicon")
        {
            cout << "Invalid CPU Type!" << endl;
            cout << "Input CPU Type (Intel, AMD, AppleSilicon): ";
            cin >> type;
        }
        this->type = type;

        while (architecture != "ARM64" && architecture != "x64" && architecture != "x86")
        {
            cout << "Input CPU Architecture (ARM64, x64[64-bit], x86[32-bit]): ";
            cin >> architecture;
        }
        this->architecture = architecture;
        this->adjustarchitecture(type, architecture);
    }

    // Accessors
    string getType() const
    {
        return this->type;
    }
    string getArchitecture() const
    {
        return this->architecture;
    }

    // Mutators
    void setType(string type)
    {
        while (type != "Intel" && type != "AMD" && type != "AppleSilicon")
        {
            cout << "Invalid CPU Type!" << endl;
            cout << "Input CPU Type (Intel, AMD, AppleSilicon): ";
            cin >> type;
        }
        this->type = type;
    }

    void setArchitecture(string architecture)
    {
        this->architecture = architecture;
        this->adjustarchitecture(this->type, architecture);
    }

    void printCPUType()
    {
        cout << "Manufacturer: " << this->type << endl;
        cout << "Architecture: " << this->architecture << endl;
    }
};

// === CPU ===
class CPU
{
    ALU alu;
    ControlUnit cu;
    CPUType cputype;
    float price;

public:
    CPU() : alu(), cu(), cputype() { this->price = 0; }

    CPU(int dummy) : alu('a'), cu('a'), cputype('a')
    {
        cout << "CPU Price ($): ";
        cin >> this->price;
    }

    CPU(int numadder, int numsubtractor, int numregister, int sizeregister, float clockspeed, string cpuname, string arch) : alu(numadder, numsubtractor, numregister, sizeregister), cu(clockspeed), cputype(cpuname, arch)
    {
        cout << "CPU Price ($): ";
        cin >> this->price;
    }

    // Mutators
    void printCPU()
    {
        cout << "** === CPU ===" << endl;
        cputype.printCPUType();
        cu.printControlUnit();
        alu.printALU();
        cout << "==============" << endl;
    }

    void setALU(int numadder, int numsubtractor, int numreg, int sizereg)
    {
        this->alu.setAdder(numadder);
        this->alu.setSubtractor(numsubtractor);
        this->alu.setRegister(numreg);
        this->alu.setSizeRegister(sizereg);
    }

    void setCU(float clockspeed)
    {
        this->cu.setClock(clockspeed);
    }

    void setCPUType(string cpuname, string arch)
    {
        this->cputype.setType(cpuname);
        this->cputype.setArchitecture(arch);
    }

    // Accessors

    ALU getALU() const
    {
        return this->alu;
    }

    double getCPUPrice() const
    {
        return price;
    }

    ControlUnit getCU() const
    {
        return this->cu;
    }

    CPUType getCPUType() const
    {
        return this->cputype;
    }
};

// === MainMemory ===
class MainMemory : public CPU
{
    int capacity;
    string technologyType;

public:
    // Constructors
    MainMemory()
    {
        this->capacity = 1;
        this->technologyType = "-";
    }

    MainMemory(int size, string type)
    {
        this->capacity = size;
        while (type != "Silicon" && type != "Semiconductor")
        {
            cout << "Unsupported Memory Type. Enter a Valid Memory Type (Silicon, Semiconductor): ";
            cin >> type;
        }
        this->technologyType = type;
    }

    MainMemory(char ch)
    {
        int size;
        string type;
        cout << "Enter Main CPU Memory Capacity (MB): ";
        cin >> size;
        while (size < 1 || size > 256)
        {
            cout << "Unsupported CPU Memory Size! Enter a Valid Size (1-256MB): ";
            cin >> size;
        }
        this->capacity = size;

        cout << "Enter Memory Type (Silicon, Semicoductor): ";
        cin >> type;
        while (type != "Silicon" && type != "Semiconductor")
        {
            cout << "Unsupported CPU Memory Type. Enter a Valid Memory Type (Silicon, Semiconductor): ";
            cin >> type;
        }
        this->technologyType = type;
    }

    // Mutators

    void setMemorySize(int size)
    {
        while (size < 1 || size > 256)
        {
            cout << "Unsupported CPU Memory Size! Enter a Valid Size (1-256MB): ";
            cin >> size;
        }
        this->capacity = size;
    }

    void setMemoryType(string type)
    {
        while (type != "Silicon" && type != "Semiconductor")
        {
            cout << "Unsupported CPU Memory Type. Enter a Valid Memory Type (Silicon, Semiconductor): ";
            cin >> type;
        }
        this->technologyType = type;
    }

    // Accessors

    int getMemorySize() const
    {
        return this->capacity;
    }

    string getMemoryType() const
    {
        return this->technologyType;
    }

    // Member Functions
    void printMainMemory()
    {
        cout << "** === CPU Bios ===" << endl;
        cout << "CPU Memory: " << this->capacity << " MB" << endl;
        cout << "CPU Memory Type: " << this->technologyType << endl;
        cout << "===================" << endl;
    }
};

istream &operator>>(istream &in, MainMemory &mm)
{
    int size;
    string type;
    cout << "Enter Main CPU Memory Capacity (MB): ";
    in >> size;
    while (size < 1 || size > 256)
    {
        cout << "Unsupported CPU Memory Size! Enter a Valid Size (1-256MB): ";
        in >> size;
    }
    mm.setMemorySize(size);

    cout << "Enter Memory Type (Silicon, Semicoductor): ";
    in >> type;
    while (type != "Silicon" && type != "Semiconductor")
    {
        cout << "Unsupported CPU Memory Type. Enter a Valid Memory Type (Silicon, Semiconductor): ";
        in >> type;
    }
    mm.setMemoryType(type);
    return in;
}

// === Port ===
class Port
{
    string type;
    int baud_rate;

public:
    Port()
    {
        this->type = "-";
        this->baud_rate = 0;
    }

    Port(string porttype, int brate)
    {
        while (porttype != "VGA" && porttype != "I/O" && porttype != "USB" && porttype != "HDMI" && porttype != "DVI" && porttype != "DP")
        {
            cout << "Port Unavailable! Enter Valid Port (VGA, DVI, DP, I/O, USB): ";
            cin >> porttype;
        }
        this->type = porttype;

        while (brate < 0 || brate > 200000)
        {
            cout << "Unsupported Baud Rate! Enter a Valid Value (0 - 200,000 bps): ";
            cin >> brate;
        }
        this->baud_rate = brate;
    }

    Port(char ch)
    {
        string porttype;
        int brate;

        cout << "Enter Port Type (VGA, DVI, DP, I/O, USB): ";
        cin >> porttype;

        while (porttype != "VGA" && porttype != "I/O" && porttype != "USB" && porttype != "HDMI" && porttype != "DVI" && porttype != "DP")
        {
            cout << "Port Unavailable! Enter Valid Port (VGA, DVI, DP, I/O, USB): ";
            cin >> porttype;
        }
        this->type = porttype;

        cout << "Enter the Port's Baud Rate (0 - 200,000 bps):";
        cin >> brate;
        while (brate < 0 || brate > 200000)
        {
            cout << "Unsupported Baud Rate! Enter a Valid Value (0 - 200,000 bps): ";
            cin >> brate;
        }
        this->baud_rate = brate;
    }

    // Accessors

    string getPortType() const
    {
        return this->type;
    }

    int getBaudRate() const
    {
        return this->baud_rate;
    }

    // Mutators

    void setPortType(string porttype)
    {
        while (porttype != "VGA" && porttype != "I/O" && porttype != "USB" && porttype != "HDMI" && porttype != "DVI" && porttype != "DP")
        {
            cout << "Port Unavailable! Enter Valid Port (VGA, DVI, DP, I/O, USB): ";
            cin >> porttype;
        }
        this->type = porttype;
    }

    void setBaudRate(int brate)
    {
        while (brate < 0 || brate > 200000)
        {
            cout << "Unsupported Baud Rate! Enter a Valid Value (0 - 200,000 bps): ";
            cin >> brate;
        }
        this->baud_rate = brate;
    }

    void printPort() const
    {
        cout << "Port Type: " << this->type << endl;
        cout << "Baud Rate: " << this->baud_rate << " bps" << endl;
    }
};

istream &operator>>(istream &in, Port &portobj)
{
    string porttype;
    int brate;

    cout << "Enter Port Type (VGA, DVI, DP, I/O, USB): ";
    in >> porttype;

    while (porttype != "VGA" && porttype != "I/O" && porttype != "USB" && porttype != "HDMI" && porttype != "DVI" && porttype != "DP")
    {
        cout << "Port Unavailable! Enter Valid Port (VGA, DVI, DP, I/O, USB): ";
        in >> porttype;
    }
    portobj.setPortType(porttype);

    cout << "Enter the Port's Baud Rate (0 - 200,000 bps):";
    in >> brate;
    while (brate < 0 || brate > 200000)
    {
        cout << "Unsupported Baud Rate! Enter a Valid Value (0 - 200,000 bps): ";
        in >> brate;
    }
    portobj.setBaudRate(brate);

    return in;
}

// === Motherboard ===
class Motherboard
{
    string manufacturer;
    MainMemory *mm;
    int numports;
    Port *ports;
    float price;

public:
    Motherboard()
    {
        this->manufacturer = "-";
        numports = 0;
        mm = nullptr;
        ports = nullptr;
        this->price = 0;
    }

    ~Motherboard()
    {
        delete[] ports;
    }

    Motherboard(string name, int noports, MainMemory memory)
    {
        this->manufacturer = name;
        while (noports < 1 || noports > 10)
        {
            cout << "Unsupported No. of Ports! Enter a Valid Number (0-10): ";
            cin >> noports;
        }
        this->numports = noports;
        this->ports = new Port[this->numports];
        mm = &memory;
        this->price = 0;
    }

    Motherboard(char ch, MainMemory memory)
    {
        string name;
        int noports;

        cout << "Enter the Motherboard Manufacturer (ASUS, Gigabyte, MSI etc.): ";
        cin >> name;
        this->manufacturer = name;

        cout << "Enter the No. of Ports on the Motherboard (1-10): ";
        cin >> noports;
        while (noports < 1 || noports > 10)
        {
            cout << "Unsupported No. of Ports! Enter a Valid Number (0-10): ";
            cin >> noports;
        }
        this->numports = noports;

        this->ports = new Port[this->numports];
        for (int i = 0; i < this->numports; i++)
        {
            cout << "Port #" << i + 1 << ": " << endl;
            cin >> ports[i];
        }
        mm = &memory;
        cout << "Motherboard Price ($): ";
        cin >> this->price;
    }

    // Accessors

    string getManufacturer() const
    {
        return this->manufacturer;
    }

    int getNumPorts() const
    {
        return this->numports;
    }

    double getMoboPrice() const
    {
        return price;
    }

    MainMemory *getMainMemory() const
    {
        return this->mm;
    }

    Port *getPort() const
    {
        return this->ports;
    }

    // Mutators
    void setManufacturer(string manu)
    {
        this->manufacturer = manu;
    }

    void setNumPorts(int noports)
    {
        while (noports < 1 || noports > 10)
        {
            cout << "Unsupported No. of Ports! Enter a Valid Number (0-10): ";
            cin >> noports;
        }
        this->numports = noports;
    }

    void setMainMemory(MainMemory memory)
    {
        this->mm = &memory;
    }

    void setPorts(int numports)
    {
        delete[] this->ports;
        this->ports = new Port[numports];
        for (int i = 0; i < numports; i++)
        {
            cout << "Port #" << i + 1 << ": " << endl;
            cin >> ports[i];
        }
    }

    // Member Functions

    void printMobo()
    {
        cout << "** === Motherboard ===" << endl;
        cout << "Motherboard Manufacturer: " << this->manufacturer << endl;
        // if (mm != nullptr)
        // {
        //     mm->printMainMemory();
        // }
        cout << "Number of Ports: " << this->numports << endl;
        if (numports != 0)
        {
            cout << "--- All Ports --- " << endl;
            for (int i = 0; i < numports; i++)
            {
                ports[i].printPort();
            }
            cout << "-----------------" << endl;
        }
        cout << "======================" << endl;
    }
};

istream &operator>>(istream &in, Motherboard &mobo)
{
    string name;
    int noports;

    MainMemory memory;
    in >> memory;
    mobo.setMainMemory(memory);

    cout << "Enter the Motherboard Manufacturer (ASUS, Gigabyte, MSI etc.): ";
    in >> name;
    mobo.setManufacturer(name);

    cout << "Enter the No. of Ports on the Motherboard (1-10): ";
    in >> noports;
    while (noports < 1 || noports > 10)
    {
        cout << "Unsupported No. of Ports! Enter a Valid Number (0-10): ";
        in >> noports;
    }
    mobo.setNumPorts(noports);
    mobo.setPorts(noports);

    return in;
}

class PhysicalMemory : public MainMemory
{
    int capacity;
    int ddrver;
    string type;
    float price;

public:
    void physicalMemoryValidation()
    {
        if (getCPUType().getType() == "AMD" || getCPUType().getType() == "Intel")
        {
            this->type = "DDR";
            cout << "Your CPU Manufacturer, which is " << getCPUType().getType() << " uses " << this->type << " memory." << endl;
        }
        else if (getCPUType().getType() == "AppleSilicon")
        {
            this->type = "LPDDR";
            cout << "Your CPU Manufacturer, which is " << getCPUType().getType() << " uses " << this->type << " memory." << endl;
        }
        else
        {
            this->type = "-";
        }
    }
    PhysicalMemory()
    {
        this->capacity = 1;
        this->type = "-";
        this->ddrver = 4;
        this->price = 0;
    }
    PhysicalMemory(int size, string type)
    {
        this->capacity = size;
        this->ddrver = 4;
        this->type = "-";
        this->price = 0;
    }
    PhysicalMemory(char ch) : MainMemory('a')
    {
        int size;
        int dver;
        string technology;

        cout << "Enter RAM Capacity (4-256GB): ";
        cin >> size;
        while (size < 4 || size > 256)
        {
            cout << "Invalid RAM Size. Please Enter Valid RAM Capacity (4-256GB): ";
            cin >> size;
        }
        this->capacity = size;

        cout << "Enter DDR/LPDDR Version (4/5): ";
        cin >> dver;
        while (dver != 4 && dver != 5)
        {
            cout << "Invalid Version! Only DDR/LPDDR 4 & 5 Supported. Enter again: ";
            cin >> dver;
        }
        this->ddrver = dver;

        cout << "RAM Price ($): ";
        cin >> this->price;

        if (getCPUType().getType() == "AMD" || getCPUType().getType() == "Intel")
        {
            this->type = "DDR";
            cout << "Your CPU Manufacturer, which is " << getCPUType().getType() << " uses " << this->type << " memory." << endl;
        }
        else if (getCPUType().getType() == "AppleSilicon")
        {
            this->type = "LPDDR";
            cout << "Your CPU Manufacturer, which is " << getCPUType().getType() << " uses " << this->type << " memory." << endl;
        }
        else
        {
            this->type = "-";
        }
    }

    void printPhysicalMemory()
    {
        cout << "** === RAM ===" << endl;
        cout << "Capacity: " << this->capacity << "GB" << endl;
        if (this->type != "-")
        {
            cout << "DDR Standard: " << this->type << this->ddrver << endl;
        }
        cout << "=============" << endl;
    }
    // Accessors
    int getCapacity() const
    {
        return this->capacity;
    }
    int getDDRVer() const
    {
        return this->ddrver;
    }

    string getPhysicalType() const
    {
        return this->type;
    }

    double getRAMPrice() const
    {
        return price;
    }
    // Mutators

    void setCapacity(int size)
    {
        while (size < 4 || size > 256)
        {
            cout << "Invalid RAM Size. Please Enter Valid RAM Capacity (4-256GB): ";
            cin >> size;
        }
        this->capacity = size;
    }

    void setDDRVer(int dver)
    {
        while (dver != 4 && dver != 5)
        {
            cout << "Invalid Version! Only DDR/LPDDR 4 & 5 Supported. Enter again: ";
            cin >> dver;
        }
        this->ddrver = dver;
    }

    void setPhysicalType(string type)
    {
        this->type = type;
        // physicalMemoryValidation();
    }
};

class Computer
{
    PhysicalMemory *pm;
    Motherboard *mb;
    CPU *cpu;

public:
    Computer() : pm(nullptr), mb(nullptr), cpu(nullptr) {}
    Computer(PhysicalMemory &pms, Motherboard &mbs, CPU &cpus) : pm(&pms), mb(&mbs), cpu(&cpus) {}
    Computer(char ch)
    {
        cpu = new CPU('a');
        pm = new PhysicalMemory('a');
        mb = new Motherboard('a', *pm);
    }
    // Accessors

    PhysicalMemory *getPhysicalMemory() const
    {
        return this->pm;
    }
    Motherboard *getMotherboard() const
    {
        return this->mb;
    }

    CPU *getCPU() const
    {
        return this->cpu;
    }

    // Mutators

    void setPhysicalMemory(PhysicalMemory mem)
    {
        this->pm = &mem;
    }

    void setMotherboard(Motherboard mobo)
    {
        this->mb = &mobo;
    }

    void setCPU(CPU proc)
    {
        this->cpu = &proc;
    }

    void printPC()
    {

        cpu->printCPU();
        cout << endl;
        pm->printMainMemory();
        cout << endl;
        pm->printPhysicalMemory();
        cout << endl;
        mb->printMobo();
    }
};

class PowerSupply
{
    int wattage;
    string efficency;
    double price;

public:
    PowerSupply()
    {
        this->wattage = 0;
        this->efficency = "-";
        this->price = 0;
    }
    PowerSupply(int wattage, string efficency, double price)
    {
        this->wattage = wattage;
        this->efficency = efficency;
        this->price = price;
    }

    PowerSupply(char ch)
    {
        int wattage;
        double price;
        string efficency;
        cout << "Enter Power Supply Wattage(W): ";
        cin >> wattage;
        while (wattage < 250 || wattage > 1500)
        {
            cout << "Dangerous Configuration! Enter a Safe PSU Rating (250W - 1500W): ";
            cin >> wattage;
        }

        this->wattage = wattage;

        cout << "Enter PSU Efficency (Bronze, Gold, Platinum): ";
        cin >> efficency;
        while (efficency != "Bronze" && efficency != "Silver" && efficency != "Gold" && efficency != "Platinum")
        {
            cout << "Wrong Certification. Enter a Valid Efficnecy Rating (Bronze, Silver, Gold, Platinum): ";
            cin >> efficency;
        }

        this->efficency = efficency;

        cout << "Enter PSU Price ($): ";
        cin >> price;
        this->price = price;
    }
    // Accessors

    int getWattage() const
    {
        return this->wattage;
    }

    string getEfficency() const
    {
        return this->efficency;
    }

    double getPSUPrice() const
    {
        return this->price;
    }

    // Mutators

    void setWattage(int watt)
    {
        this->wattage = watt;
    }

    void setEfficency(string str)
    {
        this->efficency = str;
    }

    void setPSUPrice(double psuprice)
    {
        this->price = psuprice;
    }

    // Member Functions

    void printPSU()
    {
        cout << "=== Power Supply (PSU) ===" << endl;
        cout << "PSU Wattage: " << this->wattage << "W" << endl;
        cout << "PSU Efficency: 80+ " << this->efficency << endl;
        cout << "PSU Price: $" << this->price << endl;
        cout << "==========================" << endl;
    }
};

istream &operator>>(istream &in, PowerSupply &psu)
{
    int wattage;
    double price;
    string efficency;
    cout << "Enter Power Supply Wattage(W): ";
    in >> wattage;
    while (wattage < 250 || wattage > 1500)
    {
        cout << "Dangerous Configuration! Enter a Safe PSU Rating (250W - 1500W): ";
        in >> wattage;
    }

    psu.setWattage(wattage);

    cout << "Enter PSU Efficency (Bronze, Gold, Platinum): ";
    in >> efficency;
    while (efficency != "Bronze" && efficency != "Silver" && efficency != "Gold" && efficency != "Platinum")
    {
        cout << "Wrong Certification. Enter a Valid Efficnecy Rating (Bronze, Silver, Gold, Platinum): ";
        in >> efficency;
    }

    psu.setEfficency(efficency);

    cout << "Enter PSU Price ($): ";
    in >> price;
    psu.setPSUPrice(price);
    return in;
}

class GraphicsCard
{
    string brand;
    int memorySize;
    double price;

public:
    GraphicsCard() : brand("-"), memorySize(0), price(0) {}
    GraphicsCard(string &b, int size, double p) : brand(b), memorySize(size), price(p) {}
    GraphicsCard(char ch)
    {
        string brand;
        int memorySize;
        double price;

        cout << "Enter Graphics Card Brand (NVIDIA, AMD, Intel etc.): ";
        cin >> brand;
        this->brand = brand;

        cout << "Enter Graphics Card Memory Size (GB): ";
        cin >> memorySize;
        this->memorySize = memorySize;

        cout << "Enter Graphics Card Price ($): ";
        cin >> price;
        this->price = price;
    }

    // Accessors
    string getBrand() const { return brand; }
    int getMemorySize() const { return memorySize; }
    double getGPUPrice() const { return price; }

    // Mutators
    void setBrand(string b) { brand = b; }
    void setMemorySize(int size) { memorySize = size; }
    void setPrice(double p) { price = p; }

    // Member Functions
    void printGraphicsCard()
    {
        cout << "** === GPU ===" << endl;
        cout << "Manufacturer: " << this->brand << endl;
        cout << "Memory: " << this->memorySize << "GB" << endl;
        cout << "Price: $" << this->price << endl;
        cout << "============" << endl;
    }
};

istream &operator>>(istream &in, GraphicsCard &gpu)
{
    string brand;
    int memorySize;
    double price;

    cout << "Enter Graphics Card Brand (NVIDIA, AMD, Intel etc.): ";
    in >> brand;
    gpu.setBrand(brand);

    cout << "Enter Graphics Card Memory Size (GB): ";
    in >> memorySize;
    gpu.setMemorySize(memorySize);

    cout << "Enter Graphics Card Price ($): ";
    in >> price;
    gpu.setPrice(price);

    return in;
}

class Battery
{
    int capacity;
    float price;

public:
    Battery() : capacity(0) { this->price = 0; }

    Battery(int cap) : capacity(cap) {}

    int getCapacity() const
    {
        return capacity;
    }

    double getBatteryPrice() const
    {
        return price;
    }

    void setCapacity(int cap)
    {
        capacity = cap;
    }

    void setBatteryPrice(float pr)
    {
        this->price = pr;
    }

    void printBattery()
    {
        cout << "** === Battery ===" << endl;
        cout << "Capacity: " << this->capacity << "Wh" << endl;
        cout << "===============" << endl;
    }
};

istream &operator>>(istream &in, Battery &bat)
{
    int cap;
    cout << "Enter Battery Capcity (Wh): ";
    in >> cap;
    while (cap < 10 || cap > 100)
    {
        cout << "Invalid Battery Config! Enter a Valid Capacity (10Wh - 100Wh): ";
        in >> cap;
    }
    bat.setCapacity(cap);
    return in;
}

class Case
{
    string formFactor;
    string color;
    double price;

public:
    Case() : formFactor("-"), color("-"), price(0) {}

    Case(string form, string col, double pr) : formFactor(form), color(col), price(pr) {}

    Case(char ch)
    {
        string formFactor, color;
        double price;

        cout << "Enter Case's Form Factor (ATX, mATX, MiniATX): ";
        cin >> formFactor;
        while (formFactor != "ATX" && formFactor != "mATX" && formFactor != "MiniATX")
        {
            cout << "Form Factor Not Available! Enter a Valid Form Factor (ATX, mATX, MiniATX): ";
            cin >> formFactor;
        }
        this->formFactor = formFactor;

        cout << "Enter Case Color: ";
        cin >> color;
        this->color = color;

        cout << "Enter Case Price ($): ";
        cin >> price;
        this->price = price;
    }

    // Accessors
    string getFormFactor() const
    {
        return formFactor;
    }

    void setFormFactor(string form)
    {
        formFactor = form;
    }

    string getColor() const
    {
        return color;
    }

    // Mutators
    void setColor(string col)
    {
        color = col;
    }

    double getCasePrice() const
    {
        return price;
    }

    void setPrice(double pr)
    {
        price = pr;
    }

    void printCase()
    {
        cout << "** === PC Case ===" << endl;
        cout << "Case Form Factor: " << this->formFactor << endl;
        cout << "Case Color: " << this->color << endl;
        cout << "Case Price ($): " << this->price << endl;
        cout << "==================" << endl;
    }
};

istream &operator>>(istream &in, Case &pcCase)
{
    string formFactor, color;
    double price;

    cout << "Enter Case's Form Factor (ATX, mATX, MiniATX): ";
    in >> formFactor;
    while (formFactor != "ATX" && formFactor != "mATX" && formFactor != "MiniATX")
    {
        cout << "Form Factor Not Available! Enter a Valid Form Factor (ATX, mATX, MiniATX): ";
        in >> formFactor;
    }
    pcCase.setFormFactor(formFactor);

    cout << "Enter Case Color: ";
    in >> color;
    pcCase.setColor(color);

    cout << "Enter Case Price ($): ";
    in >> price;
    pcCase.setPrice(price);

    return in;
}

class StorageDevice
{
    string type;
    int capacity;
    double price;

public:
    StorageDevice() : type("-"), capacity(0), price(0) {}

    StorageDevice(string typ, int cap, double pr) : type(typ), capacity(cap), price(pr) {}
    StorageDevice(char ch)
    {
        string type;
        int capacity;
        double price;

        cout << "Enter Storage Device (e.g., HDD, SSD): ";
        cin >> type;
        this->type = type;

        cout << "Enter Storage Capacity (GB): ";
        cin >> capacity;
        this->capacity = capacity;

        cout << "Enter Storage Price ($): ";
        cin >> price;
        this->price = price;
    }

    // Accessors
    string getType() const
    {
        return type;
    }

    void setType(string typ)
    {
        type = typ;
    }

    int getCapacity() const
    {
        return capacity;
    }

    // Mutators
    void setCapacity(int cap)
    {
        capacity = cap;
    }

    double getStoragePrice() const
    {
        return price;
    }

    void setPrice(double pr)
    {
        price = pr;
    }

    void printStorageDevice()
    {
        cout << "** === Storage Devices ===" << endl;
        cout << "Storage: " << this->type << endl;
        cout << "Capacity: " << this->capacity << "GB" << endl;
        cout << "Price: $" << this->price << endl;
        cout << "==========================" << endl;
    }
};

istream &operator>>(istream &in, StorageDevice &storage)
{
    string type;
    int capacity;
    double price;

    cout << "Enter Storage Device (e.g., HDD, SSD): ";
    in >> type;
    storage.setType(type);

    cout << "Enter Storage Capacity (GB): ";
    in >> capacity;
    storage.setCapacity(capacity);

    cout << "Enter Storage Price ($): ";
    in >> price;
    storage.setPrice(price);

    return in;
}

class NetworkCard
{
    string type;
    int speed;
    double price;

public:
    NetworkCard() : type("-"), speed(0), price(0) {}

    NetworkCard(string typ, int spd, double pr) : type(typ), speed(spd), price(pr) {}

    NetworkCard(char ch)
    {
        string type;
        int speed;
        double price;

        cout << "Enter Network Card Type (e.g., Ethernet, Wi-Fi): ";
        cin >> type;
        while (type != "Ethernet" && type != "Wi-Fi")
        {
            cout << "Unsupported Card Type! Please Re-Enter Type (Ethernet, Wi-Fi): ";
            cin >> type;
        }
        this->type = type;

        cout << "Enter Network Card Speed (Mbps): ";
        cin >> speed;
        while (speed < 0 || speed > 10000)
        {
            cout << "Unsupported Card Speed! Enter a Valid Network Connection Speed (Mbps): ";
            cin >> speed;
        }
        this->speed = speed;

        cout << "Enter Network Card Price ($): ";
        cin >> price;
        this->price = price;
    }

    // Accessors
    string getType() const
    {
        return type;
    }
    double getNetworkPrice() const
    {
        return price;
    }
    int getSpeed() const
    {
        return speed;
    }

    // Mutators

    void setType(string typ)
    {
        type = typ;
    }

    void setSpeed(int spd)
    {
        speed = spd;
    }

    void setPrice(double pr)
    {
        price = pr;
    }

    void printNetworkCard()
    {
        cout << "** === Network Card ===" << endl;
        cout << "Network Adapter: " << this->type << endl;
        cout << "Adapter Speed: " << this->speed << " Mbps" << endl;
        cout << "Network Adapter Price: $" << this->price << endl;
        cout << "=======================" << endl;
    }
};

istream &operator>>(istream &in, NetworkCard &network)
{
    string type;
    int speed;
    double price;

    cout << "Enter Network Card Type (e.g., Ethernet, Wi-Fi): ";
    in >> type;
    network.setType(type);

    cout << "Enter Network Card Speed (Mbps): ";
    in >> speed;
    network.setSpeed(speed);

    cout << "Enter Network Card Price ($): ";
    in >> price;
    network.setPrice(price);

    return in;
}

class Laptop : public Computer, public Battery, public StorageDevice, public NetworkCard, public GraphicsCard
{
    float laptopPrice;

public:
    Laptop() : Computer(), Battery(), GraphicsCard(), StorageDevice(), NetworkCard() {}
    Laptop(char ch) : Computer('a'), GraphicsCard('a'), StorageDevice('a'), NetworkCard('a'), Battery('a')
    {
        this->laptopPrice = getCPU()->getCPUPrice() + getPhysicalMemory()->getRAMPrice() + getMotherboard()->getMoboPrice() + getBatteryPrice() + getNetworkPrice() + getGPUPrice() + getStoragePrice();
        if (getCPU()->getCPUType().getType() == "AppleSilicon")
        {
            cout << endl;
            cout << "NOTICE!" << endl;
            cout << "You are using an AppleSilicon CPU, therefore your GPU is being defaulted to AppleGPU w/ same specifications!" << endl;
            GraphicsCard::setBrand("AppleGPU");
        }

        if (getCPU()->getCPUType().getType() == "AMD" || getCPU()->getCPUType().getType() == "Intel")
        {
            getPhysicalMemory()->setPhysicalType("DDR");
        }
        else if (getCPU()->getCPUType().getType() == "AppleSilicon")
        {
            getPhysicalMemory()->setPhysicalType("LPDDR");
        }
        else
        {
            getPhysicalMemory()->setPhysicalType("-");
        }
    }

    float getLaptopPrice() const
    {
        return this->laptopPrice;
    }

    void printLaptop()
    {
        cout << endl;
        printPC();
        cout << endl;
        printGraphicsCard();
        cout << endl;
        printBattery();
        cout << endl;
        printStorageDevice();
        cout << endl;
        printNetworkCard();
        cout << endl;
    }
};

class PC : public Computer, public PowerSupply, public GraphicsCard, public Case, public NetworkCard, public StorageDevice
{
    float pcPrice;

public:
    PC() : Computer(), GraphicsCard(), PowerSupply(), Case(), NetworkCard(), StorageDevice() {}
    PC(char ch) : Computer('a'), GraphicsCard('a'), PowerSupply('a'), Case('a'), NetworkCard('a'), StorageDevice('a')
    {
        this->pcPrice = getCPU()->getCPUPrice() + getPhysicalMemory()->getRAMPrice() + getMotherboard()->getMoboPrice() + getCasePrice() + getNetworkPrice() + getGPUPrice() + getPSUPrice() + getStoragePrice();
        if (getCPU()->getCPUType().getType() == "AppleSilicon")
        {
            cout << endl;
            cout << "NOTICE!" << endl;
            cout << "You are using an AppleSilicon CPU, therefore your GPU is being defaulted to AppleGPU w/ same specifications!" << endl;
            GraphicsCard::setBrand("AppleGPU");
        }

        // if (Computer::getPhysicalMemory()->getDDRVer() == 4)

        if (getCPU()->getCPUType().getType() == "AMD" || getCPU()->getCPUType().getType() == "Intel")
        {
            getPhysicalMemory()->setPhysicalType("DDR");
        }
        else if (getCPU()->getCPUType().getType() == "AppleSilicon")
        {
            getPhysicalMemory()->setPhysicalType("LPDDR");
        }
        else
        {
            getPhysicalMemory()->setPhysicalType("-");
        }
    }

    float getPCPrice() const
    {
        return this->pcPrice;
    }

    void printFinalPC()
    {
        cout << endl;
        printPC();
        cout << endl;
        printGraphicsCard();
        cout << endl;
        printPSU();
        cout << endl;
        printCase();
        cout << endl;
        printStorageDevice();
        cout << endl;
        printNetworkCard();
        cout << endl;
    }
};

class Tablet : public Laptop
{
    float tabPrice;

public:
    Tablet() : Laptop() {}
    Tablet(char ch) : Laptop('a')
    {
        this->tabPrice = getCPU()->getCPUPrice() + getPhysicalMemory()->getRAMPrice() + getMotherboard()->getMoboPrice() + getBatteryPrice() + getNetworkPrice() + getGPUPrice() + getStoragePrice();
    }

    void printTablet()
    {
        printLaptop();
    }

    float getTabPrice() const
    {
        return this->tabPrice;
    }
};

class ComputerAssembly : public PC, public Tablet
{
    double totalPrice;

public:
    ComputerAssembly()
    {
        int choice;
        cout << "**** Welcome to PC Builder ******" << endl;
        cout << "1) PC" << endl;
        cout << "2) Laptop" << endl;
        cout << "1) Tablet" << endl;
        cout << "Choose (1/2/3): " << endl;
        cin >> choice;
        while (choice != 1 && choice != 2 && choice != 3)
        {
            cout << "Enter a Valid Option (1, 2 or 3 ONLY): ";
            cin >> choice;
        }

        if (choice == 1)
        {

            cout << "Pick Your Specs: " << endl;
            PC pc('a');
            cout << "Your Final PC Specs (Adjusted for Compatibility) are: " << endl;
            pc.printFinalPC();
            this->totalPrice = pc.getPCPrice();
        }
        if (choice == 2)
        {

            cout << "Pick Your Specs: " << endl;
            Laptop lappy('a');
            cout << "Your Final Laptop Specs (Adjusted for Compatibility) are: " << endl;
            lappy.printLaptop();
            this->totalPrice = lappy.getLaptopPrice();
        }
        if (choice == 3)
        {

            cout << "Pick Your Specs: " << endl;
            Tablet tab('a');
            cout << "Your Final Tablet Specs (Adjusted for Compatibility) are: " << endl;
            tab.printTablet();
            this->totalPrice = tab.getTabPrice();
        }

        cout << "Total Price: $" << this->totalPrice << endl;
    }
};


