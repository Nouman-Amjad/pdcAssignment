#include <iostream>
using namespace std;

#ifndef Q
#define Q

class ALU {
	int noOfAdders;
	int noOfSubtractor;
	int noOfRegisters;
	int sizeOfRegisters;
public:
	ALU(int NoOfAdders = 0, int NoOfSubtractor = 0, int NoOfRegisters = 0, int SizeOfRegisters = 0): noOfAdders(NoOfAdders), noOfSubtractor(NoOfSubtractor), noOfRegisters(NoOfRegisters), sizeOfRegisters(SizeOfRegisters) {}
	void setNoOfAdders(int NoOfAdders) { noOfAdders = NoOfAdders; }
	void setNoOfSubtractors(int NoOfSubtractor) { noOfSubtractor = NoOfSubtractor; }
	void setNoOfRegisters(int NoOfRegisters) { noOfRegisters = NoOfRegisters; }
	void setSizeOfRegisters(int SizeOfRegisters) { sizeOfRegisters = SizeOfRegisters; }
	int getNoOfAdders() { return noOfAdders; }
	int getNoOfSubtractors() { return noOfSubtractor; }
	int getNoOfRegisters() { return noOfRegisters; }
	int getSizeOfRegisters() { return sizeOfRegisters; }
};

class ContorlUnit {
	float clock;
public:
	ContorlUnit(float Clock = 0) : clock(Clock) {}
};

class CPU {
	ALU alu;
	ContorlUnit cu;
public:
	CPU(){}
	CPU(ALU Alu, ContorlUnit Cu): alu(Alu), cu(Cu) {}
};

class MainMemory {
	int capacity;
	string technologyType;
public:
	MainMemory(int cap = 0, string type = ""): capacity(cap), technologyType(type) {}
};

class Port {
	string type;
	int baud_rate;
public:
	Port(string Type = "", int Baud_Rate = 0): type(Type), baud_rate(Baud_Rate) {}
};

class MotherBoard {
	MainMemory* mm;
	Port* ports;
public:
	MotherBoard(MainMemory* Mm = NULL, Port* Ports = NULL): mm(Mm), ports(Ports) {}
	
};

class PhysicalMemory {
	int capacity;
public:
	PhysicalMemory(int Capacity): capacity(Capacity) {}
};

class Computer {
	PhysicalMemory* pm;
	MotherBoard* md;
	CPU* cpu;
public:
	Computer(PhysicalMemory* Pm = NULL, MotherBoard* Md = NULL, CPU* Cpu = NULL) :pm(Pm), md(Md), cpu(Cpu) {}
};

class NetworkCard{
	string type;
	int speed;
	double price;
public:
	NetworkCard(string Type = "", int Speed = 0, double Price = 0) :type(Type), speed(Speed), price(Price) {}
};

class GraphicsCard {
	string brand;
	int memorySize;
	double price;
public:
	GraphicsCard(string Brand = "", int MemorySize = 0, double Price = 0) :brand(Brand), memorySize(MemorySize), price(Price) {}
};

#endif // !Q
