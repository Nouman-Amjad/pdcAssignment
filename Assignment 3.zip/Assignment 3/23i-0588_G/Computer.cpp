//Nabeeha Mahmood
//23i-0588
//Section G
//Sir Shereyar Rashid
// TA Husnain Ali


#include "Computer.h"
using namespace std;
  Computer::Computer(){
    mb = MotherBoard();
    pm = PhysicalMemory();
    cpu = CPU();
  }

  Computer::Computer(MotherBoard m, PhysicalMemory p, CPU c) : mb(m), pm(p), cpu(c) {}

  // Getter and Setter for mb
  MotherBoard Computer::getMotherBoard() const {
    return mb;
  }

  void Computer::setMotherBoard(MotherBoard m) {
    mb = m;
  }

  // Getter and Setter for pm
  PhysicalMemory Computer::getPhysicalMemory() const {
    return pm;
  }

  void Computer::setPhysicalMemory(PhysicalMemory p) {
    pm = p;
  }

  // Getter and Setter for cpu
  CPU Computer::getCPU() const {
    return cpu;
  }

  void Computer::setCPU(CPU c) {
    cpu = c;
  }

 
  // Display function for Computer class
  void Computer::display() {
    cout << "Motherboard:" << endl;
    mb.display();
    cout << "Physical Memory:" << endl;
    pm.display();
    cout << "CPU:" << endl;
    cpu.display();
  }