//Nabeeha Mahmood
//23i-0588
//Section G
//Sir Shereyar Rashid
// TA Husnain Ali

#include <iostream>

class ComputerAssembly{
public:
    int totalPrice;
    ComputerAssembly(int tp = 0) {}
    void display();
};

