//Nabeeha Mahmood
//23i-0588
//Section G
//Sir Shereyar Rashid
// TA Husnain Ali


#include <iostream>
class Case{
private:
  string formFactor;
  string color;
public:
  Case(string ff = "", string c = "") {}
  
  // Getter and Setter for formFactor
  string getFormFactor() const {}
  
  void setFormFactor(string ff) {}
  
  // Getter and Setter for color
  string getColor() const { }
  
  void setColor(string c) { }
  
  void display();
};
