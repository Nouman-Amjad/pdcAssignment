//Nabeeha Mahmood
//23i-0588
//Section G
//Sir Shereyar Rashid
// TA Husnain Ali


#include <iostream>
#include "Build.h"
using namespace std;


Build::Build() {
        //User Input for ALUs
        int adders;
        int subtractors;
        int registers;
        int sizeOfregisters;
        cout<<"+++++++++++++++++++++++++++++++++++"<<endl;
        cout << "Enter number of adders for ALU: ";
        cin >> adders;
        cout << "Enter number of subtractors for ALU: ";
        cin >> subtractors;
        cout << "Enter number of registers for ALU: ";
        cin>> registers;
        cout<<"Enter size of registers for ALU: ";
        cin>> sizeOfregisters;
        alu = ALU(adders, subtractors, registers , sizeOfregisters);

        //User Input for Control Unit
        cout<<"+++++++++++++++++++++++++++++++++++"<<endl;
        float clock;
        cout << "Enter clock for Control Unit: ";
        cin >> clock;
        cu = ControlUnit(clock);
        //User input for Main Memory
        cout<<"+++++++++++++++++++++++++++++++++++"<<endl;
        string technology;
        cout << "Choose technology:" << endl;
        cout << "1. Semiconductor  512 GB" << endl;
        cout << "2. Silicon        256GB" << endl;
        cout << "Enter your choice: ";
        int techChoice;
        cin >> techChoice;
        switch (techChoice) {
            case 1:
          technology = "Semiconductor ";
          mm = MainMemory(512, technology); // Set capacity to 256GB for Semiconductor
          break;
            case 2:
          technology = "Silicon";
          mm = MainMemory(256, technology);
          break;
            default:
          cout << "Invalid choice. Using default technology: Semiconductor." << endl;
          technology = "Semiconductor";
          mm = MainMemory(512, technology); // Set default capacity to 256GB for Semiconductor
          break;
        }

        // Display capacity of Main Memory
        cout << "Main Memory Capacity: " << mm.getCapacity() << "GB" << endl;
        cout << "Main Memory Technology: " << technology << endl;
          //User input for Port
        cout<<"+++++++++++++++++++++++++++++++++++"<<endl;
  
        int numPorts;
        cout << "Choose 2 port types:" << endl;
        cout << " I/O  Bandwidth: 100" << endl;
        cout << " USB  Bandwidth: 5000" << endl;
        cout << " HDMI Bandwidth: 10000" << endl;
        cout << " VGI  Bandwidth: 500"  <<endl;

        cout << "Enter the number of ports: ";
        cin >> numPorts;
        Port* ports = new Port[numPorts];
        for (int i = 0; i < numPorts; ++i) {
          string type;
          int bandwidth;
          cout << "Enter type for Port " << i + 1 << ": ";
          cin >> type;
          cout << "Enter bandwidth for Port " << i + 1 << " (in Mbps): ";
          cin >> bandwidth;
          ports[i] = Port(type, bandwidth);
        }

       // Create MotherBoard object with the main memory and ports
       MotherBoard mb(mm, numPorts, ports);

        //User input for Physical Memory
        cout<<"+++++++++++++++++++++++++++++++++++"<<endl;
        cout<<"DDR4/5 will be used for Physical Memory"<<endl;
        cout << "Please choose the capacity for Physical Memory:";
        cout<<"1. 256GB"<<endl;
        cout<<"2. 512GB"<<endl;
        cout<<"Enter your choice: ";
        int capacity;
        cin >> capacity;
        pm = PhysicalMemory(capacity);
        

        //User input for Storage Device
        cout<<"+++++++++++++++++++++++++++++++++++"<<endl;
        string sdType;
        int sdCapacity;
        float sdPrice;
        cout << "Choose storage device type:" << endl;
        cout << "1. SSD" << endl;
        cout << "2. HDD" << endl;
        cout << "Enter your choice: ";
        int choice;
        cin >> choice;
        switch (choice) {
            case 1:
          sdType = "SSD";
          cout << "Choose SSD capacity:" << endl;
          cout << "1. 256GB  $100" << endl;
          cout << "2. 512GB  $150" << endl;
          cout << "Enter your choice: ";
          int ssdChoice;
          cin >> ssdChoice;
          switch (ssdChoice) {
              case 1:
            sdCapacity = 256;
            sdPrice = 100.0; // Set the price for 256GB SSD
            break;
              case 2:
            sdCapacity = 512;
            sdPrice = 150.0; // Set the price for 512GB SSD
            break;
              default:
            cout << "Invalid choice. Using default SSD capacity of 256GB." << endl;
            sdCapacity = 256;
            sdPrice = 100.0; // Set the default price for SSD
            break;
          }
          break;
            case 2:
          sdType = "HDD";
          cout << "Choose HDD capacity:" << endl;
          cout << "1. 512GB  $80" << endl;
          cout << "2. 1TB    $120" << endl;
          cout << "Enter your choice: ";
          int hddChoice;
          cin >> hddChoice;
          switch (hddChoice) {
              case 1:
            sdCapacity = 512;
            sdPrice = 80.0; // Set the price for 512GB HDD
            break;
              case 2:
            sdCapacity = 1024;
            sdPrice = 120.0; // Set the price for 1TB HDD
            break;
              default:
            cout << "Invalid choice. Using default HDD capacity of 512GB." << endl;
            sdCapacity = 512;
            sdPrice = 80.0; // Set the default price for HDD
            break;
          }
          break;

            default:
          cout << "Invalid choice. Using default storage device type: SSD." << endl;
          sdType = "SSD";
          cout << "Choose SSD capacity:" << endl;
          cout << "1. 256GB" << endl;
          cout << "2. 512GB" << endl;
          cout << "Enter your choice: ";
          int defaultSsdChoice;
          cin >> defaultSsdChoice;
          switch (defaultSsdChoice) {
              case 1:
            sdCapacity = 256;
            sdPrice = 100.0; // Set the price for 256GB SSD
            break;
              case 2:
            sdCapacity = 512;
            sdPrice = 150.0; // Set the price for 512GB SSD
            break;
              default:
            cout << "Invalid choice. Using default SSD capacity of 256GB." << endl;
            sdCapacity = 256;
            sdPrice = 100.0; // Set the default price for SSD
            break;
          }
          break;
        }
        sd = StorageDevice(sdType, sdCapacity, sdPrice);

        // Display prices and capacities
        cout << "Storage Device Prices and Capacities:" << endl;
        cout << "------------------------------------" << endl;
        if (sdType == "SSD" || sdType == "Both") {
            cout << "SSD Capacity: " << sdCapacity << "GB" << endl;
            cout << "SSD Price: $" << sdPrice << endl;
        }
        if (sdType == "HDD" || sdType == "Both") {
            cout << "HDD Capacity: " << sdCapacity << "GB" << endl;
            cout << "HDD Price: $" << sdPrice << endl;
        }
        //User input for Network Card
        cout<<"+++++++++++++++++++++++++++++++++++"<<endl;
        string ncType;
        int speed;
        float ncPrice;
        cout << "Choose network card type:" << endl;
        cout << "1. Ethernet  $20" << endl;
        cout << "2. WiFi      $30" << endl;
        cout << "3. Both      $50" << endl;
        cout << "Enter your choice: ";
        int choiceNc;
        cin >> choiceNc;
        switch (choiceNc) {
            case 1:
          ncType = "Ethernet";
          speed = 1000;
          ncPrice = 20.0;
          break;
            case 2:
          ncType = "WiFi";
          speed = 300;
          ncPrice = 30.0;
          break;
            case 3:
          ncType = "Both";
          speed = 1000;
          ncPrice = 50.0;
          break;
            default:
          cout << "Invalid choice. Using default network card type: Ethernet." << endl;
          ncType = "Ethernet";
          speed = 1000;
          ncPrice = 20.0;
          break;
        }
        nc = NetworkCard(ncType, speed, ncPrice);


        //User input for PowerSupply
        cout<<"+++++++++++++++++++++++++++++++++++"<<endl;
        int watt;
        string efficiency;
        float psuPrice;
        cout << "Choose watt for PSU:" << endl;
        cout << "1. 500W (Efficiency: 80 Plus Bronze, Price: $50)" << endl;
        cout << "2. 600W (Efficiency: 80 Plus Gold, Price: $70)" << endl;
        cout << "Enter your choice: ";
        int choicePS;
        cin >> choicePS;
        switch (choicePS) {
            case 1:
          watt = 500;
          efficiency = "80 Plus Bronze";
          psuPrice = 50.0;
          break;
            case 2:
          watt = 600;
          efficiency = "80 Plus Gold";
          psuPrice = 70.0;
          break;
            default:
          cout << "Invalid choice. Using default wattage of 500W." << endl;
          watt = 500;
          efficiency = "80 Plus Bronze";
          psuPrice = 50.0;
          break;
        }
        psu = PSU(watt, efficiency, psuPrice);

        //User input for Case
        cout << "+++++++++++++++++++++++++++++++++++" << endl;
        string formFactor;
        string color;
        cout << "Enter form factor (1.ATX or 2.Micro ATX) for Case: ";
        int choiceCase;
        cin >> choiceCase;
        if(choiceCase = 1){
          formFactor = "ATX";
        }else if (choiceCase = 2){
          formFactor = "Micro ATX";
        }
        else 
         {
          cout<<"Invalid choice. Using ATX case "<<endl;
          formFactor = "ATX";}


        cout << "Enter color (1. Black or 2. White) for Case: ";
        int ChoiceColor;
        cin >> ChoiceColor;
         if(choiceCase = 1){
          color = "Black";
        }else if (choiceCase = 2){
          color = "White";
        }
        else 
         {
          cout<<"Invalid choice. Using Black Colour "<<endl;
          color = "Black";}
        case_ =Case(formFactor, color);



     

      float computerAssemblyPrice = sd.getPrice() + nc.getPrice() +psu.getPrice();
      ca = ComputerAssembly(computerAssemblyPrice);
    }
    
    Build::Build(ALU a, ControlUnit c, GraphicCard g, MainMemory m, Port p, PhysicalMemory pm, StorageDevice s, NetworkCard n, PSU psu, Case c_, ComputerAssembly ca, Computer comp) : alu(a), cu(c), mm(m), port(p), pm(pm), sd(s), nc(n), psu(psu), case_(c_), ca(ca), computer(comp) {}
  
  
   void  Build::display() {
        cout<<endl;
        cout<<endl;
        cout<<"Your PC Configuration is as follows: "<<endl;
        cout<<"------------------------------"<<endl;
        sd.display();
        cout<<"------------------------------"<<endl;
        mm.display();
        cout<<"------------------------------"<<endl;
        nc.display();
        cout<<"------------------------------"<<endl;
        psu.display();
        cout<<"------------------------------"<<endl;
        pm.display();
        cout<<"------------------------------"<<endl;
        case_.display();
        cout<<"------------------------------"<<endl;
        
    }

