//Nabeeha Mahmood
//23i-0588
//Section G
//Sir Shereyar Rashid
// TA Husnain Ali


#include "ComputerAssembly.h"
using namespace std;

  ComputerAssembly::ComputerAssembly(int tp = 0) : totalPrice(tp) {}
  
 // Display function for ComputerAssembly class
void ComputerAssembly::display() {
  cout << "Total Price: $" << totalPrice << endl;
}
