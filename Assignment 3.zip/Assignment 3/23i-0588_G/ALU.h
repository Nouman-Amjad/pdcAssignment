//Nabeeha Mahmood
//23i-0588
//Section G
//Sir Shereyar Rashid
// TA Husnain Ali


#include <iostream>

class ALU{
private:
  int noOfAdders;
  int noOfSubtractors;
  int noOfRegisters;
  int sizeOfRegisters;

public:
  ALU(int adders =0, int subtractors=0, int registers=0 , int size =0)  {}

  // Getter and Setter for noOfAdders
  int getNoOfAdders() const {}

  void setNoOfAdders(int adders) {}
  // Getter and Setter for noOfSubtractors
  int getNoOfSubtractors() const {}

  void setNoOfSubtractors(int subtractors) {}
  // Getter and Setter for noOfRegisters
  int getNoOfRegisters() const{}

  void setNoOfRegisters(int registers) {}
  // Getter and Setter for sizeOfRegisters
  int getSizeOfRegisters() const {}

  void setSizeOfRegisters(int size) {} 

  void display();
};