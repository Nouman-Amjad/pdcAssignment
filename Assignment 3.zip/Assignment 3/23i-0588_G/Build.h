//Nabeeha Mahmood
//23i-0588
//Section G
//Sir Shereyar Rashid
// TA Husnain Ali


#include <iostream>
#include "StorageDevice.h"
#include "NetworkCard.h"
#include "PSU.h"
#include "Case.h"
#include "MainMemory.h"
#include "Port.h"
#include "ComputerAssembly.h"
#include "ALU.h"
#include "Computer.h"
#include "ControlUnit.h"
#include "PhysicalMemory.h"
#include "MotherBoard.h"
#include "GraphicCard.h"
using namespace std;

class Build {
    StorageDevice sd;
    NetworkCard nc;
    PSU psu;
    Case case_; 
    MainMemory mm;
    Port port;


protected:
    ALU alu;
    ComputerAssembly ca;
    Computer computer;
    ControlUnit cu;
    PhysicalMemory pm;
    MotherBoard mb;
public:
    Build() {}
    
    Build::Build(ALU a, ControlUnit c, GraphicCard g, MainMemory m, Port p, PhysicalMemory pm, StorageDevice s, NetworkCard n, PSU psu, Case c_, ComputerAssembly ca, Computer comp) {}

   void display();
};