//Nabeeha Mahmood
//23i-0588
//Section G
//Sir Shereyar Rashid
// TA Husnain Ali

#include <iostream>
#include "BuildPC.h"
using namespace std;

    BuildPC::BuildPC(){
        //User Input for Graphic Card
        cout<<"+++++++++++++++++++++++++++++++++++"<<endl;
        string brand;
        int memory;
        float price;
        cout << "Choose brand for Graphic Card:" << endl;
        cout << "1. AMD" << endl;
        cout << "2. Nvidia" << endl;
        cout << "Enter your choice: ";
        int brandChoice;
        cin >> brandChoice;
        if (brandChoice == 1) {
            brand = "AMD";
            cout << "AMD Graphic Card Memory: ";
            // Display available memory options for AMD
            cout << "1. 4GB 15.5$" << endl;
            cout << "2. 8GB 20$" << endl;
            cout << "Enter your choice: ";
            int amdMemoryChoice;
            cin >> amdMemoryChoice;
            if (amdMemoryChoice == 1) {
          memory = 4;
          price = 15.5; // Set price for 4GB AMD Graphic Card
            } else if (amdMemoryChoice == 2) {
          memory = 8;
          price = 20.0; // Set price for 8GB AMD Graphic Card
            } else {
          cout << "Invalid choice. Using default memory of 4GB." << endl;
          memory = 4;
          price = 15.5; // Set default price for AMD Graphic Card
            }

        } else if (brandChoice == 2) {
            brand = "Nvidia";
            cout << "Nvidia Graphic Card Memory: ";
            // Display available memory options for Nvidia
            cout << "1. 6GB  $25.5" << endl;
            cout << "2. 12GB $30.5" << endl;
            cout << "Enter your choice: ";
            int nvidiaMemoryChoice;
            cin >> nvidiaMemoryChoice;
            if (nvidiaMemoryChoice == 1) {
          memory = 6;
          price = 25.5; // Set price for 6GB Nvidia Graphic Card
            } else if (nvidiaMemoryChoice == 2) {
          memory = 12;
          price = 30.5; // Set price for 12GB Nvidia Graphic Card
            } else {
          cout << "Invalid choice. Using default memory of 6GB." << endl;
          memory = 6;
          price = 25.5; // Set price for Nvidia Graphic Card
            }
        } else {
            cout << "Invalid choice. Using default brand: AMD 4GB" << endl;
            brand = "AMD";
            memory = 4;
            price = 15.5; // Set default price for AMD Graphic Card
        }
        gc = GraphicCard(brand, memory, price);

        cpu = CPU(Build::alu, Build::cu);
        Build::computer.setCPU(cpu);
        
        Build::ca.totalPrice += price;
    }
    BuildPC::BuildPC(ALU a, ControlUnit c, GraphicCard g, MainMemory m, Port p, PhysicalMemory pm, StorageDevice s, NetworkCard n, PSU psu, Case c_, ComputerAssembly ca, Computer comp) : Build(a, c, g, m, p, pm, s, n, psu, c_, ca, comp) {}
   
    void BuildPC::display(){
        Build::display();
        cout<<"Graphic Card"<<endl;
        gc.display(); 
        cout<<"------------------------------"<<endl;
        cout<<"CPU"<<endl;
        cpu.display();
        cout<<"------------------------------"<<endl;
        ca.display();
         cout<<"Thank you for using our service"<<endl;
    }
