//Nabeeha Mahmood
//23i-0588
//Section G
//Sir Shereyar Rashid
// TA Husnain Ali

#include <iostream>
#include "CPU.h"
#include "ALU.h" // Include the header file for ALU class
#include "ControlUnit.h" // Include the header file for ControlUnit class
#include "GraphicCard.h" // Include the header file for GraphicCard class
using namespace std;

// Define forward declarations for classes
class ALU;
class ControlUnit;
class GraphicCard;

// Define the implementation of the CPU class
CPU::CPU() {
  gc = nullptr;
  alu = ALU();
  cu = ControlUnit(); // Initialize the ControlUnit object
}

CPU::CPU(ALU a, ControlUnit c, GraphicCard* g) : alu(a), cu(c), gc(g) {}

ALU CPU::getALU() const {
  return alu; // Return the ALU object
}

void CPU::setALU(ALU a) {
  alu = a; // Set the ALU object
}

ControlUnit CPU::getControlUnit() const {
  return cu; // Return the ControlUnit object
}

void CPU::setControlUnit(ControlUnit c) {
  cu = c; // Set the ControlUnit object
}

GraphicCard* CPU::getGraphicCard() const {
  return gc; // Return the GraphicCard pointer
}

void CPU::setGraphicCard(GraphicCard* g) {
  gc = g; // Set the GraphicCard pointer
}

void CPU::display() {
  cout << "CPU" << endl; // Display CPU information
  cout << "ALU:" << endl; // Display ALU information
  alu.display();
  cout << "Control Unit:" << endl; // Display ControlUnit information
  cu.display();
}