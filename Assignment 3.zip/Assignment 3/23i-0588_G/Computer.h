//Nabeeha Mahmood
//23i-0588
//Section G
//Sir Shereyar Rashid
// TA Husnain Ali


#include <iostream>
#include "MotherBoard.h"
#include "CPU.h"
#include "PhysicalMemory.h"

class Computer{
private:
  MotherBoard mb;
  PhysicalMemory pm;
  CPU cpu;

public:
  Computer(){}

  Computer(MotherBoard m, PhysicalMemory p, CPU c)  {}

  // Getter and Setter for mb
  MotherBoard getMotherBoard() const { }

  void setMotherBoard(MotherBoard m) { }

  // Getter and Setter for pm
  PhysicalMemory getPhysicalMemory() const {}

  void setPhysicalMemory(PhysicalMemory p) {}

  // Getter and Setter for cpu
  CPU getCPU() const {}

  void setCPU(CPU c) {}
   void display();
};
