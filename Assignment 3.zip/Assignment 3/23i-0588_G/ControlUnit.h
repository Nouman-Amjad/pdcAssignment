//Nabeeha Mahmood
//23i-0588
//Section G
//Sir Shereyar Rashid
// TA Husnain Ali

#include <iostream>

class ControlUnit{
private:
  float clock;

public:
  ControlUnit(float clk = 0.0) {}

  // Getter and Setter for clock
  float getClock() const {}

  void setClock(float clk) {}

  void display();
};