//Nabeeha Mahmood
//23i-0588
//Section G
//Sir Shereyar Rashid
// TA Husnain Ali

#include "Case.h"
#include <string>
using namespace std;

  Case::Case(string ff = "", string c = "") : formFactor(ff), color(c) {}
  
  // Getter and Setter for formFactor
  string   Case::getFormFactor() const {
    return formFactor;
  }
  
  void   Case::setFormFactor(string ff) {
    formFactor = ff;
  }
  
  // Getter and Setter for color
  string   Case::getColor() const {
    return color;
  }
  
  void   Case::setColor(string c) {
    color = c;
  }

// Display function for Case class
void Case::display() {
  cout << "CASE" << endl;
  cout << "Form Factor: " << formFactor << endl;
  cout << "Color: " << color << endl;
}