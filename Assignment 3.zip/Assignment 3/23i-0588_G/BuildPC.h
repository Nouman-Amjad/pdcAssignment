//Nabeeha Mahmood
//23i-0588
//Section G
//Sir Shereyar Rashid
// TA Husnain Ali

#include "Build.h"
#include "GraphicCard.h"
#include "CPU.h"
#include <iostream>
class BuildPC: public Build{
   GraphicCard gc;
   CPU cpu;
  public: 
    BuildPC(){ }

    BuildPC(ALU a, ControlUnit c, GraphicCard g, MainMemory m, Port p, PhysicalMemory pm, StorageDevice s, NetworkCard n, PSU psu, Case c_, ComputerAssembly ca, Computer comp)  {}
    
    void display(){ }
};