//Nabeeha Mahmood
//23i-0588
//Section G
//Sir Shereyar Rashid
// TA Husnain Ali

#include<iostream>
#include<string>
using namespace std;

class ALU {
private:
    int noOfAdders;
    int noOfSubtractors;
    int noOfRegisters;
    int sizeOfRegisters;
public:
    ALU(int adders = 0, int subtractors = 0, int registers = 0, int size = 0) : noOfAdders(adders), noOfSubtractors(subtractors), noOfRegisters(registers), sizeOfRegisters(size) {}

    // Getter and Setter for noOfAdders
    int getNoOfAdders() const {
        return noOfAdders;
    }

    void setNoOfAdders(int adders) {
        noOfAdders = adders;
    }

    // Getter and Setter for noOfSubtractors
    int getNoOfSubtractors() const {
        return noOfSubtractors;
    }

    void setNoOfSubtractors(int subtractors) {
        noOfSubtractors = subtractors;
    }

    // Getter and Setter for noOfRegisters
    int getNoOfRegisters() const {
        return noOfRegisters;
    }

    void setNoOfRegisters(int registers) {
        noOfRegisters = registers;
    }

    // Getter and Setter for sizeOfRegisters
    int getSizeOfRegisters() const {
        return sizeOfRegisters;
    }

    void setSizeOfRegisters(int size) {
        sizeOfRegisters = size;
    }

    void display();
};


class ControlUnit {
private:
    float clock;

public:
    ControlUnit(float clk = 0.0) : clock(clk) {}

    // Getter and Setter for clock
    float getClock() const {
        return clock;
    }

    void setClock(float clk) {
        clock = clk;
    }

    void display();
};

class GraphicCard {
private:
    string brand;
    int memory;
    float price;
public:
    GraphicCard(string b = "", int mem = 0, float p = 0.0) : brand(b), memory(mem), price(p) {}

    // Getter and Setter for brand
    string getBrand() const {
        return brand;
    }

    void setBrand(string b) {
        brand = b;
    }

    // Getter and Setter for memory
    int getMemory() const {
        return memory;
    }

    void setMemory(int mem) {
        memory = mem;
    }

    // Getter and Setter for price
    float getPrice() const {
        return price;
    }

    void setPrice(float p) {
        price = p;
    }

    void display();
};

class CPU {
private:
    ALU alu;
    ControlUnit cu;
    GraphicCard* gc;

public:
    CPU() {
        gc = nullptr;
        alu = ALU();
        cu = ControlUnit();
    }
    //Constrictor in CPU
    CPU(ALU a, ControlUnit c, GraphicCard* g = nullptr) : alu(a), cu(c), gc(g) {}


    // Getter and Setter for alu
    ALU getALU() const {
        return alu;
    }

    void setALU(ALU a) {
        alu = a;
    }

    // Getter and Setter for cu
    ControlUnit getControlUnit() const {
        return cu;
    }

    void setControlUnit(ControlUnit c) {
        cu = c;
    }

    // Getter and Setter for gc
    GraphicCard* getGraphicCard() const {
        return gc;
    }

    void setGraphicCard(GraphicCard* g) {
        gc = g;
    }

    void display();
};


class MainMemory {
private:
    int capacity;
    string technology;

public:
    MainMemory(int cap = 0, string tech = "") : capacity(cap), technology(tech) {}

    // Getter and Setter for capacity
    int getCapacity() const {
        return capacity;
    }

    void setCapacity(int cap) {
        capacity = cap;
    }

    // Getter and Setter for technology
    string getTechnology() const {
        return technology;
    }

    void setTechnology(string tech) {
        technology = tech;
    }

    void display();
};

class Port {
private:
    string type;
    int bandwidth;

public:
    Port(string t = "", int b = 0) : type(t), bandwidth(b) {}

    // Getter and Setter for type
    string getType() const {
        return type;
    }

    void setType(string t) {
        type = t;
    }

    // Getter and Setter for bandwidth
    int getBandwidth() const {
        return bandwidth;
    }

    void setBandwidth(int b) {
        bandwidth = b;
    }

    void display();
};


class PhysicalMemory {
private:
    int capacity;

public:
    PhysicalMemory(int cap = 0) : capacity(cap) {}

    // Getter and Setter for capacity
    int getCapacity() const {
        return capacity;
    }

    void setCapacity(int cap) {
        capacity = cap;
    }

    void display();
};


class StorageDevice {
private:
    string type;
    int capacity;
    float price;
public:
    StorageDevice(string t = "", int cap = 0, float p = 0.0) : type(t), capacity(cap), price(p) {}

    // Getter and Setter for type
    string getType() const {
        return type;
    }

    void setType(string t) {
        type = t;
    }

    // Getter and Setter for capacity
    int getCapacity() const {
        return capacity;
    }

    void setCapacity(int cap) {
        capacity = cap;
    }

    // Getter and Setter for price
    float getPrice() const {
        return price;
    }

    void setPrice(float p) {
        price = p;
    }

    void display();
};
class NetworkCard {
private:
    string type;
    int speed;
    float price;
public:
    NetworkCard(string t = "", int s = 0, float p = 0.0) : type(t), speed(s), price(p) {}

    // Getter and Setter for type
    string getType() const {
        return type;
    }

    void setType(string t) {
        type = t;
    }

    // Getter and Setter for speed
    int getSpeed() const {
        return speed;
    }

    void setSpeed(int s) {
        speed = s;
    }

    // Getter and Setter for price
    float getPrice() const {
        return price;
    }

    void setPrice(float p) {
        price = p;
    }

    void display();
};

class PSU {
private:
    int watt;
    string efficiency;
    float price;
public:
    PSU(int w = 0, string e = "", float p = 0.0) : watt(w), efficiency(e), price(p) {}

    // Getter and Setter for watt
    int getWatt() const {
        return watt;
    }

    void setWatt(int w) {
        watt = w;
    }

    // Getter and Setter for efficiency
    string getEfficiency() const {
        return efficiency;
    }

    void setEfficiency(string e) {
        efficiency = e;
    }

    // Getter and Setter for price
    float getPrice() const {
        return price;
    }

    void setPrice(float p) {
        price = p;
    }

    void display();
};


class Case {
private:
    string formFactor;
    string color;
public:
    Case(string ff = "", string c = "") : formFactor(ff), color(c) {}

    // Getter and Setter for formFactor
    string getFormFactor() const {
        return formFactor;
    }

    void setFormFactor(string ff) {
        formFactor = ff;
    }

    // Getter and Setter for color
    string getColor() const {
        return color;
    }

    void setColor(string c) {
        color = c;
    }

    void display();
};
class ComputerAssembly {
public:
    int totalPrice;
    ComputerAssembly(int tp = 0) : totalPrice(tp) {}
    void display();
};

class MotherBoard {
private:
    MainMemory mm;
    Port* ports; // Pointer to Port objects
    int numPorts; // Number of ports

public:
    // Default constructor
    MotherBoard() : ports(nullptr), numPorts(0) {
        mm = MainMemory();
    }

    // Constructor with main memory and number of ports
    MotherBoard(MainMemory m, int num) : mm(m), numPorts(num) {
        ports = new Port[numPorts]; // Allocate memory for the array of Port objects
    }

    // Constructor with main memory, number of ports, and port information
    MotherBoard(MainMemory m, int num, Port* p) : mm(m), numPorts(num) {
        ports = new Port[numPorts]; // Allocate memory for the array of Port objects
        for (int i = 0; i < numPorts; ++i) {
            ports[i] = p[i]; // Copy port information
        }
    }

    // Destructor to release dynamically allocated memory
    ~MotherBoard() {
        delete[] ports; // Release memory allocated for the array of Port objects
    }

    // Getter and Setter for mm
    MainMemory getMainMemory() const {
        return mm;
    }

    void setMainMemory(MainMemory m) {
        mm = m;
    }

    // Getter and Setter for ports
    Port* getPorts() const {
        return ports;
    }

    void setPorts(Port* p, int num) {
        // Release the old memory if it exists
        if (ports != nullptr) {
            delete[] ports;
        }

        // Allocate memory for the new array of Port objects
        ports = new Port[num];
        numPorts = num;

        // Copy the contents of the new array
        for (int i = 0; i < numPorts; ++i) {
            ports[i] = p[i];
        }
    }

    void display();
};

class Computer {
private:
    MotherBoard mb;
    PhysicalMemory pm;
    CPU cpu;

public:
    Computer() {
        mb = MotherBoard();
        pm = PhysicalMemory();
        cpu = CPU();
    }

    Computer(MotherBoard m, PhysicalMemory p, CPU c) : mb(m), pm(p), cpu(c) {}

    // Getter and Setter for mb
    MotherBoard getMotherBoard() const {
        return mb;
    }

    void setMotherBoard(MotherBoard m) {
        mb = m;
    }

    // Getter and Setter for pm
    PhysicalMemory getPhysicalMemory() const {
        return pm;
    }

    void setPhysicalMemory(PhysicalMemory p) {
        pm = p;
    }

    // Getter and Setter for cpu
    CPU getCPU() const {
        return cpu;
    }

    void setCPU(CPU c) {
        cpu = c;
    }
    void display();
};


// Display function for ALU class
void ALU::display() {
    cout << "ALU" << endl;
    cout << "Number of adders: " << getNoOfAdders() << endl;
    cout << "Number of subtractors: " << getNoOfSubtractors() << endl;
    cout << "Number of Registers: " << getNoOfRegisters() << endl;
    cout << "Size of Registers: " << getSizeOfRegisters() << endl;
}

// Display function for ControlUnit class
void ControlUnit::display() {
    cout << "CONTROL UNIT" << clock << endl;
    cout << "Clock: " << clock << endl;
}

// Display function for GraphicCard class
void GraphicCard::display() {
    cout << "GRAPHIC CARD" << endl;
    cout << "Brand: " << brand << endl;
    cout << "Memory: " << memory << "GB" << endl;
    cout << "Price: $" << price << endl;
}

// Display function for CPU class
void CPU::display() {
    cout << "CPU" << endl;
    alu.display();
    cu.display();

}

// Display function for MainMemory class
void MainMemory::display() {
    cout << "Capacity: " << capacity << "GB" << endl;
    cout << "Technology: " << technology << endl;
}

// Display function for Port class
void Port::display() {
    cout << "PORT" << endl;
    cout << "Type: " << type << endl;
    cout << "Bandwidth: " << bandwidth << " Mbps" << endl;
}

// Display function for PhysicalMemory class
void PhysicalMemory::display() {
    cout << "PHYSICAL MEMORY" << endl;
    cout << "Capacity: " << capacity << "GB" << endl;
}

// Display function for StorageDevice class
void StorageDevice::display() {
    cout << "STORAGE DEVICE" << endl;
    cout << "Type: " << type << endl;
    cout << "Capacity: " << capacity << "GB" << endl;
    cout << "Price: $" << price << endl;
}

// Display function for NetworkCard class
void NetworkCard::display() {
    cout << "NETWORK CARD" << endl;
    cout << "Type: " << type << endl;
    cout << "Speed: " << speed << " Mbps" << endl;
    cout << "Price: $" << price << endl;
}

// Display function for PSU class
void PSU::display() {
    cout << "POWER SUPPLY" << endl;
    cout << "Watt: " << watt << endl;
    cout << "Efficiency: " << efficiency << endl;
    cout << "Price: $" << price << endl;
}

\
// Display function for Case class
void Case::display() {
    cout << "CASE" << endl;
    cout << "Form Factor: " << formFactor << endl;
    cout << "Color: " << color << endl;
}

// Display function for ComputerAssembly class
void ComputerAssembly::display() {
    cout << "Total Price: $" << totalPrice << endl;
}

// Display function for MotherBoard class
void MotherBoard::display() {

    cout << "Main Memory:" << endl;
    mm.display();
    cout << "Number of Ports: " << numPorts << "\n";
    // Display information about each port
    cout << "Ports Information:\n";
    for (int i = 0; i < numPorts; ++i) {
        cout << "Port " << i + 1 << ":\n";
        ports[i].display(); // Call display() function for each port
    }


}

// Display function for Computer class
void Computer::display() {
    cout << "Motherboard:" << endl;
    mb.display();
    cout << "Physical Memory:" << endl;
    pm.display();
    cout << "CPU:" << endl;
    cpu.display();
}

class Build {
    StorageDevice sd;
    NetworkCard nc;
    PSU psu;
    Case case_;
    MainMemory mm;
    Port port;


protected:
    ALU alu;
    ComputerAssembly ca;
    Computer computer;
    ControlUnit cu;
    PhysicalMemory pm;
    MotherBoard mb;
public:
    Build() {
        //User Input for ALUs
        int adders;
        int subtractors;
        int registers;
        int sizeOfregisters;
        cout << "+++++++++++++++++++++++++++++++++++" << endl;
        cout << "Enter number of adders for ALU: ";
        cin >> adders;
        cout << "Enter number of subtractors for ALU: ";
        cin >> subtractors;
        cout << "Enter number of registers for ALU: ";
        cin >> registers;
        cout << "Enter size of registers for ALU: ";
        cin >> sizeOfregisters;
        alu = ALU(adders, subtractors, registers, sizeOfregisters);

        //User Input for Control Unit
        cout << "+++++++++++++++++++++++++++++++++++" << endl;
        float clock;
        cout << "Enter clock for Control Unit: ";
        cin >> clock;
        cu = ControlUnit(clock);
        //User input for Main Memory
        cout << "+++++++++++++++++++++++++++++++++++" << endl;
        string technology;
        cout << "Choose technology:" << endl;
        cout << "1. Semiconductor  512 GB" << endl;
        cout << "2. Silicon        256GB" << endl;
        cout << "Enter your choice: ";
        int techChoice;
        cin >> techChoice;
        switch (techChoice) {
        case 1:
            technology = "Semiconductor ";
            mm = MainMemory(512, technology); // Set capacity to 256GB for Semiconductor
            break;
        case 2:
            technology = "Silicon";
            mm = MainMemory(256, technology);
            break;
        default:
            cout << "Invalid choice. Using default technology: Semiconductor." << endl;
            technology = "Semiconductor";
            mm = MainMemory(512, technology); // Set default capacity to 256GB for Semiconductor
            break;
        }

        // Display capacity of Main Memory
        cout << "Main Memory Capacity: " << mm.getCapacity() << "GB" << endl;
        cout << "Main Memory Technology: " << technology << endl;
        //User input for Port
        cout << "+++++++++++++++++++++++++++++++++++" << endl;

        int numPorts;
        cout << "Choose 2 port types:" << endl;
        cout << " I/O  Bandwidth: 100" << endl;
        cout << " USB  Bandwidth: 5000" << endl;
        cout << " HDMI Bandwidth: 10000" << endl;
        cout << " VGI  Bandwidth: 500" << endl;

        cout << "Enter the number of ports: ";
        cin >> numPorts;
        Port* ports = new Port[numPorts];
        for (int i = 0; i < numPorts; ++i) {
            string type;
            int bandwidth;
            cout << "Enter type for Port " << i + 1 << ": ";
            cin >> type;
            cout << "Enter bandwidth for Port " << i + 1 << " (in Mbps): ";
            cin >> bandwidth;
            ports[i] = Port(type, bandwidth);
        }

        // Create MotherBoard object with the main memory and ports
        MotherBoard mb(mm, numPorts, ports);

        //User input for Physical Memory
        cout << "+++++++++++++++++++++++++++++++++++" << endl;
        cout << "DDR4/5 will be used for Physical Memory" << endl;
        cout << "Please choose the capacity for Physical Memory:";
        cout << "1. 256GB" << endl;
        cout << "2. 512GB" << endl;
        cout << "Enter your choice: ";
        int capacity;
        cin >> capacity;
        pm = PhysicalMemory(capacity);


        //User input for Storage Device
        cout << "+++++++++++++++++++++++++++++++++++" << endl;
        string sdType;
        int sdCapacity;
        float sdPrice;
        cout << "Choose storage device type:" << endl;
        cout << "1. SSD" << endl;
        cout << "2. HDD" << endl;
        cout << "Enter your choice: ";
        int choice;
        cin >> choice;
        switch (choice) {
        case 1:
            sdType = "SSD";
            cout << "Choose SSD capacity:" << endl;
            cout << "1. 256GB  $100" << endl;
            cout << "2. 512GB  $150" << endl;
            cout << "Enter your choice: ";
            int ssdChoice;
            cin >> ssdChoice;
            switch (ssdChoice) {
            case 1:
                sdCapacity = 256;
                sdPrice = 100.0; // Set the price for 256GB SSD
                break;
            case 2:
                sdCapacity = 512;
                sdPrice = 150.0; // Set the price for 512GB SSD
                break;
            default:
                cout << "Invalid choice. Using default SSD capacity of 256GB." << endl;
                sdCapacity = 256;
                sdPrice = 100.0; // Set the default price for SSD
                break;
            }
            break;
        case 2:
            sdType = "HDD";
            cout << "Choose HDD capacity:" << endl;
            cout << "1. 512GB  $80" << endl;
            cout << "2. 1TB    $120" << endl;
            cout << "Enter your choice: ";
            int hddChoice;
            cin >> hddChoice;
            switch (hddChoice) {
            case 1:
                sdCapacity = 512;
                sdPrice = 80.0; // Set the price for 512GB HDD
                break;
            case 2:
                sdCapacity = 1024;
                sdPrice = 120.0; // Set the price for 1TB HDD
                break;
            default:
                cout << "Invalid choice. Using default HDD capacity of 512GB." << endl;
                sdCapacity = 512;
                sdPrice = 80.0; // Set the default price for HDD
                break;
            }
            break;

        default:
            cout << "Invalid choice. Using default storage device type: SSD." << endl;
            sdType = "SSD";
            cout << "Choose SSD capacity:" << endl;
            cout << "1. 256GB" << endl;
            cout << "2. 512GB" << endl;
            cout << "Enter your choice: ";
            int defaultSsdChoice;
            cin >> defaultSsdChoice;
            switch (defaultSsdChoice) {
            case 1:
                sdCapacity = 256;
                sdPrice = 100.0; // Set the price for 256GB SSD
                break;
            case 2:
                sdCapacity = 512;
                sdPrice = 150.0; // Set the price for 512GB SSD
                break;
            default:
                cout << "Invalid choice. Using default SSD capacity of 256GB." << endl;
                sdCapacity = 256;
                sdPrice = 100.0; // Set the default price for SSD
                break;
            }
            break;
        }
        sd = StorageDevice(sdType, sdCapacity, sdPrice);

        // Display prices and capacities
        cout << "Storage Device Prices and Capacities:" << endl;
        cout << "------------------------------------" << endl;
        if (sdType == "SSD" || sdType == "Both") {
            cout << "SSD Capacity: " << sdCapacity << "GB" << endl;
            cout << "SSD Price: $" << sdPrice << endl;
        }
        if (sdType == "HDD" || sdType == "Both") {
            cout << "HDD Capacity: " << sdCapacity << "GB" << endl;
            cout << "HDD Price: $" << sdPrice << endl;
        }
        //User input for Network Card
        cout << "+++++++++++++++++++++++++++++++++++" << endl;
        string ncType;
        int speed;
        float ncPrice;
        cout << "Choose network card type:" << endl;
        cout << "1. Ethernet  $20" << endl;
        cout << "2. WiFi      $30" << endl;
        cout << "3. Both      $50" << endl;
        cout << "Enter your choice: ";
        int choiceNc;
        cin >> choiceNc;
        switch (choiceNc) {
        case 1:
            ncType = "Ethernet";
            speed = 1000;
            ncPrice = 20.0;
            break;
        case 2:
            ncType = "WiFi";
            speed = 300;
            ncPrice = 30.0;
            break;
        case 3:
            ncType = "Both";
            speed = 1000;
            ncPrice = 50.0;
            break;
        default:
            cout << "Invalid choice. Using default network card type: Ethernet." << endl;
            ncType = "Ethernet";
            speed = 1000;
            ncPrice = 20.0;
            break;
        }
        nc = NetworkCard(ncType, speed, ncPrice);


        //User input for PowerSupply
        cout << "+++++++++++++++++++++++++++++++++++" << endl;
        int watt;
        string efficiency;
        float psuPrice;
        cout << "Choose watt for PSU:" << endl;
        cout << "1. 500W (Efficiency: 80 Plus Bronze, Price: $50)" << endl;
        cout << "2. 600W (Efficiency: 80 Plus Gold, Price: $70)" << endl;
        cout << "Enter your choice: ";
        int choicePS;
        cin >> choicePS;
        switch (choicePS) {
        case 1:
            watt = 500;
            efficiency = "80 Plus Bronze";
            psuPrice = 50.0;
            break;
        case 2:
            watt = 600;
            efficiency = "80 Plus Gold";
            psuPrice = 70.0;
            break;
        default:
            cout << "Invalid choice. Using default wattage of 500W." << endl;
            watt = 500;
            efficiency = "80 Plus Bronze";
            psuPrice = 50.0;
            break;
        }
        psu = PSU(watt, efficiency, psuPrice);

        //User input for Case
        cout << "+++++++++++++++++++++++++++++++++++" << endl;
        string formFactor;
        string color;
        cout << "Enter form factor (1.ATX or 2.Micro ATX) for Case: ";
        int choiceCase;
        cin >> choiceCase;
        if (choiceCase = 1) {
            formFactor = "ATX";
        }
        else if (choiceCase = 2) {
            formFactor = "Micro ATX";
        }
        else
        {
            cout << "Invalid choice. Using ATX case " << endl;
            formFactor = "ATX";
        }


        cout << "Enter color (1. Black or 2. White) for Case: ";
        int ChoiceColor;
        cin >> ChoiceColor;
        if (choiceCase = 1) {
            color = "Black";
        }
        else if (choiceCase = 2) {
            color = "White";
        }
        else
        {
            cout << "Invalid choice. Using Black Colour " << endl;
            color = "Black";
        }
        case_ = Case(formFactor, color);





        float computerAssemblyPrice = sd.getPrice() + nc.getPrice() + psu.getPrice();
        ca = ComputerAssembly(computerAssemblyPrice);
    }
    Build(ALU a, ControlUnit c, GraphicCard g, MainMemory m, Port p, PhysicalMemory pm, StorageDevice s, NetworkCard n, PSU psu, Case c_, ComputerAssembly ca, Computer comp) : alu(a), cu(c), mm(m), port(p), pm(pm), sd(s), nc(n), psu(psu), case_(c_), ca(ca), computer(comp) {}
    void display() {
        cout << endl;
        cout << endl;
        cout << "Your PC Configuration is as follows: " << endl;
        cout << "------------------------------" << endl;
        sd.display();
        cout << "------------------------------" << endl;
        mm.display();
        cout << "------------------------------" << endl;
        nc.display();
        cout << "------------------------------" << endl;
        psu.display();
        cout << "------------------------------" << endl;
        pm.display();
        cout << "------------------------------" << endl;
        case_.display();
        cout << "------------------------------" << endl;

    }


};


class BuildMac : public Build {
    CPU cpu;
    GraphicCard gc;
public:
    BuildMac() {
        //User Input for Graphic Card
        cout << "+++++++++++++++++++++++++++++++++++" << endl;
        cout << "Graphic Card is integrated in CPU for Mac" << endl;
        cout << "Apple Silcon is a GPU for Mac" << endl;
        cout << "Please Select memory for Apple Silcon GPU" << endl;
        cout << "1. 8GB $300" << endl;
        cout << "2. 16GB $400" << endl;
        cout << "Enter your choice: ";
        int memory;
        float price;
        cin >> memory;
        if (memory == 1) {
            memory = 8;
            price = 300.0;
        }
        else if (memory == 2) {
            memory = 16;
            price = 400.0;
        }
        else {
            cout << "Invalid choice. Using default memory of 8GB" << endl;
            memory = 8;
            price = 300.0;
        }
        string brand = "Apple";
        gc = GraphicCard("Apple", memory, price);

        cpu = CPU(Build::alu, Build::cu);
        Build::computer.setCPU(cpu);
        Build::ca.totalPrice += price;
    }

    BuildMac(ALU a, ControlUnit c, GraphicCard g, MainMemory m, Port p, PhysicalMemory pm, StorageDevice s, NetworkCard n, PSU psu, Case c_, ComputerAssembly ca, Computer comp) : Build(a, c, g, m, p, pm, s, n, psu, c_, ca, comp) {}

    void display() {
        Build::display();
        cpu.display();
        cout << "Graphic card" << endl;
        gc.display();
        cout << "------------------------------" << endl;
        ca.display();
        cout << "Thank you for using our service" << endl;
    }
};


class Mac : public BuildMac {
public:
    Mac() { cout << "mac"; }

    Mac(ALU a, ControlUnit c, GraphicCard g, MainMemory m, Port p, PhysicalMemory pm, StorageDevice s, NetworkCard n, PSU psu, Case c_, ComputerAssembly ca, Computer comp) : BuildMac(a, c, g, m, p, pm, s, n, psu, c_, ca, comp) {}


    void display() {
        BuildMac::display();
    }
};

class BuildPC : public Build {
    GraphicCard gc;
    CPU cpu;
public:
    BuildPC() {
        //User Input for Graphic Card
        cout << "+++++++++++++++++++++++++++++++++++" << endl;
        string brand;
        int memory;
        float price;
        cout << "Choose brand for Graphic Card:" << endl;
        cout << "1. AMD" << endl;
        cout << "2. Nvidia" << endl;
        cout << "Enter your choice: ";
        int brandChoice;
        cin >> brandChoice;
        if (brandChoice == 1) {
            brand = "AMD";
            cout << "AMD Graphic Card Memory: ";
            // Display available memory options for AMD
            cout << "1. 4GB 15.5$" << endl;
            cout << "2. 8GB 20$" << endl;
            cout << "Enter your choice: ";
            int amdMemoryChoice;
            cin >> amdMemoryChoice;
            if (amdMemoryChoice == 1) {
                memory = 4;
                price = 15.5; // Set price for 4GB AMD Graphic Card
            }
            else if (amdMemoryChoice == 2) {
                memory = 8;
                price = 20.0; // Set price for 8GB AMD Graphic Card
            }
            else {
                cout << "Invalid choice. Using default memory of 4GB." << endl;
                memory = 4;
                price = 15.5; // Set default price for AMD Graphic Card
            }

        }
        else if (brandChoice == 2) {
            brand = "Nvidia";
            cout << "Nvidia Graphic Card Memory: ";
            // Display available memory options for Nvidia
            cout << "1. 6GB  $25.5" << endl;
            cout << "2. 12GB $30.5" << endl;
            cout << "Enter your choice: ";
            int nvidiaMemoryChoice;
            cin >> nvidiaMemoryChoice;
            if (nvidiaMemoryChoice == 1) {
                memory = 6;
                price = 25.5; // Set price for 6GB Nvidia Graphic Card
            }
            else if (nvidiaMemoryChoice == 2) {
                memory = 12;
                price = 30.5; // Set price for 12GB Nvidia Graphic Card
            }
            else {
                cout << "Invalid choice. Using default memory of 6GB." << endl;
                memory = 6;
                price = 25.5; // Set price for Nvidia Graphic Card
            }
        }
        else {
            cout << "Invalid choice. Using default brand: AMD 4GB" << endl;
            brand = "AMD";
            memory = 4;
            price = 15.5; // Set default price for AMD Graphic Card
        }
        gc = GraphicCard(brand, memory, price);

        cpu = CPU(Build::alu, Build::cu);
        Build::computer.setCPU(cpu);

        Build::ca.totalPrice += price;
    }
    BuildPC(ALU a, ControlUnit c, GraphicCard g, MainMemory m, Port p, PhysicalMemory pm, StorageDevice s, NetworkCard n, PSU psu, Case c_, ComputerAssembly ca, Computer comp) : Build(a, c, g, m, p, pm, s, n, psu, c_, ca, comp) {}

    void display() {
        Build::display();
        cout << "Graphic Card" << endl;
        gc.display();
        cout << "------------------------------" << endl;
        cout << "CPU" << endl;
        cpu.display();
        cout << "------------------------------" << endl;
        ca.display();
        cout << "Thank you for using our service" << endl;
    }
};

class PC : public BuildPC {
public:
    PC() {
        cout << "PC";
    }
    PC(ALU a, ControlUnit c, GraphicCard g, MainMemory m, Port p, PhysicalMemory pm, StorageDevice s, NetworkCard n, PSU psu, Case c_, ComputerAssembly ca, Computer comp) : BuildPC(a, c, g, m, p, pm, s, n, psu, c_, ca, comp) {}

    void display() {
        BuildPC::display();
    }
};

int main() {
    cout << "Welcome to PC Builder" << endl;
    cout << "Please select the type of PC you want to build" << endl;
    cout << "1. Mac" << endl;
    cout << "2. PC" << endl;
    cout << "Enter your choice: ";
    int choice;
    cin >> choice;
    if (choice == 1) {
        Mac mac;
        mac.display();
    }
    else if (choice == 2) {

        PC pc;
        pc.display();
    }
    else {
        cout << "Invalid choice" << endl;
    }
    return 0;

}

