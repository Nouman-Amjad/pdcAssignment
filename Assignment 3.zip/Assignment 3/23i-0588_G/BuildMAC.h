//Nabeeha Mahmood
//23i-0588
//Section G
//Sir Shereyar Rashid
// TA Husnain Ali

#include <iostream>
#include "Build.h"


class BuildMac: public Build{
  CPU cpu;
  GraphicCard gc;
  public: 
   BuildMac(){}
  
    BuildMac(ALU a, ControlUnit c, GraphicCard g, MainMemory m, Port p, PhysicalMemory pm, StorageDevice s, NetworkCard n, PSU psu, Case c_, ComputerAssembly ca, Computer comp)  {}
   
    void display(){}
};




