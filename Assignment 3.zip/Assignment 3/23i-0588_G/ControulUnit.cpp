//Nabeeha Mahmood
//23i-0588
//Section G
//Sir Shereyar Rashid
// TA Husnain Ali

#include <iostream>
#include "ControlUnit.h"
using namespace std;


ControlUnit::ControlUnit(float clk = 0.0) : clock(clk) {}

  // Getter and Setter for clock
  float  ControlUnit::getClock() const {
    return clock;
  }

  void  ControlUnit::setClock(float clk) {
    clock = clk;
  }

 // Display function for ControlUnit class
void ControlUnit::display() {
  cout << "CONTROL UNIT" << clock << endl;
  cout << "Clock: " << clock << endl;
}