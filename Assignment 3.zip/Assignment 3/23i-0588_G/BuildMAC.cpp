//Nabeeha Mahmood
//23i-0588
//Section G
//Sir Shereyar Rashid
// TA Husnain Ali

#include "BuildMac.h"
#include <iostream>
using namespace std;

   BuildMac::BuildMac(){
      //User Input for Graphic Card
        cout<<"+++++++++++++++++++++++++++++++++++"<<endl;
        cout<<"Graphic Card is integrated in CPU for Mac"<<endl;
        cout<<"Apple Silcon is a GPU for Mac"<<endl;
        cout<<"Please Select memory for Apple Silcon GPU"<<endl;
        cout<<"1. 8GB $300"<<endl;
        cout<<"2. 16GB $400"<<endl;
        cout<<"Enter your choice: ";
        int memory;
        float price;
        cin>>memory;
        if(memory == 1){
            memory = 8;
            price = 300.0;
        }else if(memory == 2){
            memory = 16;
            price = 400.0;
        }else{
            cout<<"Invalid choice. Using default memory of 8GB"<<endl;
            memory = 8;
            price = 300.0;
        }
        string brand = "Apple";
        gc = GraphicCard("Apple", memory, price);

        cpu = CPU(Build::alu, Build::cu);
        Build::computer.setCPU(cpu);
        Build::ca.totalPrice += price;
    }
  
    BuildMac::BuildMac(ALU a, ControlUnit c, GraphicCard g, MainMemory m, Port p, PhysicalMemory pm, StorageDevice s, NetworkCard n, PSU psu, Case c_, ComputerAssembly ca, Computer comp) : Build(a, c, g, m, p, pm, s, n, psu, c_, ca, comp) {}
   
    void BuildMac::display(){
        Build::display();
        cpu.display();
        cout<<"Graphic card"<<endl;
        gc.display();
        cout<<"------------------------------"<<endl;
        ca.display();
        cout<<"Thank you for using our service"<<endl;
    }





