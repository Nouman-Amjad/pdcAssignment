//Nabeeha Mahmood
//23i-0588
//Section G
//Sir Shereyar Rashid
// TA Husnain Ali

#include <iostream>
using namespace std;
#include "ALU.h"


  ALU::ALU(int adders = 0, int subtractors = 0, int registers = 0, int size = 0 ) : noOfAdders(adders), noOfSubtractors(subtractors), noOfRegisters(registers), sizeOfRegisters(size) {}

  // Getter and Setter for noOfAdders
  int  ALU::getNoOfAdders() const {
    return noOfAdders;
  }

  void  ALU::setNoOfAdders(int adders) {
    noOfAdders = adders;
  }

  // Getter and Setter for noOfSubtractors
  int  ALU::getNoOfSubtractors() const {
    return noOfSubtractors;
  }

  void  ALU::setNoOfSubtractors(int subtractors) {
    noOfSubtractors = subtractors;
  }

  // Getter and Setter for noOfRegisters
  int  ALU::getNoOfRegisters() const {
    return noOfRegisters;
  }

  void  ALU::setNoOfRegisters(int registers) {
    noOfRegisters = registers;
  }

  // Getter and Setter for sizeOfRegisters
  int  ALU::getSizeOfRegisters() const {
    return sizeOfRegisters;
  }

  void  ALU::setSizeOfRegisters(int size) {
    sizeOfRegisters = size;
  }

// Display function for ALU class
  void ALU::display() {
    cout << "ALU" << endl;
    cout << "Number of adders: " << getNoOfAdders() << endl;
    cout << "Number of subtractors: " << getNoOfSubtractors() << endl;
    cout << "Number of Registers: " << getNoOfRegisters() << endl;
    cout << "Size of Registers: " << getSizeOfRegisters() << endl;
  }
