#pragma once
#include <iostream>
using namespace std;

class ALU {
	int NoOfAdders, NoOfSubtractor, NoOfRegisters, sizeOfRegisters;

public:
	ALU():NoOfAdders(0),NoOfSubtractor(0),NoOfRegisters(0),sizeOfRegisters(0){}
	ALU(int add, int sub, int reg, int sizereg): NoOfAdders(add), NoOfSubtractor(sub), NoOfRegisters(reg), sizeOfRegisters(sizereg){}
	int getAdders() { return NoOfAdders; }
	int getSubtractor() { return NoOfSubtractor; }
	int getRegisters() { return NoOfRegisters; }
	int getSizeReg() { return sizeOfRegisters; }

	void setAdders(int add){NoOfAdders = add;}
	void setSubtractor(int sub){NoOfSubtractor = sub;}
	void setRegisters(int reg){NoOfRegisters = reg;}
	void setSizeReg(int sizereg){sizeOfRegisters = sizereg;}
};
class ControlUnit
{
	float clock;

public:
	ControlUnit():clock(0){}
	ControlUnit(float c):clock(c){}

	float getClock(){return clock;}
	void setClock(float c){clock = c;}
};

class CPU {

	ALU alu;
	ControlUnit cu;

public:
	CPU() : alu(0,0, 0, 0), cu(0) {};
	CPU(ALU& alu1, ControlUnit& cu1) : alu(alu1), cu(cu1) {};

	ALU& getALU() { return alu; }
	ControlUnit& getCU() { return cu; }

	void setALU(ALU& alu1) { alu = alu1; }
	void setCU(ControlUnit& cu1) { cu = cu1; }


};

class PhysicalMemory {
	int capacity;



public:
	PhysicalMemory() : capacity(0) {};
	PhysicalMemory(int cap) :capacity(cap) {};

	int getCapacity() { return capacity; }
	void setCapacity(int cap) { capacity = cap; }
};



class MainMemory {
	int capacity;
	string technologyType;

public:
	MainMemory(): capacity(0),technologyType("") {}
	MainMemory(int c, string t): capacity(c), technologyType(t){}

	int getCapacity() { return capacity;  }
	string getTechnologyType() { return technologyType; }

	void setCapacity(int c) { capacity = c; }
	void setTech(string t) { technologyType = t; }
};

class Port {
	string type;
	int baud_rate;

public:
	Port()
	{
		type = '\0';
		baud_rate = 0;
	}
	Port(string type1, int br)
	{
		type = type1;
		baud_rate = br;
	}
	string getType()
	{
		return type;
	}
	int getBaud_rate()
	{
		return baud_rate;
	}
	void setType(string t)
	{
		type = t;
	}
	void setBaud_rate(int br)
	{
		baud_rate = br;
	}
};

class MotherBoard{
	MainMemory* mm;
	Port ports[];

public:
	MotherBoard() : mm(0), ports() {};
	MotherBoard(MainMemory &mm1,Port& ports1) : mm(&mm1){}

	MainMemory getMM() { return *mm; }
	Port getPorts() { return *ports; }

	void setMM(MainMemory& mm1) { mm = &mm1; }
	void setPorts(Port ports1[]) { *ports = *ports1; }

};

class Computer {
	PhysicalMemory* pm;
	MotherBoard* mb;
	CPU* cp;
public:
	Computer() : pm(nullptr), mb(nullptr), cp(nullptr) {}
	Computer(PhysicalMemory& pm1, MotherBoard& mb1, CPU& cp1) : pm(&pm1), mb(&mb1), cp(&cp1) {}

	PhysicalMemory& getPM() { return *pm; }
	MotherBoard& getMB() { return *mb; }
	CPU& getCPU() { return *cp; }

	void setPM(PhysicalMemory& pm1) { pm = &pm1; }
	void setMB(MotherBoard& mb1) { mb = &mb1; }
	void setCPU(CPU& cp1) { cp = &cp1; }
};

class StorageDevice {
	string type;
	int capacity;
	double price;

public:
	StorageDevice() : type(""), capacity(0), price(0.0) {};
	StorageDevice(string type1, int cap1, double price1) : type(type1), capacity(cap1), price(price1) {};

	string getType() { return type; }
	int getCapacity() { return capacity; }
	double getPrice() { return price; }

	void setType(string type1) { type = type1; }
	void setCapacity(int cap1) { capacity = cap1; }
	void setPrice(double price1) { price = price1; }

};

class NetworkCard {
	string type;
	int speed;
	double price;

public:
	NetworkCard() : type(""), speed(0), price(0.0) {}
	NetworkCard(string type1, int speed1, double price1) : type(type1), speed(speed1), price(price1) {}

	string getType() { return type; }
	int getSpeed() { return speed; }
	double getPrice() { return price; }

	void setType(string type1) { type = type1; }
	void setSpeed(int speed1) { speed = speed1; }
	void setPrice(double price1) { price = price1; }
};
class ComputerAssembly {
	Computer comp;
	StorageDevice* SSD;
	NetworkCard* NET;
	double totalPrice;

public:
	ComputerAssembly() : comp(Computer()), SSD(nullptr), NET(nullptr), totalPrice(0.0) {}
	ComputerAssembly(Computer& comp1, StorageDevice& SSD1, NetworkCard& NET1, double totalPrice1): comp(comp1), SSD(&SSD1), NET(&NET1), totalPrice(totalPrice1) {}

	Computer& getComp() { return comp; }
	StorageDevice& getSSD() { return *SSD; }
	NetworkCard& getNET() { return *NET; }
	double getTotalPrice() { return totalPrice; }

	void setComp(Computer& comp1) { comp = comp1; }
	void setSSD(StorageDevice& SSD1) { SSD = &SSD1; }
	void setNET(NetworkCard& NET1) { NET = &NET1; }
	void setTotalPrice(double tt) { totalPrice = tt; }
};
class GPU {
	string brand;
	int memorySize;
	double price;

public:
	GPU(): brand(""), memorySize(0), price(0.0) {}
	GPU(string brand1, int ms1,double price1): brand(brand1),memorySize(ms1),price(price1){}

	string getBrand() { return brand; }
	int getmemorySize() { return memorySize; }
	double getPrice() { return price; }

	void setBrand(string brand1) { brand = brand1; }
	void setMemorySize(int ms1) { memorySize = ms1; }
	void setPrice(double price1) { price = price1; }

};

class Case {
	string formFactor, color;
public:
	Case():formFactor(""), color("") {}
	Case(string FF, string color1):formFactor(FF),color(color1){}

	string getformFactor() { return formFactor; }
	string getColor() { return color; }

	void setFormFactor(string ff) { formFactor = ff; }
	void setColor(string color1) { color = color1; }

};

class PowerSupply {
	int wattage;
	string efficiency;
	double price;

public:
	PowerSupply(): wattage(0), efficiency(0), price(0){}
	PowerSupply(int w,string eff,double price1):wattage(w),efficiency(eff),price(price1){}

	int getWattage() { return wattage; }
	string getEfficiency() { return efficiency; }
	double getPrice() { return price; }

	void setWattage(int w) { wattage = w; }
	void setEff(string eff) { efficiency = eff; }
	void setPrice(double price1) { price = price1; }

};

class Battery {
	int capacity;
public:
	Battery() :capacity(0) {}
	Battery(int cap): capacity(cap){}

	int getCapacity() { return capacity; }
	void setCapacity(int cap) { capacity = cap; }

};

class Apple:public ComputerAssembly {
	GPU gpu;

public:
	Apple() :gpu("", 0, 0.0) {}
	Apple(GPU& gpu1):gpu(gpu1){}

	GPU getGPU() { return gpu; }
	void setGPU(GPU gpu1) { gpu = gpu1; }


};

class MacBook : public Apple {
	GPU gpu;
	Case case1;
	Battery* battery;

public:
	MacBook():gpu("", 0, 0.0),case1("", ""), battery(0) {}
	MacBook(GPU &gpu1,Case & case2, Battery & battery1): gpu(gpu1),case1(case2), battery(&battery1){}

	GPU getGPU() { return gpu; }
	Case getCase() { return case1; }
	Battery getBattery() { return *battery; }

	void setGPU(GPU gpu1) { gpu = gpu1; }
	void setCase(Case case2) { case1 = case2; }
	void setBattery(Battery bat1) { battery = &bat1; }




};
class Mac : public Apple {
	Case* case1;
	PowerSupply powersupply;

public:
	Mac() :case1(0), powersupply(0,"", 0) {}
	Mac(Case& case2, PowerSupply& ps1) : case1(&case2), powersupply(ps1) {}

	Case getCase() { return *case1; }
	PowerSupply getPowerSupply() { return powersupply; }

	void setCase(Case case2) { case1 = &case2; }
	void setPowerSupply(PowerSupply ps) { powersupply = ps; }
};

class INTEL :public ComputerAssembly {
	GPU* gpu;

public:
	INTEL() :gpu(0){}
	INTEL(GPU& gpu1):gpu(&gpu1) {}

	GPU getGPU() { return *gpu; }
	void setGPU(GPU gpu1) { gpu = &gpu1; }

};


class DELL : public INTEL {
private:
	Case towerCase;
	PowerSupply powerSupply;

public:
	DELL() : towerCase("", ""), powerSupply(0, "", 0.0) {}
	DELL(GPU& gpu1, const Case& case2, const PowerSupply& ps1) : INTEL(gpu1), towerCase(case2), powerSupply(ps1) {}

	const Case& getCase() const { return towerCase; }
	const PowerSupply& getPowerSupply() const { return powerSupply; }

	void setCase(const Case& case2) { towerCase = case2; }
	void setPowerSupply(const PowerSupply& ps1) { powerSupply = ps1; }
};

class PC : public INTEL {
private:
	Case* towerCase;
	PowerSupply powerSupply;

public:
	PC() : towerCase(nullptr), powerSupply(0, "", 0.0) {}
	PC(GPU& gpu1, Case* case2, const PowerSupply& ps1) : INTEL(gpu1), towerCase(case2), powerSupply(ps1) {}

	const Case* getCase() const { return towerCase; }
	const PowerSupply& getPowerSupply() const { return powerSupply; }

	void setCase(Case* case2) { towerCase = case2; }
	void setPowerSupply(const PowerSupply& ps1) { powerSupply = ps1; }
};
