#include <iostream>
#include "C:\Users\zarpa\OneDrive\Documents\Semester 2\OOP\23i-0027_D\23i-0027_D\Header.h"
using namespace std;



int main() {
      
        // input for GPU
        string brand;
        int memorySize;
        double price;
        cout << "Enter GPU brand: ";
        cin >> brand;
        cout << "Enter GPU memory size: ";
        cin >> memorySize;
        cout << "Enter GPU price: ";
        cin >> price;

        GPU gpu(brand, memorySize, price);

        // input for MacBook
        string formFactor, color;
        cout << "Enter MacBook form factor: ";
        cin >> formFactor;
        cout << "Enter MacBook color: ";
        cin >> color;

        Case case2(formFactor, color);

        int batteryCapacity;
        cout << "Enter MacBook battery capacity: ";
        cin >> batteryCapacity;
        Battery battery(batteryCapacity);

        MacBook macBook(gpu ,case2, battery);

        // specifications and price
        cout << "MacBook Specifications:" << endl;
        cout << "GPU Brand: " << macBook.getGPU().getBrand() << endl;
        cout << "GPU Memory Size: " << macBook.getGPU().getmemorySize() << " GB" << endl;
        cout << "GPU Price: $" << macBook.getGPU().getPrice() << endl;
        cout << "Case Form Factor: " << macBook.getCase().getformFactor() << endl;
        cout << "Case Color: " << macBook.getCase().getColor() << endl;
        cout << "Battery Capacity: " << macBook.getBattery().getCapacity() << " mAh" << endl;

        return 0;
}