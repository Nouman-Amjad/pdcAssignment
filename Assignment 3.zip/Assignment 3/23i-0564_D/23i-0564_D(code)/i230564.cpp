#include<iostream>
#include"i230564.h"

//Name: M.Hamza Rizwan
// Roll.no: 23i-0564
// Class: CS-D
//Teacher: Shehryar Rashid
//Teacher Assistant: Ali Naveed

using namespace std;

int main()
{
	int choice;

	cout << "enter 1 for PC and 2 for MAC" << endl;
	cin >> choice;

	if (choice == 1)

	
	{
		PC computer;

		PowerSupply ps;

		PriceCase pc;

		Discrete d;

		PC_Computer Pc;

		{
			int wattage;
			string efficiency;
			double price;

			cout << "enter wattage of the power supply" << endl;
			cin >> wattage;

			cout << "enter efficiency of the power supply" << endl;
			cin >> efficiency;

			cout << "enter price of the power supply" << endl;
			cin >> price;

			ps.setWattage(wattage); ps.setEfficiency(efficiency); ps.setPrice(price);

			computer.setPowerSupply(ps);
		}

		{
			string brand;
			int memorySize;
			double price;

			do 
			{
				cout << "enter the brand of the graphic card" << endl;
				cin >> brand;

				if (brand != "intel" && brand != "AMD")
				{
					cout << "wrong type. Try again" << endl;
				}
			} 
			while (brand != "intel" && brand != "AMD");

			cout << "enter the memory size of the graphic card" << endl;
			cin >> memorySize;

			cout << "enter the price of the graphic card" << endl;
			cin >> price;

			d.setBrand(brand); d.setMemorySize(memorySize); d.setPrice(price);	

			computer.setDiscrete(d);
		}

		{
			string formFactor;
			string color;
			double price;

			cout << "enter the form factor of the case" << endl;
			cin >> formFactor;

			cout << "enter the color of the case" << endl;
			cin >> color;

			cout << "enter the price of the case" << endl;
			cin >> price;

			pc.setPrice(price); pc.setFormFactor(formFactor); pc.setColor(color);

			computer.setPriceCase(pc);
		}

		MotherBoard mb;
		DDR pm;
		intelAMD cpu;

		MainMemory mm;

		{
			Port port[3];

			int capacity;
			string techType;

			cout << "enter the capacity of the main memory" << endl;
			cin >> capacity;

			cout << "enter the tech type of the main memory" << endl;
			cin >> techType;

			mm.setCapacity(capacity); mm.setType(techType);

			for (int i = 0; i < 3; i++)
			{
				string type;
				int baudRate;

				cout << "enter type of port " << i + 1 << endl;
				cin >> type;

				cout << "enter baudRate of port " << i + 1<< endl;
				cin >> baudRate;

				(port[i]).setType(type); (port[i]).setBaud(baudRate);
			}

			mb.setMainMemory(mm); mb.setPort(port);
		}

		{
			string type;
			int speed;
			int capacity;

			do 
			{
				cout << "enter the type of DDR memory" << endl;
				cin >> type;

				if (type != "DDR4" && type != "DDR5")
				{
					cout << "wrong type. Try again" << endl;
				}
			} while (type != "DDR4" && type != "DDR5");

			cout << "enter the speed of DDR memory" << endl;
			cin >> speed;

			cout << "enter the capacity of DDR memory" << endl;
			cin >> capacity;

			pm.setType(type); pm.setCapacity(capacity); pm.setSpeed(speed);
		}

		{
			ALU alu;
			CU cu;
			string type;

			do
			{
				cout << "enter the type of cpu" << endl;
				cin >> type;

				if (type != "intel" && type != "AMD")
				{
					cout << "wrong input. Try again" << endl;
				}
			} while (type != "intel" && type != "AMD");

			cpu.setType(type);

			int noOfAdders, noOfSubtractors, noOfRegisters, sizeOfRegisters;

			cout << "enter no.of adders of ALU" << endl;
			cin >> noOfAdders;

			cout << "enter no.of subtractors of ALU" << endl;
			cin >> noOfSubtractors;

			cout << "enter no.of registers of ALU" << endl;
			cin >> noOfRegisters;

			cout << "enter size of registers of ALU" << endl;
			cin >> sizeOfRegisters;

			alu.setAdder(noOfAdders); alu.setSubtractor(noOfSubtractors); alu.setRegister(noOfRegisters);
			alu.setRegisterSize(sizeOfRegisters);

			cpu.setALU(alu);

			float clock;

			cout << "enter the clock speed of CU" << endl;
			cin >> clock;

			cu.setClock(clock);

			cpu.setCU(cu);

			Pc.setDDR(pm); Pc.setMotherBoard(mb); Pc.setIntelAMD(cpu);

			computer.setPc(Pc);
		}

		double totalPrice;
		StorageDevice sd;
		NetworkCard nc;

		{
			string type;
			int capacity;
			double price;

			cout << "enter the type of storage device" << endl;
			cin >> type;

			cout << "enter the capacity of the storage device" << endl;
			cin >> capacity;

			cout << "enter the price of the storage device" << endl;
			cin >> price;

			sd.setCapacity(capacity); sd.setPrice(price); sd.setType(type);

			computer.setStorageDevice(sd);
		}

		{
			string type;
			int speed;
			double price;

			cout << "enter the type of network card" << endl;
			cin >> type;

			cout << "enter the speed of the network card" << endl;
			cin >> speed;

			cout << "enter the price of the network card" << endl;
			cin >> price;

			nc.setPrice(price); nc.setSpeed(speed); nc.setType(type);

			computer.setNetworkCard(nc);
		}

		{
			int totalPrice;

			cout << "enter the total price of PC" << endl;
			cin >> totalPrice;

			computer.setPrice(totalPrice);
		}

		system("cls");

		computer.display();

		return 0;
	}

	MAC computer;

	Battery b;

	Case c;

	Mac_Computer mc;

	{
		int capacity;

		cout << "enter capacity of battery" << endl;
		cin >> capacity;

		b.setCapacity(capacity);

		computer.setBattery(b);
	}

	{
		string formFactor;
		string color;

		cout << "enter the form factor of the case" << endl;
		cin >> formFactor;

		cout << "enter the color of the case" << endl;
		cin >> color;

		c.setFormFactor(formFactor); c.setColor(color);

		computer.setCase(c);
	}

	/* {
		string brand;
		int memorySize;
		double price;

		do
		{
			cout << "enter the brand of the graphic card" << endl;
			cin >> brand;

			if (brand != "intel" && brand != "AMD")
			{
				cout << "wrong type. Try again" << endl;
			}
		} while (brand != "intel" && brand != "AMD");

		cout << "enter the memory size of the graphic card" << endl;
		cin >> memorySize;

		cout << "enter the price of the graphic card" << endl;
		cin >> price;

		d.setBrand(brand); d.setMemorySize(memorySize); d.setPrice(price);

		computer.setDiscrete(d);
	}*/

	

	MotherBoard mb;

	LDDR pm;

	AppleSilicon cpu;

	MainMemory mm;

	{
		Port port[3];

		int capacity;
		string techType;

		cout << "enter the capacity of the main memory" << endl;
		cin >> capacity;

		cout << "enter the tech type of the main memory" << endl;
		cin >> techType;

		mm.setCapacity(capacity); mm.setType(techType);

		for (int i = 0; i < 3; i++)
		{
			string type;
			int baudRate;

			cout << "enter type of port " << i + 1 << endl;
			cin >> type;

			cout << "enter baudRate of port " << i + 1 << endl;
			cin >> baudRate;

			(port[i]).setType(type); (port[i]).setBaud(baudRate);
		}

		mb.setMainMemory(mm); mb.setPort(port);
	}

	{
		string type;
		int speed;
		int capacity;

		do
		{
			cout << "enter the type of LDDR memory" << endl;
			cin >> type;

			if (type != "LDDR4" && type != "LDDR5")
			{
				cout << "wrong type. Try again" << endl;
			}
		} while (type != "LDDR4" && type != "LDDR5");

		cout << "enter the speed of LDDR memory" << endl;
		cin >> speed;

		cout << "enter the capacity of LDDR memory" << endl;
		cin >> capacity;

		pm.setType(type); pm.setCapacity(capacity); pm.setSpeed(speed);
	}

	{
		ALU alu;
		CU cu;
		string type;

		AppleGpu gpu;

		do
		{
			cout << "enter the type of cpu" << endl;
			cin >> type;

			if (type != "AppleSilicon")
			{
				cout << "wrong input. Try again" << endl;
			}
		} while (type != "AppleSilicon");

		cpu.setType(type);

		int noOfAdders, noOfSubtractors, noOfRegisters, sizeOfRegisters;

		cout << "enter no.of adders of ALU" << endl;
		cin >> noOfAdders;

		cout << "enter no.of subtractors of ALU" << endl;
		cin >> noOfSubtractors;

		cout << "enter no.of registers of ALU" << endl;
		cin >> noOfRegisters;

		cout << "enter size of registers of ALU" << endl;
		cin >> sizeOfRegisters;

		alu.setAdder(noOfAdders); alu.setSubtractor(noOfSubtractors); alu.setRegister(noOfRegisters);
		alu.setRegisterSize(sizeOfRegisters);

		cpu.setALU(alu);

		float clock;

		cout << "enter the clock speed of CU" << endl;
		cin >> clock;

		cu.setClock(clock);

		{
			string brand;
			int memorySize;
			double price;

			do
			{
				cout << "enter the brand of the graphic card" << endl;
				cin >> brand;

				if (brand != "AppleGpu")
				{
					cout << "wrong brand. try again" << endl;
				}
			} while (brand != "AppleGpu");

			cout << "enter the memory size of the graphic card" << endl;
			cin >> memorySize;

			cout << "enter the price of the graphic card" << endl;
			cin >> price;

			gpu.setBrand(brand); gpu.setMemorySize(memorySize); gpu.setPrice(price);
		}

		cpu.setCU(cu); cpu.setGpu(gpu);

		mc.setLDDR(pm); mc.setMotherBoard(mb); mc.setAppleSilicon(cpu);

		computer.setMAC(mc);
	}

	double totalPrice;
	StorageDevice sd;
	NetworkCard nc;

	{
		string type;
		int capacity;
		double price;

		cout << "enter the type of storage device" << endl;
		cin >> type;

		cout << "enter the capacity of the storage device" << endl;
		cin >> capacity;

		cout << "enter the price of the storage device" << endl;
		cin >> price;

		sd.setCapacity(capacity); sd.setPrice(price); sd.setType(type);

		computer.setStorageDevice(sd);
	}

	{
		string type;
		int speed;
		double price;

		cout << "enter the type of network card" << endl;
		cin >> type;

		cout << "enter the speed of the network card" << endl;
		cin >> speed;

		cout << "enter the price of the network card" << endl;
		cin >> price;

		nc.setPrice(price); nc.setSpeed(speed); nc.setType(type);

		computer.setNetworkCard(nc);
	}

	{
		int totalPrice;

		cout << "enter the total price of PC" << endl;
		cin >> totalPrice;

		computer.setPrice(totalPrice);
	}

	system("cls");

	computer.display();

	return 0;
}