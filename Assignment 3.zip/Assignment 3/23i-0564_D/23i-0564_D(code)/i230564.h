#pragma once
#include<iostream>

//Name: M.Hamza Rizwan
// Roll.no: 23i-0564
// Class: CS-D
//Teacher: Shehryar Rashid
//Teacher Assistant: Ali Naveed

using namespace std;

class ALU {

	int noOfAdders, noOfSubtractors, noOfRegisters, sizeOfRegisters;

public:

	ALU(int adder = 10, int subtractor = 10, int noRegisters = 10, int sizeRegisters = 10)//Default constructor/ paratemerized constructor
	{
		this->noOfAdders = adder;

		this->noOfSubtractors = subtractor;
		
		this->noOfRegisters = noRegisters;
		
		this->sizeOfRegisters = sizeRegisters;
	}

	void setAdder(int adder)
	{
		this->noOfAdders = adder;
	}

	void setSubtractor(int subtractor)
	{
		this->noOfSubtractors = subtractor;
	}

	void setRegister(int registers)
	{
		this->noOfRegisters = registers;
	}

	void setRegisterSize(int registerSize)
	{
		this->sizeOfRegisters = registerSize;
	}

	int getAdder()
	{
		return noOfAdders;
	}

	int getSubtractor()
	{
		return noOfSubtractors;
	}

	int getRegister()
	{
		return noOfRegisters;
	}

	int getRegisterSize()
	{
		return sizeOfRegisters;
	}

	void display()//To dispaly the info in main.cpp
	{
		cout << "no.of adders: " << noOfAdders << endl;
		cout << "no.of subtractors: " << noOfSubtractors << endl;
		cout << "no.of registers: " << noOfRegisters << endl;
		cout << "size of registers: " << sizeOfRegisters << endl;

		cout << endl << endl;
	}
};

class CU {

	float clock;

public:

	CU(float clock = 10)//Default constructor/ paratemerized constructor
	{
		this->clock = clock;
	}

	void setClock(float clock)
	{
		this->clock = clock;
	}

	float getClock()
	{
		return clock;
	}

	void display()//To dispaly the info in main.cpp
	{
		cout << "clock speed: " << clock << endl;

		cout << endl << endl;
	}
};

class GraphicCard {

protected:

	string brand;
	int memorySize;
	double price;

public:

	GraphicCard(string brand = "intel", int memorySize = 5, double price = 100)//Default/ parameter constructor
	{
		this->brand = brand;

		this->memorySize = memorySize;

		this->price = price;
	}

	void setBrand(string brand)
	{
		this->brand = brand;
	}

	void setMemorySize(int memorySize)
	{
		this->memorySize = memorySize;
	}

	void setPrice(double price)
	{
		this->price = price;
	}

	string getBrand()
	{
		return brand;
	}

	int getMemorySize()
	{
		return memorySize;
	}

	double getPrice()
	{
		return price;
	}

	void display()//To dispaly the info in main.cpp
	{
		cout << "brand of graphic card: " << brand << endl;
		cout << "memory size of graphic card: " << memorySize << endl;
		cout << "price of graphic card: " << price << endl;

		cout << endl << endl;
	}
};

class Discrete : public GraphicCard {//PC graphic card class inherited from GraphicCard class

public:

	Discrete(string brand = "intel", int memorySize = 5, double price = 100) : GraphicCard(brand, memorySize, price)
	{

	}

	void display()//To dispaly the info in main.cpp
	{
		GraphicCard::display();
	}
};

class AppleGpu : public GraphicCard {//MAC graphic card class inherited from GraphicCard class

public:

	AppleGpu(string brand = "AppleGpu" ,int memorySize = 5, double price = 100) : GraphicCard(brand, memorySize, price)
	{

	}

	void display()
	{
		GraphicCard::display();
	}
};

class CPU {//CPU class composed of ALU and CU class

protected:

	ALU alu;
	CU cu;

public:

	CPU()
	{

	}

	CPU(ALU a, CU c)
	{
		alu = a;

		cu = c;
	}

	void setALU(ALU& alu)
	{
		this->alu = alu;
	}

	void setCU(CU& cu)
	{
		this->cu = cu;
	}

	ALU getALU()
	{
		return alu;
	}

	CU getCU()
	{
		return cu;
	}

	void display()//to display info in main.cpp
	{
		alu.display(); cu.display();
	}
};

class AppleSilicon : public CPU{// AppleSilicon class inherited from CPU class and composed of AppleGpu class

    string type;
	const string architect = "ARM64"; // architecture is constant

	AppleGpu gpu;

public:

	AppleSilicon()
	{
		type = "AppleSilicon";
	}

	AppleSilicon(string type, ALU a, CU cu, int memory, double price) : CPU(a, cu), gpu("AppleGpu", memory, price)
	{

	}

	void setType(string type)
	{
		this->type = type;
	}

	void setGpu(AppleGpu& gpu)
	{
		this->gpu = gpu;
	}

	AppleGpu getGpu()
	{
		return gpu;
	}

	string getType()
	{
		return type;
	}

	string getArchitecture()
	{
		return architect;
	}

	void display()// to display the info on the screen
	{
		cout << "type of cpu: " << type << endl;
		cout << "architect of cpu: " << architect << endl;

		CPU::display();

		gpu.display();
	}
};

class intelAMD : public CPU {// intelAMD class inherited from CPU class 

	string type;
	const string architect = "x86";//Architecture is constant

public:

	intelAMD()// default constructor
	{
		type = "intel";
	}

	intelAMD(string type, ALU a, CU cu) : CPU(a, cu)
	{
		this->type = type;
	}

	void setType(string type)
	{
		this->type = type;
	}

	string getType()
	{
		return type;
	}

	string getArchitect() const
	{
		return architect;
	}

	void display()// to display info on the screen
	{
		cout << "type of cpu: " << type << endl;
		cout << "architecture of cpu: " << architect << endl;

		CPU::display();

		cout << endl << endl;
	}
};

class MainMemory {

	int capacity;
	string techType;

public:

	MainMemory(int c = 5, string type = "silicon")
	{
		this->capacity = c;

		this->techType = type;
	}

	void setCapacity(int c)
	{
		this->capacity = c;
	}

	void setType(string type)
	{
		this->techType = type;
	}

	int getCapacity()
	{
		return capacity;
	}

	string getType()
	{
		return techType;
	}

	void display()// to display info on the screen
	{
		cout << "capacity of main memory: " << capacity << endl;
		cout << "type of main memory: " << techType << endl;

		cout << endl << endl;
	}
};

class Port {

	string type;
	int baudRate;

public:

	Port(string type = "usb port", int bd = 10)
	{
		this->type = type;

		this->baudRate = bd;
	}

	void setType(string type)
	{
		this->type = type;
	}

	void setBaud(int bd)
	{
		this->baudRate = bd;
	}

	string getType()
	{
		return type;
	}

	int getBaud()
	{
		return baudRate;
	}

	void display()// to display the info on the screen
	{
		cout << "type of port: " << type << endl;
		cout << "baud rate of port: " << baudRate << endl;

		cout << endl << endl;
	}
};

class MotherBoard {// MotherBoard class aggregated with MainMemory class and composed of Port class

	MainMemory* mm;
	Port port[3];

public:

	MotherBoard()
	{
		mm = nullptr;
	}

	MotherBoard(MainMemory& mm , Port* port)
	{
		this->mm = &mm;

		if (port != nullptr)
		{
			for (int i = 0; i < 3; i++)
			{
				this->port[i] = port[i];
			}
		}
	}

	void setMainMemory(MainMemory& mm)
	{
		this->mm = &mm;
	}

	void setPort(Port* port)
	{
		for (int i = 0; i < 3; i++)
		{
			this->port[i] = port[i];
		}
	}

	MainMemory getMainMemory()
	{
		return *mm;
	}

	Port* getPort()
	{
		return port;
	}

	void display()// to display the info on the screen
	{
		mm->display();

		for (int i = 0; i < 3; i++)
		{
			cout << "Port " << i + 1 << ":" << endl;

			port[i].display();
		}

		cout << endl << endl;
	}
};

class PhysicalMemory {

protected:

	int capacity;

public:

	PhysicalMemory(int c = 4)
	{
		this->capacity = c;
	}

	void setCapacity(int c)
	{
		this->capacity = c;
	}

	int getCapacity()
	{
		return capacity;
	}

	void display()// to dsiplay the info on the screen
	{
		cout << "capacity of physical memory: " << capacity << endl;

		cout << endl << endl;
	}
};

class DDR : public PhysicalMemory {// DDR class(for PC) derived from PhysicalMemory class

protected:

	string type;
	int speed;

public:

	DDR(string type = "DDR4", int speed  = 5, int capacity = 5) : PhysicalMemory(capacity)
	{
		this->type = type;

		this->speed = speed;
	}

	void setType(string type)
	{
		this->type = type;
	}

	void setSpeed(int speed)
	{
		this->speed = speed;
	}

	string getType()
	{
		return type;
	}

	int getSpeed()
	{
		return speed;
	}

	void display()// to display the info om the screen
	{
		cout << "type of physical memory: " << type << endl;
		cout << "speed of physical memory: " << speed << endl;
		
		PhysicalMemory::display();
	}
};

class LDDR : public DDR {//LDDR class(for MAC) derived from PhysicalMemory class

public:

	LDDR(string type = "LDDR4", int speed = 5, int capacity = 5) : DDR(type, speed, capacity)
	{

	}

	void display()// to display the info on the screen
	{
		DDR::display();
	}
};

class Computer {//Computer class aggregated with moMotherBoard class

protected:

	MotherBoard* mb;

public:

	Computer()
	{
		mb = nullptr;
	}

	Computer(MotherBoard& mb)
	{
		this->mb = &mb;
	}

	void setMotherBoard(MotherBoard& mb)
	{
		this->mb = &mb;
	}


	MotherBoard getMotherBoard()
	{
		return *mb;
	}

	void display()// to display the info on the screen
	{
		mb->display();
	}
};

class PC_Computer : public Computer {//This  class is derived from computer class, and is for PC

	DDR* pm;
	intelAMD* cpu;

public:

	PC_Computer()
	{
		pm = nullptr;

		cpu = nullptr;
	}

	PC_Computer(DDR& pm, intelAMD& cpu, MotherBoard& mb) : Computer(mb)
	{
		this->pm = &pm;

		this->cpu = &cpu;
	}

	void setDDR(DDR& pm)
	{
		this->pm = &pm;
	}

	void setIntelAMD(intelAMD& cpu)
	{
		this->cpu = &cpu;
	}

	DDR getDDR()
	{
		return *pm;
	}

	intelAMD getIntelAMD()
	{
		return *cpu;
	}

	void display()// to display the info on the screen
	{
		Computer::display();

		pm->display();

		cpu->display();
	}
};

class Mac_Computer : public Computer {//This class is derived form Computer class, for MAC

	LDDR* pm;// this class is aggregated with LDDR class and AppleSilicon class
	AppleSilicon* cpu;

public:

	Mac_Computer()
	{
		pm = nullptr;

		cpu = nullptr;
	}

	Mac_Computer(LDDR& pm, AppleSilicon& cpu, MotherBoard& mb) : Computer(mb)
	{
		this->pm = &pm;

		this->cpu = &cpu;
	}

	void setLDDR(LDDR& pm)
	{
		this->pm = &pm;
	}

	void setAppleSilicon(AppleSilicon& cpu)
	{
		this->cpu = &cpu;
	}

	LDDR getLDDR()
	{
		return *pm;
	}

	AppleSilicon getAppleSilicon()
	{
		return *cpu;
	}

	void display()
	{
		Computer::display();

		pm->display();

		cpu->display();
	}
};



class StorageDevice {

	string type;
	int capacity;
	double price;

public:

	StorageDevice(string type = "HDD", int capacity = 100, double price = 100)
	{
		this->type = type;

		this->capacity = capacity;

		this->price = price;
	}

	void setType(string type)
	{
		this->type = type;
	}

	void setCapacity(int capacity)
	{
		this->capacity = capacity;
	}

	void setPrice(double price)
	{
		this->price = price;
	}

	string getType()
	{
		return type;
	}

	int getCapacity()
	{
		return capacity;
	}

	double getPrice()
	{
		return price;
	}

	void display()
	{
		cout << "type of storage device: " << type << endl;
		cout << "capacity of storage device: " << capacity << endl;
		cout << "price of storage device: " << price << endl;

		cout << endl << endl;
	}
};

class NetworkCard {

	string type;
	int speed;
	double price;

public:

	NetworkCard(string type = "Ethernet", int speed = 100, double price = 100)
	{
		this->type = type;

		this->speed = speed;

		this->price = price;
	}

	void setType(string type)
	{
		this->type = type;
	}

	void setSpeed(int speed)
	{
		this->speed = speed;
	}

	void setPrice(double price)
	{
		this->price = price;
	}

	string getType()
	{
		return type;
	}

	int getSpeed()
	{
		return speed;
	}

	double getPrice()
	{
		return price;
	}

	void display()
	{
		cout << "type of network card: " << type << endl;
		cout << "speed of network card: " << speed << endl;
		cout << "price of network card: " << price << endl;

		cout << endl << endl;
	}
};

class PowerSupply {

	int wattage;
	string efficiency;
	double price;

public:

	PowerSupply(int wattage = 100, string efficiency = "80 plus bronze", double price = 100)
	{
		this->wattage = wattage;

		this->efficiency = efficiency;

		this->price = price;
	}

	void setWattage(int wattage)
	{
		this->wattage = wattage;
	}

	void setEfficiency(string efficiency)
	{
		this->efficiency = efficiency;
	}

	void setPrice(double price)
	{
		this->price = price;
	}

	int getWattage()
	{
		return wattage;
	}

	string getEfficiency()
	{
		return efficiency;
	}

	double getPrice()
	{
		return price;
	}

	void display()
	{
		cout << "wattage of power supply: " << wattage << endl;
		cout << "efficiency of power supply: " << efficiency << endl;
		cout << "price of power supply: " << price << endl;

		cout << endl << endl;
	}
};

class Battery {

	int capacity;

public:

	Battery(int capacity = 100)
	{
		this->capacity = capacity;
	}

	void setCapacity(int capacity)
	{
		this->capacity = capacity;
	}

	int getCapacity()
	{
		return capacity;
	}

	void display()
	{
		cout << "capacity of battery: " << capacity << endl;

		cout << endl << endl;
	}
};

class Case {

protected:

	string formFactor;
	string color;

public:

	Case(string formFactor = "ATX", string color = "black")
	{
		this->formFactor = formFactor;

		this->color = color;
	}

	void setFormFactor(string formFactor)
	{
		this->formFactor = formFactor;
	}

	void setColor(string color)
	{
		this->color = color;
	}

	string getFormFactor()
	{
		return formFactor;
	}

	string getColor()
	{
		return color;
	}

	void display()
	{
		cout << "form factor of case: " << formFactor << endl;
		cout << "color of the case: " << color << endl;

		cout << endl << endl;
	}
};

class PriceCase : public Case {// this class is for PC and is derived from Case class

	double price;

public:

	PriceCase(string formFactor = "ATX", string color = "black", double price = 100) : Case(formFactor, color)
	{
		this->price = price;
	}

	void setPrice(double price)
	{
		this->price = price;
	}

	double getPrice()
	{
		return price;
	}

	void display()
	{
		cout << "price of case: " << price << endl;

		Case::display();
	}
};

class ComputerAssembly {
	// this class is aggregated with StorageDevice class and NetworkCard class
protected:

	double totalPrice;
	StorageDevice* sd;
	NetworkCard* nc;

public:

	ComputerAssembly()
	{
		totalPrice = 100;

		sd = nullptr;

		nc = nullptr;
	}

	ComputerAssembly(double totalPrice, StorageDevice& sd, NetworkCard& nc)
	{
		this->totalPrice = totalPrice;

		this->sd = &sd;

		this->nc = &nc;
	}

	void setPrice(double price)
	{
		this->totalPrice = price;
	}

	void setStorageDevice(StorageDevice& sd)
	{
		this->sd = &sd;
	}

	void setNetworkCard(NetworkCard& nc)
	{
		this->nc = &nc;
	}

	double getPrice()
	{
		return totalPrice;
	}

	StorageDevice getStorageDevice()
	{
		return *sd;
	}

	NetworkCard getNrtworkCard()
	{
		return *nc;
	}

	void display()
	{
		cout << "total price of computer: " << totalPrice << endl;

		sd->display();

		nc->display();
	}
};

class PC : public ComputerAssembly {// derived from ComputerAssembly class, and is for PC
	//Aggregated with PowerSupply class, PriceCase class, Discrete class, PC_Computer class
	PowerSupply* ps;
	PriceCase* pc;
	Discrete* d;
	PC_Computer* Pc;

public:

	PC()
	{
		ps = nullptr;

		pc = nullptr;

		d = nullptr;

		Pc = nullptr;
	}

	PC(double totalPrice, StorageDevice& sd, NetworkCard& nc,PowerSupply& ps, PriceCase& pc, Discrete& d, PC_Computer& Pc) : ComputerAssembly(totalPrice, sd, nc)
	{
		this->ps = &ps;

		this->pc = &pc;

		this->d = &d;

		this->Pc = &Pc;
	}

	void setPowerSupply(PowerSupply& ps)
	{
		this->ps = &ps;
	}

	void setPriceCase(PriceCase& pc)
	{
		this->pc = &pc;
	}

	void setDiscrete(Discrete& d)
	{
		this->d = &d;
	}

	void setPc(PC_Computer& Pc)
	{
		this->Pc = &Pc;
	}

	PowerSupply getPowerSupply()
	{
		return *ps;
	}

	PriceCase getPrice()
	{
		return *pc;
	}

	Discrete getDiscrete()
	{
		return *d;
	}

	PC_Computer getPc()
	{
		return *Pc;
	}

	void display()
	{
		ComputerAssembly::display();

		ps->display();

		pc->display();

		d->display();

		Pc->display();
	}
};

class MAC : public ComputerAssembly {// derived from ComputerAssembly class, and is for MAC
	//Aggregated with Battery class, Case class, MAC_Computer class
	Battery* b;
	Case* c;
	Mac_Computer* mc;

public:

	MAC()
	{
		b = nullptr;

		c = nullptr;

		mc = nullptr;
	}

	MAC(double totalPrice, StorageDevice& sd, NetworkCard& nc, Battery& b, Case& c, Mac_Computer& mc)
		: ComputerAssembly(totalPrice, sd, nc)
	{
		this->b = &b;

		this->c = &c;

		this->mc = &mc;
	}

	void setBattery(Battery& b)
	{
		this->b = &b;
	}

	void setCase(Case& c)
	{
		this->c = &c;
	}

	void setMAC(Mac_Computer& mc)
	{
		this->mc = &mc;
	}

	Battery getBattery()
	{
		return *b;
	}

	Case getCase()
	{
		return *c;
	}

	Mac_Computer getMAC()
	{
		return *mc;
	}

	void display()
	{
		ComputerAssembly::display();

		b->display();

		c->display();

		mc->display();
	}
};

