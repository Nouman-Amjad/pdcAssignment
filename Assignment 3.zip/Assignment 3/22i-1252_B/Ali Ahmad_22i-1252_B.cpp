#include <iostream>
#include <string>

using namespace std;

class Port;

class ALU 
{
protected:
    int NoOfAdders;
    int NoOfSubtractors;
    int NoOfRegisters;
    int sizeOfRegisters;

public:
    ALU(int adders = 0, int subtractors = 0, int registers = 0, int size = 0) : NoOfAdders(adders), NoOfSubtractors(subtractors),NoOfRegisters(registers), sizeOfRegisters(size) {}

    
    int getNoOfAdders() const
    {
        return NoOfAdders; 
    }
    int getNoOfSubtractors() const 
    {
        return NoOfSubtractors; 
    }
    int getNoOfRegisters() const 
    {
        return NoOfRegisters; 
    }
    int getSizeOfRegisters() const 
    {
        return sizeOfRegisters; 
    }
};

class ControlUnit {
protected:
    float clock;

public:
    ControlUnit(float clk = 0.0) : clock(clk) {}
    float getClock() const 
    {
        return clock; 
    }
};

class Port 
{
protected:
    string type;
    int baud_rate;

public:
    Port(const string& t = "", int br = 0) : type(t), baud_rate(br) {}
    
    const string& getType() const 
    {
        return type; 
    }
    
    int getBaudRate() const 
    {
        return baud_rate; 
    }
};

class CPU : public ALU, public ControlUnit 
{
public:
    CPU(int adders = 0, int subtractors = 0, int registers = 0, int size = 0, float clk = 0.0) : ALU(adders, subtractors, registers, size), ControlUnit(clk) {}
};

class MainMemory 
{
protected:
    int capacity;
    string technologyType;

public:
    MainMemory(int cap = 0, const string& tech = "") : capacity(cap), technologyType(tech) {}

    int getCapacity() const 
    {
        return capacity; 
    }
    const string& getTechnologyType() const 
    {
        return technologyType; 
    }
};

class MotherBoard : public MainMemory 
{
protected:
    Port ports[4];

public:
    MotherBoard(int cap = 0, const string& tech = "") : MainMemory(cap, tech), ports{ {}, {}, {}, {} } {}
};

class PhysicalMemory : public MainMemory 
{
public:
    PhysicalMemory(int cap = 0, const string& tech = "") : MainMemory(cap, tech) {}
};

class Computer 
{
protected:
    PhysicalMemory pm;
    MotherBoard mb;
    CPU cpu;

public:
    Computer(const PhysicalMemory& p = PhysicalMemory(), const MotherBoard& m = MotherBoard(), const CPU& c = CPU()) : pm(p), mb(m), cpu(c) {}
    const PhysicalMemory& getPhysicalMemory() const 
    {
        return pm; 
    }
    const MotherBoard& getMotherBoard() const 
    {
        return mb; 
    }
    const CPU& getCPU() const 
    {
        return cpu; 
    }
};

class GraphicsCard 
{
protected:
    string brand;
    int memorySize;
    double price;

public:
    GraphicsCard(const string& b = "", int size = 0, double p = 0.0) : brand(b), memorySize(size), price(p) {}

    const string& getBrand() const 
    {
        return brand; 
    }
    int getMemorySize() const 
    {
        return memorySize; 
    }
    double getPrice() const 
    {
        return price; 
    }
};

class StorageDevice 
{
protected:
    string type;
    int capacity;
    double price;

public:
    StorageDevice(const string& t = "", int cap = 0, double p = 0.0) : type(t), capacity(cap), price(p) {}

    const string& getType() const 
    {
        return type; 
    }
    int getCapacity() const 
    {
        return capacity; 
    }
    double getPrice() const 
    {
        return price; 
    }
};

class NetworkCard 
{
protected:
    string type;
    int speed;
    double price;

public:
    NetworkCard(const string& t = "", int s = 0, double p = 0.0): type(t), speed(s), price(p) {}

    const string& getType() const 
    {
        return type; 
    }
    int getSpeed() const 
    {
        return speed; 
    }
    double getPrice() const 
    {
        return price; 
    }
};

class PowerSupply 
{
protected:
    int wattage;
    string efficiencyRating;
    double price;

public:
    PowerSupply(int w = 0, const string& rating = "", double p = 0.0) : wattage(w), efficiencyRating(rating), price(p) {}

    int getWattage() const 
    {
        return wattage; 
    }
    const string& getEfficiencyRating() const 
    {
        return efficiencyRating; 
    }
    double getPrice() const 
    {
        return price; 
    }
};

class Battery 
{
protected:
    int capacity;

public:
    Battery(int cap = 0) : capacity(cap) {}
    int getCapacity() const 
    {
        return capacity; 
    }
};

class Case 
{
protected:
    string formFactor;
    string color;
    double price; 

public:
    Case(const string& ff = "", const string& c = "", double p = 0.0) : formFactor(ff), color(c), price(p) {}
    const string& getFormFactor() const 
    {
        return formFactor; 
    }
    const string& getColor() const 
    {
        return color; 
    }
    double getPrice() const 
    {
        return price; 
    }
};

class ComputerAssembly 
{
protected:
    double totalPrice;

public:
    ComputerAssembly(double price = 0.0) : totalPrice(price) {}
    double getTotalPrice() const 
    {
        return totalPrice; 
    }
};

int main() {
    PhysicalMemory P1(16, "DDR");
    MotherBoard M1(64, "XYZ");
    CPU cpu(4, 2, 16, 64, 3.5);
    Computer pc(P1, M1, cpu);

    cout << "Computer Specifications:" << endl;
    cout << "Physical Memory Capacity: " << pc.getPhysicalMemory().getCapacity() << " GB" << endl;
    cout << "Main Memory Capacity: " << pc.getMotherBoard().getCapacity() << " GB" << endl;
    cout << "Main Memory Technology Type: " << pc.getMotherBoard().getTechnologyType() << endl;
    cout << "CPU Adders: " << pc.getCPU().getNoOfAdders() << endl;
    cout << "CPU Subtractors: " << pc.getCPU().getNoOfSubtractors() << endl;
    cout << "CPU Registers: " << pc.getCPU().getNoOfRegisters() << endl;
    cout << "CPU Size of Registers: " << pc.getCPU().getSizeOfRegisters() << endl;
    cout << "Control Unit Clock Speed: " << pc.getCPU().getClock() << " GHz" << endl;

    return 0;
}
