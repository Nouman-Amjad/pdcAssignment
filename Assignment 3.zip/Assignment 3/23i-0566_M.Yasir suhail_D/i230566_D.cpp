#include<iostream>
#include "i230566_D.h"
using namespace std;
int main() {
		/*
		Name: M.Yasir Suhail  Roll No.:23i-0566    Section:D      Instructor:Shehryar Rashid    TA : Muhammad Abdur Rafey   
		*/
    int noOfAdders, noOfSubtractors, noOfRegisters, sizeOfRegisters;
    float clock;
    int capacity;
    string technologyType;
    string type;
    int baud_rate;
    int price1, price2, price3, price4;
    cout << "enter prices" << endl;
    cin >> price1 >> price2 >> price3 >> price4;
    cout << endl;
    cout << "Enter number of adders: ";
    cin >> noOfAdders;
    cout << "Enter number of subtractors: ";
    cin >> noOfSubtractors;
    cout << "Enter number of registers: ";
    cin >> noOfRegisters;
    cout << "Enter size of registers: ";
    cin >> sizeOfRegisters;

    // Create ALU object using the input
    ALU alu(noOfAdders, noOfSubtractors, noOfRegisters, sizeOfRegisters);

    
    cout << "Enter clock speed: ";
    cin >> clock;

    // Create ControlUnit object using the input
    ControlUnit cu(clock);

    
    CPU cpu(alu, cu);

    cout << "Enter capacity of Main Memory: ";
    cin >> capacity;
    cout << "Enter technology type of Main Memory (Semiconductor or Silicon): ";
    cin >> technologyType;

    // Create MainMemory object using the input
    MainMemory mm(capacity, technologyType);

   
    cout << "Enter type of port (e.g., VGI Port, I/O Port): ";
    cin >> type;
    cout << "Enter baud rate of port: ";
    cin >> baud_rate;

    
    Port port(type, baud_rate);

    // Create array of ports based on user input
    int numPorts;
    cout << "Enter the number of ports: ";
    cin >> numPorts;
    Port* ports = new Port[numPorts];
    for (int i = 0; i < numPorts; i++) {
        // Get user input for each port in the array
        cout << "Enter type of port " << (i + 1) << ": ";
        cin >> type;
        cout << "Enter baud rate of port " << (i + 1) << ": ";
        cin >> baud_rate;
        ports[i] = Port(type, baud_rate);
    }

    
    MotherBoard mb(mm, ports, numPorts);

    
    PhysicalMemory pm;

    
    //Computer pc(cpu, mb, pm);

    ComputerAssembly pc;
    cout << "Computer Specifications: " << endl;;
    pc.displayInfo();

    
    double totalPrice = pc.calculateTotalPrice();
    cout << "Total Price: " << totalPrice <<"$" << endl;

    
    delete[] ports;

	
	return 0;
}