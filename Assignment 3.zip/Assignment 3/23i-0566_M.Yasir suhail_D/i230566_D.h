#pragma once
#include<iostream>
using namespace std;

class ALU {								//classes and their setters,getters and constructors are made by using the relationships of aggregation,composition and inheritance
	int NoOfAdders;
	int NoOfSubtractor;
	int NoOfRegisters;
	int SizeOfRegisters;
public:
	ALU():NoOfAdders(0),NoOfSubtractor(0),NoOfRegisters(0),SizeOfRegisters(0){}
	ALU(int NOfAdders, int NOfSubtractor, int NOfRegisters, int SOfRegisters):NoOfAdders(NOfAdders),NoOfSubtractor(NOfSubtractor),NoOfRegisters(NOfRegisters),SizeOfRegisters(SOfRegisters){}
	void setNoOfAdders(int Adder) {
		this->NoOfAdders = Adder;
	}
	void setNoOfSubtractor(int Subtractor) {
		this->NoOfSubtractor = Subtractor;
	}
	void setNoOfRegisters(int NoOfRegisters) {
		this->NoOfRegisters = NoOfRegisters;
	}
	void setSizeOfRegisters(int SizeOfRegisters) {
		this->SizeOfRegisters = SizeOfRegisters;
	}
	int getNoOfAdders() {
		return this->NoOfAdders;
	}
	int getNoOFSubtractor() {
		return this->NoOfSubtractor;
	}
	int getNoOfRegisters() {
		return this->NoOfRegisters;
	}
	int getSizeOfRegisters() {
		return this->SizeOfRegisters;
	}
};

class MainMemory {
	int capacity;
	string technologyType;
public:
	MainMemory():capacity(0),technologyType('\0'){}
	MainMemory(int cap,string techType):capacity(cap),technologyType(techType){}
	void setCapacity(int capacity) {
		this->capacity = capacity;
	}
	void setTechnologyType(int technologyType) {
		this->technologyType = technologyType;
	}
	int getCapacity() {
		return capacity;
	}

	string getTechnologyType() {
		return technologyType;
	}
};

class ControlUnit {
	float clock;
public:
	ControlUnit():clock(0.0){}
	ControlUnit(float clock):clock(clock){}
	void setClock(float clock) {
		this->clock = clock;
	}
	float getClock() {
		return clock;
	}
};

class CPU {
	ALU alu;
	ControlUnit cu;
public:
	CPU():alu(0,0,0,0),cu(0){}
	CPU(ALU alu,ControlUnit cu):alu(alu),cu(cu){}
	void setALU(int NoOfAdders, int NoOfSubtractor, int NoOfRegisters, int SIzeOfRegisters) {
		alu.setNoOfAdders(NoOfAdders);
		alu.setNoOfSubtractor(NoOfSubtractor);
		alu.setNoOfRegisters(NoOfRegisters);
		alu.setSizeOfRegisters(SIzeOfRegisters);
	}
	ALU getALU() {
		return alu;
	}
	void setCU(float clock) {
		cu.setClock(clock);
	}
	ControlUnit getcu() {
		return cu;
	}
};
class Intel_AMD :public CPU {
protected:
	DDR4_5* d;
};

class AppleSilicon :public CPU {
protected:
	LDDR4_5* l;
};

class AppleGPU :public AppleSilicon {

};

class DDR4_5:public PhysicalMemory {

};

class LDDR4_5:public PhysicalMemory {

};

class PhysicalMemory {
	int capacity;
public:
	PhysicalMemory():capacity(0){}
	PhysicalMemory(int cap):capacity(cap){}
	void setCapacity(int capacity) {
		this->capacity = capacity;
	}
	int getCapacity() {
		return capacity;
	}
};

class Port {
	string type;
	int baud_rate;
public:
	Port() :type('\0'), baud_rate(0) {}
	Port(string type,int baud_rate) :type(type), baud_rate(baud_rate) {}
	void setType(string type) {
		this->type = type;
	}
	void setBaud_rate(int baud_rate) {
		this->baud_rate = baud_rate;
	}
	string getType() {
		return type;
	}
	int getBaud_rate() {
		return baud_rate;
	}
};

class USB :public Port {

};

class HDMI :public Port {

};

class VGI :public Port {

};

class I_O :public Port {

};

class GraphicsCard {
	string brand;
	int MemorySize;
	double price;
public:
	GraphicsCard():brand('\0'),MemorySize(0),price(0.00){}
	GraphicsCard(string brand,int MemorySize,double price):brand(brand),MemorySize(MemorySize),price(price){}
	void setBrand(string brand) {
		this->brand = brand;
	}
	void setMemorySize(int MemorySize) {
		this->MemorySize = MemorySize;
	}
	void setPrice(double price) {
		this->price = price;
	}
	string getBrand() {
		return brand;
	}
	int getMemorySize() {
		return MemorySize;
	}
	double getPrice() {
		return price;
	}
};

class AMD :public GraphicsCard {

};

class NVIDIA :public GraphicsCard {

};

class MotherBoard {
	MainMemory* m;
	MainMemory mm;
	Port* ports;
	int size;
public:
	MotherBoard():mm(0,'\0'),ports(nullptr),size(0){
		for (int i = 0; i < size; i++)
			this->ports[i] = Port();
	}
	MotherBoard(MainMemory m,Port* port, int size) :mm(m) {
		 
		ports = new Port[size];
		for (int i = 0; i < size; ++i) {
			ports[i] = port[i];
		}
		
	}
	MotherBoard(const MotherBoard& other) : mm(other.mm), ports(nullptr), size(other.size) {
		ports = new Port[size];
		for (int i = 0; i < size; ++i) {
			ports[i] = other.ports[i];
		}
	}
	~MotherBoard() {
		delete[] ports;
	}
	void setMM(MainMemory mm) {
		this->mm = mm;
	}
	void setPorts(Port ports[15]) {
		for (int i = 0; i < size; i++) {
			string type;
			cout << "enter the type of the port " << endl;
			cin >> type;
			int baud_rate;
			cout << "enter the baud_rate " << endl;
			cin >> baud_rate;
			this->ports[i] = Port(type, baud_rate);
		}
	}
	void setSize(int size) {
		this->size = size;
	}
	int getSize() {
		return size;
	}
	MainMemory getMM() {
		return mm;
	}
	Port getPort(){
		for (int i = 0; i < size; i++)
			return ports[i];
	}
};

class NetworkCard {
	string type;
	int speed;
	double price;
public:
	NetworkCard():type('\0'),speed(0),price(0.00){}
	NetworkCard(string type,int speed,double price):type(type),speed(speed),price(price){}
	void setType(string type) {
		this->type = type;
	}
	void setSpeed(int speed) {
		this->speed = speed;
	}
	void setPrice(double price) {
		this->price = price;
	}
	string getType() {
		return type;
	}
	int getSpeed() {
		return speed;
	}
	double getPrice() {
		return price;
	}
};

class Computer {
	PhysicalMemory* p;
	MotherBoard* m1;
	CPU* c1;

	PhysicalMemory pm;
	MotherBoard mb;
	CPU cpu;
public:
	Computer():cpu(CPU()),mb(MotherBoard()),pm(PhysicalMemory()){}
	Computer(CPU cpu,MotherBoard mb,PhysicalMemory pm):cpu(cpu),mb(mb),pm(pm){}
	void setPM(PhysicalMemory pm){
		this->pm = pm;
	 }
	void setMB(MotherBoard mb) {
		this->mb = mb;
	}
	void setCPU(CPU cpu) {
		this->cpu = cpu;
	}
	PhysicalMemory getPM() {
		return pm;
	}
	MotherBoard getMB() {
		return mb;
	}
	CPU getCPU() {
		return cpu;
	}
};

class StorageDevice {
	string type;
	int capacity;
	double price;
public:
	void setType(string type) {
		this->type = type;
	}
	void setCapacity(int capacity) {
		this->capacity = capacity;
	}
	void setPrice(double price) {
		this->price = price;
	}
	string getType() {
		return type;
	}
	int getCapacity() {
		return capacity;
	}
	double getPrice() {
		return price;
	}
};

class ConsumerHDD :public StorageDevice {

};

class NASHDD :public StorageDevice {

};

class SSD :public StorageDevice {

};

class Battery {
	int capacity;
public:
	Battery():capacity(0){}
	Battery(int capacity):capacity(capacity){}
	void setCapacity(int cspacity) {
		this->capacity = capacity;
	}
	int getCapacity() {
		return capacity;
	}
};

class PowerSupply {
	int wattage;
	string EfficientRating;
	double price;
public:
	PowerSupply():wattage(0),EfficientRating('\0'),price(0.00){}
	PowerSupply(int wattage,string EfficientRating,double price):wattage(wattage),EfficientRating(EfficientRating),price(price){}
	void setWattage(int wattage) {
		this->wattage = wattage;
	}
	void setEfficientRating(string efficientRating) {
		this->EfficientRating = efficientRating;
	}
	void setPrice(double price) {
		this->price = price;
	}
	int getWattage() {
		return wattage;
	}
	string getEfficientRating() {
		return EfficientRating;
	}
	double getPrice() {
		return price;
	}
};

class Case {
	string formFactor;
	string color;
public:
	Case():formFactor('\0'),color('\0'){}
	Case(string formFactor, string color):formFactor(formFactor),color(color){}
	void setFormFactor(string formFactor) {
		this->formFactor = formFactor;
	}
	void setColor(string color) {
		this->color = color;
	}
	string getFormFactor() {
		return formFactor;
	}
	string getColor() {
		return color;
	}
};

class ComputerAssembly {
	double totalPrice;
	Computer comp;
	GraphicsCard gpu;
	StorageDevice storage;
	NetworkCard network;
	PowerSupply supply;
	Battery battery;
	Case compCase;
public:
	ComputerAssembly():totalPrice(0.00),comp(Computer()),gpu(GraphicsCard()),storage(StorageDevice()),network(NetworkCard()),supply(PowerSupply()),battery(Battery()),compCase(Case()){}
	ComputerAssembly(double totalPrice,Computer comp,GraphicsCard gpu,StorageDevice storage,NetworkCard network,PowerSupply supply,Battery battery,Case compCase):totalPrice(totalPrice),comp(comp),gpu(gpu),storage(storage),network(network),supply(supply),battery(battery),compCase(compCase){}
	void setTotalPrice(double totalPrice) {
		this->totalPrice = totalPrice;
	}
	double getTotalPrice() {
		return totalPrice;
	}
	void setComp(Computer comp) {
		this->comp = comp;
	}
	void setGPU(GraphicsCard gpu) {
		this->gpu = gpu;
	}
	void setStorage(StorageDevice storage) {
		this->storage = storage;
	}
	void setNetwork(NetworkCard network) {
		this->network = network;
	}
	void setSupply(PowerSupply supply) {
		this->supply = supply;
	}
	void setBattery(Battery battery) {
		this->battery = battery;
	}
	void setCompCase(Case compCase) {
		this->compCase = compCase;
	}
	Computer getComp() {
		return comp;
	}
	GraphicsCard getGPU() {
		return gpu;
	}
	StorageDevice getStorage() {
		return storage;
	}
	NetworkCard getNetwork() {
		return network;
	}
	PowerSupply getPower() {
		return supply;
	}
	Battery getBattery() {
		return battery;
	}
	Case getcompCase() {
		return compCase;
	}
	void displayInfo() {
		std::cout << "Computer Assembly Specifications:\n";
		
		cout << "CPU:"<<endl;
		cout << "  ALU Specifications"<<endl;
		cout << "    Number of Adders: " << comp.getCPU().getALU().getNoOfAdders() << '\n';
		cout << "    Number of Subtractors: " << comp.getCPU().getALU().getNoOFSubtractor() << '\n';
		cout << "    Number of Registers: " << comp.getCPU().getALU().getNoOfRegisters() << '\n';
		cout << "    Size of Registers: " << comp.getCPU().getALU().getSizeOfRegisters() << '\n';
		cout << "Motherboard Specifications:"<<endl;
		cout << "  Main Memory Capacity: " << comp.getMB().getMM().getCapacity() << " GB\n";
		cout << "  Main Memory Technology: " << comp.getMB().getMM().getTechnologyType() << '\n';
		
		cout << "  Ports Information"<<endl;
		for (int i = 0; i < comp.getMB().getSize(); ++i) {
			std::cout << "    Port " << (i + 1) << " Type: " << comp.getMB().getPort().getType() << '\n';
			std::cout << "    Port " << (i + 1) << " Baud Rate: " << comp.getMB().getPort().getBaud_rate() << '\n';
		}
		cout << "Physical Memory Specifications:<<endl";
		cout << "  Capacity: " << comp.getPM().getCapacity() << " GB<<endl";
		cout << "Graphics Card Specifications:"<<endl;
		cout << "  Brand: " << gpu.getBrand() << endl;
		cout << "  Memory Size: " << gpu.getMemorySize() << " GB"<<endl;
		cout << "  Price: $" << gpu.getPrice() << endl;
		cout << "Storage Device Specifications:"<<endl;
		cout << "  Type: " << storage.getType() << endl;
		cout << "  Capacity: " << storage.getCapacity() << " GB"<<endl;
		cout << "  Price: $" << storage.getPrice() << endl;
		cout << "Network Card Specifications:"<<endl;
		cout << "  Type: " << network.getType() << endl;
		cout << "  Speed: " << network.getSpeed() << " Mbps"<<endl;
		cout << "  Price: $" << network.getPrice() << endl;
		cout << "Power Supply Specifications:"<<endl;
		cout << "  Wattage: " << supply.getWattage() << " W"<<endl;
		cout << "  Efficiency Rating: " << supply.getEfficientRating() << endl;
		cout << "  Price: $" << supply.getPrice() << endl;
		cout << "Battery Specifications:"<<endl;
		cout << "  Capacity: " << battery.getCapacity() << " mAh"<<endl;
	}
	double calculateTotalPrice() {
		double total =  gpu.getPrice() + storage.getPrice() + network.getPrice() +supply.getPrice();
		return total;
	}

};