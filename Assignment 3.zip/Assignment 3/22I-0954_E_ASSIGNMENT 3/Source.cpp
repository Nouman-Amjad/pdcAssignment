//NAME:ABDUL RAFAY ASHFAQ
//22I-0954
//SECTION E
//ASSIGNMENT 3
//ALL LOGIC EXPLAINED IN COMMENTS


#include <iostream>
#include <string>

using namespace std;

// ALU Class
class ALU {
private:
    int NoOfAdders;
    int NoOfSubtractors;
    int NoOfRegisters;
    int sizeOfRegisters;
public:
    // Constructors
    ALU(int adders = 0, int subtractors = 0, int registers = 0, int regSize = 0)
        : NoOfAdders(adders), NoOfSubtractors(subtractors), NoOfRegisters(registers), sizeOfRegisters(regSize) {}

    // Getters and Setters
    int getNoOfAdders() const { return NoOfAdders; }
    void setNoOfAdders(int adders) { NoOfAdders = adders; }

    int getNoOfSubtractors() const { return NoOfSubtractors; }
    void setNoOfSubtractors(int subtractors) { NoOfSubtractors = subtractors; }

    int getNoOfRegisters() const { return NoOfRegisters; }
    void setNoOfRegisters(int registers) { NoOfRegisters = registers; }

    int getSizeOfRegisters() const { return sizeOfRegisters; }
    void setSizeOfRegisters(int regSize) { sizeOfRegisters = regSize; }
};

// ControlUnit Class
class ControlUnit {
private:
    float clock;
public:
    // Constructors
    ControlUnit(float clk = 0.0f) : clock(clk) {}

    // Getters and Setters
    float getClock() const { return clock; }
    void setClock(float clk) { clock = clk; }
};

// CPU Class
class CPU {
private:
    ALU alu;
    ControlUnit cu;
public:
    // Constructors
    CPU(const ALU& aluObj = ALU(), const ControlUnit& cuObj = ControlUnit())
        : alu(aluObj), cu(cuObj) {}

    // Getters and Setters
    const ALU& getALU() const { return alu; }
    void setALU(const ALU& aluObj) { alu = aluObj; }

    const ControlUnit& getControlUnit() const { return cu; }
    void setControlUnit(const ControlUnit& cuObj) { cu = cuObj; }
};

// MainMemory Class
class MainMemory {
private:
    int capacity;
    string technologyType;
public:
    // Constructors
    MainMemory(int cap = 0, const string& tech = "") : capacity(cap), technologyType(tech) {}

    // Getters and Setters
    int getCapacity() const { return capacity; }
    void setCapacity(int cap) { capacity = cap; }

    const string& getTechnologyType() const { return technologyType; }
    void setTechnologyType(const string& tech) { technologyType = tech; }
};

// Port Class
class Port {
private:
    string type;
    int baud_rate;
public:
    // Constructors
    Port(const string& portType = "", int rate = 0) : type(portType), baud_rate(rate) {}

    // Getters and Setters
    const string& getType() const { return type; }
    void setType(const string& portType) { type = portType; }

    int getBaudRate() const { return baud_rate; }
    void setBaudRate(int rate) { baud_rate = rate; }
};

// MotherBoard Class
class MotherBoard {
private:
    MainMemory mm;
    Port ports[4]; // Assuming 4 ports for simplicity
public:
    // Constructors
    MotherBoard(const MainMemory& mainMem = MainMemory()) : mm(mainMem) {}

    // Getters and Setters
    const MainMemory& getMainMemory() const { return mm; }
    void setMainMemory(const MainMemory& mainMem) { mm = mainMem; }

    const Port& getPort(int index) const {
        if (index >= 0 && index < 4) return ports[index];
        else throw out_of_range("Invalid port index");
    }

    void setPort(int index, const Port& port) {
        if (index >= 0 && index < 4) ports[index] = port;
        else throw out_of_range("Invalid port index");
    }
};

// PhysicalMemory Class
class PhysicalMemory {
private:
    int capacity;
public:
    // Constructors
    PhysicalMemory(int cap = 0) : capacity(cap) {}

    // Getters and Setters
    int getCapacity() const { return capacity; }
    void setCapacity(int cap) { capacity = cap; }
};

// GraphicsCard Class
class GraphicsCard {
private:
    string brand;
    int memorySize;
    double price;
public:
    // Constructors
    GraphicsCard(const string& br = "", int size = 0, double p = 0.0)
        : brand(br), memorySize(size), price(p) {}

    // Getters and Setters
    const string& getBrand() const { return brand; }
    void setBrand(const string& br) { brand = br; }

    int getMemorySize() const { return memorySize; }
    void setMemorySize(int size) { memorySize = size; }

    double getPrice() const { return price; }
    void setPrice(double p) { price = p; }
};

// StorageDevice Class
class StorageDevice {
private:
    string type;
    int capacity;
    double price;
public:
    // Constructors
    StorageDevice(const string& t = "", int cap = 0, double p = 0.0)
        : type(t), capacity(cap), price(p) {}

    // Getters and Setters
    const string& getType() const { return type; }
    void setType(const string& t) { type = t; }

    int getCapacity() const { return capacity; }
    void setCapacity(int cap) { capacity = cap; }

    double getPrice() const { return price; }
    void setPrice(double p) { price = p; }
};

// NetworkCard Class
class NetworkCard {
private:
    string type;
    int speed;
    double price;
public:
    // Constructors
    NetworkCard(const string& t = "", int s = 0, double p = 0.0)
        : type(t), speed(s), price(p) {}

    // Getters and Setters
    const string& getType() const { return type; }
    void setType(const string& t) { type = t; }

    int getSpeed() const { return speed; }
    void setSpeed(int s) { speed = s; }

    double getPrice() const { return price; }
    void setPrice(double p) { price = p; }
};

// PowerSupply Class
class PowerSupply {
private:
    int wattage;
    string efficiencyRating;
    double price;
public:
    // Constructors
    PowerSupply(int w = 0, const string& rating = "", double p = 0.0)
        : wattage(w), efficiencyRating(rating), price(p) {}

    // Getters and Setters
    int getWattage() const { return wattage; }
    void setWattage(int w) { wattage = w; }

    const string& getEfficiencyRating() const { return efficiencyRating; }
    void setEfficiencyRating(const string& rating) { efficiencyRating = rating; }

    double getPrice() const { return price; }
    void setPrice(double p) { price = p; }
};

// Battery Class
class Battery {
private:
    int capacity;
    double price;
public:
    // Constructors
    Battery(int cap = 0) : capacity(cap) {}

    // Getters and Setters
    int getCapacity() const { return capacity; }
    void setCapacity(int cap) { capacity = cap; }
    double getPrice() const { return price; }
    void setPrice(double p) { price = p; }
};

// Case Class
class Case {
private:
    string formFactor;
    string color;
    double price;
public:
    // Constructors
    Case(const string& form = "", const string& clr = "", double p = 0.0)
        : formFactor(form), color(clr), price(p) {}

    // Getters and Setters
    const string& getFormFactor() const { return formFactor; }
    void setFormFactor(const string& form) { formFactor = form; }

    const string& getColor() const { return color; }
    void setColor(const string& clr) { color = clr; }

    double getPrice() const { return price; }
    void setPrice(double p) { price = p; }
};

// ComputerAssembly Class
class ComputerAssembly {
private:
    PhysicalMemory pm;
    MotherBoard mb;
    CPU cpu;
    GraphicsCard gpu;
    StorageDevice storage;
    NetworkCard networkCard;
    PowerSupply powerSupply;
    Battery battery;
    Case pcCase;
    double totalPrice;
public:
    // Constructors
    ComputerAssembly(const PhysicalMemory& pmObj = PhysicalMemory(), const MotherBoard& mbObj = MotherBoard(),
        const CPU& cpuObj = CPU(), const GraphicsCard& gpuObj = GraphicsCard(),
        const StorageDevice& storageObj = StorageDevice(), const NetworkCard& networkObj = NetworkCard(),
        const PowerSupply& powerObj = PowerSupply(), const Battery& batteryObj = Battery(),
        const Case& caseObj = Case())
        : pm(pmObj), mb(mbObj), cpu(cpuObj), gpu(gpuObj), storage(storageObj), networkCard(networkObj),
        powerSupply(powerObj), battery(batteryObj), pcCase(caseObj), totalPrice(0.0) {}

    // Getters and Setters
    const PhysicalMemory& getPhysicalMemory() const { return pm; }
    void setPhysicalMemory(const MainMemory& mainMemObj) {
        
        pm = PhysicalMemory(mainMemObj.getCapacity()); 
    }
    const MotherBoard& getMotherBoard() const { return mb; }
    void setMotherBoard(const MotherBoard& mbObj) { mb = mbObj; }

    const CPU& getCPU() const { return cpu; }
    void setCPU(const CPU& cpuObj) { cpu = cpuObj; }

    const GraphicsCard& getGraphicsCard() const { return gpu; }
    void setGraphicsCard(const GraphicsCard& gpuObj) { gpu = gpuObj; }

    const StorageDevice& getStorageDevice() const { return storage; }
    void setStorageDevice(const StorageDevice& storageObj) { storage = storageObj; }

    const NetworkCard& getNetworkCard() const { return networkCard; }
    void setNetworkCard(const NetworkCard& networkObj) { networkCard = networkObj; }

    const PowerSupply& getPowerSupply() const { return powerSupply; }
    void setPowerSupply(const PowerSupply& powerObj) { powerSupply = powerObj; }

    const Battery& getBattery() const { return battery; }
    void setBattery(const Battery& batteryObj) { battery = batteryObj; }

    const Case& getCase() const { return pcCase; }
    void setCase(const Case& caseObj) { pcCase = caseObj; }

    double getTotalPrice() const { return totalPrice; }
    void setTotalPrice(double price) { totalPrice = price; }
};


int main() {
    
    ComputerAssembly computer;

    

    // Set CPU
    ALU alu(4, 2, 8, 64); // Example ALU configuration
    ControlUnit cu(3.2);  // Example control unit clock speed
    CPU cpu(alu, cu);
    computer.setCPU(cpu);

    // Set Main Memory
    MainMemory mainMem(16, "Semiconductor"); // Example main memory configuration
    computer.setPhysicalMemory(mainMem);

    // Set Motherboard
    MotherBoard mb(mainMem); // Assuming main memory is part of the motherboard
    computer.setMotherBoard(mb);

    // Set Graphics Card
    GraphicsCard gpu("Nvidia", 8, 400.0); // Example graphics card
    computer.setGraphicsCard(gpu);

    // Set Storage Device
    StorageDevice storage("SSD", 512, 100.0); // Example storage device
    computer.setStorageDevice(storage);

    // Set Network Card
    NetworkCard network("Ethernet", 1000, 30.0); // Example network card
    computer.setNetworkCard(network);

    // Set Power Supply
    PowerSupply psu(750, "80 Plus Gold", 120.0); // Example power supply
    computer.setPowerSupply(psu);

    // Set Battery (for laptops)
    Battery battery(50); // Example battery capacity
    battery.setPrice(50.0); // Set a price for the battery
    computer.setBattery(battery);


    // Set Case
    Case pcCase("ATX", "Black", 50.0); // Example case
    computer.setCase(pcCase);

    // Calculate total price
    double totalPrice = gpu.getPrice() + storage.getPrice() + network.getPrice() +
        psu.getPrice() + battery.getPrice() + pcCase.getPrice();

    computer.setTotalPrice(totalPrice);

    // Display specifications and price
    cout << "Computer Specifications:\n";
    cout << "------------------------\n";
    cout << "CPU: " << cpu.getALU().getNoOfAdders() << " adders, "
        << cpu.getALU().getNoOfSubtractors() << " subtractors, "
        << cpu.getALU().getNoOfRegisters() << " registers of size "
        << cpu.getALU().getSizeOfRegisters() << " bits\n";
    cout << "Main Memory: " << mainMem.getCapacity() << " GB, Technology: " << mainMem.getTechnologyType() << endl;
    cout << "Graphics Card: " << gpu.getBrand() << " " << gpu.getMemorySize() << " GB\n";
    cout << "Storage Device: " << storage.getType() << " " << storage.getCapacity() << " GB\n";
    cout << "Network Card: " << network.getType() << " " << network.getSpeed() << " Mbps\n";
    cout << "Power Supply: " << psu.getWattage() << "W, Efficiency: " << psu.getEfficiencyRating() << endl;
    cout << "Battery Capacity: " << battery.getCapacity() << " Wh\n";
    cout << "Case: " << pcCase.getFormFactor() << ", Color: " << pcCase.getColor() << endl;
    cout << "Total Price: $" << totalPrice << endl;

    return 0;
}
