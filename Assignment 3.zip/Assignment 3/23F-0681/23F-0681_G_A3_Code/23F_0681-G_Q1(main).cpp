#include "23F_0681_G_Q1.h"
int i = 0;
int main()
{
	cout << "----------------computer creation :----------------";
	cout << "\nenter one of the 4 computors that you want to make: ";
	cout << "\n\t 1-Mac\n\t 2-Macbook\n\t3-WindowsPC \n\t 4-WindowsLaptop : ";
	cin >> i;

	

	MacPC* mpc; MacLaptop* mlp; WindowsPC* wpc; WindowsLaptop* wlp;
	MotherBoard* mb;
	MainMemory* mm;
	NetworkCard* Ncard;
	StorageDevice* SD;
	Case* casing;
	Battery* battery;
	PowerSupply* charger;
	Graphics* graphicCard;

	while (i < 1 || i > 4)
	{
		
		if ((i < 1 || i > 4))
			{
			cout << "\ninvalid input enter the input again: ";
			cout << "\n\t 1-Mac\n\t 2-Macbook\n\t 3-WindowsPC\n\t 4-WindowsLaptop : ";
			cin >> i;
			}

	}
	switch (i)
	{
	case 1:
	{
		cout << "\n--------------creating your new Mac--------------";		
		mpc = new MacPC;

		cout << "\n--------------mother board creation--------------";		
		mb = new MotherBoard;

		cout << "\n--------------making of main memory--------------";
		mm = new MainMemory;
		
		cout << "\n--------------Network card creation--------------";
		Ncard = new NetworkCard;

		cout << "\n--------------storage device creation--------------";
		SD = new StorageDevice;

		cout << "\n--------------adding main memory to motherboard--------------";
		mb->setMainMemory(mm);

		cout << "\n--------------adding network card to motherboard--------------";
		mb->setNetworkCard(Ncard);

		cout << "\n--------------adding storage device to motherboard--------------";
		mb->setStorageDevice(SD);

		cout << "\n--------------adding motherboard to Mac--------------";
		mpc->setMotherBoard(mb);

		cout << "\n--------------creating and adding casing to pc--------------";
		casing = new Case;
		mpc->setCasing(casing);

		mpc->display();
		
		break;
	}
	case 2:
	{
		cout << "\n--------------creating your new Macbook--------------";
		mlp = new MacLaptop;

		cout << "\n--------------mother board creation--------------";
		mb = new MotherBoard;

		cout << "\n--------------making of main memory--------------";
		mm = new MainMemory;

		cout << "\n--------------Network card creation--------------";
		Ncard = new NetworkCard;

		cout << "\n--------------storage device creation--------------";
		SD = new StorageDevice;

		cout << "\n--------------adding main memory to motherboard--------------";
		mb->setMainMemory(mm);

		cout << "\n--------------adding network card to motherboard--------------";
		mb->setNetworkCard(Ncard);

		cout << "\n--------------adding storage device to motherboard--------------";
		mb->setStorageDevice(SD);

		cout << "\n--------------adding motherboard to Macbook--------------";
		mlp->setMotherBoard(mb);

		cout << "\n--------------creating battery for Macbook--------------";
		battery = new Battery;

		cout << "\n--------------adding battery to Macbook--------------";
		mlp->setBattery(battery);

		cout << "\n--------------creating charger for Macbook--------------";
		charger = new PowerSupply;

		cout << "\n--------------adding battery to Macbook--------------";
		mlp->setBattery(battery);

		mlp->display();


		break;
	}
	case 3:
	{
		cout << "\n--------------creating your new WindowsPC--------------";
		wpc = new WindowsPC;

		cout << "\n--------------mother board creation--------------";
		mb = new MotherBoard;

		cout << "\n--------------making of main memory--------------";
		mm = new MainMemory;

		cout << "\n--------------Network card creation--------------";
		Ncard = new NetworkCard;

		cout << "\n--------------storage device creation--------------";
		SD = new StorageDevice;

		cout << "\n--------------adding main memory to motherboard--------------";
		mb->setMainMemory(mm);

		cout << "\n--------------adding network card to motherboard--------------";
		mb->setNetworkCard(Ncard);

		cout << "\n--------------adding storage device to motherboard--------------";
		mb->setStorageDevice(SD);

		cout << "\n--------------adding motherboard to WindowsPC--------------";
		wpc->setMotherBoard(mb);

		cout << "\n--------------creating and adding dedicated graphics to Windowspc--------------";
		graphicCard = new Graphics;
		wpc->setGPU(graphicCard);

		
		cout << "\n--------------creating and adding casing to Windowspc--------------";
		casing = new Case;
		wpc->setCasing(casing);

		wpc->display();
		break;
	}
	case 4:
	{
		cout << "\n--------------creating your new WindowsLaptop--------------";
		wlp = new WindowsLaptop;

		cout << "\n--------------mother board creation--------------";
		mb = new MotherBoard;

		cout << "\n--------------making of main memory--------------";
		mm = new MainMemory;

		cout << "\n--------------Network card creation--------------";
		Ncard = new NetworkCard;

		cout << "\n--------------storage device creation--------------";
		SD = new StorageDevice;

		cout << "\n--------------adding main memory to motherboard--------------";
		mb->setMainMemory(mm);

		cout << "\n--------------adding network card to motherboard--------------";
		mb->setNetworkCard(Ncard);

		cout << "\n--------------adding storage device to motherboard--------------";
		mb->setStorageDevice(SD);

		cout << "\n--------------adding motherboard to Laaptop--------------";
		wlp->setMotherBoard(mb);

		cout << "\n--------------creating battery for Laptop--------------";
		battery = new Battery;

		cout << "\n--------------adding battery to WindowLaptop--------------";
		wlp->setBattery(battery);

		cout << "\n--------------creating charger for WindowLaptop--------------";
		charger = new PowerSupply;

		cout << "\n--------------creating and adding dedicated graphics to WindowsLaptop--------------";
		graphicCard = new Graphics;
		wlp->setGPU(graphicCard);


		cout << "\n--------------adding battery to WindowLaptop--------------";
		wlp->setBattery(battery);

		wlp->display();


		break;
	}

	}


}