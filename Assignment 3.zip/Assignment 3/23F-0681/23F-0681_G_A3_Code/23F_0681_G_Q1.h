#pragma once
#include <iostream>
#include <string>
#include <math.h>
using namespace std;

class Port {
	string type;
	int baud_rate;
	double price;
public:

	Port()
	{
		cout << "\nENTER PORT TYPE of the following (VGA,I/O,usb,typec,hdmi,headphonejack,ethernet,thunderbolt) : ";
		cin >> type;
		while (type != "vga" && type != "i/o" && type != "usb" && type != "typec" && type != "hdmi" && type != "headphonejack" && type != "ethernet" && type != "thunderbolt" )
		{
			cout << "\nwrong input ............... enter the input again from following : ";
			cout << "\nENTER PORT TYPE of the following (VGA,I/O,usb,typec,hdmi,headphonejack,ethernet,thunderbolt) : ";
			cin >> type;

		}
		cout << "\nENTER BAUD RATE : ";
		cin >> baud_rate;
		while (baud_rate != 110 && baud_rate != 300 && baud_rate != 600 && baud_rate != 1200 && baud_rate != 2400 && baud_rate != 4800 && baud_rate != 9600 && baud_rate != 14400 && baud_rate != 19200 && baud_rate != 38400 && baud_rate != 57600 && baud_rate && 115200 && baud_rate != 128000 && baud_rate != 256000)
		{
			cout << "\nwrong input ............... enter the input again from following(present in code) : ";
			cout << "\nENTER BAUD RATE : ";
			cin >> baud_rate;

		}
			price = baud_rate * 0.5;
		cout << "\nport added";
	}
	int GetBaud_Rate()const { return baud_rate; }
	string GetType() const { return type; }
	void SetType(string newType) { type = newType; }
	void SetBaud_Rate(int newRate) { baud_rate = newRate; }
	double getPrice()
	{
		return price;
	}


};

class MainMemory {
	int Capacity;
	string TechnologyType;
	double price;

public:
	MainMemory()
	{
		cout << "\nenter the capacity of main memory : ";
		cin >> Capacity;
		while ((Capacity & (Capacity - 1)) != 0) 
		{ // Check wether Capacity is not a power of 2
			cout << "\nError: Capacity must be a power of 2..... enter the input again : " << endl;
			cout << "\nenter the capacity of main memory : ";
			cin >> Capacity;

		}

		
		cout << "\nenter technology type (semiconductor,silicon,germanium) : ";
		cin >> TechnologyType;
		while (TechnologyType != "silicon" && TechnologyType != "germanium" && TechnologyType != "semiconductor")
		{
			cout << "wrong input ............enter input again from following : ";

			cout << "\nenter technology type (semiconductor,silicon,germanium) : ";
			cin >> TechnologyType;

		}

		cout << "\nMainMemory added!";

		if (TechnologyType == "semiconductor")
			price = Capacity * 10;
		else if (TechnologyType == "silicon")
			price = Capacity * 20;
		else
			price = Capacity * 15;
	}
	MainMemory(int n, string tech)
	{
		
		while ((n & (n - 1)) != 0)
		{ // Check wether Capacity is not a power of 2
			cout << "\nError: Capacity must be a power of 2..... enter the input again : " << endl;
			cout << "\nenter the capacity of main memory : ";
			cin >> n;

		}


		while (tech != "silicon" && tech != "germanium" && tech != "semiconductor")
		{
			cout << "wrong input ............enter input again from following : ";

			cout << "\nenter technology type (semiconductor,silicon,germanium) : ";
			cin >> TechnologyType;

		}

		Capacity = n;
		TechnologyType = tech;
		cout << "\nMainMemory added!";
		if (TechnologyType == "semiconductor")
			price = Capacity * 10;
		else if (TechnologyType == "silicon")
			price = Capacity * 20;
		else
			price = Capacity * 15;
	}
	MainMemory(MainMemory& copy)
	{
		Capacity = copy.Capacity;
		TechnologyType = copy.TechnologyType;
		price = copy.price;
	}
	double getPrice()
	{
		return price;
	}
	int GetCapacity() const
	{
		return Capacity;
	}
	string GetTechType()const
	{
		return TechnologyType;
	}
	void SetTechType(string newtech)
	{
		TechnologyType = newtech;
	}
	void SetCapacity(int newCap)
	{
		Capacity = newCap;
	}

};



class NetworkCard {
	int speed;
	string type;
	double price;

public:
	NetworkCard()
	{
		cout << "\nenter the type of Network Card : ";
		cin >> type;
		while (type != "ethernet" && type != "wifi")
		{
			cout << "\nyou entered wrong input enter the input again (wifi or etherner)";
			cout << "\nenter the type of Network Card : ";
			cin >> type;

		}
		cout << "\nenter the speed of Network Card : ";
		cin >> speed;
		while (speed % 10 != 0)
		{
			cout << "\nyou entered wrong input enter the input again (10,100,1000 or 10000 Megabits)";
			cout << "\nenter the speed of Network Card : ";
			cin >> speed;

		}
		price = speed * 0.25;
		cout << "\nNetworkCard added!";
	}
	NetworkCard(int s, string t) :speed(s), type(t)
	{
		while (type != "ethernet" && type != "wifi")
		{
			cout << "\nyou entered wrong input enter the input again (wifi or etherner)";
			cout << "\nenter the type of Network Card : ";
			cin >> type;

		}
		while (speed % 10 != 0)
		{
			cout << "\nyou entered wrong input enter the input again (10,100,1000 or 10000 Megabits)";
			cout << "\nenter the speed of Network Card : ";
			cin >> speed;

		}
		price = speed * 0.25;
		cout << "\nNetworkCard added!";
	}
	NetworkCard(NetworkCard& copy) :speed(copy.speed), type(copy.type), price(copy.price) {}
	int getSpeed() { return speed; }
	void setSpeed(int s) { speed = s; }
	string getype() { return type; }
	void settype(string s) { type = s; }
	double getprice() { return price; }
	
};



class StorageDevice
{
	string type;
	int capacity;
	double price;

public:
	StorageDevice()
	{
		cout << "\nenter the type of Storage Device (HDD,SSD,NVMe) : ";
		cin >> type;
		while (type != "hdd" && type != "ssd" && type != "nvme")
		{
			cout << "\nentered the wrong input...... enter the input again of following : ";
			cout << "\nenter the type of Storage Device (HDD,SSD,NVMe) : ";
			cin >> type;

		}
		cout << "\nenter the capacity of Storage : ";
		cin >> capacity;
		while ((capacity & (capacity - 1)) != 0)
		{
			cout << "\nentered the wrong input...... enter the input again of following : ";
			cout << "\nenter the capacity in power of 2: ";
			cin >> capacity;

		}
		if (type == "SSD" || type == "ssd" || type == "Ssd")
			price = capacity * 0.2;
		else if (type == "NVMe" || type == "NVME" || type == "nvme")
			price = capacity * 0.4;
		else
			price = capacity * 0.1;

		cout << " \nstorage device added !";
	}
	StorageDevice(int n , string t)
	{

		while (t != "hdd" && t != "ssd" && t != "nvme")
		{
			cout << "\nentered the wrong input...... enter the input again of following : ";
			cout << "\nenter the type of Storage Device (HDD,SSD,NVMe) : ";
			cin >> t;

		}
		while ((n & (n - 1)) != 0)
		{
			cout << "\nentered the wrong input...... enter the input again of following : ";
			cout << "\nenter the type of Storage Device (HDD,SSD,NVMe) : ";
			cin >> n;

		}
		type = t;
		capacity = n;
		if (type == "SSD" || type == "ssd" || type == "Ssd")
			price = capacity * 0.2;
		else if (type == "NVMe" || type == "NVME" || type == "nvme")
			price = capacity * 0.4;
		else
			price = capacity * 0.1;

		cout << " \nstorage device added !";
	}
	StorageDevice(StorageDevice& copy)
	{
		capacity = copy.capacity;
		type = copy.type;
		price = copy.price;
	}
	string getType() { return type; }
	int getCap() { return capacity; }
	double getPrice() { return price; }
	void setType(string x) { type = x; }
	void setCap(int x) { capacity = x; }

};

class Battery {
	int capacity;
	double price;
public:
	Battery(Battery& copy)
	{
		capacity = copy.capacity;
		price = copy.price;
	}
	Battery()
	{
		cout << "\nenter the capacity of battery : ";
		cin >> capacity;
		while (capacity < 1 || capacity >= 4000)
		{
			cout << "invalid input ...... should be in under 4000";
			cout << "\nenter the capacity of battery : ";
			cin >> capacity;
		}
		price = capacity * 0.02;
	}
	int getCap() { return capacity; }
	void setCap(int cap) { capacity = cap; }
	double getPrice() { return price; }
};
class PowerSupply {
	int wattage;
	string efficiency;
	double price;

public:
	PowerSupply()
	{

		cout << "\nenter the wattage required : ";
		cin >> wattage;
		while (wattage < 60 || wattage > 200)
		{
			cout << "invalid input..... should be in range of 60--200";
			cout << "\nenter the wattage required : ";
			cin >> wattage;
		}

		cout << "\nenter the efficiency (1-Gold or 2-Silver) :";
		cin >> efficiency;
		while (efficiency != "gold" && efficiency != "silver")
		{
			cout << "invalid input..... should be gold or silver";
			cout << "\nenter the efficiency (1-Gold or 2-Silver) :";
			cin >> efficiency;
		}

		price = wattage * 2;
		if (efficiency == "gold")
			price += 20;
		cout << "\npower supply added successfully!";
	}
	PowerSupply(int w , string e)
	{

		while (w < 60 || w > 200)
		{
			cout << "invalid input..... should be in range of 60--200";
			cout << "\nenter the wattage required : ";
			cin >> w;
		}
		while (e != "gold" || e != "silver")
		{
			cout << "invalid input..... should be gold or silver";
			cout << "\nenter the efficiency (1-Gold or 2-Silver) :";
			cin >> e;
		}
		efficiency = e;
		wattage = w;
		price = wattage * 2;
		if (efficiency == "gold")
			price += 20;
		cout << "\npower supply added successfully!";
	}
	PowerSupply(PowerSupply& copy)
	{
		wattage = copy.wattage;
		efficiency = copy.efficiency;
		price = copy.price;
	}
	int getWatt() { return wattage; }
	void setWatt(int w) { wattage = w; }
	double getPrice() { return price; }
	string getEffic() { return efficiency; }
	void setEffic(string n) { efficiency = n; }

};

class Case {
	string formFactor;
	string color;
	double price;
public:
	Case(string f = "ATX", string c = "black")
	{
		cout << "enter colour of the case : ";
		cin >> color;
		cout << "enter form fact : \n\t1-ATX\n\t2-MicroATX";
		cin >> formFactor;
		while(formFactor != "atx" && formFactor != "microatx" && formFactor != "desktop" && formFactor != "tower" )
		if (formFactor == "microatx")
			price = 50;
		else
			price = 100;

		cout << "case allotted";
	}

	Case(Case& copy)
	{
		formFactor = copy.formFactor;
		color = copy.color;
		price = copy.price;

	}

	// Getters
	string getFormFactor() const { return formFactor; }
	string getColor() const { return color; }
	double getPrice() const { return price; }

	// Setters
	void setFormFactor(const string& f) { formFactor = f; }
	void setColor(const string& c) { color = c; }
	void setPrice(double p) { price = p; }

};

class Graphics {
private:
	string brand;
	int size;
	double price;

public:
	// Default constructor
	Graphics() : brand(""), size(0), price(0) {
		cout << "\nEnter the brand of Graphics: ";
		cin >> brand;
		/*if (i == 3 || i == 4)
		{
			while (brand != "nvidia" || brand != "amd")
			{
				cout << "invalid input for windows .....enter the input again";
				cout << "\nEnter the brand of Graphics: ";
				cin >> brand;
			}
		}
		if (i == 1 || i == 2)
		{
			while (brand != "applegpu")
			{
				cout << "invalid input for apple silicon .....enter the input again";
				cout << "\nEnter the brand of Graphics: ";
				cin >> brand;
			}
		}*/

		cout << "\nEnter the size of Graphics in GBs: ";
		cin >> size;
		while ((size & (size - 1)) != 0)
		{
			cout << "\nwrong input.....enter in power of 2 : ";
			cout << "\nEnter the size of Graphics in GBs: ";
			cin >> size;

		}
		price = size * 200;
		cout << "\nGraphics added\n";
	}

	//parametrized constructor
	Graphics(string b,int s) : brand(""), size(0){
		

		while ((s & (s - 1)) != 0)
		{
			cout << "\nwrong input.....enter in power of 2 : ";
			cout << "\nEnter the size of Graphics in GBs: ";
			cin >> s;

		}
		size = s;
		brand = b;
		price = size * 200;
		cout << "\nGraphics added\n";
	}

	// Copy constructor
	Graphics(const Graphics& copy) : brand(copy.brand), size(copy.size), price(copy.price) {
		cout << "\nGraphics added\n";
	}

	// Getters
	string getBrand() const { return brand; }
	int getSize() const { return size; }
	double getPrice() const { return price; }

	// Setters
	void setBrand(const string& b) { brand = b; }
	void setSize(int s) { size = s; price = size * 200; }
	void setPrice(double p) { price = p; }
};




class ALU {
private:
	int NoOfAdders;
	int NoOfSubtractors;
	int NoOfRegisters;
	int SizeOfRegisters;

public:
	// Default constructor
	ALU() : NoOfAdders(0), NoOfSubtractors(0), NoOfRegisters(0), SizeOfRegisters(0) 
	{
		cout << "\nenter number of adders : ";
		cin >> NoOfAdders;
		while ((NoOfAdders & (NoOfAdders - 1)) != 0)
		{
			cout << "\nwrong input.....enter in power of 2 : ";
			cout << "\nEnter the number of adders :: ";
			cin >> NoOfAdders;

		}
		cout << "\nenter number of subtractors : ";
		cin >> NoOfSubtractors;
		while ((NoOfSubtractors & (NoOfSubtractors - 1)) != 0)
		{
			cout << "\nwrong input.....enter in power of 2 : ";
			cout << "\nEnter the number of subtractors :: ";
			cin >> NoOfSubtractors;

		}
		cout << "\nenter number of Number of Registers : ";
		cin >> NoOfRegisters;
		while ((NoOfRegisters & (NoOfRegisters - 1)) != 0)
		{
			cout << "\nwrong input.....enter in power of 2 : ";
			cout << "\nEnter the number of registers :: ";
			cin >> NoOfRegisters;

		}
		cout << "\nenter number of size of Registers : ";
		cin >> SizeOfRegisters;
		while ((SizeOfRegisters & (SizeOfRegisters - 1)) != 0)
		{
			cout << "\nwrong input.....enter in power of 2 : ";
			cout << "\nEnter the size of registers :: ";
			cin >> SizeOfRegisters;

		}
	}
			
	// Parameterized constructor
	ALU(int adders, int subtractors, int registers, int size): NoOfAdders(adders), NoOfSubtractors(subtractors),NoOfRegisters(registers), SizeOfRegisters(size)
	{
		while ((NoOfAdders & (NoOfAdders - 1)) != 0)
		{
			cout << "\nwrong input.....enter in power of 2 : ";
			cout << "\nEnter the number of adders :: ";
			cin >> NoOfAdders;

		}
		while ((NoOfSubtractors & (NoOfSubtractors - 1)) != 0)
		{
			cout << "\nwrong input.....enter in power of 2 : ";
			cout << "\nEnter the number of subtractors :: ";
			cin >> NoOfSubtractors;

		}
		while ((NoOfRegisters & (NoOfRegisters - 1)) != 0)
		{
			cout << "\nwrong input.....enter in power of 2 : ";
			cout << "\nEnter the number of registers :: ";
			cin >> NoOfRegisters;

		}
		while ((SizeOfRegisters & (SizeOfRegisters - 1)) != 0)
		{
			cout << "\nwrong input.....enter in power of 2 : ";
			cout << "\nEnter the size of registers :: ";
			cin >> SizeOfRegisters;

		}
	}


	// Getters
	int getNoOfAdders() const { return NoOfAdders; }
	int getNoOfSubtractors() const { return NoOfSubtractors; }
	int getNoOfRegisters() const { return NoOfRegisters; }
	int getSizeOfRegisters() const { return SizeOfRegisters; }

	// Setters
	void setNoOfAdders(int adders) { NoOfAdders = adders; }
	void setNoOfSubtractors(int subtractors) { NoOfSubtractors = subtractors; }
	void setNoOfRegisters(int registers) { NoOfRegisters = registers; }
	void setSizeOfRegisters(int size) { SizeOfRegisters = size; }
};

class ControlUnit {
private:
	float Clock;

public:
	// Default constructor
	ControlUnit() : Clock(0.0)
	{
		cout << "\nenter ClockSpeed : ";
		cin >> Clock;
		while (Clock <= 0)
		{
			cout << "\ninvalid input enter the input again : ";
			cout << "\nenter ClockSpeed : ";
			cin >> Clock;

		}
		cout << "\ncloack generated";
	}

	// Parameterized constructor
	ControlUnit(float clock) : Clock(clock) 
	{
		while (Clock <= 0)
		{
			cout << "\ninvalid input enter the input again : ";
			cout << "\nenter ClockSpeed : ";
			cin >> Clock;

		}
		cout << "\ncloack generated";

	}

	// Getter for Clock
	float getClock() const { return Clock; }

	// Setter for Clock
	void setClock(float clock) { Clock = clock; }
};
class MotherBoard {
	Port* ports;
	NetworkCard* Ncard;
	MainMemory* mm;
	StorageDevice* SD;
	int no_Of_Ports;
	double price;

public:

	
	MotherBoard()
	{

		cout << "\nenter the number of Ports : ";
		cin >> no_Of_Ports;
		while (no_Of_Ports < 1 || no_Of_Ports > 10)
		{
			cout << "invalid input enter the input again";

			cout << "\nenter the number of Ports : ";
			cin >> no_Of_Ports;
		}
		ports = new Port[no_Of_Ports];
		mm = nullptr;
		SD = nullptr;
		Ncard = nullptr;
		cout << "\nmotherBoard added without Memory and Storage : ";
	}
	MotherBoard(const MotherBoard& copy)
	{
		no_Of_Ports = (copy.no_Of_Ports);
		Ncard = (copy.Ncard);
		mm = copy.mm;
		SD = copy.SD;
		ports = new Port[no_Of_Ports];
		for (int i = 0; i < no_Of_Ports; ++i) {
			ports[i] = copy.ports[i];
		}
	}
	~MotherBoard() {
		delete mm;
		delete SD;
		delete[] ports;
		delete Ncard;
	}
	int getNoOfPorts() { return no_Of_Ports; }
	Port* getPorts() { return ports; }
	NetworkCard* getNetworkCard() { return Ncard; }

	void setNetworkCard(NetworkCard* card) { Ncard = card; cout << "\nNetworkCard added successfully!"; }

	// Getter and setter for MainMemory
	MainMemory* getMainMemory() const { return mm; }

	void setMainMemory(MainMemory* memory) { mm = memory; cout << "\nmemory added successfully!"; }

	// Getter and setter for StorageDevice
	StorageDevice* getStorageDevice() const { return SD; }

	void setStorageDevice(StorageDevice* device) { SD = device; cout << "\nstorage added successfully!"; }

	double getPrice()
	{
		price += mm->getPrice() + SD->getPrice() + Ncard->getprice();
		for (int i = 0; i < no_Of_Ports; i++)
			price += ports[i].getPrice();
		return price;
	}

};


class CPU {
private:
	ControlUnit CU;
	ALU alu;


public:
	CPU() 
	{
		cout << "CPU added";
	}
	CPU(const ControlUnit& cu, const ALU& alu) : CU(cu), alu(alu) {}

	const ControlUnit& getCU() const { return CU; }
	void setCU(const ControlUnit& cu) { CU = cu; }

	const ALU& getALU() const { return alu; }
	void setALU(const ALU& alu) { this->alu = alu; }
};
class ComputorAssembly {
	double price;
	MotherBoard* MB;

public:
	double getPrice()
	{
		
		return price;
	}
	// Constructor
	ComputorAssembly() : price(0.0), MB(nullptr) {}

	// Destructor
	~ComputorAssembly() {
		delete MB;
	}

	// Getter for MotherBoard
	MotherBoard* getMotherBoard() {
		return MB;
	}

	// Setter for MotherBoard
	void setMotherBoard(MotherBoard* mb) {
		MB = mb;
		cout << "\nmother board added with components!";
	}
};
class PhysicalMemory {
	int capacity;
	int price;
public:
	PhysicalMemory()
	{
		cout << "\nenter the capacity of RAM : ";
		cin >> capacity;
		while ((capacity & (capacity - 1)) != 0 || capacity <0)
		{
			cout << "\nenter in power of 2 : ";
			cout << "\nenter the capacity of RAM : ";
			cin >> capacity;

		}
		price = capacity * 30;
		cout << "\nmemory added ";
	}
	int getCapacity() const { return capacity; }

	// Setter for capacity
	void setCapacity(int cap) {
		capacity = cap;
		price = capacity * 30; // Update price based on new capacity
	}

	// Getter for price
	int getPrice() const { return price; }
};

class LpddrApple : public PhysicalMemory {

};

class DdrWindows : public PhysicalMemory {

};

class IntelX86 : public CPU {
private:
	std::string name;
	double price;

public:
	IntelX86() : CPU(), name(""), price(0.0) 
	{
		cout << "\nenter the name of CPU (Intel or AMD) : ";
		cin >> name;
		while (name != "intel" && name != "amd")
		{
			cout << "\n invalid input;";
			cout << "\nenter the name of CPU (Intel or AMD) : ";
			cin >> name;

		}
		if(name == "intel")
			price = 30.0 + CPU::getCU().getClock()*140 + CPU::getALU().getNoOfAdders() * 0.01 + CPU::getALU().getNoOfSubtractors() * 0.01 + CPU::getALU().getNoOfRegisters() * CPU::getALU().getSizeOfRegisters() * 0.02;
		else
			price = 10.0 + CPU::getCU().getClock() * 140 + CPU::getALU().getNoOfAdders() * 0.01 + CPU::getALU().getNoOfSubtractors() * 0.01 + CPU::getALU().getNoOfRegisters() * CPU::getALU().getSizeOfRegisters() * 0.02;

		cout << "\n CPU added !";
	}
	IntelX86(string& name, double price) : name(name), price(price) {}

	string& getName() { return name; }
	void setName(string& name) { this->name = name; }

	double getPrice() { return price; }
};

class AppleARM : public CPU {
private:
	std::string name;
	double price;
	Graphics Agpu;
public:
	AppleARM() : CPU(), name(""), price(0.0), Agpu() 
	{
		
			cout << "\nenter the name of CPU (Core m1,m2,m3 or m4) : ";
			cin >> name;
			while (name[0] != 'm' && name[0] != 'M')
			{
				cout << "\ninvalid input :";
				cout << "\nenter the name of CPU (Core m1,m2,m3 or m4) : ";
				cin >> name;

			}
			price = 60.0 + CPU::getCU().getClock() * 140 + CPU::getALU().getNoOfAdders() * 0.01 + CPU::getALU().getNoOfSubtractors() * 0.01 + CPU::getALU().getNoOfRegisters() * CPU::getALU().getSizeOfRegisters() * 0.02;

			cout << "\n CPU added !";
		

	}
	AppleARM(const string& name, double price, const Graphics& agpu) :name(name), Agpu(agpu) {}

	const std::string& getName() const { return name; }
	void setName(const std::string& name) { this->name = name; }

	double getPrice() const { return price; }
	void setPrice(double price) { this->price = price; }

	const Graphics& getAgpu() const { return Agpu; }
	void setAgpu(const Graphics& agpu) { Agpu = agpu; }
};


class Mac : public ComputorAssembly {
	LpddrApple mem;
	AppleARM appleSilicon;

public:
	Mac() 
	{
		cout << "\n computor of type MAC is creating : ";
	}

	// Destructor
	~Mac() {}

	// Getter and setter for mem
	LpddrApple& getMem()  { return mem; }
	void setMem(const LpddrApple& m) { mem = m; }

	// Getter and setter for appleSilicon
	const AppleARM& getAppleSilicon() const { return appleSilicon; }
	void setAppleSilicon(const AppleARM& a) { appleSilicon = a; }
};


class Windows : public ComputorAssembly {
private:
	IntelX86 intel;
	DdrWindows storage;
	Graphics* GPU;

public:
	// Constructor
	Windows() : GPU(nullptr) 
	{
		cout << "\ncomputor of type windows is creating !";
	}

	// Destructor
	~Windows() {
		delete GPU;
	}

	// Getter and setter for intel
	IntelX86& getIntel() { return intel; }
	void setIntel(const IntelX86& i) { intel = i; }

	// Getter and setter for storage
	 DdrWindows& getStorage() { return storage; }
	void setStorage(const DdrWindows& s) { storage = s; }

	// Getter and setter for GPU
	 Graphics* getGPU()  { return GPU; }
	void setGPU(Graphics* g) { GPU = g; }

	// Other member functions as needed
};







class MacPC : public Mac {
private:
	Case* casing;
	PowerSupply supply;

public:
	// Default constructor
	MacPC() : casing(nullptr) 
	{
		cout << "\nMac pc created successfully";
	}

	// Getters
	Case* getCasing() const { return casing; }
	const PowerSupply& getSupply() const { return supply; }

	// Setters
	void setCasing(Case* c) { casing = c; }
	void setSupply(const PowerSupply& ps) { supply = ps; }

	void display() {
		cout << "----------------price of each component----------------\n";
		cout << "\tcase :\n\t" << "color: " << casing->getColor()<< "\tform factor: " << casing->getFormFactor() << "\tprice : " << casing->getPrice() << "\n";
		cout << "\tcharger :\n\t" << "wattage: " << supply.getWatt() << "\tefficiency: " << supply.getEffic() << "\tprice: " << supply.getPrice() << "\n";
		cout << "\tCPU :\n\t" << "name: " << getAppleSilicon().getName() << "\tprice: " << getAppleSilicon().getPrice() << "\n";
		cout << "\tGPU :\n\t" << "size: " << getAppleSilicon().getAgpu().getSize() << "\tprice: " << getAppleSilicon().getAgpu().getPrice() << "\n";
		cout << "\tcase :\n\t\t price: " << 0 << "\n";
		cout << "\tPhysical memory:\n\tcapacity: " << getMem().getCapacity() << "\tprice: " << getMem().getPrice() << '\n';
		cout << "\tstorage device:\n\ttype: " << getMotherBoard()->getStorageDevice()->getType() << "\tcapacity: " << getMotherBoard()->getStorageDevice()->getCap() << "\tprice: " << getMotherBoard()->getStorageDevice()->getPrice() << '\n';
		cout << "\tNetworkCard:\n\t type: " << getMotherBoard()->getNetworkCard()->getype() << "\tspeed: " << getMotherBoard()->getNetworkCard()->getSpeed() << "\tprice: " << getMotherBoard()->getNetworkCard()->getprice() << '\n';
		cout << "\tports:\n ";
		for (int i = 0; i < getMotherBoard()->getNoOfPorts(); i++)
		{
			cout << "port " << i << " type: " << getMotherBoard()->getPorts()[i].GetType() << "\tbaud rate: " << getMotherBoard()->getPorts()[i].GetBaud_Rate() << "\tprice: " << getMotherBoard()->getPorts()[i].getPrice() << '\n';
		}
		cout << "\tMainMemory:\n\t type: " << getMotherBoard()->getMainMemory()->GetTechType() << "\tcapacity: " << getMotherBoard()->getMainMemory()->GetCapacity() << "\tprice: " << getMotherBoard()->getMainMemory()->getPrice() << '\n';
		cout << "\tmother board combined price:\n\t\t price: " << getMotherBoard()->getPrice() << '\n';


	}
};


class WindowsPC : public Windows{
private:
	Case* casing;
	PowerSupply supply;

public:
	// Default constructor
	WindowsPC() : casing(nullptr) 
	{
		
			cout << "\nWindows pc created successfully";
		
	}
	~WindowsPC() {
		if (casing != nullptr)
			delete casing;
	}
	// Getters
	Case* getCasing() const { return casing; }
	const PowerSupply& getSupply() const { return supply; }

	// Setters
	
	void setSupply(const PowerSupply& ps) { supply = ps; }
	void setCasing(Case* c) {
		if (casing != nullptr) {
			delete casing;
		}
		casing = c;
	}
	void display() {
		cout << "----------------price of each component----------------\n";
		cout << "\tcase :\n\t" << "color: " << casing->getColor() << "\tform factor: " << casing->getFormFactor() << "\tprice : " << casing->getPrice() << "\n";
		cout << "\tcharger :\n\t" << "wattage: " << supply.getWatt() << "\tefficiency: " << supply.getEffic() << "\tprice: " << supply.getPrice() << "\n";
		cout << "\tCPU :\n\t" << "name: " << getIntel().getName() << "\tprice: " << getIntel().getPrice() << "\n";
		cout << "\tGPU :\n\t" << "brand:  " << getGPU()->getBrand() << "\tsize: " << getGPU()->getSize() << "\tprice: " << getGPU()->getPrice() << "\n";
		cout << "\tcase :\n\t\t price: " << 0 << "\n";
		cout << "\tPhysical memory:\n\tcapacity: " << getStorage().getCapacity() << "\tprice: " << getStorage().getPrice() << '\n';
		cout << "\tstorage device:\n\ttype: " << getMotherBoard()->getStorageDevice()->getType() << "\tcapacity: " << getMotherBoard()->getStorageDevice()->getCap() << "\tprice: " << getMotherBoard()->getStorageDevice()->getPrice() << '\n';
		cout << "\tNetworkCard:\n\t type: " << getMotherBoard()->getNetworkCard()->getype() << "\tspeed: " << getMotherBoard()->getNetworkCard()->getSpeed() << "\tprice: " << getMotherBoard()->getNetworkCard()->getprice() << '\n';
		cout << "\tports:\n ";
		for (int i = 0; i < getMotherBoard()->getNoOfPorts(); i++)
		{
			cout << "port " << i << " type: " << getMotherBoard()->getPorts()[i].GetType() << "\tbaud rate: " << getMotherBoard()->getPorts()[i].GetBaud_Rate() << "\tprice: " << getMotherBoard()->getPorts()[i].getPrice() << '\n';
		}
		cout << "\tMainMemory:\n\t type: " << getMotherBoard()->getMainMemory()->GetTechType() << "\tcapacity: " << getMotherBoard()->getMainMemory()->GetCapacity() << "\tprice: " << getMotherBoard()->getMainMemory()->getPrice() << '\n';
		cout << "\tmother board combined price:\n\t\t price: " << getMotherBoard()->getPrice() << '\n';


	}
};

// WindowsLaptop class
class WindowsLaptop : public Windows {
private:
	Battery* battery;
	PowerSupply* charger;

public:
	// Default constructor
	WindowsLaptop() : battery(nullptr), charger(nullptr) 
	{
		cout << "\nWindows laptop created successfully";
	}

	// Getters
	Battery* getBattery() const { return battery; }
	PowerSupply* getCharger() const { return charger; }

	// Setters
	void setBattery(Battery* b) { battery = b; }
	void setCharger(PowerSupply* ps) { charger = ps; }
	void display() {
		cout << "----------------price of each component----------------\n";
		cout << "\tbattery :\n\t" << "capacity: " << battery->getCap() << "\tprice : " << battery->getPrice() << "\n";
		cout << "\tcharger :\n\t" << "wattage: " << charger->getWatt() << "\tefficiency: " << charger->getEffic() << "\tprice: " << charger->getPrice() << "\n";
		cout << "\tCPU :\n\t" << "name: " << getIntel().getName() << "\tprice: " << getIntel().getPrice() << "\n";
		cout << "\tGPU :\n\t" << "brand:  " << getGPU()->getBrand() << "\tsize: " << getGPU()->getSize() << "\tprice: " << getGPU()->getPrice() << "\n";
		cout << "\tcase :\n\t\t price: " << 0 << "\n";
		cout << "\tPhysical memory:\n\tcapacity: " << getStorage().getCapacity() << "\tprice: " << getStorage().getPrice() << '\n';
		cout << "\tstorage device:\n\ttype: " << getMotherBoard()->getStorageDevice()->getType() << "\tcapacity: " << getMotherBoard()->getStorageDevice()->getCap() << "\tprice: " << getMotherBoard()->getStorageDevice()->getPrice() << '\n';
		cout << "\tNetworkCard:\n\t type: " << getMotherBoard()->getNetworkCard()->getype() << "\tspeed: " << getMotherBoard()->getNetworkCard()->getSpeed() << "\tprice: " << getMotherBoard()->getNetworkCard()->getprice() << '\n';
		cout << "\tports:\n ";
		for (int i = 0; i < getMotherBoard()->getNoOfPorts(); i++)
		{
			cout << "port " << i << " type: " << getMotherBoard()->getPorts()[i].GetType() << "\tbaud rate: " << getMotherBoard()->getPorts()[i].GetBaud_Rate() << "\tprice: " << getMotherBoard()->getPorts()[i].getPrice() << '\n';
		}
		cout << "\tMainMemory:\n\t type: " << getMotherBoard()->getMainMemory()->GetTechType() << "\tcapacity: " << getMotherBoard()->getMainMemory()->GetCapacity() << "\tprice: " << getMotherBoard()->getMainMemory()->getPrice() << '\n';
		cout << "\tmother board combined price:\n\t\t price: " << getMotherBoard()->getPrice() << '\n';


	}
};

// MacLaptop class
class MacLaptop : public Mac {
private:
	Battery* battery;
	PowerSupply* charger;

public:
	// Default constructor
	MacLaptop() : battery(nullptr), charger(nullptr)
	{
		cout << "\nMac Laptop created successfully";
	}

	// Getters
	Battery* getBattery() const { return battery; }
	PowerSupply* getCharger() const { return charger; }

	// Setters
	void setBattery(Battery* b) { battery = b; }
	void setCharger(PowerSupply* ps) { charger = ps; }
	void display() {
		cout << "----------------price of each component----------------\n";
		cout << "\tbattery :\n\t" << "capacity: " << battery->getCap() << "\tprice : " << battery->getPrice() << "\n";
		cout << "\tcharger :\n\t" << "wattage: " << charger->getWatt()<< "\tefficiency: " << charger->getEffic() << "\tprice: " << charger->getPrice() << "\n";
		cout << "\tCPU :\n\t" << "name: " << getAppleSilicon().getName() << "\tprice: " << getAppleSilicon().getPrice() << "\n";
		cout << "\tGPU :\n\t" << "size: " << getAppleSilicon().getAgpu().getSize()<< "\tprice: " << getAppleSilicon().getAgpu().getPrice() << "\n";
		cout << "\tcase :\n\t\t price: " << 0 << "\n";
		cout << "\tPhysical memory:\n\tcapacity: "<< getMem().getCapacity()<< "\tprice: " << getMem().getPrice() << '\n';
		cout << "\tstorage device:\n\ttype: " << getMotherBoard()->getStorageDevice()->getType()<< "\tcapacity: " << getMotherBoard()->getStorageDevice()->getCap() << "\tprice: " << getMotherBoard()->getStorageDevice()->getPrice() << '\n';
		cout << "\tNetworkCard:\n\t type: " << getMotherBoard()->getNetworkCard()->getype()<< "\tspeed: " << getMotherBoard()->getNetworkCard()->getSpeed() << "\tprice: " << getMotherBoard()->getNetworkCard() ->getprice()<< '\n';
		cout << "\tports:\n ";
		for (int i = 0; i < getMotherBoard()->getNoOfPorts(); i++)
		{
			cout << "port " << i << " type: " << getMotherBoard()->getPorts()[i].GetType() << "\tbaud rate: " << getMotherBoard()->getPorts()[i].GetBaud_Rate() << "\tprice: " << getMotherBoard()->getPorts()[i].getPrice() << '\n';
		}
		cout << "\tMainMemory:\n\t type: " << getMotherBoard()->getMainMemory()->GetTechType() << "\tcapacity: " << getMotherBoard()->getMainMemory()->GetCapacity() << "\tprice: " << getMotherBoard()->getMainMemory()->getPrice() << '\n';
		cout << "\tmother board combined price:\n\t\t price: " << getMotherBoard()->getPrice() << '\n';


	}
};



