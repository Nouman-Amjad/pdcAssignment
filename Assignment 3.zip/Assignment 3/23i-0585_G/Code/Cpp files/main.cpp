#include<iostream>
#include"MAC.h"
#include"PC.h"
//Muhammad Usman Al Haq
//G
//23i-0585
//Shehreyar Rashid
//Muhammad Nouman Amjad
int main()
{
	PC pc;
	cout << "------------------------------------------\nSpecifications Of Your PC:-  \n";
	pc.printSpecs();
	return 0;
}